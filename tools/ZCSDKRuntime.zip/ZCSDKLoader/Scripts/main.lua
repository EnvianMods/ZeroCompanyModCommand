-- ZCSDKLoader v1.2 — runtime loader for Zero Company SDK content mods (pairs with the ZCSDKBridge C++ mod).
--
-- What it does, once the main-menu world is up:
--   1. arms the bridge (writes the PrintString trigger address to ue4ss/ZCSDKBridge.ctl),
--   2. discovers content-mod manifests  <Mod>.zcsdk.lua  in Content/Paks and Content/Paks/~mods,
--   3. ROUTE B: injects each mod's <Mod>.AssetRegistry.bin into the live asset registry (enumeration),
--   3b. preloads each manifest's `preload` packages (net-new classes resident like the game's own; 1.2.0),
--   3c. rescans each manifest's `primaryTypes` and refreshes the game's per-type caches (1.1.0),
--   4. when a campaign HQ inventory exists, grants each manifest's `grants` items ONCE per save
--      (skipped if the save has ever owned the item), so net-new items show up in the armory/inventory.
--
-- Manifest (emitted by zcmod-build.js next to the pak trio):
--   return { name = "My Mod", version = "1.0.0", registry = "MyMod.AssetRegistry.bin",
--            primaryTypes = { { type = "CustomizationPartDefinition", path = "/Game/ZCSDK", class = "...", blueprintClasses = false } },
--            preload = { "/Game/ZCSDK/GA_MyPassive" },
--            grants = { { item = "/Game/ZCSDK/DA_X.DA_X", amount = 1 } } }
-- Log: ue4ss/ZCSDKLoader.log. Bridge log: ue4ss/ZCSDKBridge.log.
local UEHelpers = require("UEHelpers")

-- SDK dev builds only: also dump item properties (the real scope mod + ours) for schema comparison.
-- Leave OFF for players: reading a TSoftObjectPtr property of a freshly loaded net-new item through
-- UE4SS's Lua binding crashed the game (null deref inside UE4SS.dll, 2026-09-04) — soft props are now
-- skipped in dumpObject, but the dump is diagnostics, not a feature.
local DIAG = false

-- ---- paths (relative to the game's Binaries/Win64; the bridge resolves $paks / $mods itself) ----
local function detectWin64()
    local ok, p = pcall(function() local h = io.popen("cd"); local d = h:read("*l"); h:close(); return d end)
    if ok and p and p ~= "" then
        p = p:gsub("\\", "/")
        local f = io.open(p .. "/ue4ss/UE4SS-settings.ini", "r"); if f then f:close(); return p end
    end
    return "G:/SteamLibrary/steamapps/common/Star Wars Zero Company/SWZeroCompany/Binaries/Win64"
end
local WIN64 = detectWin64()
local UE4SS = WIN64 .. "/ue4ss/"
local LOGFILE = UE4SS .. "ZCSDKLoader.log"

local function log(m)
    local line = "[ZCSDKLoader] " .. tostring(m); print(line .. "\n")
    local f = io.open(LOGFILE, "a"); if f then f:write(os.date("%H:%M:%S ") .. line .. "\n"); f:close() end
end
local function bridge(cmd)
    log("BRIDGE> " .. cmd)
    local ok, err = pcall(function()
        UEHelpers.GetKismetSystemLibrary():PrintString(UEHelpers.GetWorld(), cmd, false, false, {R=1,G=1,B=1,A=1}, 0.0, FName("None"))
    end)
    if not ok then log("bridge call failed: " .. tostring(err)) end
end
local function setTrigger()
    local fn = StaticFindObject("/Script/Engine.KismetSystemLibrary:PrintString")
    if not (fn and fn:IsValid()) then log("PrintString UFunction not found"); return false end
    local f = io.open(UE4SS .. "ZCSDKBridge.ctl", "w"); if not f then log("cannot write ZCSDKBridge.ctl"); return false end
    f:write(string.format("trigger=%x\n", fn:GetAddress())); f:close()
    log(string.format("trigger @ 0x%x", fn:GetAddress()))
    return true
end
local function readLines(path)
    local out = {}
    local f = io.open(path, "r"); if not f then return out end
    for line in f:lines() do line = line:gsub("^\239\187\191", ""):gsub("[\r\n]+$", ""); if line ~= "" then out[#out + 1] = line end end
    f:close(); return out
end
local function dirOf(p) return (p:match("^(.*)/[^/]*$")) or "." end

-- ---- diagnostics: dump every reflected property of an object (class chain), one level into arrays/objects ----
local function fmtValue(v, depth)
    if type(v) ~= "userdata" then return tostring(v) end
    local ok, s
    ok, s = pcall(function() return v:GetFullName() end); if ok and type(s) == "string" then return s end
    ok, s = pcall(function() return v:ToString() end); if ok and type(s) == "string" then return s end
    if depth < 1 then
        local items = {}
        local okArr = pcall(function() v:ForEach(function(i, e)
            local ev = e; pcall(function() ev = e:get() end)
            items[#items + 1] = fmtValue(ev, depth + 1)
        end) end)
        if okArr and #items > 0 then return "[" .. table.concat(items, ", ") .. "]" end
        local okTags = pcall(function() v.GameplayTags:ForEach(function(i, e)
            local t = e:get(); items[#items + 1] = t.TagName:ToString()
        end) end)
        if okTags and #items > 0 then return "{tags: " .. table.concat(items, ", ") .. "}" end
    end
    return "<" .. tostring(v) .. ">"
end
local function dumpObject(obj, label, depth)
    depth = depth or 0
    local okc, cls = pcall(function() return obj:GetClass() end)
    if not okc or not cls or not cls:IsValid() then log(label .. ": no class"); return end
    log(label .. "  class=" .. cls:GetFullName() .. "  obj=" .. obj:GetFullName())
    local c = cls
    local subobjects = {}
    while c and c:IsValid() do
        local okp, errp = pcall(function()
            c:ForEachProperty(function(prop)
                local name = prop:GetFName():ToString()
                local pcls = ""; pcall(function() pcls = prop:GetClass():GetFName():ToString() end)
                if pcls:find("Soft") then log(string.rep("  ", depth + 1) .. name .. " = <" .. pcls .. " skipped>"); return end
                local ok, v = pcall(function() return obj[name] end)
                local s = ok and fmtValue(v, 0) or ("<err " .. tostring(v) .. ">")
                log(string.rep("  ", depth + 1) .. name .. " = " .. s)
                if ok and depth == 0 and type(v) == "userdata" then
                    pcall(function() v:ForEach(function(i, e)
                        local ev = e; pcall(function() ev = e:get() end)
                        if type(ev) == "userdata" and pcall(function() return ev:GetClass() end) then subobjects[#subobjects + 1] = { ev, name .. "[" .. tostring(i) .. "]" } end
                    end) end)
                end
            end)
        end)
        if not okp then log("  (ForEachProperty failed on " .. tostring(c:GetFullName()) .. ": " .. tostring(errp) .. ")") end
        local oks, sup = pcall(function() return c:GetSuperStruct() end)
        c = oks and sup or nil
    end
    for _, so in ipairs(subobjects) do pcall(dumpObject, so[1], string.rep("  ", depth + 1) .. so[2], depth + 1) end
end

-- ---- manifests + registries ----
local manifests = {}   -- { path=, dir=, m=table }
local grants = {}      -- { item=, amount=, from=, done=bool }
local injected = false
local function discover()
    for _, root in ipairs({ "$paks", "$mods" }) do
        bridge("ZCSDK:scan|" .. root .. "|*.zcsdk.lua")
        for _, p in ipairs(readLines(UE4SS .. "ZCSDKBridge.scan")) do
            local ok, m = pcall(dofile, p)
            if ok and type(m) == "table" then
                manifests[#manifests + 1] = { path = p, dir = dirOf(p), m = m }
                log("manifest: " .. p .. "  (" .. tostring(m.name) .. " v" .. tostring(m.version) .. ")")
                for _, g in ipairs(m.grants or {}) do
                    if type(g.item) == "string" then grants[#grants + 1] = { item = g.item, amount = tonumber(g.amount) or 1, from = tostring(m.name), done = false } end
                end
            else
                log("manifest failed: " .. p .. " -> " .. tostring(m))
            end
        end
    end
    log(#manifests .. " manifest(s), " .. #grants .. " grant(s)")
end
local function injectRegistries()
    for _, mf in ipairs(manifests) do
        if type(mf.m.registry) == "string" then
            local reg = mf.m.registry:match("^%a:/") and mf.m.registry or (mf.dir .. "/" .. mf.m.registry)
            local probe = (mf.m.grants and mf.m.grants[1] and mf.m.grants[1].item) or ""
            bridge("ZCSDK:injreg|" .. reg .. "|" .. probe)
        end
    end
    injected = true
end
-- Preload (loader 1.2.0 / runtime 0.5): a manifest may list packages to LoadPackage right after the registries are injected —
--   preload = { "/Game/ZCSDK/GA_ZCSDK_LongStride", ... }
-- zcmod-build lists a mod's blueprints[] class packages. Why: the game's own ability classes are resident at startup (its preload
-- manifest), so systems that resolve a part's soft class refs and seed derived data in ONE pass (the Focus tree's allocation
-- seeding, ABrunoFocusCentral::RefreshFocusData) see every stock tier synchronously; a net-new class arrives through an async
-- soft-class load a moment later and the seed pass misses the tree (v1.11.0: the net-new specialization's passive row drew no nodes).
-- Resident classes make the mod's content behave like the game's.
local function preloadPackages()
    local n = 0
    for _, mf in ipairs(manifests) do
        for _, p in ipairs(mf.m.preload or {}) do
            if type(p) == "string" and p:sub(1, 1) == "/" then bridge("ZCSDK:loadpkg|" .. p); n = n + 1 end
        end
    end
    if n > 0 then log("preload requested for " .. n .. " package(s)") end
end
-- Primary-asset rescan: the asset manager built its primary-asset map at startup (ScanPathsForPrimaryAssets over the
-- registry); an injected registry does not update it. A manifest lists the primary asset types it ships —
--   primaryTypes = { { type = "CustomizationPartDefinition", path = "/Game/ZCSDK", class = "/Script/BitReactorCore.CustomizationPartDefinition" } }
-- and the bridge rescans that type over that path (the customization part picker, classes, missions... enumerate this way).
local function rescanPrimaryTypes()
    local n = 0
    for _, mf in ipairs(manifests) do
        for _, pt in ipairs(mf.m.primaryTypes or {}) do
            if type(pt.type) == "string" and type(pt.path) == "string" then
                bridge("ZCSDK:rescan|" .. pt.type .. "|" .. pt.path .. "|" .. tostring(pt.class or "") .. "|" .. tostring(pt.blueprintClasses and 1 or 0))
                n = n + 1
            end
        end
    end
    if n > 0 then log("primary-asset rescan requested for " .. n .. " type(s)") end
end
-- Per-type cache refreshers: the game keeps its own per-type caches built from the primary-asset list at startup; a
-- rescan alone does not reach them. Each entry names the subsystem object to find and the nullary native method the
-- bridge calls on it (`callthis`, bridge v0.4). Found via tools/recon/pdbsyms.py `calls`:
--   CustomizationPartDefinition -> UCustomizationPartsTagSubsystem (EngineSubsystem) caches a tag -> parts map that
--   UCustomizationStatics::GetCustomizationPartIds (the customizer's part picker) reads; BuildPartTagMaps() rebuilds it
--   (the same thing the game does on HandleAssetAdded / HandlePakFileMounted).
local REFRESHERS = {
    CustomizationPartDefinition = { { find = "CustomizationPartsTagSubsystem", sym = "?BuildPartTagMaps@UCustomizationPartsTagSubsystem@@AEAAXXZ" } },
}
local function refreshCaches()
    local done = {}
    for _, mf in ipairs(manifests) do
        for _, pt in ipairs(mf.m.primaryTypes or {}) do
            for _, r in ipairs(REFRESHERS[tostring(pt.type)] or {}) do
                local key = r.find .. r.sym
                if not done[key] then
                    done[key] = true
                    local ok, obj = pcall(FindFirstOf, r.find)
                    if ok and obj and obj:IsValid() then
                        bridge(string.format("ZCSDK:callthis|%s|%x", r.sym, obj:GetAddress()))
                        log("cache refresh: " .. r.find .. " -> " .. r.sym)
                    else
                        log("cache refresh: " .. r.find .. " not found (skipped " .. r.sym .. ")")
                    end
                end
            end
        end
    end
end

-- ---- grants: once per save, when an HQ inventory exists ----
local statics = nil
local function findHQ()
    local ok, hq = pcall(FindFirstOf, "BrunoHQInventory")
    if ok and hq and hq:IsValid() and not hq:GetFullName():find("Default__") then return hq end
    return nil
end
local function applyGrants()
    local pending = 0
    for _, g in ipairs(grants) do if not g.done then pending = pending + 1 end end
    if pending == 0 then return true end
    local hq = findHQ(); if not hq then return false end
    if not statics then
        local s = StaticFindObject("/Script/Bruno.Default__BrunoGameStatics")
        if s and s:IsValid() then statics = s else log("BrunoGameStatics CDO not found"); return false end
    end
    for _, g in ipairs(grants) do
        if not g.done then
            local item = StaticFindObject(g.item)
            if not (item and item:IsValid()) then
                log("grant: loading " .. g.item); pcall(LoadAsset, g.item)   -- registry-resolved (works after injection); async -> retry next tick
                local pkg = g.item:match("^(.-)%.[^%.]+$"); if pkg then bridge("ZCSDK:loadpkg|" .. pkg) end
            else
                local okH, owned = pcall(function() return hq:HasEverOwnedItem(item) end)
                if okH and owned then
                    log("grant: " .. g.item .. " already owned by this save (skip)")
                else
                    local okG, err = pcall(function() statics:GrantItem(hq, item, g.amount) end)
                    log("grant: " .. g.item .. " x" .. g.amount .. " (" .. g.from .. ") -> " .. (okG and "GRANTED" or ("failed: " .. tostring(err))))
                    if DIAG and okG then pcall(dumpObject, item, "granted item") end
                end
                g.done = true
            end
        end
    end
    return false
end

-- ---- sequencing ----
local steps = {}
local function addStep(d, fn) steps[#steps + 1] = { delay = d, fn = fn } end
local function runSteps(i)
    local s = steps[i]; if not s then return end
    ExecuteInGameThread(function()
        local ok, err = pcall(s.fn); if not ok then log("STEP ERROR: " .. tostring(err)) end
        ExecuteWithDelay(s.delay, function() runSteps(i + 1) end)
    end)
end
addStep(3000, function() log("=== ZCSDKLoader start ==="); setTrigger() end)
addStep(1000, function() discover() end)
addStep(1000, function() bridge("ZCSDK:byclass|/Script/Bruno|BrunoModificationInventoryItem") end)
addStep(1000, function() injectRegistries() end)
addStep(3000, function() bridge("ZCSDK:byclass|/Script/Bruno|BrunoModificationInventoryItem") end)
addStep(1000, function() preloadPackages() end)
addStep(1000, function() rescanPrimaryTypes() end)
addStep(3000, function() refreshCaches() end)
if DIAG then
    local REAL = "/Game/Game/GameData/ItemData/Modifications/Modification_Scope_LongRange_T1.Modification_Scope_LongRange_T1"
    addStep(1000, function() pcall(LoadAsset, REAL) end)
    addStep(5000, function()
        local o = StaticFindObject(REAL)
        if o and o:IsValid() then dumpObject(o, "REAL scope item") else log("real scope item not loaded (yet)") end
        for _, g in ipairs(grants) do
            pcall(LoadAsset, g.item); local pkg = g.item:match("^(.-)%.[^%.]+$"); if pkg then bridge("ZCSDK:loadpkg|" .. pkg) end
        end
    end)
    addStep(5000, function()
        for _, g in ipairs(grants) do
            local o = StaticFindObject(g.item)
            if o and o:IsValid() then dumpObject(o, "MOD item") else log("mod item not loaded: " .. g.item) end
        end
    end)
end
addStep(1000, function() log("=== ZCSDKLoader ready; waiting for an HQ inventory to apply grants ===") end)

local ticks, armed = 0, false
LoopAsync(3000, function()
    if armed then return true end
    ticks = ticks + 1
    local ok, pc = pcall(UEHelpers.GetPlayerController)
    local wname = ""; pcall(function() wname = UEHelpers.GetWorld():GetFullName() end)
    if (ok and pc and pc:IsValid() and wname ~= "" and not wname:find("PSOLoader")) or ticks >= 40 then
        armed = true; log("armed: world=" .. wname); ExecuteWithDelay(8000, function() runSteps(1) end); return true
    end
    return false
end)
LoopAsync(4000, function()
    if not injected then return false end
    local done = false
    ExecuteInGameThread(function() local ok, r = pcall(applyGrants); if not ok then log("grant loop error: " .. tostring(r)) end; done = (ok and r) end)
    return done
end)
log("ZCSDKLoader v1.2 loaded (win64=" .. WIN64 .. "); waiting for the main-menu world")
