-- ZCSDKLoader v1.8.54 — runtime loader for Zero Company SDK content mods (pairs with the ZCSDKBridge C++ mod).
--   (1.8.54) SECURITY (review 2026-11-12): a manifest is DATA. <Mod>.zcsdk.lua is read as text by a literal-subset parser
--           (DATA-ONLY MANIFESTS block; `return { ... }` of strings, numbers, booleans, nil and tables) and never run; anything
--           else is refused with one line and the other mods load. Each manifest is schema-checked and processed in its own
--           pcall; manifest refreshers name only known symbols (no dedupe), cdoWrites only the mod's own CDOs and object
--           properties, the registry stays inside the manifest folder. Bridge 0.7.3 protocol: session token, arm ack, scan
--           request ids. No machine path fallback; the log rotates per session; whole-file reads are capped.
--   (1.8.53) ZCU REFUSED THIS BUILD (retail 2026-11-10, game CL 201250): ZC Unlocked 1.4.76 logged `refused: unsupported game
--           build` and armed nothing, yet the zcu-bridge still left a bridged mod to it (0/55 blaster items listed) and ROWFIX
--           read the HEAD of the appended ZCUnlocked.log (weeks-old armed lines) and skipped. CP.zcuSession reads the log's
--           tail from the last session start; refused = the bridge lists the mod itself (grants as before) and ROWFIX runs.
--           Healthy ZC Unlocked: unchanged. tools/replay_zcubridge.py Z*, tools/replay_pump.py R12-R14.
--   (1.8.52) AIMIMICS PARTIAL APPEND (Jedi aicast L1 2026-11-01, loader 1.8.51: "30 of our entries appended this pass ... 41 of 41
--           mimic class(es) resident", 15 of 41 per list, Force Stasis never cast): every mimic class was collected after the hub
--           preload, so RESOLVE re-loaded them one per frame (loadpkg) for 41 s; a garbage collection inside that window freed the
--           26 classes loaded before it (nothing referenced them yet), WORK dropped them silently (uvalid) and AM.res kept them as
--           resident, so no later pass looked again. A class collected before its append is now looked up again in its list's
--           frame and appended in that same frame; a list is marked done only when it holds every mimic that is not given up;
--           a found class clears its load clock. Same per-frame limits. tools/replay_aimimics.py A19-A20.
--   (1.8.51) AIMIMICS pass sliced over frames: 1.8.50 still looked up EVERY mimic class (one StaticFindObject = a whole-array
--           walk) on every 10 s pass - "pump: task aimimics took 1757 ms in one frame" every ~12 s with 41 mimics (Jedi L1, Sith
--           B5, 2026-10-31). A pass over unchanged lists now makes no class lookup at all (one FindAllOf + Nums); work is done at
--           most 2 lookups / one list step / 12 appends per frame. tools/replay_aimimics.py A17-A18.
--   (1.8.50) AIMIMICS pass cost: each planner list is read once per pass and an unchanged list is skipped (the 1.8.49 pass
--           took ~680 ms in one frame every 10 s in a mission, Sith B2 2026-10-29).
--   (1.8.49) AIMIMICS (mod-def `aiMimics[]`): a mod's cloned GAM_* mimic classes are appended to every live AIPlanner's
--           DefaultAbilityMimics (and the built MimicTypes caches) in a mission, so the game's AI plans the mod's own GAs.
--           settings.ini [AIMIMICS] Enabled / Lists / Pawns; see the AIMIMICS block and docs/recon/AI_MIMICS_RECON.md.
--   (1.8.48) COMPOSITE PARENTS / STATUSFX (bridge 0.7.2 `ZCSDK:dtparent`): a mod overlay table that never joined the LIVE
--           composite (199049: the game had DT_StatusFX loaded before the gfp mounted, so Sith Force Shock's ZCSith_LightningShock
--           row never drew) is appended with UCompositeDataTable::AppendParentTables, then every row is reported:
--           `STATUSFX row <Name> live|MISSING (table <path>)`. Manifest `composites` (zcmod-build 2026-10-28); older manifests get
--           the DT_StatusFX check at /Game/<ns>/DT_<ns>_StatusFX. settings.ini [COMPOSITES] Append = 0 = verify only.
--   (1.8.47) WHEEL SIGNAL: shared variable ZCSDK_WheelActive (ModRef:SetSharedVariable) = true once WHEEL is armed, false when
--           [Wheel] Enabled=off, on a setup error or on the 20-error stand-down; nil before WHEEL's first tick (~6 s). For a
--           mod that carries its own wheel (ZCUltimateUI zcui_wheel.lua): true = stand aside, false = run its own.
--   (1.8.46) RETAIL PROBE = 1.8.44 (WHEEL) + 1.8.45 (SLOTFIX give-up, the pump new-max line), merged on integrate/1022
--           (1.8.42). Both features kept as they were offline-tested. Own change (a separate commit, can be dropped): THE BEAM
--           UNITS - castBeams (Sith Force Lightning / Shock bolts drew nothing in retail 10-22: GetAllRelevantLivingUnits read
--           "table #15 with no usable unit") falls back to CX.findUnits through a cached walk (CX.beamUnits: one FindAllOf at most
--           every 1.5 s, never every 0.1 s pass), and CX.findUnits now REQUIRES the map's folder and skips dead / bHidden pawns
--           (the off-map B2 at 11003 cm in the Lord's aura list). tools/replay_classfx.py R14-R16.
--   (1.8.45) SLOTFIX GIVES UP CLEANLY (retail 2026-10-22 03:54-04:08, the Sith operator session, loader 1.8.42): on Gia, a story
--           Mentor whose pawn runs Class_Default with NO BitReactorCombatSet, the count GE (an Override on
--           CombatSet.BonusModificationSlots) moved nothing, and every hub load re-ran the retry ladder ("count GE v nil -> 4 ...
--           v 4 -> 5, read back 2 hexes - NOT the wanted count ... (try 57 of 3)"): F.stuck was never reset and only the quick
--           "pending" return was capped. Now a unit whose count does not move on 2 tries in a row (or is still short after
--           STUCK_MAX) is GIVEN UP for the session per (unit, saber kind, class): its GE comes off, ONE line, no class-map write or
--           GE after that; a kind / class change tries it again. The GE never stacked (the old v comes off first; the def's clamp
--           caps v at 5) - "v 4 -> 5" was the second self-correcting step, not a ratchet. No mission change: SLOTFIX already
--           works in the hub only (no SLOTFIX line after the 04:09:22 mission arm). The class re-add count ("re-add 10") is one per
--           hub load (a fresh class object each load), not a loop. THE PUMP: past a task's 20 slow lines a frame that sets its NEW
--           session maximum is still logged (the heartbeat's "saberlook 692" / "saber 239" had no line saying when; "saber 239"
--           = the one-shot vault-hook arming, 8 RegisterHooks, at 02:56:06). The Dual's late / off-hand LEFT blade is not the
--           loader's (no loader code attaches, moves, hides or lights a saber actor: replay_saberlook SL16): a saber-pack def
--           matter. tools/replay_slotfix.py SF34, replay_pump.py P16b.
--   (1.8.44) THE TACTICAL WHEEL'S CLASS CAP (WHEEL block; recon Project Handoffs/ZeroCompanyModSDK-ACTION-WHEEL-RECON-2026-10-22.md):
--           WBP_RadialSlice builds `Button Count` wedges once at Construct and drops every ability past them, so the class
--           slice showed 4 of a Sith Lord's 11 actives and its 253-degree span ran over the Standard arc. In a mission whose
--           class bucket exceeds 4 (or [Wheel] always=1) the loader raises the class slice to [Wheel] classButtons (10,
--           4..12), narrows Standard / Class / Utility to fit the stock 330-degree track, writes the class WidgetTree
--           template (later panels) and rebuilds the live panel through the BP's own "Setup Wedges" while the wheel is
--           closed, hides the 8/9/0 labels on class wedges 5+, and sets SetWedgeWidth (`Arc Width`) on the re-laid wedges.
--           No hook, no soft pointer, counted FindAllOf. 1.8.43 is feat/aura-source-gained-v2. tools/replay_wheel.py W1-W12.
--   (1.8.42) GFP GAMEPLAY TAGS ARE REGISTERED (bridge 0.7.0, `ZCSDK:tagini`). Retail R0 (2026-10-20, build 199049): the game
--           mounts Mods/<Mod>/ with no Game Features state machine, so no gfp Config/Tags ini ever reached the tag manager and
--           every ZCJedi_/ZCSith_ tag read invalid. CP.registerTags (THE TAG STEP block) runs right after discover() and before
--           the rescans / cache refresh: one tagini per gfp manifest folder, logged `tags: <Mod> N/M registered (...)`. An older
--           bridge is detected (no ZCSDKBridge.tags answer) and logged once. Cut from main 1.8.34; merged onto feat/saber-stage-e
--           1.8.41 (the aura fix below) in probe/tags-stage-e. tools/replay_tags.py T1-T8.
--   (1.8.41) THE AURA UNIT READ (Sith B11 on 1.8.40, retail 2026-10-20 10:14-10:16, SK_Mapuzo_010 from a save load): 1.8.40's
--           skip lines showed GetAllRelevantLivingUnits AND GetLivingUnitsByTeam both reading 0 units with the squad alive.
--           The pulse now falls back to ONE counted FindAllOf(BitReactorGameCharacter) per team turn (CX.findUnits; the
--           team from GetTeam); the skip keys are per TEAM TURN (1.8.40's per-round keys were spent by WorldTeam_PrePlayer_C,
--           so the PlayerTeam_C turn logged nothing); every team turn ends with one `aura pulse (round R, TEAM): ...` line
--           naming the unit source and what each native came back as; a None turn team gets a second read (the static
--           UBitReactorGameStatics::GetTeamTurn), the malformed/empty-turn lines are per mission with the round value and
--           are re-read every 1 s (was 5 s), and the first good turn says how long it was unreadable. replay_classfx R9-R13.
--   (1.8.40) THE SILENT AURA PULSE (Sith sandbox 2026-10-20 b-091519, loader 1.8.38, Pass B B11): the Lord held both aura sources,
--           the pulse ran at every team turn (turn lines + its grant-class loadpkgs in ZCSDKBridge.log), no ally got the buff and
--           no aura line was logged - CX.pulse printed only when a source had a target. A source now also counts as on the turn
--           team by its own GetTeam (UBitReactorGameStatics) when GetLivingUnitsByTeam leaves it out, the turn team's units join
--           the unit list, every skip logs why (CX.skip: one line per aura per reason per round), the pulse line counts where
--           the marker landed, CX.list names a unit read it could not iterate, and CX.obj's give-up line is reached when the
--           lookups are >= 10 s apart (the aura's own cadence). (1.8.39 is the unmerged pack-options branch.) replay_classfx R1-R8.
--   (1.8.38) CLASSFX CLASSES RELOAD (Jedi mission bundle 2026-10-18-06-51-36, loader 1.8.37): the hub preload's ZCSith marker/buff GE
--   classes were collected before the mission and CX.obj never re-sent the bridge loadpkg; it now does (every 10 s while missing).
--   (1.8.37) THE SABERSLOTS v105 RUN (retail sandbox 2026-10-18 04:28-04:43, loader 1.8.36, saber pack 1.0.5; the session log
--           ZCSDKLoader.log 04:28:08 + the run's transcript):
--           * GRANT BUDGET OVERRUN: every grants pass took 186-235 ms for 4 operations against BudgetMs 100 (fps 7-31). The budget
--             now counts from the start of the pass (the FindAllOf walk included), each operation kind's cost is measured and
--             a next one starts only if it fits; load requests (~75 ms) run in LOAD PASSES of their own without the walk (~65
--             ms), at most 4 in a row, then a walk pass grants the loaded items. A pass stays within ~100 ms. CP.GR; tools/
--             replay_grants.py Q16-Q19 (a retail cost model).
--           * THE TRANSIENT STRIP: after the 04:32:39 save load Jae's saber read ownerless for one scan (04:33:04) and SLOTFIX
--             stripped Jae (`3 -> 1 open`) - the shrink unequipped its StandardCell, which ended on no unit; the saber was back at
--             04:33:17. A former wielder is no longer stripped while a saber of ours of its kind is ownerless (at most 30 s).
--             tools/replay_slotfix.py SF32.
--           * NEVER SILENT: an equip on a SLOTFIX wielder that does not land is said once per unit and item (not refused by the
--             loader + the game's CanCharacterEquipItemID answer: a single saber has one crystal and one power-cell part slot,
--             so a second cell is refused by the game whatever the hex count). SF33.
--           * A REFUSAL TOUCHES NOTHING: a DUALHEX refusal now also sets the Slot past every count (the body's first test refuses
--             it before any re-init / unequip), and the post-equip check never takes off a copy that MOVED from another unit;
--             refusal lines once per unit and item. tools/replay_dualhex.py DX7, DX18.
--   (1.8.36) THE GRANT FREEZE (retail 2026-10-18, loader 1.8.35 + saber pack 1.0.5, its unlock-all setting ON, first load):
--           145 grants in one frame each pass - `pump: task grants took 13362 ms` (145 load requests) then `8062 ms` (145
--           grants); 3247 ms for 145 `already owned` on the restart. Each item paid a StaticFindObject (an object-array walk
--           in this UE4SS build). Now ONE FindAllOf(BrunoInventoryItem) per pass answers every item, the HQ comes from
--           GetInventory on its CDO, and a pass does at most [GRANTS] PerTick (8) item operations within BudgetMs (100) of
--           work, the next one 0.25 s later; one `grants: done - N GRANTED, ...` line at the end. Gates, per-item lines and
--           once-per-item are unchanged; a map change / save load mid-queue pauses, then resumes on the new HQ with
--           ownership re-checked. See "1.8.36: GRANT QUEUE"; tools/replay_grants.py.
--   (1.8.35) THE SABER CUSTOMIZATION FEATURES (branch feat/saber-stage-e, merged with main c6320cf = SDK 1.0.5, game 199049).
--           1.8.34 (SDK 1.0.5) shipped without them, so this is the first loader release that answers requires[] features
--           (CP.FEATURES): saberlook (the blade applier: shade / opacity / look), saberheadings (own MODS-page headings
--           CRYSTAL / POWER CELL / EFFECTS, blaster mods hidden), slotfix (fixed 3 / 3 / 6 saber slot counts, in memory; the
--           C7 save-load fix), saberrows (split Core + Glow color rows, Dual = 4 rows) and dualhex (Option B dual layout:
--           hexes 1-3 right, 4-6 left, hidden _Left twins, gap + labels, copy rule). Everything of 1.8.34 is unchanged: the
--           199049 re-baseline, the zcu-bridge rescan skip, the classfx malformed-turn guard and the ATacticalGameState turn
--           read. tools/replay_saberlook / replay_saberheadings / replay_slotfix / replay_dualhex.
--   (1.8.33) THE RETAIL TEST OF 1.8.32 (2026-10-02 18:18-18:41; ZCClassMods\SithClass\notes\RETAIL_4_VOICES.md).
--           * A RECRUITED CARD STAYED A CARD. PS.cards was emptied only by a refresh or a world NAME change, so the
--             recruited Kael kept card rules and his own voice (The Professional, in the acceptOn "roster" set) was
--             written back at 18:26:09. RecruitCharacter now demotes the recruited card (PS.demoteCard; identified by the
--             actor's RecruitmentTime, else by the Name the recruitment view model no longer lists, else every card of
--             ours); its delivered slots stay delivered. A delivered slot that reads something else consults the
--             accept-set first (`holds accepted … — left as the player chose`), so a verify pass never re-pins a choice.
--           * THE SAVE LOAD. A save load keeps the world name (HUB_Root), so PS.setT survived and the reloaded Kael was a
--             card again (his Weapon toggled, 18:28:17). A replaced world OBJECT (its address) or a census collapse
--             (< 40% of the world's high-water mark) is now a new world: PS.worldReset, and the hub re-arms.
--           * VOICE FIRST, NO RE-PIN CYCLE. Info.Voiceover is driven before the Class (it is not a Class child); a voice
--             that holds ours, resolved, is settled (1.8.32 re-collected it every pass, never `done`); a ROSTER Class
--             holding ours, resolved, is not toggled; the Class-children wait no longer counts the voice. A DIAG line
--             reads the Class and specs back right after a voice write.
--           * THE HUB COST. A stable, populated sweep with nothing ours ends the world's passes (DORMANT) at once; a
--             not-ours verdict is cached per character until a re-arm (1.8.28 swept 16 times: ~280 ms every ~8 s).
--           * DIAGNOSTIC (log only): a customization proxy of ours, and each character of ours once, logs its Class,
--             owner tags (CachedOwnedGameplayTags) and the Info.Voiceover / Specializations.Tactical.Primary required
--             sets (AllowedTags + SlotNameTag + owner tags). While dormant in a hub where something of ours was seen, a
--             proxy census runs every PS.DIAG_POLL_S (one FindAllOf; PS.DIAG_POLLS per re-arm; 0 = off).
--           tools/replay_pin.py RC1-RC3, RL1-RL2, VF1-VF2, HC1, DG1-DG2.
--   (1.8.32) TWO RECRUIT-PIN BUGS OF THE 2026-10-02 RETAIL TEST OF 1.8.31 (ZCClassMods\JediClass\notes\RETAIL_2_TEO_SPEC.md).
--           * STOCK RECRUITS CONVERTED. Identity rank 1 ("a slot already holds one of the pin's parts", PS.walkOne) took
--             ANY pin part as evidence - the Sith pins' stock Talents (CPD_TalentSpec_TheIntimidator / TheColdBlooded, which
--             VoiceOverToTalentMapping hands stock recruits) scoped stock cards, which then got the Sith Class, spec and
--             saber. Now only a part in the pin's OWN namespace (its definition's / Name part's package root, the mod's
--             primaryTypes paths, gfp /<mod>/) is evidence - never a stock part, an accept-set or escape id, a fallback
--             or a dead id (PS.evidence; one `is not identity evidence` line per part).
--           * THE RE-PIN STORM. A refresh cleared the `|card:` state of the PREVIOUS card set while those objects lived;
--             their delivered Class was TOGGLED out, every write back was a no-op, and the attempt counter reset every
--             pass (1,597 writes in 6 min; the new cards starved: one slot per 120 s sweep). Now: (a) a write that does
--             not deliver counts against PS.NOOP_MAX per character per slot, across passes; (b) a RefreshCharacterVMs
--             RETIRES every card seen before it (PS.retireCards: never driven, toggled or verified again); (c) a card's
--             delivered Class is never toggled; (d) the newest card set is driven first within the frame budget. The
--             1.8.28 frame budget / dormancy, 1.8.29 ROWFIX and 1.8.31 talent gate + verify window are unchanged.
--             tools/replay_pin.py ID1-ID4, RS1-RS3.
--           * CARD-NESS IS NOT IDENTITY. "Identified by its pool CustomizationDefinition" was also taken to mean "is a
--             recruitment card", but a RECRUITED character keeps its pool CD: its `acceptOn = "roster"` accept-sets and
--             its escape never applied and a player's own voice / saber change was pinned back. A CARD is now a pool-CD
--             character first seen at/after the world's latest refresh (PS.cards); identity (byDefinition) and card-ness
--             are independent: keys, CP.accepted, the roster `kept` rule, the talent gate, the urgent wait, the Talent
--             re-pin cap and the never-toggle-Class rule all read card-ness. tools/replay_pin.py CR1-CR3.
--           * THE CONSOLE WINDOW AT LAUNCH. detectWin64() asked `io.popen("cd")` (cmd.exe). It now reads the script's own
--             path (debug.getinfo), then a relative open, then the known install path; no process is spawned anywhere
--             (tools/selftest_loader.py check_no_spawn).
--   (1.8.31) THE RECRUIT TALENT-PIN TIMING REGRESSION (1.8.28-1.8.30; ZCClassMods\SithClass\notes\TALENT_VOICE_FIX.md §2/§5).
--           Retail 2026-10-01: every Sith Talent pin logged DELIVERED 6-7 s after RefreshCharacterVMs and the cards still
--           showed the CD voice's talent. 1.8.28's urgent pass drove a card by AGE (PS.SPAWN_SETTLE_S, 1.5 s), which can
--           be BEFORE the game's own voice->Talent write in OnSpawnCharacterAsyncComplete; the game's write won, and the
--           one verify pass (+8 s) was too early to see it. Now: (a) THE TALENT GATE - after a refresh a CARD's Talent
--           waits for BrunoCharacterRecruitmentViewModel.RemainingCharactersToGenerate == 0 (the reflected counter that
--           function decrements after its write; the function itself is native, not hookable), read once per pass inside
--           the 1.8.28 lookup budget, bounded by PS.GEN_WAIT_S; the other slots keep 1.8.28's timing. (b) THE RE-VERIFY
--           WINDOW - verify passes at 8/30/60/120 s after `done` read the live Talent back (`verify ... HELD` /
--           `OVERWRITTEN`, with every slot object of the tag) and re-pin a card's Talent up to 3 times; a write is
--           DELIVERED only when the slot reads our id back. 1.8.28's frame budget and dormancy and 1.8.29's ROWFIX are
--           unchanged. See "1.8.31: THE TALENT GATE" above PS.genRead; tools/replay_pin.py TG1-TG4.
--   (1.8.30) VERSION ONLY, no code change: runtime 0.12.1 (3 signature files; mod 9 keeps its own) needs a loader
--           version bump so Mod Command, which compares bridge/loader versions only, offers the update.
--   (1.8.29) THE ROWFIX STUTTER (support 2026-09-30, loader 1.8.26 + ZC Ultimate Blaster pack 1.0.0 + ZCUnlocked 1.4.72,
--           game 197649): `pump: task rowfix took 60-73 ms in one frame` every 5 s in the hub, forever, with 0 heals. Every
--           ROWFIX pass began with a StaticFindObject of the row class (a whole-object-array walk in this UE4SS build), and
--           a not-resident class re-paid it every fifth second. Now: no class lookup (one row FindAllOf per pass answers
--           "page open?" and "which rows"), the idle probe backs off 5 -> 30 s, the 1 s pass backs off to 2 -> 8 s after 3
--           clean passes on the page, page close / leaving the hub disarm, and with ZCUnlocked's vm-blank / listfix on
--           ROWFIX makes no lookup at all (said once). See "1.8.29: ROWFIX" at the bottom; tools/replay_pump.py R1-R8.
--   (1.8.28) THE RETAIL PROBLEMS OF 1.8.27 (ZCClassMods\JediClass\notes\RETAIL_1_LOG_ANALYSIS.md §1, §2, §3).
--           * THE 2.9 s FRAME. StaticFindObject is NOT a hash lookup in this UE4SS build: it costs a FindAllOf (a walk
--             of the object array, 28 ms in the menu, 50-90 ms in the hub). 1.8.27 re-found every slot by path and did
--             ~40 lookups in one act frame (pass 591: max slice 2917 ms). The pass is now FRAME-BOUNDED: a drive frame
--             makes ONE FindAllOf of the slots, collects and acts on those objects in that frame (nothing is re-found,
--             so no UObject crosses a frame by construction), and at most PS.LOOKUPS (2) object lookups run per frame;
--             residency answers are cached booleans asked once per id per world. See "THE FRAME-BOUNDED PASS".
--           * SCOPE. With every pin carrying a `definition`, a pass collects only OUR characters; the world-wide ghost /
--             stale-slot / roster sweep runs on a world's first PS.SWEEP_PASSES (16) passes and once per PS.SWEEP_S
--             (120 s) after them; a world with nothing ours goes DORMANT.
--           * HOOK-DRIVEN. A RefreshCharacterVMs / RecruitCharacter event makes the pin task due on the next frame, re-arms
--             a dormant loop, bypasses the spawn-wave settle and drives the cards of ours once they are 1.5 s old;
--             `recruit pin: <event> -> done N s after the event` is T-G1's number, and ONE verify pass follows 8 s later.
--           * CLASS + CHILDREN IN ONE PASS: a delivered Class holds its character 3 idle frames, then the same pass
--             re-finds the re-created children and drives them.
--           * THE CENSUS TRIGGER only when RefreshCharacterVMs could not be hooked (or the kill switch is off); off for
--             good once the hook fires. One roll line per real refresh.
--           * `recruit pin: appearance <owner>: …Head.Face.Mesh=<id> Hair.Hair.Mesh=<id> (read-only)`, once per character.
--   (1.8.27) THE FORCE CLASS MODS' RUNTIME (ZCClassMods\_Shared\SDK_CHANGE_REQUEST.md §1b, §2d, §3, §4, §5.1, §5.6), AND
--           THE DEN PAUSE. One release, one retail pass (D4).
--           * THE PIN PASS IS SLICED. 1.8.26's recruit-pin pass ran in ONE frame: 3,208 / 2,105 / ~1,000 ms in the Den
--             (ZCSDKLoader.log 2026-09-29 03:21). It is now a resumable pass (instances -> slot scan -> walk -> act):
--             the walk over the pinned-tag slots stops at PS.SLICE_MS (4 ms) and resumes on the next frame, and NOTHING
--             but strings crosses a frame - a slot or an instance is re-found by its path (StaticFindObject) in the
--             frame that uses it, so a garbage collection between two slices can never hand the walk a freed object.
--             The first pass of a session runs whole (1.8.26 behaviour) and PROVES that route: StaticFindObject(<the
--             path>) must return the very object FindAllOf just returned; if it does not, slicing stays OFF for the
--             session and says so. Only slots carrying a tag some pin reads are named at all (the rest were walked
--             for nothing). `recruit pin: pass N timing: …` gives each pass's slices, total and max slice.
--           * THE CHEAP WORLD READ. UEHelpers.GetWorld() is FindAllOf("PlayerController") on every call - 50-170 ms per
--             frame in retail for every task that read the world (arm, saber, rowfix, the idle pin, each bridge()).
--             `gameWorld()` reads Engine.GameViewport.World (reflected: jmap Engine.GameViewport @3128,
--             GameViewportClient.World @120) and falls back to UEHelpers only when that chain is empty.
--           * G1: `done` no longer stops the pin for the session. It goes DORMANT (an O(1) tick) and RE-ARMS on a
--             Recruitment refresh (a RefreshCharacterVMs hook, or a census change in the same hub), a recruit
--             (RecruitCharacter) or a world change, at most once per 5 s and PIN_REARM_MAX (20) times a session.
--           * G2: the Talent slot toggles through CPD_TalentSpec_TheToughGuy and is driven LAST.
--           * H1 / §5.6: a pinned slot may carry an ACCEPT-SET (`accept` ids, `acceptTags` read off the equipped
--             GearKit part, `acceptOn = "roster"`) and a roster-only `escape` (fallbackSpec / fallbackWeapon): the
--             pin leaves a player's choice alone and still gives a fresh card the class default.
--           * §2d: `requires[]` - the dependency is reported once, a slot into a missing / too-old dependency is
--             delivered as its `fallback` (or dropped), and a dead id of a removed dependency is either overwritten
--             by that fallback or reported as a GHOST naming the dependency.
--           * §1b: `classPool` rows get a runtime weight (a player's settings.ini wins), rolled after the follow-up and
--             again per Recruitment refresh (roll-ahead), written to the live pool's bIsActive and read back.
--           * The Recruitment watcher's hooks arm once per process, in the hub only, after the census has settled and
--             10 s have passed (the 1.8.23 discipline); their callbacks only count events.
--   (1.8.26) NO LUA ON UE4SS's ASYNC THREAD. The Den (HUB_Root) crashes of 2026-09-13, 09-15, 09-28 21:51 and 09-29 02:46
--           share one stack: UE4SS `UObject:IsValid` faulting inside the Lua VM's protected-call path, reached from the
--           game-thread action runner. The 21:51 minidump shows WHY (scratchpad crash/R_staffprobe_hub_crash.md): at the
--           fault `L->top` sat on the IsValid function's own slot with a valid `self` above it — impossible on one
--           thread. UE4SS runs `LoopAsync`/`ExecuteWithDelay` bodies on its async thread and calls queued
--           `ExecuteInGameThread` actions with its action mutex RELEASED (UE4SS+0x2f92a0: _Mtx_lock, move the queue
--           out, _Mtx_unlock, then call), so two OS threads ran Lua in this mod's ONE lua_State. 1.8.23 blamed
--           RegisterHook and 1.8.25 thinned the async bodies; both only narrowed the window.
--           THE FIX: every LoopAsync and ExecuteWithDelay is gone. ONE function, `pump`, runs on the game thread
--           through `ExecuteInGameThread(pump)` and re-queues ITSELF (the same function value, no new closure) as its
--           first statement; the runner has already moved its queue out, so the re-queue lands on the NEXT engine
--           tick. The arm check, the startup steps, grants, the recruit pin, ROWFIX, vault-saber arming and the (OFF)
--           relight timers are tasks inside it, timed with os.clock() (wall time on the Windows CRT). At most ONE task
--           runs per frame (round-robin), so a Den load never stacks the pin, ROWFIX and grants into one frame.
--           Cadences are unchanged (arm 3 s, grants 4 s, pin 2.5 s with its skips, ROWFIX 1 s, saber 5 s, steps as
--           declared); the *Queued/*QueuedFor watchdogs are deleted because nothing crosses a thread any more.
--           ALSO: the recruit pin's `pcall(IsValid) and IsValid()` double call (the second, unguarded one is the
--           21:51 fault line) is one guarded call (`pinOk`) everywhere in the pin block; the pin defers its slot walk
--           while the CustomizationInstance census is still CLIMBING (the spawn wave; at most pinSettle.max passes);
--           and RACEPROBE (default OFF) counts any loader Lua that runs off the game thread or re-enters the pump.
--   (1.8.25) HARDENING (the X1 crash review of 2026-09-24 03:14, SWBF2 Models Project notes/X1_crash_0314.md). UE4SS's
--           game-thread runner called a queued action whose Lua registry ref had been reused (a C finaliser, not the
--           closure), and this loader's recruit-pin closure had replayed stale a minute before. The ROWFIX, recruit-pin and grant
--           loops now keep AT MOST ONE closure in the game-thread queue (a 10-tick watchdog re-queues a dropped one), and
--           ROWFIX re-finds its rows every tick while rows exist, so no widget userdata crosses a tick.
--   (1.8.24) THE ARMOURY'S BLANK MODEL ROWS. A weapon list longer than the ~7 visible rows scrolls, and every row generated
--           after the page's one-time build-on cascade keeps its WBP_Customization_WeaponBox entry at BuildOn "Off" (root
--           opacity 0): blank, yet clickable. This is a latent game bug that stock lists (6 parts at most) never reach. A paced,
--           hub-only loop re-runs the stuck entry's own PlayBuildOn(0) ("entry" mode), or re-lays-out the list ("list" mode),
--           whichever the round-6 experiment proves. See the block above the final log line.
--   (1.8.23) THE HUB'S SPAWN WAVE KILLS RegisterHook, SO THE SABER HOOKS WAIT FOR A MISSION. The crash is now
--           CAPTURED TWICE, and both are the same shape: 2026-09-13 22:51:55 and 2026-09-15 08:58:38.9,
--           `EXCEPTION_ACCESS_VIOLATION` (0x70 and 0xa) with UE4SS-ONLY top frames — `+c5f4dd`, `+2a9cf9`,
--           `+2ad787`/`+2ad78a`, `+b94064`, `+b98dec`, `+c68a7e` — and no game frame anywhere near the top. Both
--           landed at the exact instant `LoopAsync(5000, …)` found `BP_FX_LightSaber_Base_C` resident and started
--           `RegisterHook`ing the 8 saber functions DURING THE HUB'S SPAWN WAVE (the pin census climbing 27 -> 73 ->
--           116 instances in the same seconds). The 09-15 UE4SS.log ends on `[RegisterHook] Registered script hook
--           (8, 8) for … Cinematic_Deactivate` — the 4th of the 8 — with no further Lua line: the fault is inside
--           UE4SS during the 4th/5th registration, or inside the game calling one of the just-hooked functions on a
--           saber actor that is still mid-spawn. 7 of 9 hub loads survived the identical code, so this is a RACE
--           with the spawn wave, not a deterministic fault. INFERRED (not proven): hooking a Blueprint UFunction
--           while that class's instances are being constructed is unsafe in UE4SS 3.0.1.
--           THE FIX IS TO STOP ARMING WHERE THE HOOKS ARE NOT NEEDED. They exist for a VAULT or a STRIKE, both of
--           which happen in a mission, so arming now needs all three of: (a) the world name contains
--           `/Maps/Skirmish/` — the same mission marker the TurnProbe uses, which `HUB_Root` and `MainMenu` can
--           never match; (b) `BP_FX_LightSaber_Base_C` resident (`StaticFindObject` valid, unchanged); and (c)
--           `SABER_HOOK_SETTLE` = 8 s elapsed since that mission world was FIRST seen, so the mission's own spawn
--           wave and its `ActivateLightsaber` burst at +2 s are over before anything is registered. Everything the
--           1.8.2 lesson bought is kept verbatim: exactly ONE registration per process (`saberHookArmed` set BEFORE
--           the call), never a retry after a failure, and the hooks persist across worlds so one mission arms them
--           for the whole session. The hub now logs `vault saber: arming deferred to a mission world (1.8.23) …`
--           once when the class is first seen there, and the first mission logs `vault saber: mission world seen at
--           <t>; arming in 8 s` and then the 8 `hook armed on` lines as before.
--           THE COST, stated because session_audit.py must not be edited to hide it: hooks armed inside a mission
--           MISS that mission's own start burst (`PATH> Activate` ×4 / `PATH> ActivateLightsaber`), which is
--           session_audit's mission-boundary marker — so for the FIRST mission of a session that marker will be
--           absent. Every later mission, and every vault or strike in the first one after the 8 s, logs as before.
--           Nothing else moved: relight still OFF (1.8.21), the stale-slot rebuild, the ghost holds and the
--           residency ladder are byte-for-byte 1.8.22.
--   (1.8.22) THE SLOT THE OPERATOR CANNOT CHANGE, AND THE SAVE THAT KEEPS IT. Retail 2026-09-14/15 (CHANGELOG
--           v1.28.53 §9(b), §11, §13): PROVEN in the data, INFERRED for the symptom. Two facts already in this header
--           — `LoadCustomization` rebuilds a slot's FragmentInstances ONLY on an id CHANGE (09-13 09:04:40), and a
--           MISSION re-creates every character FROM SAVE DATA (21:28:27 vs 21:28:30) — together explain HAWKS. He is
--           NOT a pinned character (game class `CPD_Char_Class_Hero_Humanoid`), but his `Specializations.Weapon` slot
--           holds `CPD_WeaponSpec_ZCSDK_SaberAnakin`, picked in the armoury and serialised under that mod's v1.0.0,
--           and his armoury Change Weapon is GREYED OUT — so the id never changes, the fragments stay v1.0.0, and
--           every mission rebuilds him from them: the REMOVED `GA_OverwatchMelee_Base` still draws a "Melee Overwatch"
--           card (and locks the turn) and his sprint still uses his previous BLASTER's anim proxy table while the
--           visible saber comes from the equipped part. A byte-grep of the whole deployed game finds that ability in
--           NO ZCSDK container: the card is the SAVE, not the pak. VEX is the control and he is CLEAN — because the
--           pin toggles his Weapon slot every hub load (`[TOGGLE to CPD_WeaponSpec_Blaster_Longarm]`,
--           `FragmentInstances REPLACED`) and a manual save carried the rebuilt fragments into the mission (§11,
--           retail-verified).
--           SO THE PIN NOW DOES FOR A NON-PINNED CHARACTER WHAT IT ALREADY DOES FOR A PINNED ONE: one toggle-and-back
--           on the Weapon slot, `STALE_SLOT_REBUILD` (default true), through the SAME setter and the SAME
--           BEFORE/AFTER fragment-identity check. It is the 1.8.18 toggle re-aimed, not a new mechanism, and every
--           fence narrows it: HUB ONLY; the WEAPON TAG ONLY (a Class drive re-creates the child slots, fact B); only
--           an id THIS INSTALL SHIPS — enumerated by a manifest (`pinManifestParts()`) OR RESIDENT at the SDK's own
--           `/Game/ZCSDK/<id>.<id>`, and the second test is not optional: `build/ZCSDK_SaberAnakin.zcsdk.lua`, the mod
--           whose spec is stuck on Hawks, enumerates NOTHING (one primary type over /Game/ZCSDK, empty grants), so the
--           enumerated set alone would never have fired on the one character this exists for. Either way it is never a
--           vanilla part (not under /Game/ZCSDK) and never a GHOST (not resident — that is what makes it a ghost);
--           never a character that is OURS (the pin's own toggle would
--           fight it); never a proxy and never an owner that cannot be NAMED (1.8.20); once per session per
--           (owner, id), at most PIN_MAX_RETRY writes, and a failure is FINAL. The one that matters: BOTH ids are
--           minted from live objects BEFORE the first write, because a toggle written with no way back would leave
--           the character wearing a Blaster Longarm — and if the toggle write itself does not move the fragments the
--           original id is UNWOUND back onto the slot in the same pass (one write of what it already held; the
--           verdict stays FAILED). `done` is held while a rebuild is mid-flight, bounded by those
--           same budgets. The REBUILT line ends `— make a manual save before the next mission`, because rebuilt
--           fragments live in the hub instance and the mission reads the save; the summary at `done` is
--           `stale-slot rebuild: N slot(s) REBUILT, M FAILED, K skipped (not ours, not ours-shipped)`. NOT
--           retail-verified: the check is Hawks' hub load printing REBUILT, then a manual save, then a mission with
--           no "Melee Overwatch" on him and saber locomotion on his sprint.
--   (1.8.21) THE RELIGHT IS OFF, AND THE RULE IT BROKE IS NOW WRITTEN DOWN. Retail 2026-09-14 04:53 (loader 1.8.20,
--           deployed), one second into a mission: the insertion mantle extinguished a blade (04:53:30
--           `PATH> DeactivateLightsaber` / `relighting through ActivateSaberCheck (HasMantled=true)`), and the 350 ms
--           relight threw `main.lua:2011: [Lua::Registry::get_function_ref] Ref was not function` with the traceback
--           in `[C]: in method 'ActivateSaberCheck'`. THAT FUNCTION IS ONE THIS SAME MOD HAS RegisterHook'd — the
--           log-only `[state]` probe hook of 1.8.6 — and calling it from Lua made UE4SS's hook dispatcher fail to
--           find its own callback ref. The 900 ms call then went through and even reported `RELIGHT VERIFIED (900ms)
--           - bIsActive=true | Activated Lightsaber Blade=set | Sheath=0.000`, but the operator saw EVERY CHARACTER
--           RUNNING IN PLACE at mission start: the insertion sequence never completed. INFERRED (not proven): a Lua
--           exception thrown inside UE4SS's hook dispatch while the game was mid-`ActivateSaberCheck` broke the
--           mission's start sequence. Exact or not, two rules are now proven and stand on their own:
--             (A) THIS RUNTIME MUST NEVER CALL A UFUNCTION IT HAS HOOKED. Registering and invoking the same UFunction
--                 is the `Ref was not function` fault, and it throws INSIDE the game's own call frame.
--             (B) THIS RUNTIME MUST NOT DRIVE THE SABER DURING THE INSERTION MANTLE. A scripted sequence owns the
--                 characters at mission start and a relight lands in the middle of it.
--           So `RELIGHT_ENABLED` is FALSE by default. The vault handlers still READ and still print every vdiag line
--           (the diagnostics are the point), but they schedule NOTHING and log `vault saber: relight DISABLED
--           (1.8.21) ...` once per deactivation. The blade is left to the game's own `ActivateSaberCheck`, and the
--           next retail vault decides it: PASS = the game's check reads `bIsActive=false` and `PATH>
--           ActivateLightsaber` follows and the blade comes back; FAIL = `bIsActive=false` with no
--           `ActivateLightsaber`, blade dark — then the game does not recover on its own and a relight that does NOT
--           call a hooked function is needed (drop the `[state]` hooks first). If `RELIGHT_ENABLED` is ever set true,
--           the `[state]` probe hooks on ActivateSaberCheck/DeactivateSaberCheck are NOT registered, because rule (A)
--           is not a thing to re-learn in retail. With the default false, all 8 hooks arm exactly as in 1.8.20.
--   (1.8.20) THE FLAG WAS NOT THE BLADE. Retail 2026-09-13 22:52 (loader 1.8.19, deployed) broke three things open:
--           * THE VAULT SABER RELIGHT WAS NEVER A FIX — it was the thing STOPPING the fix. 23:17:41 Hawks vaulted,
--             the relight replayed the four captured arguments into `ActivateLightsaber` and logged `re-lit (350ms)
--             - bIsActive now true`; the blade was NOT visible for the rest of the mission, and at 23:21:16 the
--             game's own `ActivateSaberCheck` logged `HasMantled=false bIsActive=true` and did nothing. Proven with
--             tools/recon/kismet.py over the cooked BP_FX_LightSaber_Base (offsets in the block comment on
--             `relight`): `+2086 EX_JumpIfNot Self.bIsActive -> +1904` is the game's OWN next-turn recovery, and
--             setting the flag turns it into a no-op; the visible blade comes only from `Timeline_Blade__UpdateFunc`
--             (`SetScalarParameterValueOnMaterials("Sheath", ...)`), which `bIsActive` does not touch; and the 4th
--             parameter `Target Saber` is DEAD — `K2Node_CustomEvent_Target_Saber_2` never appears as an operand in
--             the 1389-opcode ubergraph, so the replay of 1.8.7-1.8.19 replayed nothing that mattered.
--             THE RELIGHT NOW CALLS THE GAME'S OWN `ActivateSaberCheck(TargetSaber)` — signature READ, not guessed
--             (`kismet.py --function ActivateSaberCheck`: ONE `TargetSaber : ByteProperty`), with the saber's own
--             `Owning Saber Position` (then `GetTargetLightsaber()`, then the enum's "both" member 2). It is
--             self-idempotent at `+2086`, so the 350/900 ms pair is kept; the three captured components are gone and
--             the stale-pointer dance with them. AND `bIsActive` NO LONGER REPORTS SUCCESS: 600 ms after the call
--             one more read prints `RELIGHT VERIFIED` / `RELIGHT UNVERIFIED` from `Activated Lightsaber Blade` and,
--             where it can be read at all, the blade material's `Sheath` scalar. A relight that flips the flag and
--             leaves the blade dark now says so.
--           * THREE OF THE FOUR GHOST LINES WERE THE GAME'S OWN PARTS. `CPD_TacticalSpec_Soldier` (pass 1) and
--             `CPD_TacticalSpec_Hero_Aurelio_Assault` (pass 50) matched evidence shape 2 while the character was
--             still spawning (27 instances at pass 50 -> 109 at pass 54), and all three printed the owner as
--             `/Engine/Transient` because `shortOwner` was reading the SLOT's path. Two rules: a non-`CPD_ZCSDK_` id
--             needs PIN_GHOST_PASSES (4) CONSECUTIVE unresolved passes, and NO REPORT WITHOUT A NAMED OWNER — the
--             owner is the owning CustomizationInstance and an unnamed one DEFERS the report instead of printing it.
--             Hawks' real line is unchanged, verbatim. A candidate is counted, not blocked, unless it is a
--             `CPD_ZCSDK_` id: blocking an evidence-2 candidate would stop the drive that could disprove it.
--           * THE RESIDENCY LADDER RE-RAN ON A DELIVERED PART. 23:00:38-23:00:58, after all three slots read
--             `finished`, every pass alternated `did not resolve — step 1` / `resolved after step 1`. The drive path
--             cleared `partStep` and left the part on `partWatch`, where a step count of 0 reads as "not started".
--             Not a stale read — the tick's own precondition is a VALID StaticFindObject — so the line contradicted
--             the test that produced it, and its LoadAsset was a real request for an already-loaded asset. A part
--             that resolves once is now SETTLED: off the watch list, refused by `escalateResidency`. The 1.8.18
--             delivery path is untouched.
--   (1.8.19) THE EXPERIMENTS ARE DELETED, AND THE LOADER LEARNS TO REFUSE. 1.8.18 is RETAIL-VERIFIED (CHANGELOG
--           v1.28.46/47: all three Sith parts DELIVERED, the Focus tree DRAWS on the Sith Acolyte rails), so
--           everything it carried "in case" is now dead weight that the next reader would have to rule out again:
--           * GONE — `PIN_ROUTE` and both equip routes with all five marshalling shapes
--             (EquipCustomizationDefinition `allowed`/`tags`/`all`, EquipCustomizationParts `struct`/`table`), their
--             judge/commit helpers and the `arrival` observable that scored them. Retail 09:04:40 proved the plain
--             1.4.0 setter delivers, and an EMPTY AllowedSlots container re-created the character's own child slots
--             TWICE (07:52:26, 09:04:44). No route is going back in without a retail run that needs it.
--           * GONE — `PIN_RESOLVER_PROBE` and the whole KismetSystemLibrary resolver probe, including its
--             self-validation against the game's CPD_TacticalSpec_Assault. Its question was answered at 09:04:18:
--             the AssetManager resolves every one of our parts once they are RESIDENT. The TSoftObjectPtr accessor
--             chain it cost a crashed game to find is KEPT, as a comment beside the residency code — it is the only
--             verified way to read one in UE4SS 3.0.1 and nothing else in this project records it.
--           * NEW — THE GHOST REFUSAL (HANDOFF open items 3 and 7). Before driving anything, the pin looks at every
--             pinned slot on every real character in the world, OURS OR NOT, and if one holds a `CPD_ZCSDK_*` part id
--             that no currently enumerated manifest carries and that is resident nowhere — or a leveled tree whose
--             tier classes are null, the FocusProbe's shape on Hawks' save — it logs
--             `recruit pin: GHOST <owner> <slot tag>: holds <partId> from a mod that is not installed ...` and never
--             drives that slot. A save written while a mod was installed is not something to write over; the
--             2026-09-12 turn-end block is the INFERRED cost of one.
--           * VOCABULARY, per session_audit.py's own recommendations: one arming verb (`hook armed on <class>:<fn>`,
--             was `watching <fn>`), one firing verb (`PATH> <fn>`, was `<fn> FIRED`), `RegisterHook FAILED on <fn>`
--             names the function, and the HQ banner only says "waiting" when grants were actually declared.
--           Nothing on the proven path changed: residency before the first write, Class to completion then Weapon
--           then Tactical, the TOGGLE through a vanilla id, delivered-is-final, `done` ends the loop, proxies never
--           pinned, identity per CustomizationInstance, stale slots deduped by highest object index, xpcall around
--           the pass, IsValid before any UObject method, no UObject held across passes.
--   (1.8.18) THE ANSWER, AND IT WAS THE SETTER ALL ALONG. Retail 2026-09-13 09:02 (no crash):
--             09:04:18  GetObjectFromPrimaryAssetId returns OUR OBJECT for all three parts once resident - the
--                       AssetManager was never the problem (its path half was broken; that reading is discarded).
--             09:04:40  the plain 1.4.0 setter on Tactical.Primary: BEFORE partId=CPD_TacticalSpec_Assault |
--                       partDefinition=CPD_TacticalSpec_Assault | 3 leveled tree(s) -> AFTER partId=
--                       CPD_ZCSDK_TacticalSpec_Sith | partDefinition=CPD_ZCSDK_TacticalSpec_Sith | 2 leveled tree(s)
--                       -> DELIVERED. OUR TWO TREES, through the door eight versions tried to replace.
--             09:04:40  then a Class re-drive in the same second, and from 09:04:44 every Tactical AFTER reads
--                       partDefinition=<null> | 0 leveled tree(s), with the delivered trees stranded on stale slots.
--           TWO PROVEN FACTS: (A) LoadCustomization rebuilds fragments only on an id CHANGE, so a slot that already
--           holds our id is a no-op for ever - which is exactly why the Sith has been empty since the first session
--           that wrote our id onto him; (B) driving the CLASS part re-creates the character's child slots and
--           discards what was just delivered into them. So: Class FIRST then Weapon then Tactical (1.8.15's 'Class
--           last' was backwards); a slot that already holds our id with no fragments is TOGGLED through a different
--           id (its own remembered vanilla part, else the game default for that tag) and given ours back on the NEXT
--           pass; a delivered slot is never driven again; and `done` now means all of them delivered. The equip
--           routes and the resolver probe are both OFF by default - the setter is the route that works, and the
--           probe's question is answered.
--   (1.8.17) MY OWN PROBE CRASHED THE GAME, AND EVERY LINE IT PRINTED WAS AN ARTEFACT. Retail 2026-09-13 09:00:44,
--           91 s in: EXCEPTION_ACCESS_VIOLATION reading 0xa, frames UE4SS+2a9cf9 / +2ac8a6 (the userdata fetch and
--           UObject method binding). The 1.8.16 probe called methods on part objects it had just reported as
--           MISSING - the exact IsValid-before-method rule this file states twice elsewhere. And its output was
--           worthless in three separate ways: `id=FString: 0000...` (Conv_PrimaryAssetIdToString returns an FString
--           USERDATA, printed as its address), `path=EMPTY` for the GAME CONTROL as well as for ours (so the
--           soft-reference read was simply broken and every 'NameData is missing' line was noise), and
--           `valid=false` for our ids (because the probe ran before our parts were resident, so
--           GetPrimaryAssetIdFromObject was handed an invalid object).
--           THE ACCESSORS ARE NOW READ, NOT GUESSED. UE4SS 3.0.1's TSoftObjectPtr userdata metatable registers
--           exactly GetWeakPtr / GetTagAtLastTest / GetObjectID / type / __gc (UE4SS.dll push_softobjectproperty,
--           RVA 0x2cafe0) - no ToString, no GetAssetPathString. GetObjectID yields an FSoftObjectPath, and the
--           196985 jmap gives its shape: { AssetPath : FTopLevelAssetPath { PackageName : FName, AssetName : FName },
--           SubPathString }. The id string comes from the id's own members, the read slotState has used since 1.8.9.
--           SAFETY: a part is not asked about at all until StaticFindObject returns an object that passes IsValid -
--           before that the probe logs `not resident yet` and requests the load, and touches nothing. Every call is
--           pcall'd and every object IsValid-checked. A failed READ is reported as `<unreadable: why>` and concludes
--           NOTHING; only a successful read of an empty name means 'the manager holds no path'.
--           SELF-VALIDATION: the GAME's own CPD_TacticalSpec_Assault is probed FIRST and must answer on BOTH halves
--           (object and path). If it does not, the probe prints PROBE BROKEN, never touches our parts, and does not
--           run again this session. A probe that cannot be trusted has to say so.
--   (1.8.16) EVERY EQUIP LEAVES THE OLD SLOT OBJECTS ALIVE, AND THE CAP WAS COUNTING CORPSES. Retail 2026-09-13
--           08:38: 08:41:06 `skip Char_Hero_Humanoid_C_2: 6 slot(s) match this pin's 3 tag(s)` (the cap refused the
--           RECRUIT), 08:41:12 scoped, 08:41:17 scoped and Specializations.Weapon DELIVERED, 08:41:22
--           `12 slot(s) ...` and he was refused for the rest of the session. 3 -> 6 -> 12: each equip adds a new
--           slot object beside the previous one and the old ones stay findable. Fixes:
--           * slots are deduped BY TAG keeping the HIGHEST object index (UE numbers each new object above the last),
--             and the rest are reported as data: `<n> stale duplicate slot object(s) ignored`;
--           * an IDENTIFIED character is never refused by the cap - identity gates the drive, so the cap's only job
--             is to stop an instance nobody identified, and it can no longer fire on the recruit himself;
--           * NO VERDICT WITHOUT A DRIVE. That session ended with `STILL does not resolve` for all three parts, two
--             of which had resolved and delivered minutes earlier - the verdict was measured on a character the pin
--             had stopped driving. The ladder now holds at step 4 and says so.
--           AND THE INSTRUMENT CHANGED: a DIRECT RESOLVER PROBE replaces inference from equips. The AssetManager's
--           primary-asset API is BlueprintCallable on the KismetSystemLibrary CDO the pin already holds, takes a
--           by-value FPrimaryAssetId the pin already mints, and needs no equip, no character and no identification:
--           GetObjectFromPrimaryAssetId IS the resolver's own first step and GetSoftObjectReferenceFromPrimaryAssetId
--           is its second, so one line per part separates `no NameData` from `path present, object null` from `our
--           object reports a different id`. A game part (CPD_TacticalSpec_Assault) is probed as a control, so a
--           broken probe cannot masquerade as a broken asset.
--   (1.8.15) THE PIN LOST THE CHARACTER IT HAD JUST FOUND, AND SAID NOTHING. Retail 2026-09-13 07:47: the Sith was
--           identified at 07:52:21 and 07:52:26, the Class part DELIVERED through its own AllowedSlots container -
--           and from pass 32 onward the census read `0 ours, 14 with pinned slot(s), 0 pinned, 14 skipped` for the
--           rest of the session, with no line saying why, because the skip dedup was per OWNER and he had already
--           spent his one line on an earlier reason. THE CAUSE IS THE CALL ITSELF: the cooked
--           CPD_ZCSDK_Char_Class_Sith carries NO AllowedSlots property, so that container was EMPTY, and an empty
--           container equips every slot the definition names - the whole CD_ZCSDK_Char_Sith. That replaced the class
--           fragment, the class fragment is what builds the character's child slots, and the Info.Name slot the pin
--           identifies by was re-created underneath it. Four fixes: skip dedup is per (owner, REASON); identity is
--           STICKY for the session and has a SECOND source (a slot already holding one of this pin's own parts -
--           the Class slot re-identified him in the offline replay); a part whose AllowedSlots is EMPTY is never
--           equipped through the `allowed` shape, and the Class part goes LAST regardless so a re-creation cannot
--           orphan the specs; and the residency ladder runs on its OWN per-part clock (a step every
--           PART_STEP_PASSES ~ 15 s, ticked every pass whether or not a character was identified) instead of
--           stalling at step 2 for a whole session as it did at 07:52:26.
--           ON (e), REPORTED HONESTLY: the rescan did NOT flip the weapon at 05:48:53 - the log line ORDER shows the
--           weapon read as resolved BEFORE that pass issued the rescan command, and the bridge's before==after says
--           the rescan registered nothing. And there is NO asset-level difference to name: our weapon part's
--           registry class is BP_CPD_WeaponSpec_Base_C, identical to the game's own CPD_WeaponSpec_Blaster_Longarm,
--           and our tactical part's is BP_CPD_TacticalSpec_Base_C, identical to CPD_TacticalSpec_Assault; the
--           tactical is also the SMALLEST of the three (21 imports / 7 exports vs the class's 25/13), so 'a heavier
--           load graph' - my own earlier guess - is wrong too. Steps 3 and 4 fired in the SAME SECOND at 05:48:53,
--           so the ladder was measuring itself. The per-part clock is what makes the next run informative.
--   (1.8.14) THE PIN STOPS WHEN IT IS DONE, AND NEVER TOUCHES A PREVIEW PROXY. Retail 2026-09-13 05:43 crashed at
--           05:50:58 - EXCEPTION_ACCESS_VIOLATION reading 0xffffffffffffffff, 43 frames inside the Lua VM, no
--           GetClass frame, one pass after the loader's last line (pass 66 at 05:50:56.98; pass 67 never logged).
--           That session re-drove BP_CustomizationProxyCharacter_C_1 NINE times and C_0 three times EVERY pass,
--           forever, with zero give-up lines. Four causes, four fixes:
--           (1) A preview/portrait proxy is a transient actor the game destroys and recreates while Personnel is
--               open. It is never pinned now (`skip <owner>: preview/portrait proxy`) - pointless AND the likeliest
--               source of a userdata whose object is gone.
--           (2) PIN_MAX_RETRY was keyed by the instance PATH, which changes as proxies are recreated, so the bound
--               was unreachable. It is keyed by the character's stable identity (the pin's Name part) now.
--           (3) When every pinned slot on every identified real character is delivered or has given up, the loop
--               logs `recruit pin: done - ...` and STOPS for the session. 66 passes could not have helped.
--           (4) Nothing survives a pass but strings and numbers - the one cached UObject (the CustomizationStatics
--               CDO) is re-found every time. Cadence 3 s -> 5 s.
--           ON THE RESOLVER, CORRECTING 1.8.13's INFERENCE: the bridge's `before=3393 after=3393` with `scanned=19`
--           is GetPrimaryAssetIdList's COUNT before and after ScanPathsForPrimaryAssets (main.cpp:674-708), so the
--           manager already carried our ids and NameData was never missing. And the whole of
--           GetCustomizationPartDefinitionFromPartId (0x8c46060..0x8c46209) touches only UAssetManager::Get, two of
--           its virtuals ([+0x318] loaded-object, [+0x388] path) and a soft-path load pair - there is NO
--           UCustomizationPartsTagSubsystem call on the resolution path. What differs between the three parts is
--           asynchronous LOAD COMPLETION: Class resolved after LoadAsset alone, Weapon only two minutes after its
--           loadpkg, and the rescan that followed added nothing because there was nothing to add. The ladder keeps
--           the BuildPartTagMaps step anyway, because a step that flips a part would disprove this paragraph.
--   (1.8.13) THE MARSHALLING QUESTION IS CLOSED; THE RESOLVER ONE IS NOT. Retail 2026-09-13 05:30:21: three
--           EquipCustomizationDefinition calls, one per pinned part, each with that part's own AllowedSlots
--           container. Class -> `AFTER partDefinition=CPD_ZCSDK_Char_Class_Sith | 6 fragment instance(s)` ->
--           DELIVERED - FragmentInstances REPLACED. Weapon and Tactical.Primary -> `not delivered - nothing on the
--           slot changed`, partDefinition still <null>, fragments untouched, 0 leveled trees. One call in the same
--           pass delivering PROVES the userdata container reaches the native, so what separates the three parts is
--           GetCustomizationPartDefinitionFromPartId (RVA 0x8c46060), which asks the AssetManager for the LOADED
--           object for that FPrimaryAssetId and then for its path: an id the manager never SCANNED answers neither.
--           Cooked evidence that the three are not interchangeable: CPD_ZCSDK_Char_Class_Sith carries NO AllowedSlots
--           tagged property (an EMPTY container - so the call that delivered is the one that passed an empty one),
--           while the two spec parts carry populated ones. Both readings are now TESTED rather than argued: each
--           pinned part prints `part <name>: object=<found|missing> | valid=<y/n> | <full path>` once, and a part
--           whose slot will not resolve climbs one observable step per pass - LoadAsset, then the bridge's
--           synchronous loadpkg, then a rescan of that package's OWN directory - each step logged, and the step it
--           resolved on is logged too. Four steps in, the log says plainly that this is an asset-registration
--           question and not a loader one.
--   (1.8.12) THE UNIT OF IDENTITY IS THE CHARACTER, AND A CHARACTER IS ITS UCustomizationInstance. 1.8.10/1.8.11 made
--           it the slot's immediate parent OBJECT, and retail 2026-09-13 05:03 proved that unsatisfiable by
--           construction: `pass 39: 73 instance(s) seen, 73 candidate(s), 73 group(s), 0 pinned, 14 skipped,
--           world=HUB_Root`, every character skipped three times with `no identity: it holds 1 | 2 | 2 pinned tag(s)
--           … Info.Name reads <not present>`. One character's slots are not siblings: Class hangs off the instance,
--           the two Specializations slots off a container slot, Info.Name off a third parent - so no parent object
--           can hold both a pinned tag and the identity, and the rule could only ever fail. 1.8.7, which pinned this
--           recruit correctly, identified at INSTANCE level; that is restored. A character is ours if its instance's
--           own default CustomizationDefinition is the pin's OR if ANY slot under that instance carries the pin's
--           `match` part (in this save Vex came from the pool row, so only the Name part finds him), and the pinned
--           tags are then taken from anywhere under that same instance, at any depth. The owning instance is found by
--           walking GetOuter() with a validity check at every step (IsValid and GetFullName only - never GetClass),
--           falling back to the proven full-name prefix test.
--           WHAT STOPS THE 22:15:47 MASS-PIN IS THE CAP, NOT THE GROUPING: a character has exactly one slot per
--           pinned tag, so more matching slots than the pin declares means the instance carries more than one
--           character (a customization proxy accumulates what it has previewed) and NOTHING is written.
--   (1.8.11) 1.8.10 PINNED NOTHING, AND SAID NOTHING. Retail 2026-09-13 04:38: not one `recruit pin:` line after the
--           manifest was read, through a mission and a hub visit with the Focus tree open, while the probe showed the
--           Sith still at `partDefinition=<null> | fragment trees = 0`. Cause: 1.8.10 made the `match` Name-part
--           identity MANDATORY for every candidate - including the ones 1.8.9 found by the instance's own default
--           CustomizationDefinition, which never needed a Name slot - and every failure of that test returned in
--           silence. Same failure class as the probe that died on its first tick: a check that never PASSES reads,
--           from the log, exactly like a check that never RUNS.
--           FIXED THREE WAYS. (1) TWO identity sources, not one: a group carrying the pin's `match` part is that
--           character; failing that, an instance whose own default definition is the pin's AND which owns exactly one
--           slot group is that character (1.8.9's rule, restored). Anything else is refused - which is still the
--           22:15:47 mass-pin guard. (2) EVERY rejection logs one line naming the owner and the reason, once per owner
--           per session (`recruit pin: skip <owner>: ...`), and every accepted character logs how it was identified
--           (`recruit pin: scoped to <owner> by ...`). (3) A per-pass census - `recruit pin: pass N: X instance(s)
--           seen, Y candidate(s), Z group(s), W pinned, V skipped, world=<name>` - printed on the first pass, whenever
--           the shape changes, and every 20th pass, so a silent no-op is not expressible any more.
--   (1.8.10) A SAFETY FIX FIRST: THE PIN WAS WRITING OVER OTHER CHARACTERS. Retail 2026-09-12 22:15:47 — the pin
--           matched BP_CustomizationProxyCharacter_C_1, collected 21 slots belonging to SEVEN pool characters
--           (Astromech, Scoundrel, Sniper, Soldier, Assault, LongStrider, the Sith), asked for 18 changes, and when
--           every equip route came back empty the setter wrote Sith parts over all of them: 33 writes across the two
--           proxies. Cause: a slot belonged to a target if its full name started with the INSTANCE path. A character
--           is a slot GROUP - the immediate parent of its slots. Slots are now keyed tag -> slot PER GROUP (so a
--           group can never exceed the pin's own tags), a group is only pinned when it CARRIES THE PIN'S IDENTITY
--           (the `match` slot holding the mod's own Name part), a pin with no identity rule may only pin an instance
--           that yields exactly ONE group, and a collection larger than the pin's declared slot count is REFUSED.
--           THE SAME SESSION PROVED THE SETTER DOES DELIVER FRAGMENTS, so 1.8.9's whole premise needed narrowing:
--           at 22:15:50 `SetCustomizationPartPrimaryAssetId` left Tactical.Primary at `partDefinition=
--           CPD_ZCSDK_TacticalSpec_Sith | 5 fragment instance(s) | 2 leveled tree(s)` and DELIVERED - two trees,
--           exactly what the cooked part carries. `LoadCustomization` rebuilds the fragment instances whenever the
--           part RESOLVES, and `GetCustomizationPartDefinitionFromPartId` (RVA 0x8c46060) asks the AssetManager for
--           the LOADED object first - so ASSET RESIDENCY is the variable, not the door. The gap that kept the Sith
--           broken: the setter only ran when the id DIFFERED, so a slot carrying our id from a session where the
--           asset was not yet resident (definition NULLed, 0 trees) was never re-driven. It is now, bounded by
--           PIN_MAX_RETRY, and a retry is only spent when a route actually ran.
--           MARSHALLING: both Lua-built containers and both Lua-built maps reached the native EMPTY in that session
--           (`arrival: 0/18 ... did NOT reach the native`, `returned true; OutOriginalParts = <nil>` on all four).
--           So nothing is built in Lua any more: the first container shape is the part asset's OWN
--           `FGameplayTagContainer AllowedSlots` (CustomizationPartDefinition.h:15) passed as a real struct
--           userdata - UE4SS's userdata path is a type-checked CopyCompleteValue - one call per pinned part.
--   (1.8.9) THE RECRUIT PIN'S SUCCESS CRITERION WAS WRONG, AND IT FAILED ITS OWN NEW ROUTE. 1.8.8 judged a slot
--           equipped only when CustomizationPartDefinition came back non-null. It is not a criterion in either
--           direction: the game's own CPD_TalentSpec_TheToughGuy reads partDefinition=<null> with one leveled tree
--           and draws a full row, and the id-only setter resolves a definition by itself once the asset is resident
--           (both in the 2026-09-12 21:28 session). The criterion is now the one thing only the WithFragments door
--           can do: the slot's FragmentInstances are REPLACED (object identity) or it gains LeveledAbilities /
--           LoadedLeveledAbilities entries — and the criterion itself is printed once per session.
--           A route is also no longer demoted on a pass where every pinned slot already held the requested id
--           (1.8.8 read that no-op as a refused marshalling and locked the session to legacy before the route had
--           run once on a real change); each pass prints the ARRIVAL observable — how many of the slots that were
--           asked to change now hold the requested partId — which is what separates an empty argument from a
--           populated one when the native returns true either way.
--           NEW FIRST ROUTE: UCustomizationStatics::EquipCustomizationDefinition(CustomizationInstance,
--           CustomizationDefinition, FGameplayTagContainer SlotsToEquip, out TMap) — the same WithFragments door
--           with no TMap INPUT at all, taking the definition object the pin already holds. Order:
--           EquipCustomizationDefinition -> EquipCustomizationParts -> the 1.8.7 setter, each judged by the
--           criterion above and the winner remembered. The fragment-carrying routes are STRATEGY-SIDE ONLY: in a
--           mission the characters are rebuilt from save data and the game re-equips them during load, so an
--           in-mission pin keeps 1.8.7 behaviour exactly.
--           ALSO IN 1.8.9, from the 2026-09-12 crash analysis (the crashes were the FocusProbe, not the loader,
--           but the same shape was here): UE4SS's GetClass / GetFName bindings do NOT test validity - they read
--           [obj+0x10] off the pointer, so a null/stale UObject is a native access violation that pcall CANNOT
--           catch. IsValid() is a pure [obj+0x70] != 0 test and is the only safe first ask. dumpObject now checks
--           IsValid before every GetClass / GetFName, and the vault saber's relight re-validates the three
--           captured components (blade / light / collision) before replaying them 350 ms and 900 ms later - a
--           window long enough for the wielder to be destroyed - and NAMES the one that went stale.
--   (1.8.8) THE RECRUIT PIN NOW PINS THROUGH A PATH THAT CREATES FRAGMENT INSTANCES. Every version through 1.8.7
--           called UCustomizationFragmentInstanceSlot::SetCustomizationPartPrimaryAssetId, which (RVA 0x8c54660)
--           writes the id, NULLS CustomizationPartDefinition, and iterates the EXISTING FragmentInstances without
--           replacing them — so a pinned spec's leveled-ability fragment could never reach the instance and the
--           Focus tree drew rails with no nodes (18 hub dumps, `fragment trees = 0`; CHANGELOG v1.28.32). The pin
--           now calls UCustomizationStatics::EquipCustomizationParts(CustomizationInstance,
--           TMap<FGameplayTag,FPrimaryAssetId>, out TMap) — a BlueprintCallable UFUNCTION whose parameter list was
--           READ OUT OF THE 196985 jmap, not guessed (the v1.28.29 lesson) — which routes through the
--           ...WithFragments sibling every game equip path uses. The 1.8.7 setter stays as the fallback, the route
--           that ran is named in the log (`PATH> <fn>`), and each pinned slot prints the probe's own
--           `partId | partDefinition | fragment count` reading BEFORE and AFTER. Success = a non-null
--           partDefinition; that is the one thing the old setter can never produce.
--   (1.8.7) THE FIX, WITH THE SIGNATURE READ RATHER THAN GUESSED. bpclass.py against the cooked package gives
--           ActivateLightsaber(Lightsaber Blade: StaticMeshComponent, BladeLight: PointLightComponent,
--           WeaponInteractionCollision: BoxComponent, Target Saber: Enum_LightsaberStateTarget) - and
--           DeactivateLightsaber takes THE IDENTICAL FOUR. So the extinguish hook is handed exactly what the
--           relight needs: capture the args on the way out, replay them on the way back in. Nothing is
--           reconstructed from the actor or guessed, which is what broke 1.8.0-1.8.5.
--           THIS MATTERS BEYOND ONE SAVE: every saber mod the SDK produces inherits the bug, so the fix belongs
--           in the runtime rather than in any one mod.
--   (1.8.6) THE 1.8.5 RELIGHT CALL IS WITHDRAWN - it threw on every vault. ActivateLightsaber takes FOUR
--           parameters and was called with none ("UFunction expected 4 parameters, received 0"); the function was
--           checked for EXISTENCE and never for SIGNATURE. The turn also would not end in that session - not yet
--           attributed (bKismetScriptError appears three minutes BEFORE the relight ran), which is exactly why
--           this version calls nothing at all. NEW EVIDENCE: HasMantled was TRUE when DeactivateLightsaber fired,
--           so the v1.28.4 discriminator was right all along and was only ever read on the wrong function. The
--           live hypothesis is that HasMantled is never CLEARED after a scripted traversal, so ActivateSaberCheck
--           still believes the wielder is mid-vault and declines. This version logs the state at every check.
--   (1.8.5) THE FIX, ON THE PROVEN TRIGGER. The 1.8.4 probe named the whole sequence in retail (2026-09-12):
--           first vault = DeactivateLightsaber + DeactivateSaberCheck; later vaults = DeactivateSaberCheck alone;
--           next turn = ActivateSaberCheck fires and DECLINES. ActivateLightsaber never runs again, so the blade
--           never returns. Hook moved to DeactivateLightsaber and relight() now calls ActivateLightsaber (four
--           versions called the generic `Activate`, which is not on the blade path at all). Discriminator is
--           bSaberAutoActivateForCombat - the game's own answer - with HasMantled logged rather than trusted.
--   (1.8.4) THE PATH PROBE: 1.8.3 proved `Deactivate` is NOT on the vault path (it never fired). The cooked class
--           exports 50 UFunctions including ActivateLightsaber / DeactivateLightsaber / *SaberCheck / Cinematic_*;
--           the fix has been aimed at the generic Activate/Deactivate pair for four versions. Log-only hooks on
--           every candidate, so the next vault names the real path instead of costing another guess.
--   (1.8.3) DIAGNOSTICS ONLY, no behaviour change: the 1.8.2 hook ARMED in retail (2026-09-11) and the blade still
--           went out on a vault, with nothing else logged - because all four guards in the hook body and both in
--           relight() were bare returns. Five distinct failures shared one silence. Each now names itself.
--   (1.8.2) THE VAULT SABER FIX, REDONE — the DIAGNOSIS of 1.8.0 was right, only its ARMING was wrong. RegisterHook
--           is now called AT MOST ONCE, guarded by a flag and reached only after StaticFindObject proves the saber
--           class is loaded; the loop only LOOKS and stops for good on the first attempt, so the registry-flooding
--           abort of 1.8.0 is structurally impossible. Verified offline first (see the block at the bottom): both
--           UFunctions and all three variables are real in the cooked packages. See CHANGELOG v1.28.16.
--   (1.8.1) THE VAULT SABER FIX OF 1.8.0 IS WITHDRAWN. It hooked BP_FX_LightSaber_Base_C's Deactivate, and because that
--           Blueprint is not loaded at the main menu the arming loop RETRIED RegisterHook every 5 s. Registration never
--           succeeded, the retries piled bad entries into UE4SS's Lua function registry, and the game aborted 175 s in at
--           the main menu ('[Lua::Registry::get_function_ref] Ref was not function', retail 2026-09-10 05:46).
--           LESSON: RegisterHook is NOT retry-safe — register once, from a callback that fires when the class actually
--           exists (NotifyOnNewObject), never on a timer. The diagnosis of the vault bug itself still stands (see
--           CHANGELOG v1.28.4): the saber actor caches `Cached Humanoid ABP` / `bIsActive` /
--           `bSaberAutoActivateForCombat`, which is everything the fix needs — only the ARMING has to be redone.
--   (1.7.0) the recruit-pin loop no longer sweeps EVERY object twice, every 3 s, in every world, for as long as a pin exists.
--           It used to run unchanged inside tactical missions, where nothing can be pinned — 2 x FindAllOf on the game thread
--           forever. Two guards: the expensive CustomizationFragmentInstanceSlot sweep runs only when there is something to
--           pin, and the loop backs off 3 -> 6 -> 12 -> 24 s while nothing changes, resetting on a world change or a pin.
--           (Found chasing a GameThread HANG inside UE4SS's Lua, 2026-09-09/10: same stack in HUB_Root and in a Ryloth
--           mission, ~29 min in each time. Not proven to be the cause — but an unbounded per-frame object sweep on the game
--           thread is a defect either way, and it is the only thing this runtime does forever.)
--   (1.6.0) manifests are also discovered in SWZeroCompany/Mods/<Mod>/ (the game's own mod layout, SDK "gfp"): their registry is the
--           plugin's (not injected); refreshers, follow-ups, recruit pins, grants, rescans apply. Needs bridge 0.5.3 (depth-1 scan).
--   (1.5.0) recruitPins[].match = { slot=, part= }: pins also apply to live characters identified by a slot holding a part (a recruited
--   character carries no CustomizationDefinition, so `definition` alone never reaches it after recruitment).
--   5. (1.4.0) recruit pins: keeps the listed customization slots of every live character spawned from a manifest's
--      CustomizationDefinition set to the listed parts (the game re-rolls a pool recruit's specialization / weapon on every
--      Recruitment refresh) — see applyRecruitPins.
--   3d. runs each manifest's `refreshers` (native calls on live objects: data registries re-scan the injected registry) and the
--       game-specific follow-ups (character pools re-created; 1.3.0, bridge 0.5 `callfname`),
--
-- What it does, once the main-menu world is up:
--   1. arms the bridge (writes the PrintString trigger address to ue4ss/ZCSDKBridge.ctl),
--   2. discovers content-mod manifests  <Mod>.zcsdk.lua  in Content/Paks and Content/Paks/~mods,
--   3. ROUTE B: injects each mod's <Mod>.AssetRegistry.bin into the live asset registry (enumeration),
--   3b. preloads each manifest's `preload` packages (net-new classes resident like the game's own; 1.2.0),
--   3c. rescans each manifest's `primaryTypes` and refreshes the game's per-type caches (1.1.0),
--   4. when a campaign HQ inventory exists, grants each manifest's `grants` items ONCE per save
--      (skipped if the save has ever owned the item), so net-new items show up in the armory/inventory.
--
-- Manifest (emitted by zcmod-build.js next to the pak trio):
--   return { name = "My Mod", version = "1.0.0", registry = "MyMod.AssetRegistry.bin",
--            primaryTypes = { { type = "CustomizationPartDefinition", path = "/Game/ZCSDK", class = "...", blueprintClasses = false } },
--            preload = { "/Game/ZCSDK/GA_MyPassive" },
--            grants = { { item = "/Game/ZCSDK/DA_X.DA_X", amount = 1 } } }
--   (1.8.35) a grant may carry setting = "<key>", declared once as settings = { <key> = { default = true, section = "Settings" } }:
--            delivered only while the setting resolves ON (block GRANT SETTINGS, before discover).
-- Log: ue4ss/ZCSDKLoader.log. Bridge log: ue4ss/ZCSDKBridge.log.
local UEHelpers = require("UEHelpers")

-- SDK dev builds only: also dump item properties (the real scope mod + ours) for schema comparison.
-- Leave OFF for players: reading a TSoftObjectPtr property of a freshly loaded net-new item through
-- UE4SS's Lua binding crashed the game (null deref inside UE4SS.dll, 2026-09-04) — soft props are now
-- skipped in dumpObject, but the dump is diagnostics, not a feature.
local DIAG = false

-- ---- paths (relative to the game's Binaries/Win64; the bridge resolves $paks / $mods itself) ----
-- 1.8.32: NO PROCESS SPAWN. 1.0-1.8.31 asked `io.popen("cd")`, which starts cmd.exe - the console window that flashed open
-- at every game launch. The Win64 folder now comes from this script's OWN path (UE4SS loads it as
-- <Win64>/ue4ss/Mods/ZCSDKLoader/Scripts/main.lua), then from the game's working directory (normally Win64) by a relative
-- open. Each answer is trusted only if ue4ss/UE4SS-settings.ini opens under it (the v1.28.32 FocusProbe lesson).
-- tools/selftest_loader.py refuses io.popen / os.execute anywhere in this file. 1.8.54 (security review L-1): the
-- last-resort fallback to a fixed install path is gone (it named one machine's drive layout and, on any other machine,
-- pointed every log and ctl write at a folder that does not exist). No answer = one print line and the loader stands down.
local function detectWin64()
    local function valid(p)
        local f = io.open(p .. "/ue4ss/UE4SS-settings.ini", "r"); if f then f:close(); return true end
        return false
    end
    local src = nil
    pcall(function() src = debug.getinfo(1, "S").source end)
    if type(src) == "string" then
        src = src:gsub("^@", ""):gsub("\\", "/")
        local base = src:match("^(.+)/[Uu][Ee]4[Ss][Ss]/[Mm]ods/[^/]+/[Ss]cripts/[^/]+$")
                     or src:match("^(.+)/[Mm]ods/[^/]+/[Ss]cripts/[^/]+$")
        if base and valid(base) then return base end
    end
    if valid(".") then return "." end
    return nil
end
local WIN64 = detectWin64()
if not WIN64 then
    print("[ZCSDKLoader] cannot find the game's Binaries/Win64 folder (no ue4ss/UE4SS-settings.ini beside this script or in the " ..
          "working directory) - the loader stands down this session and no SDK mod is loaded\n")
    do return end
end
local UE4SS = WIN64 .. "/ue4ss/"
local LOGFILE = UE4SS .. "ZCSDKLoader.log"

-- 1.8.54 (security review L-2): the log was appended across launches without limit. The FIRST line of a session moves the
-- last session's file to ZCSDKLoader.prev.log (overwriting it) and starts a fresh one.
local log
do
    local rotated = false
    function log(m)
        local line = "[ZCSDKLoader] " .. tostring(m); print(line .. "\n")
        if not rotated then
            rotated = true
            local prev = UE4SS .. "ZCSDKLoader.prev.log"
            pcall(os.remove, prev); pcall(os.rename, LOGFILE, prev)
        end
        local f = io.open(LOGFILE, "a"); if f then f:write(os.date("%H:%M:%S ") .. line .. "\n"); f:close() end
    end
end
-- ---- 1.8.27: THE CHEAP WORLD READ (begin; tools/replay_pump.py extracts this block verbatim) ----
-- WHY. UEHelpers.GetWorld() is GetPlayerController():GetWorld(), and UEHelpers.GetPlayerController() is
-- FindAllOf("PlayerController") - a walk of the whole GUObjectArray on EVERY call. Retail 1.8.26 (ZCSDKLoader.log
-- 2026-09-29/30) logged every task that reads the world at 50-170 ms per frame: arm ~60, saber ~80, rowfix ~100, the
-- idle main-menu pin ~65, and each bridge() command paid it too. The engine's viewport holds the world in a reflected
-- property (jmap: Engine.GameViewport @3128, GameViewportClient.World @120) and UEHelpers caches the Engine (one
-- FindFirstOf, and the engine is never collected), so the read is three property accesses. UEHelpers.GetWorld() is
-- the fallback for when that chain is empty (before the viewport exists). Nothing is cached here: the WORLD is re-read
-- on every call, so no UObject crosses a frame.
local WORLDREAD = { cheap = 0, fallback = 0 }
local function gameWorld()
    local w = nil
    pcall(function()
        local vp = UEHelpers.GetEngine().GameViewport
        local ww = vp and vp.World
        if ww and ww:IsValid() then w = ww end
    end)
    if w ~= nil then WORLDREAD.cheap = WORLDREAD.cheap + 1; return w end
    WORLDREAD.fallback = WORLDREAD.fallback + 1
    return UEHelpers.GetWorld()
end
-- ---- 1.8.27: THE CHEAP WORLD READ (end) ----
-- 1.8.54: the main chunk's CP table is declared here (it was declared after the diagnostics) so the bridge wrapper keeps its
-- session state on it (CP.BR, the BRIDGE SESSION block below) without a new file-scope local.
local CP = {}
-- THE ONLY SENDER of bridge commands (tools/selftest_loader.py pins that PrintString is called nowhere else). Every caller
-- writes "ZCSDK:<verb>|..."; CP.BR.wire adds the session token. The log line keeps the caller's form (no token in the log).
local function bridge(cmd)
    log("BRIDGE> " .. cmd)
    local wire = CP.BR.wire(cmd)
    local ok, err = pcall(function()
        UEHelpers.GetKismetSystemLibrary():PrintString(gameWorld(), wire, false, false, {R=1,G=1,B=1,A=1}, 0.0, FName("None"))
    end)
    if not ok then log("bridge call failed: " .. tostring(err)) end
end
local function setTrigger()
    local fn = StaticFindObject("/Script/Engine.KismetSystemLibrary:PrintString")
    if not (fn and fn:IsValid()) then log("PrintString UFunction not found"); return false end
    CP.BR.token = CP.BR.token or CP.BR.newToken()
    pcall(os.remove, UE4SS .. "ZCSDKBridge.ack")
    local f = io.open(UE4SS .. "ZCSDKBridge.ctl", "w"); if not f then log("cannot write ZCSDKBridge.ctl"); return false end
    f:write(CP.BR.ctl(fn:GetAddress())); f:close()
    log(string.format("trigger @ 0x%x (session token written)", fn:GetAddress()))
    return true
end
-- 1.8.54 (security review L-3): at most 256 KB of the file is read
local function readLines(path)
    local out = {}
    local f = io.open(path, "rb"); if not f then return out end
    local text = f:read(262144) or ""; f:close()
    for line in (text .. "\n"):gmatch("([^\n]*)\n") do
        line = line:gsub("^\239\187\191", ""):gsub("\r+$", ""); if line ~= "" then out[#out + 1] = line end
    end
    return out
end
-- ---- 1.8.54: BRIDGE SESSION (begin; tools/selftest_manifest_load.py extracts this block verbatim) ----
-- Bridge 0.7.3 protocol (ZCSDK-bridge-protocol-0.7.3 spec; security review I-1 / M-4):
--   * a per-session TOKEN (16 hex characters) is written into ZCSDKBridge.ctl beside trigger=, and every command goes out as
--     ZCSDK@<token>:<verb>|... - built in ONE place, bridge() above;
--   * the bridge ACKs the arm in ue4ss/ZCSDKBridge.ack (ack=<token>): the loader deletes that file before it writes the ctl
--     and waits for it on the pump (CP.BR.waitAck, a startup step that re-runs, no blocking sleep), at most CP.BR.ACK_S;
--   * every SCAN carries a request id; ZCSDKBridge.scan is deleted before each request and its first line must be #scan|<id>
--     (a first line that is not #scan| = a bridge older than 0.7.3: accepted with one warning, the file was just deleted).
-- No ack in time (missing, older than 0.7.3, or blocked): one line, and the commands go out in the bare pre-0.7.3 form
-- (ZCSDK:<verb>|...), so a mixed install still loads mods (a 0.7.3 release bridge ignores bare commands).
CP.BR = { token = nil, acked = false, bare = false, ackAt = nil, ACK_S = 15, reqN = 0, warnedOld = false, clock = os.time }
function CP.BR.newToken()
    local seed = os.time() + math.floor((os.clock() * 1000000) % 1000000)
    local addr = tostring({}):match("0x(%x+)") or tostring({}):match("(%x+)$") or ""
    for i = 1, #addr, 6 do seed = seed ~ (tonumber(addr:sub(i, i + 5), 16) or 0) end
    math.randomseed(seed)
    local t = {}
    for i = 1, 16 do t[i] = string.format("%x", math.random(0, 15)) end
    return table.concat(t)
end
-- the wire form of a command: "ZCSDK:<verb>|..." -> "ZCSDK@<token>:<verb>|..." (bare before a token exists or after no ack)
function CP.BR.wire(cmd)
    local BR = CP.BR
    if BR.token and not BR.bare and cmd:sub(1, 6) == "ZCSDK:" then return "ZCSDK@" .. BR.token .. ":" .. cmd:sub(7) end
    return cmd
end
-- the ctl body: trigger=<hex> + token=<16 hex>
function CP.BR.ctl(addr) return string.format("trigger=%x\ntoken=%s\n", addr, CP.BR.token) end
-- -> nil when the ack is in (or the wait is over), else the seconds until the next look (a startup step re-runs on a number)
function CP.BR.waitAck()
    local BR = CP.BR
    if BR.acked or BR.bare then return nil end
    if not BR.token then BR.bare = true; log("bridge: no session token (the trigger was not written) - commands go out in the pre-0.7.3 form"); return nil end
    local f = io.open(UE4SS .. "ZCSDKBridge.ack", "rb")
    if f then
        local s = f:read(256) or ""; f:close()
        if s:match("ack=(%x+)") == BR.token then BR.acked = true; log("bridge acknowledged the session (bridge 0.7.3 protocol)"); return nil end
    end
    BR.ackAt = BR.ackAt or BR.clock()
    if BR.clock() - BR.ackAt >= BR.ACK_S then
        BR.bare = true
        log("bridge did not acknowledge (missing, older than 0.7.3, or blocked) - commands go out in the pre-0.7.3 form, best effort")
        return nil
    end
    return 0.25
end
-- one directory listing through the bridge: root, a file pattern, depth 0/1 -> the paths (this request's answer only)
function CP.BR.scan(root, pattern, depth)
    local BR = CP.BR
    BR.reqN = BR.reqN + 1
    local id = tostring(BR.reqN) .. "." .. tostring(BR.token or "0")
    local path = UE4SS .. "ZCSDKBridge.scan"
    pcall(os.remove, path)
    bridge("ZCSDK:scan|" .. root .. "|" .. pattern .. "|" .. ((depth == 1) and "1" or "0") .. "|" .. id)
    local lines = readLines(path)
    local first = lines[1]
    if first == nil then return {} end
    if first:sub(1, 6) == "#scan|" then
        if first:sub(7) ~= id then
            log("scan " .. root .. " [" .. pattern .. "]: the answer belongs to another request (" .. first:sub(7) .. ") - no answer")
            return {}
        end
        table.remove(lines, 1)
        return lines
    end
    if not BR.warnedOld then
        BR.warnedOld = true
        log("scan: the bridge's answer has no request id (a bridge older than 0.7.3) - accepted, it was deleted before the request")
    end
    return lines
end
-- ---- 1.8.54: BRIDGE SESSION (end) ----
local function dirOf(p) return (p:match("^(.*)/[^/]*$")) or "." end

-- ---- diagnostics: dump every reflected property of an object (class chain), one level into arrays/objects ----
local function fmtValue(v, depth)
    if type(v) ~= "userdata" then return tostring(v) end
    local ok, s
    ok, s = pcall(function() return v:GetFullName() end); if ok and type(s) == "string" then return s end
    ok, s = pcall(function() return v:ToString() end); if ok and type(s) == "string" then return s end
    if depth < 1 then
        local items = {}
        local okArr = pcall(function() v:ForEach(function(i, e)
            local ev = e; pcall(function() ev = e:get() end)
            items[#items + 1] = fmtValue(ev, depth + 1)
        end) end)
        if okArr and #items > 0 then return "[" .. table.concat(items, ", ") .. "]" end
        local okTags = pcall(function() v.GameplayTags:ForEach(function(i, e)
            local t = e:get(); items[#items + 1] = t.TagName:ToString()
        end) end)
        if okTags and #items > 0 then return "{tags: " .. table.concat(items, ", ") .. "}" end
    end
    return "<" .. tostring(v) .. ">"
end
-- 1.8.9 (the 2026-09-12 crash analysis): UE4SS's `GetClass` / `GetFName` bindings do NOT test validity - they read
-- [obj+0x10] (UObjectBase::ClassPrivate) straight off the pointer, so calling either on a null/stale UObject is a
-- native access violation that `pcall` CANNOT catch (it is a hardware fault, not a Lua error). `IsValid()` is a pure
-- [obj+0x70] != 0 test and is the only safe thing to ask first; `GetFullName()` is guarded internally and returns nil.
-- Two game crashes in that session came from exactly this shape in ZCSDK_FocusProbe. RULE: IsValid, then GetClass.
local function uvalid(o)
    if o == nil then return false end
    local t = type(o)
    if t ~= "userdata" and t ~= "table" then return false end
    local ok, r = pcall(function() return o.IsValid and o:IsValid() end)
    return (ok and r) and true or false
end
local function dumpObject(obj, label, depth)
    depth = depth or 0
    if not uvalid(obj) then log(label .. ": object not valid (GetClass would fault)"); return end
    local okc, cls = pcall(function() return obj:GetClass() end)
    if not okc or not uvalid(cls) then log(label .. ": no class"); return end
    log(label .. "  class=" .. cls:GetFullName() .. "  obj=" .. obj:GetFullName())
    local c = cls
    local subobjects = {}
    while uvalid(c) do
        local okp, errp = pcall(function()
            c:ForEachProperty(function(prop)
                if not uvalid(prop) then log(string.rep("  ", depth + 1) .. "<invalid FProperty skipped>"); return end
                local name = ""; pcall(function() name = prop:GetFName():ToString() end)
                if name == "" then log(string.rep("  ", depth + 1) .. "<unnamed FProperty skipped>"); return end
                local pcls = ""
                pcall(function() local pc = prop:GetClass(); if uvalid(pc) then pcls = pc:GetFName():ToString() end end)
                if pcls:find("Soft") then log(string.rep("  ", depth + 1) .. name .. " = <" .. pcls .. " skipped>"); return end
                local ok, v = pcall(function() return obj[name] end)
                local s = ok and fmtValue(v, 0) or ("<err " .. tostring(v) .. ">")
                log(string.rep("  ", depth + 1) .. name .. " = " .. s)
                if ok and depth == 0 and type(v) == "userdata" then
                    pcall(function() v:ForEach(function(i, e)
                        local ev = e; pcall(function() ev = e:get() end)
                        if uvalid(ev) and pcall(function() return ev:GetClass() end) then subobjects[#subobjects + 1] = { ev, name .. "[" .. tostring(i) .. "]" } end
                    end) end)
                end
            end)
        end)
        if not okp then log("  (ForEachProperty failed on " .. tostring(c:GetFullName()) .. ": " .. tostring(errp) .. ")") end
        local oks, sup = pcall(function() return c:GetSuperStruct() end)
        c = oks and sup or nil
    end
    for _, so in ipairs(subobjects) do pcall(dumpObject, so[1], string.rep("  ", depth + 1) .. so[2], depth + 1) end
end

-- ---- manifests + registries ----
local manifests = {}   -- { path=, dir=, m=table }
local grants = {}      -- { item=, amount=, from=, done=bool }
local recruitPins = {} -- 1.4.0: { definition=<CustomizationDefinition object path>, slots={ {tag=, part=<part object path>} }, from= }
-- 1.8.27: the class-mod runtime's state and functions (requires[], classPool, the Recruitment watcher, the pin's accept-sets
-- and dormancy). ONE table because the main chunk sits near Lua's 200-local limit. `local CP` is declared above bridge()
-- (1.8.54); its functions are defined inside the recruit-pin block (tools/replay_pin.py / replay_recruit.py extract them).
local injected = false
-- ---- 2026-10-13: ZCU BRIDGE (begin; tools/replay_zcubridge.py extracts this block verbatim) ----
-- One zip per mod (docs/ZCUNLOCKED_BRIDGE.md §8.2): a gfp mod's zip may carry a pak-less ZC Unlocked pack
-- ue4ss/Mods/<Folder>/addon.ini whose [addon] says bridge=<ModId> (tools/zcu_addon_from_gfp.js --ini-only). When ZC Unlocked
-- is installed AND enabled and that pack is live, ZC Unlocked lists the mod's items from the pack's rows, so this runtime
-- must NOT list them a second time. The ONLY thing skipped is the listing: the mod's primaryTypes rescan (and its share of
-- the per-type cache refresh). The gfp container is still mounted by the game, and preload, refreshers, follow-ups,
-- recruit pins, requires and grants run as before. The switch: addon_<Folder>=0 is only LOGGED (retail 2026-10-14, below): ZC
-- Unlocked alone decides the listing and the grants stay, until its own section for the key is confirmed.
-- No ZC Unlocked, ZC Unlocked not enabled, addons=0 / addons_mods=0, no bridge, or [addon] enabled=0 = exactly as before.
-- Layouts searched: 2 (ue4ss/Mods/<Folder>/addon.ini, where the zip installs it) and 1 (Mods/ZCUnlocked/addons/<Folder>/).
-- Layouts 3/4 (a manager's wrapper folder) need a depth-2/3 bridge scan the DLL does not have: such a bridge is not seen
-- and the SDK lists the items itself (the safe side: shown twice, never hidden).
CP.ZCU = { DIR = "Mods/ZCUnlocked/" }
function CP.zcuIni(text, section, key)              -- last value of key (in section, or anywhere when section is nil)
    local sec, found = "", nil
    for raw in ((text or "") .. "\n"):gmatch("([^\r\n]*)\r?\n") do
        local line = raw:gsub("^\239\187\191", ""):gsub("%s*[;#].*$", ""):match("^%s*(.-)%s*$") or ""
        local s = line:match("^%[%s*(.-)%s*%]$")
        if s then sec = s:lower()
        elseif section == nil or sec == section:lower() then
            local k, v = line:match("^([^=]-)%s*=%s*(.*)$")
            if k and k:lower() == key:lower() then found = v end
        end
    end
    return found
end
function CP.zcuText(path)                          -- 1.8.54 (L-3): at most 256 KB
    local f = io.open(path, "rb"); if not f then return nil end
    local s = f:read(262144); f:close(); return s or ""
end
function CP.zcuSwitch(folder) return "addon_" .. (folder:gsub("[^A-Za-z0-9_]", "_")) end
-- installed AND enabled, the same test as RF.zcuCheck (the ROWFIX block): dlls/main.dll + (mods.txt `ZCUnlocked : 1` | enabled.txt)
function CP.zcuInstalled()
    local dir = UE4SS .. CP.ZCU.DIR
    local f = io.open(dir .. "dlls/main.dll", "rb"); if not f then return false, "ZC Unlocked is not installed" end
    f:close()
    for _, l in ipairs(readLines(UE4SS .. "Mods/mods.txt")) do
        if l:match("^%s*ZCUnlocked%s*:%s*1%s*$") then return true end
    end
    f = io.open(dir .. "enabled.txt", "rb"); if f then f:close(); return true end
    return false, "ZC Unlocked is installed but not enabled"
end
-- ---- 1.8.53: ZCU SESSION LOG (begin; tools/replay_zcubridge.py + tools/replay_pump.py extract this block verbatim) ----
-- ZCUnlocked.log is APPENDED across launches (retail 2026-11-10: 72 MB, its head from early October), so its head is not this
-- launch's account. CP.zcuSession reads only the TAIL (CP.ZCU.TAIL bytes; a cut first line is dropped) and keeps the part from
-- the LAST session start: a `[ZCUnlocked] ue4ss: version` / `ue4ss: detected=` line, backed up over a header run printed just
-- before it (a launch can print the version / exe-stamp pair twice). No marker in the tail = the whole tail is this session.
-- ZC Unlocked starts before any Lua mod, so its refusal and its armed lines are written by the time the loader reads.
-- -> state ("refused" | "armed" | "unknown" | "nolog"), this session's text (nil with "nolog")
CP.ZCU.TAIL = 1024 * 1024
CP.ZCU.LOGS = { "dlls/ZCUnlocked.log", "ZCUnlocked.log" }
function CP.zcuSessionOf(text)
    local start, head = 1, false
    for p, line in (text .. "\n"):gmatch("()([^\n]*)\n") do
        local mark = line:find("^%[ZCUnlocked%] ue4ss: version") or line:find("^%[ZCUnlocked%] ue4ss: detected=")
        if mark and not head then start = p end
        head = (mark or (head and (line:find("^%[ZCUnlocked%] ue4ss: ") or line:find("^%[ZCUnlocked%] game: ")))) and true or false
    end
    return text:sub(start)
end
function CP.zcuSession()
    local lg = nil
    for _, rel in ipairs(CP.ZCU.LOGS) do
        local f = io.open(UE4SS .. CP.ZCU.DIR .. rel, "rb")
        if f then
            local size = f:seek("end") or 0
            local cut = size > CP.ZCU.TAIL
            f:seek("set", cut and (size - CP.ZCU.TAIL) or 0)
            lg = f:read(CP.ZCU.TAIL) or ""; f:close()   -- 1.8.54 (L-3): a bounded read
            if cut then local nl = lg:find("\n", 1, true); lg = nl and lg:sub(nl + 1) or "" end
            break
        end
    end
    if not lg then return "nolog", nil end
    local s = CP.zcuSessionOf(lg)
    -- 1.8.54 (security review L-5): the refusal line carries no exe stamp (`[ZCUnlocked] refused: unsupported game build`;
    -- the stamp is on the `game: exe build stamp` header line before it), so the match stays bound to THIS session's text
    -- (the session marker above) and nothing else.
    if s:find("%[ZCUnlocked%] refused:[^\n]*unsupported") then return "refused", s end
    return (s:find(" armed", 1, true) and "armed" or "unknown"), s
end
-- ---- 1.8.53: ZCU SESSION LOG (end) ----
function CP.zcuBridge()
    local gfps = {}
    for _, mf in ipairs(manifests) do if mf.gfp then gfps[#gfps + 1] = mf end end
    if #gfps == 0 then return 0 end
    local ok, why = CP.zcuInstalled()
    if not ok then log("zcu-bridge: " .. why .. " - the SDK lists every gfp mod's items itself"); return 0 end
    local ini = CP.zcuText(UE4SS .. CP.ZCU.DIR .. "dlls/settings.ini") or ""
    if CP.zcuIni(ini, nil, "addons") == "0" then log("zcu-bridge: ZC Unlocked addons=0 (its add-on lane is off) - the SDK lists every gfp mod's items itself"); return 0 end
    local mods = CP.zcuIni(ini, nil, "addons_mods") ~= "0"   -- 0 = ZC Unlocked searches layout 1 only
    local packs = {}                                           -- lower(mod id) -> { folder =, path = }
    for _, root in ipairs({ "$ue4ss/Mods", "$ue4ss/" .. CP.ZCU.DIR .. "addons" }) do
        if mods or root:find("addons", 1, true) then
            for _, p in ipairs(CP.BR.scan(root, "addon.ini", 1)) do
                local d = dirOf((p:gsub("\\", "/")))
                local folder = d:match("([^/]+)$")
                local lo = d:lower()
                if folder and not lo:match("/ue4ss/mods$") and not lo:match("/zcunlocked/addons$") then
                    local text = CP.zcuText(p) or ""
                    local mod = CP.zcuIni(text, "addon", "bridge")
                    -- 1.8.54 (security review L-4): a pack counts for mod <id> only from a folder named <id> or <id>_ZCU, and a
                    -- second pack claiming an id already claimed is logged (the first one found keeps it)
                    local fl = folder:lower()
                    if mod and mod ~= "" and fl ~= mod:lower() and fl ~= mod:lower() .. "_zcu" then
                        log("zcu-bridge: pack " .. folder .. " names bridge=" .. mod .. " but its folder is not " .. mod .. " or " .. mod ..
                            "_ZCU - ignored, the SDK lists " .. mod .. " itself")
                    elseif mod and mod ~= "" then
                        if CP.zcuIni(text, "addon", "enabled") == "0" then
                            log("zcu-bridge: pack " .. folder .. " (bridge=" .. mod .. ") has [addon] enabled=0 - ZC Unlocked hides it, the SDK lists " .. mod .. " itself")
                        elseif not packs[mod:lower()] then
                            packs[mod:lower()] = { folder = folder, path = p, mod = mod }
                        elseif packs[mod:lower()].path ~= p then
                            log("zcu-bridge: WARN packs " .. packs[mod:lower()].folder .. " and " .. folder .. " both claim " .. mod ..
                                " - " .. packs[mod:lower()].folder .. " (found first) is used")
                        end
                    end
                end
            end
        end
    end
    local n, off, used, zst = 0, {}, {}, nil
    for _, mf in ipairs(gfps) do
        local id = (mf.path:gsub("\\", "/"):match("([^/]+)%.zcsdk%.lua$") or ""):lower()
        local gf = (mf.dir:gsub("\\", "/"):match("([^/]+)$") or ""):lower()
        local pk = packs[id] or packs[gf]
        -- 1.8.53 (retail 2026-11-10, game CL 201250): a ZC Unlocked that REFUSED this game build arms nothing and lists no
        -- pack, so a bridged mod showed 0/55 items. Its session log is read once, on the first matched pack.
        if pk and zst == nil then zst = CP.zcuSession() end
        if pk and zst == "refused" then
            used[pk] = true
            log("zcu-bridge: ZC Unlocked refused this game build - the SDK lists " .. pk.mod .. " itself")
        elseif pk then
            used[pk] = true; n = n + 1
            local sw = CP.zcuSwitch(pk.folder)
            -- 2026-10-14 retail P3: a [Creator] addon_<Folder>=0 was NOT read by ZC Unlocked's pack switch (it kept listing all
            -- 120 items) while this block called the mod OFF and dropped its grants. Until ZC Unlocked's own section for the key
            -- is confirmed, the switch is only logged: ZC Unlocked decides the listing and the grants stay (fail safe = ON).
            if CP.zcuIni(ini, nil, sw) == "0" then
                mf.zcu = { folder = pk.folder }
                log("zcu-bridge: " .. pk.mod .. " - " .. sw .. "=0 seen in ZC Unlocked's settings.ini, not trusted (its section is unconfirmed); ZC Unlocked decides the listing, the SDK skips its rescan and keeps its grants")
            else
                mf.zcu = { folder = pk.folder }
                log("zcu-bridge: " .. pk.mod .. " listed by ZC Unlocked (pack " .. pk.folder .. ") - the SDK skips its primaryTypes rescan")
            end
        end
    end
    for _, pk in pairs(packs) do
        if not used[pk] then log("zcu-bridge: pack " .. pk.folder .. " names " .. pk.mod .. ", which has no gfp manifest here - nothing to settle") end
    end
    if next(off) then
        for i = #grants, 1, -1 do if off[grants[i].src] then table.remove(grants, i) end end
    end
    -- a rescan covers a PATH, not a mod: an unbridged manifest rescanning the same type over the same path lists the bridged items too
    for _, mf in ipairs(manifests) do
        if mf.zcu then
            for _, pt in ipairs(type(mf.m.primaryTypes) == "table" and mf.m.primaryTypes or {}) do
                for _, o in ipairs(manifests) do
                    if not o.zcu then
                        for _, q in ipairs(type(o.m.primaryTypes) == "table" and o.m.primaryTypes or {}) do
                            if q.type == pt.type and q.path == pt.path then
                                log("zcu-bridge: WARN " .. tostring(pt.type) .. " over " .. tostring(pt.path) .. " is still rescanned for " .. tostring(o.m.name) .. " - " .. tostring(mf.m.name) .. "'s items under it may be listed twice")
                            end
                        end
                    end
                end
            end
        end
    end
    return n
end
-- ---- 2026-10-13: ZCU BRIDGE (end) ----
-- ---- 2026-10-17: GRANT SETTINGS (begin; tools/replay_zcubridge.py extracts this block verbatim) ----
-- A grant with setting = "<key>" (SDK def "settings" + grants[].setting, tools/zcmod-packsettings.js) is delivered only when the
-- setting resolves ON. Order: (1) ZC Unlocked's dlls/settings.ini, when ZC Unlocked is installed AND enabled and the key is
-- there - read in ANY section, because the section ZC Unlocked stores a pack's [setting:<key>] row under is UNCONFIRMED (the
-- addon_<Folder> / [Creator] lesson, docs/ZCUNLOCKED_BRIDGE.md 8.2); (2) the pack's own settings.ini [<section>] (gfp:
-- Mods/<Mod>/settings.ini, paks: <Mod>.settings.ini); (3) the manifest default (absent: ON, as ZC Unlocked counts an undeclared
-- key). 1/true/on/yes and any non-zero number = ON; 0/false/off/no = OFF; anything else is logged and the next source decides.
-- Resolved once per mod + key per session, when the first HQ is found (so a menu change before loading a save counts), one log
-- line each. Grants stay once per save: OFF withholds what is not yet granted and never removes an item already owned.
CP.GS = { seen = {} }
function CP.gsBool(v)
    local s = tostring(v or ""):lower():match("^%s*(.-)%s*$")
    if s == "1" or s == "true" or s == "on" or s == "yes" then return true end
    if s == "0" or s == "false" or s == "off" or s == "no" then return false end
    local n = tonumber(s); if n then return n ~= 0 end
    return nil
end
function CP.grantSettingOn(g)
    local key, mf = g.setting, g.mf or {}
    local id = tostring(g.src) .. "|" .. key:lower()
    local c = CP.GS.seen[id]; if c ~= nil then return c end
    local m = type(mf.m) == "table" and mf.m or {}
    local decl = type(m.settings) == "table" and m.settings[key] or nil
    local on, src, notes = nil, nil, {}
    if CP.zcuInstalled() then
        local v = CP.zcuIni(CP.zcuText(UE4SS .. CP.ZCU.DIR .. "dlls/settings.ini") or "", nil, key)
        if v ~= nil then
            on = CP.gsBool(v)
            if on == nil then notes[#notes + 1] = "ZC Unlocked " .. key .. "=" .. v .. " ignored" else src = "ZC Unlocked settings.ini" end
        end
    end
    if on == nil and mf.dir then
        local base = (tostring(mf.path or ""):match("([^/\\]+)%.zcsdk%.lua$")) or tostring(m.name)
        local path = mf.gfp and (mf.dir .. "/settings.ini") or (mf.dir .. "/" .. base .. ".settings.ini")
        local sec = type(decl) == "table" and type(decl.section) == "string" and decl.section or "Settings"
        local text = CP.zcuText(path)
        local v = text and CP.zcuIni(text, sec, key)
        if v ~= nil then
            on = CP.gsBool(v)
            if on == nil then notes[#notes + 1] = "settings.ini " .. key .. "=" .. v .. " ignored" else src = "the pack's settings.ini [" .. sec .. "]" end
        end
    end
    if on == nil then
        if type(decl) == "table" and type(decl.default) == "boolean" then on, src = decl.default, "the manifest default"
        else on, src = true, "not declared in the manifest: ON" end
    end
    CP.GS.seen[id] = on
    log("grant setting: " .. tostring(m.name) .. " " .. key .. " = " .. (on and "ON" or "OFF") .. " (" .. src .. ")"
        .. (#notes > 0 and ("; " .. table.concat(notes, "; ")) or "")
        .. (on and "" or " - its grants are withheld this session; items already granted stay"))
    return on
end
-- ---- 2026-10-17: GRANT SETTINGS (end) ----
-- ---- 1.8.54: DATA-ONLY MANIFESTS (begin; tools/selftest_manifest_load.py extracts this block verbatim) ----
-- WHY (security review 2026-11-12, H-1 / M-1..M-3 / L-6 / I-2). Up to 1.8.53 every *.zcsdk.lua found next to the paks or in
-- SWZeroCompany/Mods/<Mod>/ went through dofile: a file that players treat as part of a pak mod ran as Lua with io / os and
-- every UE4SS global. A manifest is now DATA: CP.MP.parse reads the file as TEXT and accepts exactly what zcmod-build writes,
-- and nothing is ever executed (no load / loadstring / loadfile / dofile anywhere in this file; tools/selftest_loader.py pins it).
-- THE GRAMMAR. Optional `--` line comments (anywhere between tokens), `return`, ONE table constructor, an optional `;`. Fields:
-- `name = v`, `[<string or number>] = v`, or a positional `v`, separated by `,` or `;` (a trailing one allowed). Values:
-- "double" or 'single' quoted strings (Lua's escapes \n \t \r \a \b \f \v \\ \" \' \xXX \ddd \u{XXX}; JSON's \uXXXX and \/
-- are NOT Lua and dofile refused them too), decimal numbers (integer / decimal / exponent, a leading minus), true, false, nil,
-- and nested tables. REFUSED: calls, operators, `..`, a name used as a value, long brackets ([[ ]], --[[ ]]), function, a
-- bytecode chunk, a file over 4 MB, nesting over 32, over 500k tokens. Entries behave as in Lua's constructor: a later duplicate
-- key overwrites, a nil value drops the key, positional items are stored in batches of 50 after the keyed ones between them.
-- The result is plain tables (no metatables). tools/selftest_manifest_load.py proves the parse equals Lua's own result on every
-- installed and emitter-shaped manifest (the reference runs in the test only), and that a hostile corpus is refused.
-- A refused file: `manifest not supported (data-only manifests): <Mod>: <file>:<line>: <reason>`, and the other mods load.
CP.MP = { MAX_BYTES = 4 * 1024 * 1024, MAX_DEPTH = 32, MAX_TOKENS = 500000, FLUSH = 50, RESERVED = {},
          ESC = { n = "\n", t = "\t", r = "\r", a = "\a", b = "\b", f = "\f", v = "\v", ["\\"] = "\\", ['"'] = '"', ["'"] = "'" } }
for w in ("and break do else elseif end false for function goto if in local nil not or repeat return then true until while"):gmatch("%a+") do
    CP.MP.RESERVED[w] = true
end
-- UTF-8 of one code point up to 7FFFFFFF, byte for byte what Lua's lexer writes for \u{XXX} (luaO_utf8esc)
function CP.MP.utf8(x)
    if x < 0x80 then return string.char(x) end
    local out, mfb = {}, 0x3f
    repeat
        table.insert(out, 1, string.char(0x80 | (x & 0x3f)))
        x = x >> 6; mfb = mfb >> 1
    until x <= mfb
    table.insert(out, 1, string.char(((~mfb << 1) | x) & 0xFF))
    return table.concat(out)
end
-- text -> the table | nil, line, reason
function CP.MP.parse(s)
    local MP = CP.MP
    if type(s) ~= "string" then return nil, 0, "not text" end
    if #s > MP.MAX_BYTES then return nil, 0, "larger than 4 MB" end
    if s:sub(1, 4) == "\27Lua" then return nil, 1, "a precompiled (bytecode) chunk" end
    local pos, tokens = 1, 0
    if s:sub(1, 3) == "\239\187\191" then pos = 4 end
    local function fail(why) error({ mp = true, pos = pos, why = why }, 0) end
    local function tick() tokens = tokens + 1; if tokens > MP.MAX_TOKENS then fail("more than " .. MP.MAX_TOKENS .. " tokens") end end
    local function skip()
        while true do
            local _, e = s:find("^[ \t\r\n\f\v]+", pos)
            if e then pos = e + 1 end
            if s:sub(pos, pos + 1) ~= "--" then return end
            if s:find("^%[=*%[", pos + 2) then fail("a long comment (--[[ ]]); only -- line comments are supported") end
            pos = s:find("[\r\n]", pos + 2) or (#s + 1)
        end
    end
    local function str(q)
        pos = pos + 1
        local buf, stop = {}, (q == '"') and '[\\\r\n"]' or "[\\\r\n']"
        while true do
            local a = s:find(stop, pos)
            if not a then fail("an unterminated string") end
            buf[#buf + 1] = s:sub(pos, a - 1)
            local c = s:sub(a, a)
            if c == q then pos = a + 1; return table.concat(buf) end
            pos = a
            if c ~= "\\" then fail("an unterminated string (a line break inside quotes)") end
            local e = s:sub(a + 1, a + 1)
            if MP.ESC[e] then buf[#buf + 1] = MP.ESC[e]; pos = a + 2
            elseif e == "x" then
                local h = s:match("^%x%x", a + 2); if not h then fail("a bad \\x escape") end
                buf[#buf + 1] = string.char(tonumber(h, 16)); pos = a + 4
            elseif e:find("^%d") then
                local d = s:match("^%d%d?%d?", a + 1); local n = tonumber(d)
                if n > 255 then fail("a decimal escape above 255") end
                buf[#buf + 1] = string.char(n); pos = a + 1 + #d
            elseif e == "u" then
                local h = s:match("^{(%x+)}", a + 2)
                if not h then fail("a \\u escape without braces (JSON's \\uXXXX is not Lua; Lua writes \\u{XXXX})") end
                local hh = h:gsub("^0+", "")
                if #hh > 8 or (tonumber(hh ~= "" and hh or "0", 16) > 0x7FFFFFFF) then fail("a \\u escape above 7FFFFFFF") end
                buf[#buf + 1] = MP.utf8(tonumber(hh ~= "" and hh or "0", 16)); pos = a + 4 + #h
            else fail("an unsupported escape \\" .. e) end
        end
    end
    local function num()
        if s:sub(pos, pos) == "-" then
            pos = pos + 1; skip()
            if s:sub(pos, pos) == "-" then fail("a '-' that is not followed by a number") end
            return -num()
        end
        local a = pos
        while true do
            local c = s:sub(pos, pos)
            if c ~= "" and c:find("^[%w_%.]") then pos = pos + 1
            elseif (c == "+" or c == "-") and pos > a and s:sub(pos - 1, pos - 1):find("^[eE]") then pos = pos + 1
            else break end
        end
        local t = s:sub(a, pos - 1)
        local ok = t:find("^%d+%.?%d*$") or t:find("^%.%d+$") or t:find("^%d+%.?%d*[eE][%+%-]?%d+$") or t:find("^%.%d+[eE][%+%-]?%d+$")
        local n = ok and tonumber(t) or nil
        if n == nil then pos = a; fail(t == "" and "a '-' that is not followed by a number" or ("a malformed number '" .. t .. "' (decimal only)")) end
        return n
    end
    local tbl
    local function value(depth)
        skip(); tick()
        local c = s:sub(pos, pos)
        if c == "{" then return tbl(depth + 1)
        elseif c == '"' or c == "'" then return str(c)
        elseif c == "-" or c:find("^%d") or (c == "." and s:sub(pos + 1, pos + 1):find("^%d")) then return num()
        elseif c ~= "" and c:find("^[%a_]") then
            local nm = s:match("^[%a_][%w_]*", pos)
            if nm == "true" then pos = pos + 4; return true end
            if nm == "false" then pos = pos + 5; return false end
            if nm == "nil" then pos = pos + 3; return nil end
            fail(MP.RESERVED[nm] and ("the keyword '" .. nm .. "'") or ("a name used as a value ('" .. nm .. "')"))
        elseif c == "[" and s:find("^%[=*%[", pos) then fail("a long-bracket string ([[ ]])")
        elseif c == "" then fail("the end of the file where a value belongs")
        end
        fail("'" .. c .. "' where a value belongs (only strings, numbers, true / false / nil and tables)")
    end
    tbl = function(depth)
        if depth > MP.MAX_DEPTH then fail("tables nested deeper than " .. MP.MAX_DEPTH) end
        pos = pos + 1
        local t, pend, np, na = {}, {}, 0, 0
        local function flush()
            for i = 1, np do t[na + i] = pend[i]; pend[i] = nil end
            na = na + np; np = 0
        end
        while true do
            skip(); tick()
            local c = s:sub(pos, pos)
            if c == "}" then pos = pos + 1; break end
            if np == MP.FLUSH then flush() end
            if c == "[" and not s:find("^%[=*%[", pos) then
                pos = pos + 1
                local k = value(depth)
                if type(k) ~= "string" and type(k) ~= "number" then fail("a [key] that is not a string or a number") end
                skip(); if s:sub(pos, pos) ~= "]" then fail("']' expected after a [key]") end
                pos = pos + 1; skip()
                if s:sub(pos, pos) ~= "=" then fail("'=' expected after a [key]") end
                pos = pos + 1
                t[k] = value(depth)
            else
                local nm = (c ~= "" and c:find("^[%a_]")) and s:match("^[%a_][%w_]*", pos) or nil
                local keyed = false
                if nm and not MP.RESERVED[nm] then
                    local save = pos
                    pos = pos + #nm; skip()
                    if s:sub(pos, pos) == "=" and s:sub(pos + 1, pos + 1) ~= "=" then keyed = true; pos = pos + 1 else pos = save end
                end
                if keyed then t[nm] = value(depth)
                else np = np + 1; pend[np] = value(depth) end
            end
            skip()
            c = s:sub(pos, pos)
            if c == "," or c == ";" then pos = pos + 1
            elseif c == "}" then pos = pos + 1; break
            elseif c == "" then fail("the end of the file inside a table")
            else fail("'" .. c .. "' after a value (calls, operators and concatenation are not supported)") end
        end
        flush()
        return t
    end
    local ok, r = pcall(function()
        skip()
        if not s:find("^return", pos) or s:sub(pos + 6, pos + 6):find("^[%w_]") then fail("the file must be `return { ... }`") end
        pos = pos + 6; skip()
        if s:sub(pos, pos) ~= "{" then fail("`return` must be followed by one table { ... }") end
        tick()
        local v = tbl(1)
        skip()
        if s:sub(pos, pos) == ";" then pos = pos + 1; skip() end
        if pos <= #s then fail("text after the manifest table") end
        return v
    end)
    if ok then return r end
    if type(r) == "table" and r.mp then
        local _, nl = s:sub(1, math.min(r.pos, #s + 1) - 1):gsub("\n", "")
        return nil, nl + 1, r.why
    end
    return nil, 0, "parser error: " .. tostring(r)
end
-- the file as text, at most MAX_BYTES -> text | nil, reason
function CP.MP.read(path)
    local f = io.open(path, "rb"); if not f then return nil, "cannot be opened" end
    local s = f:read(CP.MP.MAX_BYTES + 1) or ""; f:close()
    if #s > CP.MP.MAX_BYTES then return nil, "larger than 4 MB" end
    return s
end
-- L-6: the bridge protocol is `|`-delimited and line-based: a string (value or key) holding | CR LF or NUL -> where, else nil
function CP.MP.badString(v, where)
    where = where or ""
    if type(v) == "string" then
        if v:find("[|\r\n\0]") then return (where ~= "" and where or "a string") .. " holds '|', a line break or NUL" end
        return nil
    end
    if type(v) ~= "table" then return nil end
    for k, x in pairs(v) do
        local w = where .. (type(k) == "number" and ("[" .. k .. "]") or ((where ~= "" and "." or "") .. tostring(k)))
        local bad = CP.MP.badString(k, w .. " (key)") or CP.MP.badString(x, w)
        if bad then return bad end
    end
    return nil
end

-- ---- the manifest schema (M-1 / M-2 / M-3 / I-2): every field the loader reads is type-checked once, here ----
-- A bad FIELD is dropped (or a bad ENTRY of a list), with one line each; the rest of the manifest loads.
CP.MF = {
    SYMS = { ["?RefreshRuntimeSources@UDataRegistry@@MEAAXXZ"] = true },   -- + REFRESHERS / FOLLOWUPS (filled where they are defined)
    FNAMES = {},                                                             -- + the FOLLOWUPS fnames
    LISTS = { grants = "table", preload = "string", primaryTypes = "table", refreshers = "table", composites = "table",
              recruitPins = "table", requires = "table", effectAnims = "table", castBeams = "table", fxSettings = "table",
              auras = "table", aiMimics = "table" },
    MAPS = { classPool = true, sabers = true, classKeys = true, settings = true },
    STRS = { name = true, version = true, displayName = true, registry = true },
}
-- the registry file name: relative, inside the manifest's folder -> ok, why
function CP.MF.registryOk(rel)
    if type(rel) ~= "string" or rel == "" then return false, "empty" end
    if rel:find("^[/\\]") then return false, "it starts with a slash" end
    if rel:find(":", 1, true) then return false, "it names a drive (':')" end
    for seg in rel:gmatch("[^/\\]+") do if seg == ".." then return false, "it holds a '..' segment" end end
    return true
end
-- the mod's own /Game/<mount>/ roots, from what it ships (primaryTypes paths, grant items, composite overlay tables);
-- never /Game/Game/ (the game's own content)
function CP.MF.mounts(m)
    local out = {}
    local function add(p)
        local ns = type(p) == "string" and p:match("^/Game/([^/%.]+)[/%.]") or nil
        if ns and ns ~= "Game" then out["/Game/" .. ns .. "/"] = true end
    end
    for _, pt in ipairs(m.primaryTypes or {}) do add(tostring(pt.path or "") .. "/") end
    for _, g in ipairs(m.grants or {}) do add(g.item) end
    for _, c in ipairs(m.composites or {}) do add(c.table) end
    return out
end
function CP.MF.under(path, mounts)
    if type(path) ~= "string" or path:find("..", 1, true) then return false end
    for mt in pairs(mounts) do if path:sub(1, #mt) == mt then return true end end
    return false
end
function CP.MF.amount(a)                               -- I-2: 1..999; NaN / not a number = 1
    if type(a) ~= "number" or a ~= a then return 1 end
    a = math.floor(a)
    if a < 1 then return 1 elseif a > 999 then return 999 end
    return a
end
-- m (a parsed manifest) is cleaned IN PLACE -> the notes (one log line each)
function CP.MF.schema(m)
    local MF, notes = CP.MF, {}
    local function note(x) notes[#notes + 1] = x end
    for k in pairs(MF.STRS) do
        if m[k] ~= nil and type(m[k]) ~= "string" then note(k .. " is not a string - ignored"); m[k] = nil end
    end
    for k in pairs(MF.MAPS) do
        if m[k] ~= nil and type(m[k]) ~= "table" then note(k .. " is not a table - ignored"); m[k] = nil end
    end
    for k, want in pairs(MF.LISTS) do
        local v = m[k]
        if v ~= nil and type(v) ~= "table" then note(k .. " is not a list - ignored"); m[k] = nil
        elseif v ~= nil then
            local out, bad = {}, 0
            for _, e in ipairs(v) do if type(e) == want then out[#out + 1] = e else bad = bad + 1 end end
            if bad > 0 then note(k .. ": " .. bad .. " entry(ies) not a " .. want .. " - skipped") end
            m[k] = out
        end
    end
    local function keep(k, test)                       -- filter list m[k] by test(e) -> nil (keep) | why (drop)
        if not m[k] then return end
        local out = {}
        for i, e in ipairs(m[k]) do
            local why = test(e)
            if why then note(k .. "[" .. i .. "] skipped: " .. why) else out[#out + 1] = e end
        end
        m[k] = out
    end
    keep("grants", function(g)
        if type(g.item) ~= "string" then return "no item path" end
        g.amount = MF.amount(g.amount)
        if g.setting ~= nil and type(g.setting) ~= "string" then g.setting = nil end
    end)
    keep("primaryTypes", function(pt)
        if type(pt.type) ~= "string" or type(pt.path) ~= "string" then return "type and path must be strings" end
        if pt.class ~= nil and type(pt.class) ~= "string" then return "class must be a string" end
    end)
    keep("refreshers", function(r)
        if r.dedupe ~= nil then note("refreshers: dedupe is ignored in a manifest (only the loader's own follow-ups carry one)"); r.dedupe = nil end
        if type(r.find) ~= "string" or type(r.sym) ~= "string" then return "find and sym must be strings" end
        if not MF.SYMS[r.sym] then return "refused: sym " .. r.sym .. " is not one of the loader's known refresh symbols" end
        if r.fname ~= nil and not (type(r.fname) == "string" and MF.FNAMES[r.fname]) then return "refused: fname " .. tostring(r.fname) .. " is not a known pool type" end
        if r.name ~= nil and type(r.name) ~= "string" then return "name must be a string" end
        if r.arg ~= nil and math.type(r.arg) ~= "integer" then return "arg must be an integer" end
        if r.assets ~= nil then
            if type(r.assets) ~= "table" then return "assets must be a list" end
            local a = {}
            for _, x in ipairs(r.assets) do if type(x) == "string" then a[#a + 1] = x end end
            r.assets = a
        end
    end)
    keep("composites", function(c)
        if type(c.target) ~= "string" or type(c.table) ~= "string" then return "target and table must be strings" end
        if c.rows ~= nil and type(c.rows) ~= "table" then c.rows = nil end
    end)
    if m.registry ~= nil then
        local ok, why = MF.registryOk(m.registry)
        if not ok then note("registry " .. m.registry .. " refused (" .. why .. "; it must be a file name inside the manifest's folder)"); m.registry = nil end
    end
    local mounts = MF.mounts(m)
    for i, fs in ipairs(m.fxSettings or {}) do
        if fs.cdoWrites ~= nil then
            if type(fs.cdoWrites) ~= "table" then note("fxSettings[" .. i .. "].cdoWrites is not a list - ignored"); fs.cdoWrites = nil
            else
                local out = {}
                for j, w in ipairs(fs.cdoWrites) do
                    local why = nil
                    if type(w) ~= "table" or type(w.cdo) ~= "string" or type(w.class) ~= "string" or type(w.property) ~= "string" then why = "cdo, class and property must be strings"
                    elseif not w.property:find("^[%a_][%w_]*$") then why = "property is not a property name"
                    elseif not (MF.under(w.cdo, mounts) and MF.under(w.class, mounts)) then why = "refused: " .. w.cdo .. " is not under the mod's own /Game/<mount>/"
                    end
                    if why then note("fxSettings[" .. i .. "].cdoWrites[" .. j .. "] skipped: " .. why) else out[#out + 1] = w end
                end
                fs.cdoWrites = out
            end
        end
    end
    return notes
end
-- the name a refusal line uses: the manifest's file name (<Mod>.zcsdk.lua -> <Mod>), else its folder
function CP.MF.label(p)
    p = tostring(p):gsub("\\", "/")
    return p:match("([^/]+)%.zcsdk%.lua$") or p:match("([^/]+)/[^/]*$") or p
end
-- one manifest file: read, parse (never run), schema -> appended to manifests / grants; false when refused
function CP.MF.add(p, gfp)
    local label = CP.MF.label(p)
    local text, why = CP.MP.read(p)
    local m, line = nil, 0
    if text then m, line, why = CP.MP.parse(text) end
    if m then
        local bad = CP.MP.badString(m)
        if bad then
            local at = text:find("|", 1, true)
            local _, nl = text:sub(1, at or 0):gsub("\n", "")
            m, line, why = nil, at and (nl + 1) or 1, bad
        end
    end
    if not m then
        log("manifest not supported (data-only manifests): " .. label .. ": " .. tostring(p) .. ":" .. tostring(line) .. ": " .. tostring(why))
        return false
    end
    for _, n in ipairs(CP.MF.schema(m)) do log("manifest " .. label .. ": " .. n) end
    local mf = { path = p, dir = dirOf(p), m = m, gfp = gfp }
    local gl = {}
    for _, g in ipairs(m.grants or {}) do   -- 1.8.35: setting (GRANT SETTINGS)
        gl[#gl + 1] = { item = g.item, amount = g.amount, from = tostring(m.name), done = false, setting = g.setting, mf = mf, src = p }
    end
    manifests[#manifests + 1] = mf
    for _, g in ipairs(gl) do grants[#grants + 1] = g end
    log("manifest: " .. p .. "  (" .. tostring(m.name) .. " v" .. tostring(m.version) .. (gfp and ", gfp: registry is the plugin's" or "") .. ")")
    return true
end
-- ---- 1.8.54: DATA-ONLY MANIFESTS (end) ----
local function discover()
    -- 1.6.0: "$gamemods" = SWZeroCompany/Mods/<Mod>/ (the game's own layout, SDK v1.21.0 "gfp"; each manifest one folder down, hence the
    -- bridge's depth-1 scan, v0.5.3). A gfp mod's registry is the plugin's own (loaded by the game) — never injected here; its refreshers,
    -- follow-ups (the recruit pool re-run), recruit pins, grants and primary-type rescans apply as for any manifest.
    -- 1.8.54: each manifest is read as DATA (CP.MF.add) in its own pcall; one bad file never stops the others.
    for _, root in ipairs({ "$paks", "$mods", "$gamemods" }) do
        local gfp = (root == "$gamemods")
        for _, p in ipairs(CP.BR.scan(root, "*.zcsdk.lua", gfp and 1 or 0)) do
            local ok, err = pcall(CP.MF.add, p, gfp)
            if not ok then log("manifest failed: " .. tostring(p) .. " -> " .. tostring(err) .. " (skipped; the other mods load)") end
        end
    end
    local ok, err = pcall(CP.zcuBridge)   -- 2026-10-13: a gfp mod whose ZC Unlocked bridge pack is live is listed by ZC Unlocked, not here
    if not ok then log("zcu-bridge: error " .. tostring(err) .. " - the SDK lists every gfp mod's items itself") end
    log(#manifests .. " manifest(s), " .. #grants .. " grant(s)")
    -- 1.4.0 recruitPins (1.5.0 `match`) are built by CP.afterDiscover, once EVERY manifest is known:
    -- 1.8.27 a slot may name a dependency (`requires`) whose presence decides which part it pins.
    CP.afterDiscover()   -- 1.8.27: requires[] -> the recruit pins -> classPool + settings.ini (one reader, in the pin block)
end
-- ---- 1.8.42: THE TAG STEP (begin; tools/replay_tags.py extracts this block verbatim) ----
-- A gfp mod's net-new gameplay tags ship in SWZeroCompany/Mods/<Mod>/Config/Tags/*.ini. Stock UE registers that folder only
-- when a Game Features state machine reaches Registering, and this game mounts its mods with none (retail R0, 2026-10-20:
-- GameFeaturePluginStateMachines.Num = 0, the tag manager's only search path = the game's own Config/Tags): every ZCJedi_ /
-- ZCSith_ tag read invalid, so ASC tag counts (cooldowns), MatchesTag (net-new slots) and the asset registry's part-tag text
-- import all missed them. The bridge (0.7.0, `ZCSDK:tagini`) now makes the engine's own call,
-- UGameplayTagsManager::AddTagIniSearchPath(<Mod>/Config/Tags), for every gfp manifest folder, and checks the result
-- (`tagcheck`). It runs right after discover() and BEFORE the primary-asset rescans and the per-type cache refresh
-- (BuildPartTagMaps), so the part-tag map is rebuilt with the tags registered. The bridge answers in ue4ss/ZCSDKBridge.tags
-- (key=value; removed before each call): no file = a bridge without the verb (< 0.7.0) -> one "update the Runtime" line,
-- and the step stops. Paks-layout mods need nothing: their pak's Config/Tags ini is read at startup.
function CP.readTagAnswer()
    local a = {}
    for _, l in ipairs(readLines(UE4SS .. "ZCSDKBridge.tags")) do
        local k, v = l:match("^(%w+)=(.*)$"); if k then a[k] = v end
    end
    return a
end
function CP.registerTags()
    local mgr = ""
    pcall(function()
        local o = FindFirstOf("GameplayTagsManager")
        if uvalid(o) then mgr = string.format("%x", o:GetAddress()) end
    end)
    local mods, tagsOk, tagsAll = 0, 0, 0
    for _, mf in ipairs(manifests) do
        if mf.gfp then
            local mod = mf.dir:match("([^/]+)$") or tostring(mf.m.name)
            pcall(os.remove, UE4SS .. "ZCSDKBridge.tags")
            bridge("ZCSDK:tagini|" .. mf.dir .. "/Config/Tags|" .. mgr .. "|" .. mod)
            local a = CP.readTagAnswer()
            if a.mod == nil then
                log("tags: the bridge did not answer ZCSDK:tagini (ZCSDKBridge older than 0.7.0?) - update the ZCSDK Runtime; " ..
                    "the gfp mods' net-new gameplay tags stay unregistered this session")
                return
            end
            if a.state == "noini" then
                -- a gfp mod with no net-new tags: nothing to say
            elseif a.state == "ok" then
                mods = mods + 1; tagsOk = tagsOk + (tonumber(a.valid) or 0); tagsAll = tagsAll + (tonumber(a.total) or 0)
                log(("tags: %s %s/%s registered (hierarchy %s/%s, route=%s)"):format(mod, tostring(a.valid), tostring(a.total),
                    tostring(a.hierok), tostring(a.hiertotal), tostring(a.route)))
                if (tonumber(a.valid) or 0) < (tonumber(a.total) or 0) then
                    log("tags: WARN " .. mod .. ": " .. (tonumber(a.total) - tonumber(a.valid)) .. " tag(s) still unregistered - see ZCSDKBridge.log (tagcheck)")
                end
            else
                log("tags: " .. mod .. " NOT registered (state=" .. tostring(a.state) .. ") - see ZCSDKBridge.log; the step goes on with the next mod")
            end
        end
    end
    log(("tags: %d gfp mod(s), %d/%d tag(s) registered (before the rescan / cache refresh)"):format(mods, tagsOk, tagsAll))
end
-- ---- 1.8.42: THE TAG STEP (end) ----
local function injectRegistries()
    for _, mf in ipairs(manifests) do
        -- 1.8.54 (M-2): the registry is a file name inside the manifest's folder (CP.MF.registryOk; no drive, no '..')
        local ok, err = pcall(function()
            if type(mf.m.registry) == "string" and not mf.gfp and CP.MF.registryOk(mf.m.registry) then   -- 1.6.0: a gfp mod's registry is loaded by the game itself
                local reg = mf.dir .. "/" .. mf.m.registry
                local g1 = type(mf.m.grants) == "table" and mf.m.grants[1] or nil
                local probe = (type(g1) == "table" and type(g1.item) == "string") and g1.item or ""
                bridge("ZCSDK:injreg|" .. reg .. "|" .. probe)
            end
        end)
        if not ok then log("registry: " .. tostring(mf.m.name) .. " failed: " .. tostring(err)) end
    end
    injected = true
end
-- Preload (loader 1.2.0 / runtime 0.5): a manifest may list packages to LoadPackage right after the registries are injected —
--   preload = { "/Game/ZCSDK/GA_ZCSDK_LongStride", ... }
-- OPT-IN (mod-def `preload: true` or an explicit list); zcmod-build then lists the mod's blueprints[] class packages. The idea:
-- the game's own ability classes are resident at startup, so systems that resolve soft class refs and seed derived data in ONE
-- pass see every stock tier synchronously, while a net-new class arrives through an async soft-class load a moment later.
-- CORRECTED v1.28.21: this comment used to present the Focus tree's empty row as the motivating case. **It is not** — v1.11.0
-- tested preload against exactly that symptom and RULED IT OUT (the note survives in zcmod-build.js, and the two comments
-- disagreed for ten versions). The real gate was found in v1.28.21: `FocusUpgradesConfiguration`, a
-- TMap<FGameplayTag, FFocusPointLevelThresholds> keyed by br.AbilityID.*, in which a net-new ability simply had no entry, so
-- the tree drew its rails and no nodes. Fixed then by OVERRIDING that asset (in the sith_class_mod.json sample, since retired:
-- ZCSithClass replaces it; docs/NETNEW_ABILITY.md has the focus-curve rule). Preload remains available and
-- off by default, for content a synchronous startup pass must genuinely see.
local function preloadPackages()
    local n = 0
    for _, mf in ipairs(manifests) do
        local ok, err = pcall(function()   -- 1.8.54 (M-3): one manifest at a time
            for _, p in ipairs(type(mf.m.preload) == "table" and mf.m.preload or {}) do
                if type(p) == "string" and p:sub(1, 1) == "/" then bridge("ZCSDK:loadpkg|" .. p); n = n + 1 end
            end
        end)
        if not ok then log("preload: " .. tostring(mf.m.name) .. " failed: " .. tostring(err)) end
    end
    if n > 0 then log("preload requested for " .. n .. " package(s)") end
end
-- Primary-asset rescan: the asset manager built its primary-asset map at startup (ScanPathsForPrimaryAssets over the
-- registry); an injected registry does not update it. A manifest lists the primary asset types it ships —
--   primaryTypes = { { type = "CustomizationPartDefinition", path = "/Game/ZCSDK", class = "/Script/BitReactorCore.CustomizationPartDefinition" } }
-- and the bridge rescans that type over that path (the customization part picker, classes, missions... enumerate this way).
local function rescanPrimaryTypes()
    local n = 0
    for _, mf in ipairs(manifests) do
        local ok, err = pcall(function()   -- 1.8.54 (M-3): one manifest at a time
            for _, pt in ipairs(not mf.zcu and type(mf.m.primaryTypes) == "table" and mf.m.primaryTypes or {}) do   -- 2026-10-13: a bridged mod is listed by ZC Unlocked
                if type(pt) == "table" and type(pt.type) == "string" and type(pt.path) == "string" then
                    bridge("ZCSDK:rescan|" .. pt.type .. "|" .. pt.path .. "|" .. tostring(pt.class or "") .. "|" .. tostring(pt.blueprintClasses and 1 or 0))
                    n = n + 1
                end
            end
        end)
        if not ok then log("rescan: " .. tostring(mf.m.name) .. " failed: " .. tostring(err)) end
    end
    if n > 0 then log("primary-asset rescan requested for " .. n .. " type(s)") end
end
-- Per-type cache refreshers: the game keeps its own per-type caches built from the primary-asset list at startup; a
-- rescan alone does not reach them. Each entry names the subsystem object to find and the nullary native method the
-- bridge calls on it (`callthis`, bridge v0.4). Found via tools/recon/pdbsyms.py `calls`:
--   CustomizationPartDefinition -> UCustomizationPartsTagSubsystem (EngineSubsystem) caches a tag -> parts map that
--   UCustomizationStatics::GetCustomizationPartIds (the customizer's part picker) reads; BuildPartTagMaps() rebuilds it
--   (the same thing the game does on HandleAssetAdded / HandlePakFileMounted).
local REFRESHERS = {
    CustomizationPartDefinition = { { find = "CustomizationPartsTagSubsystem", sym = "?BuildPartTagMaps@UCustomizationPartsTagSubsystem@@AEAAXXZ" } },
}
local function refreshCaches()
    local done = {}
    for _, mf in ipairs(manifests) do
        for _, pt in ipairs(not mf.zcu and type(mf.m.primaryTypes) == "table" and mf.m.primaryTypes or {}) do   -- 2026-10-13: nothing of a bridged mod's to refresh
            for _, r in ipairs(type(pt) == "table" and REFRESHERS[tostring(pt.type)] or {}) do
                local key = r.find .. r.sym
                if not done[key] then
                    done[key] = true
                    local ok, obj = pcall(FindFirstOf, r.find)
                    if ok and obj and obj:IsValid() then
                        bridge(string.format("ZCSDK:callthis|%s|%x", r.sym, obj:GetAddress()))
                        log("cache refresh: " .. r.find .. " -> " .. r.sym)
                    else
                        log("cache refresh: " .. r.find .. " not found (skipped " .. r.sym .. ")")
                    end
                end
            end
        end
    end
end

-- Manifest refreshers (loader 1.3.0 / runtime 0.6): a manifest may list native calls to make on live objects after the injection +
-- rescan, when the game built something from the asset registry ONCE at startup that no rescan reaches:
--   refreshers = { { find = "CharacterPoolDataRegistry", name = "DR_InitialCharacterPool", sym = "?RefreshRuntimeSources@UDataRegistry@@MEAAXXZ" }, ... }
--   find = the UE4SS class name to FindAllOf, name = the object's short name (optional: first live instance), sym = a nullary method
--   (bridge callthis) or, with fname = "<Name>", a void(const FName&) method (bridge callfname, v0.5).
-- zcmod-build emits one for every DataRegistry-derived asset a mod appends to (the registry's meta sources re-scan the asset registry,
-- which now holds the mod's tables). FOLLOWUPS adds what the game then has to redo: the character pools are created once in
-- UBitReactorCharacterPoolManager::OnDataRegistrySubsystemInitialized (tools/recon/pdbsyms.py callers), so after DR_InitialCharacterPool
-- is refreshed the pool creation is re-run for that registry type. NOT idempotent by itself (SDK v1.12.0 retail, PoolVerifier round 2):
-- CreateNewCharacterPool always AddDefaulted()s a fresh FCharacterPoolData onto CharacterPools, then the async acquire callback files the
-- registry's characters into the FIRST pool of that name — so a re-run fills the original pool and leaves an EMPTY duplicate at the END of
-- the array. `dedupe` (1.3.1, bridge 0.5.1 `arrpop`) pops that trailing duplicate right after the call: only when >= 2 pools carry the
-- name, the last one is one of them and it holds no characters; the element is destructed by the game's own ~FCharacterPoolData.
-- CreatePreAuthoredCharacterPool(const FName& RegistryType, const ECharacterPoolType& PoolType): the pool type rides as `arg` (an integer the
-- bridge passes by const reference; 6 = InitialCharacterPool, 7 = EnemyCharacterPool — the values the manager's pools report).
local CPACP = "?CreatePreAuthoredCharacterPool@UBitReactorCharacterPoolManager@@AEAAXAEBVFName@@AEBW4ECharacterPoolType@@@Z"
local POOLS = { prop = "CharacterPools", offset = 328, elemSize = 120, dtor = "??1FCharacterPoolData@@QEAA@XZ" }   -- jmap: UBitReactorCharacterPoolManager.CharacterPools @ 328, FCharacterPoolData 120 bytes
local FOLLOWUPS = {
    DR_InitialCharacterPool = { find = "BitReactorCharacterPoolManager", sym = CPACP, fname = "InitialCharacterPool", arg = 6, dedupe = POOLS },
    DR_EnemyCharacterPool   = { find = "BitReactorCharacterPoolManager", sym = CPACP, fname = "EnemyCharacterPool", arg = 7, dedupe = POOLS },
}
-- 1.8.54 (M-2): a manifest refresher may name only these symbols / fnames (CP.MF.schema refuses any other)
for _, list in pairs(REFRESHERS) do for _, r in ipairs(list) do CP.MF.SYMS[r.sym] = true end end
for _, f in pairs(FOLLOWUPS) do CP.MF.SYMS[f.sym] = true; if f.fname then CP.MF.FNAMES[f.fname] = true end end
-- After a pool re-run: drop the empty duplicate pool entry named `poolName` if it sits at the END of obj.<d.prop> (see FOLLOWUPS).
local function dedupeTrailingPool(obj, d, poolName, tag)
    local ok, err = pcall(function()
        local arr = obj[d.prop]
        local n = arr:GetArrayNum()
        if n < 2 then return end
        local firstIdx, lastName, lastCount = nil, nil, 0
        arr:ForEach(function(i, e)
            local p = e:get()
            local nm = ""; pcall(function() nm = p.CharacterPoolName:ToString() end)
            if nm == poolName and not firstIdx then firstIdx = i end
            if i == n then lastName = nm; pcall(function() p.Characters:ForEach(function() lastCount = lastCount + 1 end) end) end
        end)
        if lastName ~= poolName or not firstIdx or firstIdx == n then log(tag .. ": no trailing duplicate pool (" .. n .. " pools)"); return end
        if lastCount > 0 then log(tag .. ": trailing pool '" .. poolName .. "' holds " .. lastCount .. " character(s) — kept"); return end
        local addr = nil
        pcall(function() addr = arr:GetArrayAddress() end)                     -- UE4SS TArray API, when available
        if type(addr) ~= "number" or addr == 0 then addr = obj:GetAddress() + d.offset end   -- else the owner + the property's jmap offset
        bridge(string.format("ZCSDK:arrpop|%x|%d|%s|%d", addr, d.elemSize, d.dtor, n))
        log(tag .. ": popped the empty duplicate pool '" .. poolName .. "' (entry " .. n .. " of " .. n .. "; first '" .. poolName .. "' is entry " .. firstIdx .. ")")
    end)
    if not ok then log(tag .. ": dedupe failed: " .. tostring(err)) end
end
-- 1.8.54 (M-3): the short name is matched as PLAIN text with explicit boundaries (it used to be built into a Lua pattern, so a
-- manifest name holding `[` or `%` raised "malformed pattern" and stopped every later mod's refreshers):
-- `<.|:>name` at the end of the full name, or `<.|:|/>name<.|:>` anywhere in it.
function CP.MF.nameIn(full, nm)
    local init = 1
    while true do
        local a, b = full:find(nm, init, true)
        if not a then return false end
        local pre, post = full:sub(a - 1, a - 1), full:sub(b + 1, b + 1)
        if (pre == "." or pre == ":") and post == "" then return true end
        if (pre == "." or pre == ":" or pre == "/") and (post == "." or post == ":") then return true end
        init = a + 1
    end
end
local function findLive(className, shortName)
    local ok, list = pcall(FindAllOf, className)
    if not ok or not list then return nil end
    for _, o in ipairs(list) do
        if o and o:IsValid() then
            local full = o:GetFullName()
            if type(full) == "string" and not full:find("Default__", 1, true) and (not shortName or CP.MF.nameIn(full, shortName)) then return o end
        end
    end
    return nil
end
local function runRefresher(r, tag)
    if type(r) ~= "table" or type(r.find) ~= "string" or type(r.sym) ~= "string" then return end
    if not CP.MF.SYMS[r.sym] then log(tag .. ": " .. r.sym .. " is not a known refresh symbol - refused"); return end   -- 1.8.54 (M-2)
    if r.name ~= nil and type(r.name) ~= "string" then return end
    local obj = findLive(r.find, r.name)
    if not obj then log(tag .. ": " .. r.find .. (r.name and (" '" .. r.name .. "'") or "") .. " not found (skipped " .. r.sym .. ")"); return end
    -- assets = registry-resolved asset paths to hand to a DataRegistry first (UDataRegistry::RegisterSpecificAsset via bridge `dtreg`):
    -- its meta sources create a child source per registered table, no path search involved
    for _, a in ipairs(type(r.assets) == "table" and r.assets or {}) do
        bridge(string.format("ZCSDK:dtreg|%x|%s", obj:GetAddress(), tostring(a)))
        log(tag .. ": registered " .. a .. " with " .. (r.name or r.find))
    end
    if type(r.fname) == "string" and r.fname ~= "" then
        if r.arg ~= nil then bridge(string.format("ZCSDK:callfname|%s|%x|%s|%d", r.sym, obj:GetAddress(), r.fname, tonumber(r.arg)))
        else bridge(string.format("ZCSDK:callfname|%s|%x|%s", r.sym, obj:GetAddress(), r.fname)) end
    else
        bridge(string.format("ZCSDK:callthis|%s|%x", r.sym, obj:GetAddress()))
    end
    log(tag .. ": " .. r.find .. (r.name and (" '" .. r.name .. "'") or "") .. " -> " .. r.sym .. (r.fname and (" (" .. r.fname .. ")") or ""))
    -- 1.8.54 (M-1): dedupe (an address + destructor the bridge acts on) comes ONLY from the loader's own FOLLOWUPS, never a manifest
    if type(r.dedupe) == "table" and type(r.fname) == "string" and rawequal(FOLLOWUPS[r.name or ""], r) then dedupeTrailingPool(obj, r.dedupe, r.fname, tag) end
end
local followups = {}
local function applyRefreshers()
    local n = 0
    for _, mf in ipairs(manifests) do
        for _, r in ipairs(type(mf.m.refreshers) == "table" and mf.m.refreshers or {}) do
            -- 1.8.54 (M-3): each refresher in its own pcall; a manifest refresher never carries dedupe (M-1)
            local ok, err = pcall(function()
                if type(r) ~= "table" then return end
                local rr = {}
                for k, v in pairs(r) do if k ~= "dedupe" then rr[k] = v end end
                runRefresher(rr, "refresh"); n = n + 1
                local f = type(r.name) == "string" and FOLLOWUPS[r.name] or nil
                if f and not followups[r.name] then followups[r.name] = f end
            end)
            if not ok then log("refresh: " .. tostring(mf.m.name) .. " failed: " .. tostring(err)) end
        end
    end
    if n > 0 then log("refreshers: " .. n .. " requested") end
end
local function applyFollowups()
    for name, f in pairs(followups) do
        local ok, err = pcall(runRefresher, f, "follow-up for " .. name)
        if not ok then log("follow-up for " .. name .. " failed: " .. tostring(err)) end
    end
end

-- ---- grants: once per save, when an HQ inventory exists ----
-- ---- 1.8.36: GRANT QUEUE (begin; tools/replay_grants.py extracts this block verbatim) ----
-- THE EVIDENCE. Retail 2026-10-18 (loader 1.8.35, saber pack 1.0.5, its unlock-all setting ON, a save that had none of the
-- 145 items): `pump: task grants took 13362 ms in one frame` (pass 1: 145 x `grant: loading`) and then `8062 ms` (pass 2:
-- 145 x GRANTED); on the restart the all-owned pass still took 3247 ms (145 x `already owned`).
-- THE CAUSE. The pass did every item in ONE frame, and every item began with `StaticFindObject(g.item)` - which in this
-- UE4SS build is not a hash lookup but a walk of the whole object array (1.8.28, "THE FRAME-BOUNDED PASS": 28 ms in the
-- menu, 50-90 ms in the hub). 145 items = 145 walks per pass, on top of the load request (LoadAsset + the bridge's
-- loadpkg), HasEverOwnedItem and GrantItem. The HQ itself was a FindFirstOf (another walk) per pass.
-- THE FIX. (1) ONE item walk per pass: a single FindAllOf(BrunoInventoryItem) (every grant item is a UBrunoInventoryItem;
--     FindAllOf matches subclasses, as UEHelpers' FindAllOf("PlayerController") does) answers residency for every pending
--     item, used in that frame only (no UObject crosses a frame). If it returns nothing, the 1.8.34 per-item
--     StaticFindObject is the fallback, and each one counts as an operation. (2) THE HQ by ABrunoHQInventory::GetInventory
--     on its CDO (a static UFunction, the call shape of GrantItem on BrunoGameStatics; both CDOs are looked up once a
--     session), FindFirstOf only when that returns nothing. (3) SPREAD OVER FRAMES: at most GR.PER_TICK item operations (a
--     load request, or an owned check + GrantItem) per pass, and no new one once the pass's item work has taken
--     GR.BUDGET_MS; while work remains the next pass is due in GR.NEXT_S, otherwise the task's own 4 s period. A
--     not-yet-resident item's load is re-requested at most every GR.LOAD_RETRY_S (1.8.34 re-requested it every pass).
--     Knobs: ue4ss/Mods/ZCSDKLoader/settings.ini [GRANTS] PerTick = 8 (0 = no cap) and BudgetMs = 100 (0 = no time
--     budget); PerTick = 0 + BudgetMs = 0 is 1.8.34's one-frame pass.
-- WHAT DID NOT CHANGE. The gates (the registries injected, an HQ, the BrunoGameStatics CDO), the per-item log lines
-- (`grant: loading`, `already owned by this save (skip)`, `-> GRANTED` / `-> failed`), once per item per session (an item
-- is `done` after its one owned-check / grant attempt, whatever the answer), HasEverOwnedItem on the CURRENT HQ right before
-- every GrantItem. NEW: one `grants: done - N GRANTED, ...` summary when the last item is done (`grants:`, plural, so
-- session_audit's `^grant: ` gate is not fed by it).
-- A MAP CHANGE OR SAVE LOAD MID-QUEUE. Every pass re-reads the HQ (nothing is kept across frames but its address, as a
-- number): no HQ (a loading screen, the main menu) = the queue PAUSES and the task polls at its period; a different HQ =
-- one log line and the queue RESUMES on it. Items already done are never re-attempted, and each remaining one is checked
-- with HasEverOwnedItem on the new HQ before GrantItem, so nothing is granted twice to a save; a save left with part of
-- the set gets the rest on its next session's pass (that pass skips what it owns).
-- A setting-gated grant (g.setting, the GRANT SETTINGS block where it exists) is withheld before it costs an operation.
-- 1.8.37: THE BUDGET OVERRUN (retail 2026-10-18 04:29:23-04:30:08, loader 1.8.36, the same first load): every pass took
-- 186-235 ms (`pump: task grants took 215 ms in one frame` ... `235 ms`; the summary `at most 4 item operation(s) and 371 ms
-- in one pass`) against BudgetMs 100, at fps 7-31. A pass was `loading A, loading A_Left` (215 ms), the next `GRANTED A,
-- GRANTED A_Left, loading B, loading B_Left` (228 ms); the all-owned restart (04:41:57-04:42:07) did 8 owned checks in 79-101
-- ms. Solved: the FindAllOf walk ~65 ms, one load request (LoadAsset + the bridge's synchronous loadpkg) ~75 ms, a grant
-- ~6 ms, an owned check ~2.5 ms. The budget was measured from AFTER the walk and only checked before an operation, so the
-- walk was free and one load (75 ms) always fit after it. Now: (1) the budget counts from the START of the pass (the walk
-- included); (2) every operation kind's cost is measured (GR.COST, seeded with the retail numbers, then the mean of the last
-- measure and the previous estimate) and a next operation starts only if the pass so far + its cost fits the budget (the
-- first operation of a pass always runs, so the queue moves); (3) LOAD PASSES: an item the walk found not resident is
-- marked, and its load request runs in a pass of its own WITHOUT the walk (one ~75 ms load fits there, never after a walk),
-- at most GR.LOAD_RUN load passes in a row before a walk pass picks the loaded items up and grants them (~65 + n x 6 ms). A
-- pass with nothing done but loads due returns NEXT_S as well. BudgetMs = 0 keeps the old inline loads (0/0 = 1.8.34's
-- one-frame pass). tools/replay_grants.py Q16-Q18.
CP.GR = {
    PER_TICK = 8, BUDGET_MS = 100, NEXT_S = 0.25, LOAD_RETRY_S = 8, LOAD_RUN = 4,
    INI = "Mods/ZCSDKLoader/settings.ini", ITEM_CLASS = "BrunoInventoryItem",
    clock = os.clock,
    COST = { walk = 65, load = 75, item = 6, look = 65 },   -- ms per operation kind (retail 2026-10-18), re-measured as it runs
    statics = nil, hqCDO = nil, hqAddr = nil, cfg = false, said = {},
    passes = 0, maxOps = 0, maxMs = 0, summary = false, loadRun = 0, loadPasses = 0,
}
-- the measured cost of one operation kind (ms) that began at clock `a`
function CP.GR.took(kind, a) local GR = CP.GR; GR.COST[kind] = (GR.COST[kind] + (GR.clock() - a) * 1000) / 2 end
-- one load request (the item is then looked for by a later walk; re-requested at most every LOAD_RETRY_S)
function CP.GR.load(g)
    local GR = CP.GR
    local a = GR.clock()
    g.loadAt, g.checked, g.needLoad = a, false, false
    log("grant: loading " .. g.item); pcall(LoadAsset, g.item)   -- registry-resolved (works after injection); found by a later pass
    local pkg = g.item:match("^(.-)%.[^%.]+$"); if pkg then bridge("ZCSDK:loadpkg|" .. pkg) end
    GR.took("load", a)
end
-- a marked item whose load request is due now
function CP.GR.due(g, now) return not g.done and g.needLoad and (g.loadAt == nil or now - g.loadAt >= CP.GR.LOAD_RETRY_S) end
function CP.GR.once(k, line) if CP.GR.said[k] then return end; CP.GR.said[k] = true; log(line) end
function CP.GR.config()
    local GR = CP.GR
    if GR.cfg then return end
    GR.cfg = true
    local text = CP.zcuText(UE4SS .. GR.INI) or ""
    for _, kv in ipairs({ { "PerTick", "PER_TICK" }, { "BudgetMs", "BUDGET_MS" } }) do
        local v = CP.zcuIni(text, "GRANTS", kv[1])
        if v ~= nil then
            local n = tonumber(v)
            if n and n >= 0 then GR[kv[2]] = math.floor(n) else log("grants: settings.ini [GRANTS] " .. kv[1] .. "=" .. v .. " ignored (a whole number >= 0)") end
        end
    end
    log(("grants: spread over frames - at most %s item operation(s) per pass, %s, the next pass %.2f s later while work remains ([GRANTS] PerTick / BudgetMs)")
        :format(GR.PER_TICK > 0 and tostring(GR.PER_TICK) or "unlimited", GR.BUDGET_MS > 0 and ("a " .. GR.BUDGET_MS .. " ms budget from the start of the pass (the item walk included; load requests in passes of their own)") or "no time budget", GR.NEXT_S))
end
function CP.GR.findHQ()
    local GR = CP.GR
    if GR.hqCDO == nil then
        local c = StaticFindObject("/Script/Bruno.Default__BrunoHQInventory")
        GR.hqCDO = (c and c:IsValid()) and c or false
        if not GR.hqCDO then log("grants: the BrunoHQInventory CDO was not found - the HQ is found by FindFirstOf") end
    end
    local hq = nil
    if GR.hqCDO then pcall(function() hq = GR.hqCDO:GetInventory(gameWorld()) end) end
    if not (hq and hq:IsValid()) then
        local ok, h = pcall(FindFirstOf, "BrunoHQInventory")
        hq = ok and h or nil
    end
    if hq and hq:IsValid() then
        local okN, full = pcall(function() return hq:GetFullName() end)
        if okN and type(full) == "string" and not full:find("Default__") then return hq end
    end
    return nil
end
-- residency of every pending item from ONE FindAllOf; nil = that walk gave nothing (the per-item fallback runs)
function CP.GR.resolve()
    local ok, list = pcall(FindAllOf, CP.GR.ITEM_CLASS)
    if not ok or type(list) ~= "table" or #list == 0 then
        CP.GR.once("nolist", "grants: FindAllOf(" .. CP.GR.ITEM_CLASS .. ") returned nothing - items are looked up one by one (StaticFindObject), each one an operation")
        return nil
    end
    local want, found = {}, {}
    for _, g in ipairs(grants) do if not g.done then want[g.item] = true end end
    for _, o in ipairs(list) do
        local okN, full = pcall(function() return o:GetFullName() end)
        local p = okN and type(full) == "string" and full:match("^%S+%s+(.+)$") or nil
        if p and want[p] then found[p] = o end
    end
    return found
end
function CP.GR.finish()
    local GR = CP.GR
    if GR.summary or #grants == 0 then return end
    GR.summary = true
    local c = { granted = 0, owned = 0, failed = 0, withheld = 0 }
    for _, g in ipairs(grants) do
        local r = g.res or (g.setting and "withheld") or "failed"
        c[r] = (c[r] or 0) + 1
    end
    log(("grants: done - %d GRANTED, %d already owned, %d failed, %d withheld (of %d declared; %d pass(es), at most %d item operation(s) and %.0f ms in one pass)")
        :format(c.granted, c.owned, c.failed, c.withheld, #grants, GR.passes, GR.maxOps, GR.maxMs))
end
-- one pass: true = every grant is done (the task stops), a number = run again that many seconds later, false = the period
function CP.GR.pass()
    local GR = CP.GR
    local pending = 0
    -- withheld grants settle BEFORE the HQ lookup and the FindAllOf walk (all withheld = no walk at all; retail: 98 ms for 0 operations)
    for _, g in ipairs(grants) do
        if not g.done and g.setting and CP.grantSettingOn and not CP.grantSettingOn(g) then g.done = true; g.res = "withheld" end
        if not g.done then pending = pending + 1 end
    end
    if pending == 0 then GR.finish(); return true end
    local hq = GR.findHQ(); if not hq then return false end
    if not GR.statics then
        local s = StaticFindObject("/Script/Bruno.Default__BrunoGameStatics")
        if s and s:IsValid() then GR.statics = s else log("BrunoGameStatics CDO not found"); return false end
    end
    GR.config()
    local addr = nil; pcall(function() addr = hq:GetAddress() end)
    if GR.hqAddr ~= nil and addr ~= nil and addr ~= GR.hqAddr then
        log("grants: the HQ inventory changed mid-queue (a map change or a save load) - resuming on the new one, " .. pending ..
            " item(s) left; each is checked against it (HasEverOwnedItem) before any grant")
    end
    if addr ~= nil then GR.hqAddr = addr end
    local t0 = GR.clock()
    GR.passes = GR.passes + 1
    local ops = 0
    -- 1.8.37: may one more operation of `kind` start? PerTick, then the budget from the START of the pass (the walk included)
    -- against that kind's measured cost; the first operation of a pass always runs (the queue moves), except a load request
    -- in a walk pass (`strict`: it waits for a load pass of its own)
    local function fits(kind, strict)
        if GR.PER_TICK > 0 and ops >= GR.PER_TICK then return false end
        if GR.BUDGET_MS <= 0 or (ops == 0 and not strict) then return true end
        return (GR.clock() - t0) * 1000 + GR.COST[kind] <= GR.BUDGET_MS
    end
    local now = GR.clock()
    local due = 0
    for _, g in ipairs(grants) do if GR.due(g, now) then due = due + 1 end end
    if due > 0 and GR.BUDGET_MS > 0 and GR.loadRun < GR.LOAD_RUN then
        -- A LOAD PASS: the marked items' load requests, no walk (a later walk pass finds them and grants them)
        GR.loadRun = GR.loadRun + 1; GR.loadPasses = GR.loadPasses + 1
        for _, g in ipairs(grants) do
            if GR.due(g, now) then
                if not fits("load") then break end
                GR.load(g); ops = ops + 1
            end
        end
    else
        GR.loadRun = 0
        local tw = GR.clock()
        local found = GR.resolve()
        GR.took("walk", tw)
        for _, g in ipairs(grants) do
            if not g.done then
                if GR.PER_TICK > 0 and ops >= GR.PER_TICK then break end
                local wait = g.loadAt ~= nil and now - g.loadAt < GR.LOAD_RETRY_S   -- its load was requested recently
                -- the walk's answer is free; the per-item fallback looks ONCE after a load request, then waits for the retry
                if found or not (wait and g.checked) then
                    local item
                    local tl = GR.clock()
                    if found then item = found[g.item]
                    elseif not fits("look") then break
                    else item = StaticFindObject(g.item); ops = ops + 1; GR.took("look", tl); if wait then g.checked = true end end
                    if not (item and item:IsValid()) then
                        if not wait then
                            g.needLoad = true                                   -- a load pass requests it
                            if fits("load", true) then GR.load(g); if found then ops = ops + 1 end end
                        end
                    else
                        if found and not fits("item") then break end
                        if found then ops = ops + 1 end
                        local ti = GR.clock()
                        local okH, owned = pcall(function() return hq:HasEverOwnedItem(item) end)
                        if okH and owned then
                            log("grant: " .. g.item .. " already owned by this save (skip)"); g.res = "owned"
                        else
                            local okG, err = pcall(function() GR.statics:GrantItem(hq, item, g.amount) end)
                            log("grant: " .. g.item .. " x" .. g.amount .. " (" .. g.from .. ") -> " .. (okG and "GRANTED" or ("failed: " .. tostring(err))))
                            g.res = okG and "granted" or "failed"
                            if DIAG and okG then pcall(dumpObject, item, "granted item") end
                        end
                        GR.took("item", ti)
                        g.done = true
                    end
                end
            end
        end
    end
    local ms = (GR.clock() - t0) * 1000
    if ms > GR.maxMs then GR.maxMs = ms end
    if ops > GR.maxOps then GR.maxOps = ops end
    pending, due = 0, 0
    for _, g in ipairs(grants) do
        if not g.done then pending = pending + 1 end
        if GR.due(g, now) then due = due + 1 end
    end
    if pending == 0 then GR.finish(); return true end
    if ops > 0 or due > 0 then return GR.NEXT_S end            -- 1.8.37: loads waiting for their own pass count as work
    return false
end
-- ---- 1.8.36: GRANT QUEUE (end) ----
local function applyGrants() return CP.GR.pass() end
-- the pre-1.8.36 `local function findHQ` stays reachable under its old name (the same main-chunk local slot): SLOTFIX and
-- DUALHEX call the bare `findHQ()` (retail 2026-10-18 03:39:23 without this alias: "attempt to call a nil value (global
-- 'findHQ')"; tools/check_lua_globals.py now fails on any such call)
local findHQ = CP.GR.findHQ

-- ---- recruit pins (loader 1.4.0 / runtime 0.7; the ORDER + the TOGGLE in 1.8.18, the dead experiments cut in 1.8.19) ----
-- A pre-authored recruit's Specializations slots (tactical spec, weapon class...) are RE-ROLLED by the game on every Recruitment refresh
-- (UBitReactorGameStatics_Spawn::SpawnCharacter -> UCustomizationStatics::Randomize over the spawn params' slots; nothing data-side
-- survives it — docs/NETNEW_CLASS.md). The spawn is native (no ProcessEvent to hook), so the pin is a poll: every few seconds, every live
-- CustomizationInstance whose default CustomizationDefinition is a manifest's `recruitPins[].definition` gets the listed slots equipped
-- with the listed parts and its customization refreshed. Slot instances are matched to their instance by full-name prefix (the SlotProbe
-- technique); a fragment's TSoftObjectPtr is never read from Lua (that crashed the game in v1.3.0).
--
-- 1.8.9's SUCCESS CRITERION, which 1.8.19 keeps because it is the thing the pin still judges by: a slot counts as
-- equipped when its FragmentInstances are REPLACED (object identity) or it gains LeveledAbilities /
-- LoadedLeveledAbilities entries. `CustomizationPartDefinition` is NOT a criterion in either direction - the game's own
-- CPD_TalentSpec_TheToughGuy reads partDefinition=<null> with one leveled tree and draws a full row, and the id-only
-- setter resolves a definition by itself once the asset is resident.
--
-- 1.8.9's THIRD correction, also kept: in a MISSION the characters are rebuilt from save data and the game re-equips
-- them during load (21:28:27 vs 21:28:30), so a pin there can only write the id; PIN_STRATEGY_ONLY logs that once.
--
-- WHAT 1.8.19 DELETED, AND WHY IT IS NOT COMING BACK. Loader 1.8.8-1.8.17 tried to reach the fragment-carrying
-- `...WithFragments` sibling through UCustomizationStatics::EquipCustomizationDefinition (shapes `allowed` / `tags` /
-- `all`) and ::EquipCustomizationParts (shapes `struct` / `table`), judged by an `arrival` observable, and probed the
-- AssetManager through UKismetSystemLibrary. Retail 2026-09-13 09:04:40 settled it: the PLAIN 1.4.0 setter
-- `UCustomizationFragmentInstanceSlot::SetCustomizationPartPrimaryAssetId` (RVA 0x8c54660) delivered the Sith's two
-- leveled trees, because `LoadCustomization` rebuilds the fragment instances on an id CHANGE once the part is
-- resident. The equip routes cost two sessions: an EMPTY AllowedSlots container means "every slot this definition
-- names", so equipping the Class part through it re-created the character's own child slots twice (07:52:26,
-- 09:04:44). All of it is deleted. The sequence that WORKS is below: residency first, then Class to completion, then
-- Weapon, then Tactical, toggling through a vanilla id, delivered-is-final.
local PIN_MAX_RETRY = 4           -- re-equips of a slot that holds our id but never took a fragment instance
local PIN_RESIDENCY_PASSES = 12   -- 1.8.19: passes `done` is held while a pinned part is still loading (~60 s at the
                                  -- 5 s cadence). BOUNDED on purpose: an unbounded pin loop is the 05:43 crash.
local PIN_STRATEGY_ONLY = true    -- 1.8.19: now only an OBSERVABILITY gate — it logs, once, that this world is not the
                                  -- hub, so a pass that changes nothing in a mission is never a silent one
-- what to TOGGLE a slot through when it already holds our part but never took its fragments. The vanilla id the slot
-- itself carried is preferred and remembered per slot; these are the fallbacks, read off other characters in the same
-- hub (retail 08:41/09:04 BEFORE lines).
-- 1.8.27 (G2, SDK_CHANGE_REQUEST §4): the Talent slot too. A Talent that holds our id with no fragments and no remembered
-- vanilla id had nothing to toggle through. CPD_TalentSpec_TheToughGuy's path is VERIFIED in build/_gameregistry.json
-- (2026-09-29), and the ghost refusal's toggle-id exemption (PIN_TOGGLE_PATH[cur]) covers it by construction.
local PIN_TOGGLE_DEFAULT = {
    ["br.Customization.Slot.Character.Class"] = "CPD_Char_Class_Hero_Humanoid",
    ["br.Customization.Slot.Character.Specializations.Weapon"] = "CPD_WeaponSpec_Blaster_Longarm",
    ["br.Customization.Slot.Character.Specializations.Tactical.Primary"] = "CPD_TacticalSpec_Assault",
    ["br.Customization.Slot.Character.Specializations.Talent"] = "CPD_TalentSpec_TheToughGuy",
}
local PIN_TOGGLE_PATH = {
    CPD_Char_Class_Hero_Humanoid = "/Game/Game/Customizations/Characters/Common/CharacterClass/CPD_Char_Class_Hero_Humanoid.CPD_Char_Class_Hero_Humanoid",
    CPD_WeaponSpec_Blaster_Longarm = "/Game/Game/Customizations/Characters/Common/Specialization/Weapon/CPD_WeaponSpec_Blaster_Longarm.CPD_WeaponSpec_Blaster_Longarm",
    CPD_TacticalSpec_Assault = "/Game/Game/Customizations/Characters/Common/Specialization/Tactical/CPD_TacticalSpec_Assault.CPD_TacticalSpec_Assault",
    CPD_TalentSpec_TheToughGuy = "/Game/Game/Customizations/Characters/Common/Specialization/Talent/CPD_TalentSpec_TheToughGuy.CPD_TalentSpec_TheToughGuy",
}
-- 1.8.27: THE PASS STATE. One table, for the 200-local limit. `P` is the pass in flight (nil between passes).
-- 1.8.28: THE LOOKUP BUDGET (see "THE FRAME-BOUNDED PASS" above PS.get). A pass holds strings, numbers and booleans across
-- frames; the objects a frame uses come from THAT frame's own FindAllOf / StaticFindObject, and at most PS.LOOKUPS of those
-- run per frame. The one exception is PS.ksl(): a class default object (KismetSystemLibrary's CDO), which is never
-- collected, exactly as UEHelpers caches it.
local PS = { OVER_MS = 16, OVER_CAP = 30, P = nil, clock = os.clock, overLogged = 0, walked = 0, knownRp = {},
             LOOKUPS = 2,          -- object lookups (FindAllOf / StaticFindObject) per frame: the slot FindAllOf + ONE more
             DRIVE_MAX = 16,       -- drive frames per pass (the Class, then the children, one part lookup per frame)
             LOOK_MAX = 24,        -- lookup-only frames per pass (the ghost / stale residency checks)
             SWEEP_PASSES = 16,    -- the first N passes of every world sweep the WHOLE world (ghosts, stale slots, roster)
             SWEEP_S = 120,        -- ... and after that one pass in SWEEP_S does, while the loop is awake
             CLASS_HOLD = 3,       -- idle frames after a Class delivery before its children are re-found
             CLASS_TRIES = 4,      -- drive frames that may find the children NOT yet re-created before they are driven anyway
             URGENT_WAIT_S = 12,   -- a Recruitment event: how long an urgent pass waits for a card of ours to exist
             URGENT_STEP_S = 0.5,  -- ... looking again every URGENT_STEP_S
             SPAWN_SETTLE_S = 1.5, -- a card must have existed this long (its async spawn sets the Talent at its end)
             VERIFY_S = 8,         -- after an urgent episode's `done`: the FIRST verify pass this much later
             -- 1.8.31: THE TALENT GATE AND THE RE-VERIFY WINDOW (see "1.8.31: THE TALENT GATE" above PS.genRead)
             VERIFY_AT = { 8, 30, 60, 120 }, -- verify passes, seconds after an episode's `done` (a new card set ends it)
             GEN_WAIT_S = 90,      -- how long the Talent of a card waits for RemainingCharactersToGenerate to reach 0
             GEN_STEP_S = 1,       -- ... looking again every GEN_STEP_S while it waits
             REPIN_MAX = 3,        -- re-pins of ONE card's Talent the verify passes may make (other slots: 1, as 1.8.28)
             VLOG_CAP = 120,       -- `verify Talent` read-back lines per session
             -- 1.8.32: THE RE-PIN STORM AND THE STOCK-RECRUIT IDENTITY (see "1.8.32" above PS.evidence)
             NOOP_MAX = 3,         -- writes that change nothing, per character per slot, before that slot is given up
             cards = {}, retired = {}, noop = {}, setT = nil, ev = nil, cardClass = {},
             -- 1.8.33: A RECRUITED CARD, THE SAVE LOAD, THE HUB COST AND THE CUSTOMIZE DIAGNOSTIC (see "1.8.33" above
             -- PS.demoteCard)
             recruited = {},       -- instance path -> a card the player RECRUITED: a roster character from then on
             cardRp = {},          -- instance path -> the pin of a card (its pool CD), for the recruit identification
             recruitN = 0, demote = nil,   -- RecruitCharacter events seen; the demotion the next pass owes
             notOurs = {},         -- instance path -> a sweep read its slots and it is not ours (until a re-arm/world reset)
             swept = false,        -- a stable, populated sweep of THIS world found nothing ours
             cHi = 0, LOAD_FRAC = 0.4, LOAD_MIN = 40,   -- the census high-water mark; a drop below LOAD_FRAC of it = a load
             loadN = 0, loadSeen = 0, wAddr = nil, wAddrName = nil,   -- save loads seen / folded; the world OBJECT's address
             diagDone = {}, diagN = 0, diagAny = 0, diagCharDone = {}, diagOwn = {},
             DIAG_CAP = 16,        -- DIAG lines for proxies / characters of ours, per session
             DIAG_ANY_CAP = 30,    -- one-line `DIAG proxy … not ours` reports, per session
             DIAG_POLL_S = 15, DIAG_POLLS = 0,    -- 1.8.34: OFF in the release (a test build sets 40). While DORMANT in a hub with ours: one proxy census per 15 s, 40 per world
             dg = nil, dgPolls = 0, dgNext = 0, oursSeen = false,
             gen = nil, genN = 0, vlog = 0,
             res = {}, partRes = {}, cdos = {}, firstSeen = {}, lookEchoed = {}, accKey = {}, reverted = {},
             worldPasses = 0, lastWorld = nil, sweepAt = nil, forceFull = false, urgent = nil, sfo = 0, fao = 0 }

local pinLoadRequested = false
local pinLog = {}
local pinArmed = {}          -- function name -> true, so "hook armed on <fn>" is logged once (session_audit.py vocabulary)
local pinAttempts = {}       -- owner|tag -> re-equips spent on a slot that never took a fragment
local criterionLogged = false
local pinExpected = {}       -- 1.8.18: owner|tag -> this pin wants this slot; `done` means all of them delivered
local pinDelivered = {}      -- 1.8.18: owner|tag -> this slot has delivered; never drive it again
local pinToggled = {}        -- 1.8.18: owner|tag -> the pass a toggle id was written, so ours goes back next pass
local pinVanilla = {}        -- 1.8.18: owner|tag -> the non-ours part this slot was last seen holding
local pinQuiet = {}          -- 1.8.18: one-shot log keys
local pinGaveUp = {}         -- owner|tag -> the give-up message has been logged once (1.8.10)
local pinWaited = 0          -- 1.8.19: passes spent holding `done` while a pinned part was still not resident
-- 1.8.14: a preview/portrait proxy is a TRANSIENT actor the game destroys and recreates while Personnel is open. The
-- 05:43 session re-drove BP_CustomizationProxyCharacter_C_1 nine times and C_0 three times, every pass, forever -
-- pointless (they are previews, not the saved character) and the likeliest source of a stale userdata. Never again.
local PIN_PROXY_PATTERNS = { "CustomizationProxyCharacter", "CustomizationPreviewProxyCharacter",
                             "BrunoPortraitCharacter", "PortraitCharacter", "BP_PreviewActor" }
local function isProxyOwner(p)
    for _, pat in ipairs(PIN_PROXY_PATTERNS) do if p:find(pat, 1, true) then return pat end end
    return nil
end
local pinKnown = {}          -- 1.8.15: instance path -> how it was identified; identity is sticky for the session
local pinDone = false        -- 1.8.14: every pinned slot on every real character is settled; the loop stops
local pinSkipLogged = {}     -- owner -> the skip reason has been logged once this session (1.8.11)
local pinRefused = {}        -- instance path -> already logged a refusal (1.8.10)
local scopeLogged = false

local function shortTag(t) return (tostring(t):gsub("^br%.Customization%.Slot%.Character%.", "")) end
local function shortOwner(o) return (tostring(o):gsub("^.*PersistentLevel%.", ""):gsub("%..*$", "")) end
-- 1.8.26: ONE guarded IsValid. The pin block used to write `o.IsValid and pcall(function() return o:IsValid() end) and
-- o:IsValid()` — the pcall's first result is its STATUS, so that only proved IsValid did not raise and then called it
-- a second time UNGUARDED. The 2026-09-28 21:51 fault is that second call (owningInstance, the old main.lua:1705).
-- A pcall cannot catch a hardware fault, so this is hygiene, not the crash fix (that is the pump, below); it halves
-- the IsValid calls on the hottest path in the loader and leaves no unguarded one. Defined INSIDE the pin block so
-- tools/replay_pin.py, which extracts this block verbatim, carries it.
local function pinOk(o)
    if o == nil then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return (ok and v) and true or false
end

-- session_audit.py reads "hook armed on <fn>" as an arming and "PATH> <fn>" as a firing (tools/session_audit.py:203/206).
-- Arming is therefore logged at the point the route is CHOSEN, and PATH> immediately BEFORE the call, so "armed and never
-- fired" can only ever mean "the loader decided to use it and never got as far as calling it".
local function pinArm(fn, why)
    if pinArmed[fn] then return end
    pinArmed[fn] = true
    log("recruit pin: hook armed on " .. fn .. (why and (" (" .. why .. ")") or ""))
end

-- v1.28.32's lesson, applied here too: GetFullName() on an invalid world returns nil WITHOUT raising, so the TYPE of the
-- result is what gets tested, never the pcall's ok.
-- 1.8.27: through gameWorld() (the viewport's world: three property reads), not UEHelpers.GetWorld() (a FindAllOf).
local function pinWorldName()
    local n = nil
    pcall(function() n = gameWorld():GetFullName() end)
    return (type(n) == "string" and n ~= "") and n or "<none>"
end
local function strategySide()
    local w = pinWorldName()
    return (w:find("HUB_Root", 1, true) ~= nil), w
end

-- The probe's reading (ZCSDK_FocusProbe/Scripts/main.lua:147 dumpOwningSlot / :161 dumpLeveledInstance), plus the two numbers
-- that actually decide it: the fragment instances' OBJECT IDENTITIES and their leveled-ability counts.
local function fragState(s)
    local names, trees, loaded = {}, 0, 0
    pcall(function()
        s.FragmentInstances:ForEach(function(_, e)
            local fi = e
            local okG, g = pcall(function() return e:get() end)
            if okG and g then fi = g end
            -- 1.8.9: IsValid before anything else. GetFullName is internally guarded (it returns nil on a dead
            -- object), but a PROPERTY read on one is not, and a native access violation is not pcall-catchable.
            if not (pinOk(fi)) then
                names[#names + 1] = "<invalid>"; return
            end
            local n = nil
            pcall(function() n = fi:GetFullName() end)
            names[#names + 1] = (type(n) == "string") and n or "<?>"
            pcall(function() fi.LeveledAbilities:ForEach(function() trees = trees + 1 end) end)
            pcall(function() fi.LoadedLeveledAbilities:ForEach(function() loaded = loaded + 1 end) end)
        end)
    end)
    return table.concat(names, ";"), #names, trees, loaded
end

local function slotState(s)
    local st = { id = "?", defn = "<null>" }
    pcall(function()
        local p = s.CustomizationPartPrimaryAssetId
        st.id = tostring(p.PrimaryAssetType.Name:ToString()) .. ":" .. tostring(p.PrimaryAssetName:ToString())
    end)
    pcall(function()
        local d = s.CustomizationPartDefinition
        if d and d.IsValid and d:IsValid() then st.defn = (d:GetFullName():gsub("^[^ ]+ ", ""):gsub("^.*[/%.]", "")) end
    end)
    st.frags, st.nfrag, st.trees, st.loaded = fragState(s)
    return st
end

local function sigOf(st)
    return string.format("partId=%s | partDefinition=%s | %d fragment instance(s) | %d leveled tree(s) | %d loaded tree(s)",
        st.id, st.defn, st.nfrag, st.trees, st.loaded)
end

-- THE CRITERION. Not "did the definition resolve" (both doors can do that, and neither has to) — "did a fragment instance move".
local function deliveredTo(before, after)
    if after.frags ~= before.frags then return true, "FragmentInstances REPLACED" end
    if after.trees > before.trees then return true, "leveled trees " .. before.trees .. " -> " .. after.trees end
    if after.loaded > before.loaded then return true, "loaded trees " .. before.loaded .. " -> " .. after.loaded end
    if after.id ~= before.id then return false, "partId changed and the fragment instances did not — the id-only signature" end
    return false, "nothing on the slot changed"
end

local function logCriterion()
    if criterionLogged then return end
    criterionLogged = true
    log("recruit pin: success criterion = the slot's FragmentInstances are REPLACED (object identity) or it gains " ..
        "LeveledAbilities / LoadedLeveledAbilities entries. CustomizationPartDefinition is NOT a criterion: the game's own " ..
        "CPD_TalentSpec_TheToughGuy reads partDefinition=<null> with 1 leveled tree and draws a full row, and the id-only setter " ..
        "resolves a definition by itself once the asset is resident.")
end

-- ---- 1.8.19: THE GHOST REFUSAL (HANDOFF open items 3 and 7) ----
-- A save can carry a part id from a mod that is NO LONGER INSTALLED. Hawks' save does: a `ZCSDKLongStride` leveled
-- tree whose tier classes are all null, left behind by the uninstalled ZCSDK_Passive (CHANGELOG v1.28.32), and the
-- 2026-09-12 turn-end block is the INFERRED consequence — four launches with the runtime OFF (eight mods / one / none)
-- all blocked after a vault, and a fresh mission with no mods was clean. Writing over a slot in that state is the last
-- thing a loader should do: it cannot know what else in the save refers to it. So the loader REPORTS the ghost and
-- REFUSES to drive that slot, on ANY character in the hub, ours or not. Nothing is ever written by this code.
--
-- WHAT COUNTS AS A GHOST — all three, so the normal 1.8.18 toggle case can never be mistaken for one:
--   (1) the slot carries one of THIS pin's declared tags (so the sweep is bounded), and
--   (2) its part id is NOT carried by any CURRENTLY ENUMERATED manifest — the loader has just discovered every
--       `<Mod>.zcsdk.lua` on disk, so "not in that set" means "no installed mod ships this part"; a slot holding OUR
--       id is in that set BY CONSTRUCTION and is therefore never a ghost, resident or not, and
--   (3) the part is not resident anywhere the loader can see: no resolved `CustomizationPartDefinition` on the slot
--       AND no object at the SDK's own `/Game/ZCSDK/<name>.<name>`.
-- Two EVIDENCE SHAPES satisfy (2)'s "this came from a mod": a `CPD_ZCSDK_*` id (the SDK's own naming), or the
-- FocusProbe's shape — a LEVELED TREE whose tier classes are null (LeveledAbilities entries, zero
-- LoadedLeveledAbilities, and nothing resolved), which is exactly how Hawks' LongStrider tree reads.
--
-- ---- 1.8.20: AND WHAT 1.8.19 GOT WRONG — THREE FALSE POSITIVES IN ONE RETAIL SESSION ----
-- Retail 2026-09-13 (the 22:52:48 session), three of the four GHOST lines named the GAME's own parts:
--     22:54:11  GHOST /Engine/Transient Specializations.Tactical.Primary: holds CPD_TacticalSpec_Soldier ...
--     23:00:21  GHOST /Engine/Transient Specializations.Tactical.Primary: holds CPD_TacticalSpec_Hero_Aurelio_Assault ...
--     23:00:21  GHOST /Engine/Transient Class: holds CPD_ZCSDK_Char_Class_Vanguard ...
-- and only the fourth was real:
--     23:00:37  GHOST Char_Hero_HAWKS_Control_C_0 Specializations.Tactical.Primary: holds CPD_ZCSDK_TacticalSpec_LongStrider ...
-- Both defects are in the same three lines. (a) They were judged WHILE THE CHARACTER WAS STILL SPAWNING: the census
-- went 27 instance(s) at pass 50 -> 73 at pass 51 -> 109 at pass 54 -> 122 at pass 58, and at pass 50 the loader
-- itself recorded `0 with pinned slot(s)` — the slots existed, nothing owned them yet, and evidence shape 2 (a
-- leveled tree with zero LoadedLeveledAbilities on an unresolved slot) is exactly what a half-built slot looks like.
-- (b) The owner was printed from the SLOT's own name, and `shortOwner` strips up to `PersistentLevel.`, which
-- `/Engine/Transient...` does not contain — so the line named a package, not a character. `/Engine/Transient` is not
-- an owner; a report that cannot say WHOSE save is affected is not worth printing.
--
-- TWO RULES, and neither of them guesses:
--   (1) A non-`CPD_ZCSDK_` id is only called a ghost after PIN_GHOST_PASSES CONSECUTIVE passes reading unresolved
--       with trees>0 / loaded==0. Any pass that reads otherwise resets the count to zero. N is taken from the log
--       above: passes 50 -> 54 is how long the hub took to go from 27 half-built instances to the full 109 with
--       every character named (and the true Hawks ghost printed at pass 52, inside that window, so N must not be so
--       large that a real ghost is lost — it is not, because rule (1) does not apply to a `CPD_ZCSDK_` id at all).
--       STATED HONESTLY: the Aurelio slot's own resolution was never measured, because 1.8.19 marked the slot and
--       stopped looking at it; N is derived from the world-population evidence, not from that slot.
--   (1b) NOT DONE, and why: "is this id a registered GAME primary asset" would settle it in one call, but the
--       AssetManager API the loader can reach (GetObjectFromPrimaryAssetId on the KismetSystemLibrary CDO) needs a
--       real by-value FPrimaryAssetId, and the only way this runtime has ever minted one is
--       `GetPrimaryAssetIdFromObject(<a live object>)` — which needs the object a ghost by definition does not have.
--       There is no safe read, so the consecutive-pass rule stands alone. (1.8.16 guessed a UE4SS accessor and
--       printed an address for a whole session; that is not repeated here.)
--   (2) NO REPORT WITHOUT A NAMED OWNER. The owner is the OWNING CUSTOMIZATIONINSTANCE (`owningInstance`), never the
--       slot's own path, and a slot that has no owning instance yet is DEFERRED to a later pass, not printed. This
--       alone would have suppressed all three false lines, and it costs nothing on the real one: Hawks' slot was
--       owned and named at pass 52.
-- BLOCKING vs REPORTING, kept apart on purpose. A `CPD_ZCSDK_*` candidate is certain enough to refuse the moment its
-- owner can be named (that is the Hawks case, and the whole point of the mechanism). An evidence-shape-2 candidate
-- is NOT blocked while it is being counted — if it were, the pin could never drive it, it could never resolve, and
-- the count would reach N by its own doing. It is counted, and the drive is allowed to prove it wrong.
local PIN_GHOST_PASSES = 4   -- consecutive unresolved passes before a non-CPD_ZCSDK_ id is called a ghost
local pinKnownParts = nil    -- short part name -> true, for every part any enumerated manifest carries
local pinKnownPaths = {}     -- 1.8.22: ... and the object path it was named by, so a part the loader did not pin can
                             -- still be re-minted into an FPrimaryAssetId (the stale-slot rebuild needs the ORIGINAL
                             -- id back, and minting one has only ever worked from a live object)
local pinGhostLogged = {}    -- owner|tag|partId -> the GHOST line has been logged once this session
local pinGhostSlot = {}      -- slot full name -> a REPORTED ghost lives here; never collect it, never drive it
local pinGhostSeen = {}      -- slot full name|partId -> consecutive passes this slot has read as a candidate
local pinGhostHeld = {}      -- slot full name|partId|reason -> the "not reported" line has been logged once

local function pinManifestParts()
    if pinKnownParts then return pinKnownParts end
    local k = {}
    local function add(p)
        if type(p) == "string" then
            local n = p:match("([^/.]+)$")
            if n and n ~= "" then k[n] = true; pinKnownPaths[n] = pinKnownPaths[n] or p end
        end
    end
    -- 1.8.27: an id a pin ACCEPTS (H1 / §5.6) or leaves alone on a roster character (its `escape`) is
    -- a part the install ships or a stock part: never a ghost. Only the NAME is recorded - a stock id given a path here
    -- would make the 1.8.22 stale-slot rebuild treat every Blaster Pistol in the hub as ours-shipped.
    local function addName(p)
        local n = (type(p) == "string") and p:match("([^/.]+)$") or nil
        if n and n ~= "" then k[n] = true end
    end
    local function addAny(p)
        if type(p) ~= "string" then return end
        if p:find("/", 1, true) and not p:find("^/Game/Game/") then add(p) else addName(p) end
    end
    for _, rp in ipairs(recruitPins) do
        add(rp.definition)
        if rp.match then add(rp.match.part) end
        for _, s in ipairs(rp.slots or {}) do
            add(s.part)
            for n in pairs(s.accept or {}) do k[n] = true end
            for n in pairs(s.rosterIds or {}) do k[n] = true end
        end
    end
    if type(manifests) == "table" then
        for _, mf in ipairs(manifests) do
            local m = (type(mf) == "table") and mf.m or nil
            if type(m) == "table" then
                for _, g in ipairs(m.grants or {}) do add(g.item) end
                for _, p in ipairs(m.preload or {}) do add(p) end
                for _, rp in ipairs(m.recruitPins or {}) do
                    add(rp.definition)
                    if type(rp.match) == "table" then add(rp.match.part) end
                    for _, s in ipairs(rp.slots or {}) do
                        add(s.part)
                        addAny(s.fallback); addAny(s.escape)
                        if type(s.accept) == "table" then for _, a in ipairs(s.accept) do addAny(a) end end
                    end
                end
            end
        end
    end
    -- 1.8.27 (§2d.3, the :1094 rule narrowed): a part of a dependency that is MISSING is not shipped by anything installed,
    -- whatever a manifest names. Its ids leave the set, so the ghost refusal can see them.
    for n in pairs(CP.deadName or {}) do k[n] = nil; pinKnownPaths[n] = nil end
    pinKnownParts = k
    return k
end

-- returns the ghost part id, or nil. Reads only; IsValid before every method, every read pcall'd.
-- 1.8.27 (§2d.3): a THIRD evidence shape. An id in the name snapshot of a dependency that is MISSING (`requires[].names`,
-- plus the dependency's packages and the pinned parts into it) is certain enough to report - it has no tags, no residency
-- and no installed mod behind it - UNLESS a pin on this tag declares a `fallback`: then it is not a ghost at all, because
-- the normal delivery writes the fallback over it (the removed-pack case with an escape hatch). Second return: the dep.
local function ghostOf(s, tag)
    local cur = ""
    pcall(function() cur = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end)
    if type(cur) ~= "string" or cur == "" or cur == "None" then return nil end
    local dead = CP.deadName and CP.deadName[cur]
    if dead then
        if dead.fb[tag or ""] then return nil end                       -- the fallback will be delivered over it
        local res = false
        pcall(function() local d = s.CustomizationPartDefinition; res = (d and d.IsValid and d:IsValid()) and true or false end)
        if res then return nil end                                      -- resolved after all: the asset is there
        return cur, dead
    end
    if pinManifestParts()[cur] then return nil end                      -- an installed mod ships it: never a ghost
    -- ... and never an id THIS LOADER ITSELF WRITES. The toggle parks a vanilla id on one of our own slots for a
    -- pass; if that pass were ever read as a ghost the slot would be blocked for the session and the toggle - the
    -- whole of the 1.8.18 delivery path - would stop halfway. The toggle targets and every vanilla id a slot was
    -- remembered holding are therefore excluded by name.
    if PIN_TOGGLE_PATH[cur] then return nil end
    for _, v in pairs(pinVanilla) do if v == cur then return nil end end
    local resolved = false
    pcall(function()
        local d = s.CustomizationPartDefinition
        resolved = (d and d.IsValid and d:IsValid()) and true or false
    end)
    if resolved then return nil end                                     -- the game resolved it: the asset is there
    if cur:find("^CPD_ZCSDK_") == nil then
        local _, _, trees, loaded = fragState(s)                        -- evidence 2: a tree with null tier classes
        if not (trees > 0 and loaded == 0) then return nil end
    end
    -- resident after all? then it is not a ghost. 1.8.28: a CACHED answer (PS.resident): one StaticFindObject costs a
    -- whole object-array walk in this UE4SS build, so it is asked once per id per world, in a lookup frame of its own.
    -- Unknown yet -> "pending": the slot is neither reported nor driven this pass.
    local res = PS.resident("/Game/ZCSDK/" .. cur .. "." .. cur)
    if res == nil then return nil, nil, true end
    if res then return nil end
    return cur
end

-- 1.8.20: is `ipath` a name a human can act on? An owning CustomizationInstance under PersistentLevel yields a
-- character name; anything else (no owner yet, /Engine/Transient, a bare package) yields nil and DEFERS the report.
local function namedOwner(ipath)
    if type(ipath) ~= "string" or not ipath:find("PersistentLevel.", 1, true) then return nil end
    local n = shortOwner(ipath)
    if type(n) ~= "string" or n == "" or n:find("/", 1, true) or n == "None" then return nil end
    return n
end

-- one-shot, so a deferral is never a SILENT pass but is never spam either
local function ghostHold(sname, partId, tag, why, reason)
    local k = sname .. "|" .. partId .. "|" .. why
    if pinGhostHeld[k] then return end
    pinGhostHeld[k] = true
    log("recruit pin: ghost candidate " .. partId .. " on " .. shortTag(tag) .. ": not reported — " .. reason)
end

-- the one line this whole mechanism exists to print, and the flag that stops the slot being driven.
-- 1.8.20: `ipath` is the OWNING INSTANCE, not the slot; `pass` is the pin pass number. Returns nothing, writes
-- nothing to the game — the only state it touches is this file's own bookkeeping.
local function ghostReport(sname, ipath, tag, partId, pass, dead)
    local seen = pinGhostSeen[sname]
    -- the id CHANGING is also a pass that read otherwise: the count is per (slot, id), stored per slot because a
    -- slot holds exactly one id at a time
    -- 1.8.28: consecutive CHECKS of this slot, not consecutive pass numbers. A character that is not ours is only
    -- read on a sweep pass (PS.SWEEP_PASSES / PS.SWEEP_S), so its passes are not adjacent any more; a check that reads
    -- otherwise still resets the count (walkOne), and a pass that reads the slot twice (two drive frames) counts once.
    if not (seen and seen.id == partId) then seen = { id = partId, n = 0 } end
    if seen.pass ~= (pass or 0) then seen.n = seen.n + 1; seen.pass = pass or 0 end
    pinGhostSeen[sname] = seen
    local sdk = (partId:find("^CPD_ZCSDK_") ~= nil) or (dead ~= nil)   -- 1.8.27: a missing dependency's id is certain too
    if not sdk and seen.n < PIN_GHOST_PASSES then
        ghostHold(sname, partId, tag, "passes", "unresolved on " .. seen.n .. " of the " .. PIN_GHOST_PASSES ..
            " consecutive pass(es) a non-CPD_ZCSDK_ id needs before it is called a ghost (a character that is still " ..
            "spawning reads exactly like this)")
        return
    end
    local owner = namedOwner(ipath)
    if not owner then
        ghostHold(sname, partId, tag, "owner", "its owning character cannot be named yet (the slot is still under " ..
            shortOwner(sname) .. "), and a report that names no character names nothing — deferred to a later pass")
        return
    end
    pinGhostSlot[sname] = true      -- only a REPORTED ghost blocks the slot; a candidate must stay drivable
    local key = owner .. "|" .. tag .. "|" .. partId
    if pinGhostLogged[key] then return end
    pinGhostLogged[key] = true
    if dead then
        log("recruit pin: GHOST " .. owner .. " " .. shortTag(tag) .. ": holds " .. partId .. " from " .. dead.dep ..
            ", which " .. dead.mod .. " requires and is not installed — reinstall it; the loader will not write over it")
        return
    end
    log("recruit pin: GHOST " .. owner .. " " .. shortTag(tag) .. ": holds " .. partId ..
        " from a mod that is not installed — a save written while it was equipped; the loader will not write over it")
end


-- ---- 1.8.22: THE STALE-SLOT REBUILD ----
-- THE EVIDENCE (retail 2026-09-14/15, CHANGELOG v1.28.53 §9(b) and §13; PROVEN in the data, INFERRED for the symptom).
-- Two facts this file already states, put together:
--   (A) `LoadCustomization` rebuilds a slot's FragmentInstances ONLY when the slot's part id CHANGES (the 1.8.19 header
--       records it from retail 2026-09-13 09:04:40 / 09:04:44), and
--   (B) a MISSION re-creates every character FROM SAVE DATA (ZCSDKLoader.log 21:28:27 vs 21:28:30, quoted by
--       `applyOwner` below).
-- HAWKS is what that costs. He is NOT a pinned character (game class `CPD_Char_Class_Hero_Humanoid`), but his
-- `Specializations.Weapon` slot holds a ZCSDK weapon spec — `CPD_WeaponSpec_ZCSDK_SaberAnakin`, picked in the armoury
-- and written into the save under that mod's v1.0.0 — and his armoury Change Weapon is GREYED OUT, so the slot's id
-- can never change again. By (A) his fragments stay the v1.0.0 ones for ever, and by (B) every mission rebuilds him
-- from them: the REMOVED `GA_OverwatchMelee_Base` still draws a "Melee Overwatch" card (and locks the turn, §1), and
-- his sprint still uses his previous BLASTER's anim proxy table while the visible saber comes from the currently
-- equipped part (§13). A byte-grep over the whole deployed game finds the ability in no ZCSDK container at all — the
-- card is the SAVE, not the pak.
-- VEX is the control, and he is fine — BECAUSE the pin toggles his Weapon slot every hub load
-- (`[TOGGLE to CPD_WeaponSpec_Blaster_Longarm]`, `FragmentInstances REPLACED`) and a manual save afterwards carried
-- the rebuilt fragments into the mission (§11: hub delivery -> manual save -> mission, and no card).
-- SO: do for a non-pinned character exactly what the pin already does for a pinned one — ONE toggle-and-back on the
-- Weapon slot, once per session, in the hub only. Nothing here is a new mechanism; it is the 1.8.18 toggle, aimed at a
-- slot this loader does not own but a mod THIS INSTALL SHIPS put a part into.
--
-- THE FENCES, every one of them narrowing, because this writes to a character that is not ours:
--   * HUB ONLY (`HUB_Root`). In a mission the game re-equips during load and a write there is thrown away anyway.
--   * THE WEAPON TAG ONLY. Class and Tactical are out of scope: driving a Class re-creates the child slots (1.8.18's
--     fact B) and no retail evidence says either of them is stale.
--   * ONLY A PART THIS INSTALL SHIPS — see `staleOursPath` below for the two tests and why one of them is not enough.
--     Either way this can never touch a vanilla part (nothing to fix — the game's own fragments are current) and can
--     never touch a GHOST (a ghost is by construction an id no installed mod ships AND is not resident; the
--     `pinGhostSlot` test is belt and braces on top of that).
--   * NOT OURS. A pinned character already gets the 1.8.18 toggle; running both on him would fight the pin mid-flight.
--   * A REAL CHARACTER: never a preview/portrait proxy (`isProxyOwner`), and never a slot whose owning
--     CustomizationInstance cannot be NAMED (1.8.20's rule — an unnamed owner is a slot mid-spawn).
--   * ONCE PER SESSION per (owner, id), at most PIN_MAX_RETRY writes, and a failure is FINAL — no retry, ever.
--   * BOTH IDS ARE MINTED BEFORE THE FIRST WRITE. This is the one that matters: if the toggle went on and the ORIGINAL
--     id could not be minted back, the character would be left wearing a Blaster Longarm. So the toggle is not written
--     until the original part and the toggle part are BOTH resident and both mint an FPrimaryAssetId.
-- AND IT IS ONLY HALF THE FIX: rebuilt fragments live in the hub instance, and a mission reads the SAVE. The REBUILT
-- line therefore tells the operator to make a manual save, exactly as §11's verified Vex sequence did.
local STALE_SLOT_REBUILD = true
local STALE_TAG = "br.Customization.Slot.Character.Specializations.Weapon"
local staleState = {}        -- owner|partId -> { phase = "toggle"|"back"|"done"|"failed", tries =, waits = }
local staleSkipped = {}      -- slot full name -> counted once as "not ours, not ours-shipped"
local staleCand = {}         -- rebuilt every pass: instance path -> the LIVE Weapon slot on a character that is not ours
local staleFlight = {}       -- owner -> the ORIGINAL part id, while the slot is parked on the toggle id. Without this
                             -- the next pass re-reads the slot, sees the (vanilla) TOGGLE id, calls it "not
                             -- ours-shipped" and walks away — leaving the character on a Blaster Longarm for ever.
local staleRebuilt, staleFailed = 0, 0

-- DOES THIS INSTALL SHIP THIS PART, and where does it live? Returns the object path, or nil.
-- TWO TESTS, because ONE IS NOT ENOUGH — and this is the correction that made the mechanism work at all. The first is
-- `pinManifestParts()`, the enumerated set. But a manifest does not have to ENUMERATE a part for the install to ship
-- it: `build/ZCSDK_SaberAnakin.zcsdk.lua` — the very mod whose spec is stuck on Hawks — declares ONE primary type
-- (`{ type = "CustomizationPartDefinition", path = "/Game/ZCSDK" }`), an empty `grants`, no `preload` and no
-- `recruitPins`, so the enumerated set does not contain `CPD_WeaponSpec_ZCSDK_SaberAnakin` and never will.
-- The second test is the one the GHOST RULE already uses in the negative: a live object at the SDK's own content root
-- `/Game/ZCSDK/<id>.<id>`, which is where every mod this SDK builds cooks its parts (it is the manifests' own
-- `primaryTypes[].path`). It is a RESIDENCY test, not a name guess, and nothing else can pass it: a VANILLA part is
-- never under /Game/ZCSDK, and a GHOST is by definition NOT resident there (that is what makes it a ghost). It also
-- hands back the path, which is what the write-back needs to re-mint the original id.
-- 1.8.28: the residency answer is CACHED per world (PS.resident); nil = not asked yet (queued for a lookup frame), and the
-- caller treats that as "not judged this pass" - never as "vanilla".
local function staleOursPath(id)
    local p = pinKnownPaths[id]
    if p then return p end
    if not pinManifestParts()[id] then
        local sdk = "/Game/ZCSDK/" .. id .. "." .. id
        local res = PS.resident(sdk)
        if res == nil then return nil, true end
        if res then return sdk end
        return nil
    end
    return nil
end

-- a live object for `path`, minted into a real FPrimaryAssetId the same way the pin's own drive does. Returns nil and
-- REQUESTS THE LOAD when the part is not resident — never a guess, never a Lua table pretending to be one.
-- 1.8.28: counted (PS.get) but NOT budgeted: a rebuild writes at most twice per character per session, and its
-- both-ids-before-the-first-write rule (and the unwind) must never be split across frames by a budget.
local function staleMint(path, ksl)
    if type(path) ~= "string" or path == "" then return nil end
    local o = PS.get(path, true)
    if not (pinOk(o)) then
        pcall(LoadAsset, path)
        return nil
    end
    if not (pinOk(ksl)) then return nil end
    local ok, id = pcall(function() return ksl:GetPrimaryAssetIdFromObject(o) end)
    if ok and id then return id end
    return nil
end

-- collected during the slot sweep so identity is settled before anything is judged; the LIVE slot is the highest
-- object index, the same 1.8.16 rule the pin's own collection uses (every equip leaves the old slot objects alive).
local function staleConsider(s, sname, ipath, tag)
    if not STALE_SLOT_REBUILD then return end
    if tag ~= STALE_TAG then return end
    if pinGhostSlot[sname] then return end
    if isProxyOwner(sname) or isProxyOwner(tostring(ipath or "")) then return end
    if not namedOwner(ipath) then return end
    local idx = tonumber(sname:match("_(%d+)$") or "0") or 0
    local prev = staleCand[ipath]
    if prev and prev.idx >= idx then return end
    local cur = ""
    pcall(function() cur = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end)
    if type(cur) ~= "string" or cur == "" or cur == "None" then return end
    -- 1.8.28: the slot is THIS frame's (the drive frame collects and acts in one frame); staleCand is rebuilt per frame.
    staleCand[ipath] = { slot = s, sname = sname, tag = tag, id = cur, idx = idx }
end

-- one write, judged by the SAME criterion the pin uses: did the FragmentInstances' OBJECT IDENTITIES move.
local function staleWrite(cand, owner, id, step)
    -- session_audit.py reads `hook armed on <fn>` as an arming and `PATH> <fn>` as a firing, and a firing with no
    -- arming above it is a FINDING. The rebuild can write before `legacyOwner` ever arms the setter (it runs earlier
    -- in the pass), so it arms it itself — pinArm is one-shot, so the pin's own line is unaffected.
    pinArm("SetCustomizationPartPrimaryAssetId", "1.4.0 setter: LoadCustomization rebuilds the fragments on an id CHANGE")
    local before = slotState(cand.slot)
    log("recruit pin: PATH> SetCustomizationPartPrimaryAssetId (" .. shortTag(cand.tag) .. ") on " .. owner ..
        " [stale-slot rebuild: " .. step .. "]")
    local ok, err = pcall(function() cand.slot:SetCustomizationPartPrimaryAssetId(id) end)
    if not ok then return false, "the setter raised on the " .. step .. ": " .. tostring(err) end
    local after = slotState(cand.slot)
    log("recruit pin:   " .. shortTag(cand.tag) .. " BEFORE " .. sigOf(before))
    log("recruit pin:   " .. shortTag(cand.tag) .. " AFTER  " .. sigOf(after))
    if after.frags == before.frags then
        return false, "the " .. step .. " left FragmentInstances at the same object identities — LoadCustomization " ..
            "did not run, so nothing was rebuilt"
    end
    return true
end

-- the two-pass state machine for ONE candidate. Returns true while it is still mid-flight, so `done` can be held.
local function staleOne(cand, ipath, inst, ksl)
    local owner = namedOwner(ipath)
    if not owner then return false end
    local key = owner .. "|" .. cand.id
    local st = staleState[key]
    if st == nil then st = { phase = "toggle", tries = 0, waits = 0 }; staleState[key] = st end
    if st.phase == "done" or st.phase == "failed" then return false end
    local toggle = PIN_TOGGLE_DEFAULT[cand.tag]
    local tpath = PIN_TOGGLE_PATH[toggle or ""]
    -- remembered as a STRING the first time it resolves: mid-flight the slot holds the toggle id, and re-deriving the
    -- original's path from a slot that no longer names it is how a character gets left on a Blaster Longarm.
    st.opath = st.opath or staleOursPath(cand.id)
    local opath = st.opath
    local line = "recruit pin: stale-slot rebuild " .. owner .. " " .. shortTag(cand.tag) .. ": " .. cand.id ..
        " -> " .. tostring(toggle) .. " -> " .. cand.id .. " "
    local function fail(why)
        st.phase = "failed"
        staleFlight[owner] = nil
        staleFailed = staleFailed + 1
        log(line .. "rebuild FAILED (" .. why .. ")")
        return false
    end
    if st.tries >= PIN_MAX_RETRY then
        return fail("spent all " .. PIN_MAX_RETRY .. " attempt(s)" ..
            (st.phase == "back" and " and the slot is still on " .. tostring(toggle) .. " — re-pick the weapon in the armoury" or ""))
    end
    if st.phase == "toggle" then
        -- BOTH ids first. A toggle written without a way back would leave this character wearing the toggle part.
        local oid = staleMint(opath, ksl)
        local tid = staleMint(tpath, ksl)
        if oid == nil or tid == nil then
            st.waits = st.waits + 1
            if st.waits > PIN_RESIDENCY_PASSES then
                return fail("waited " .. PIN_RESIDENCY_PASSES .. " pass(es) and " ..
                    ((oid == nil) and (cand.id .. " (" .. tostring(opath) .. ")") or (tostring(toggle) .. " (" .. tostring(tpath) .. ")")) ..
                    " never became resident — nothing was written")
            end
            if st.waits == 1 then
                log(line .. "holding: both ids must be mintable before the first write is allowed (requested the load)")
            end
            return true
        end
        st.tries = st.tries + 1
        local ok, why = staleWrite(cand, owner, tid, "toggle out")
        if not ok then
            -- UNWIND, and it is not a retry: the verdict is already FAILED and this key never runs again. It is one
            -- write of the id the slot ALREADY HELD, because the one state this must never leave behind is a
            -- character wearing the toggle part.
            local okR = staleWrite(cand, owner, oid, "restore")
            return fail(why .. "; the original id was written back" ..
                (okR and "" or " but that write did not move the fragments either — check the slot in the armoury"))
        end
        st.phase = "back"
        staleFlight[owner] = cand.id
        log(line .. "toggled out (FragmentInstances REPLACED); ours goes back on the next pass")
        return true
    end
    -- phase "back": re-mint the ORIGINAL id from a live object (never held across passes) and put it back.
    local oid = staleMint(opath, ksl)
    if oid == nil then
        st.waits = st.waits + 1
        if st.waits > PIN_RESIDENCY_PASSES then
            return fail("the original part " .. cand.id .. " (" .. tostring(opath) .. ") could not be re-minted, and " ..
                "the slot is still on " .. tostring(toggle) .. " — re-pick the weapon in the armoury")
        end
        return true
    end
    st.tries = st.tries + 1
    local ok, why = staleWrite(cand, owner, oid, "write back")
    if not ok then return fail(why) end
    st.phase = "done"
    staleFlight[owner] = nil
    staleRebuilt = staleRebuilt + 1
    -- the hub instance now carries current fragments; the MISSION reads the save, so the save is the other half.
    if pinOk(inst) then
        local okR, errR = pcall(function() inst:RefreshCustomization() end)
        if not okR then log("recruit pin: RefreshCustomization failed on " .. owner .. ": " .. tostring(errR)) end
    end
    log(line .. "REBUILT (FragmentInstances REPLACED twice) — make a manual save before the next mission")
    return false
end

-- every candidate this pass. Returns true while any rebuild is mid-flight, so `done` does not stop the loop halfway
-- through one (bounded: PIN_MAX_RETRY writes and PIN_RESIDENCY_PASSES waits, then it fails and stops for good).
local function staleDrive(instByPath, ksl, hub)
    if not STALE_SLOT_REBUILD or not hub then return false end
    local busy = false
    for ipath, cand in pairs(staleCand) do
        local c = instByPath[ipath]
        local ours = (c and c.ident) or pinKnown[ipath]
        if not ours then
            -- a slot PARKED ON THE TOGGLE ID reads as a vanilla part; it is this pass's job to FINISH it, not to
            -- re-judge it, so the id in flight is the one the state machine is handed.
            local fowner = namedOwner(ipath)
            local flight = fowner and staleFlight[fowner] or nil
            if flight then
                cand = { slot = cand.slot, sname = cand.sname, tag = cand.tag, id = flight, idx = cand.idx }
            end
            local shipped, pending = nil, false
            if not flight then shipped, pending = staleOursPath(cand.id) end
            if pending then
                -- 1.8.28: its residency is being looked up (a lookup frame of its own): judged on a later pass
            elseif not flight and not shipped then
                staleSkipped[cand.sname] = true          -- vanilla, or a ghost: nothing this install shipped, nothing to rebuild
            else
                -- 1.8.28: the slot is this frame's own (collected by this frame's FindAllOf); the owning instance is
                -- reached from it by GetOuter (PS.instOf), never by a StaticFindObject
                local live = cand.slot
                if pinOk(live) then
                    if staleOne(cand, ipath, PS.instOf(live, ipath), ksl) then busy = true end
                elseif flight then
                    busy = true                          -- mid-flight and gone this frame: hold `done`, finish next pass
                end
            end
        end
    end
    return busy
end

local function staleSummary()
    local k = 0
    for _ in pairs(staleSkipped) do k = k + 1 end
    log(string.format("recruit pin: stale-slot rebuild: %d slot(s) REBUILT, %d FAILED, %d skipped " ..
        "(not ours, not ours-shipped)", staleRebuilt, staleFailed, k))
end


-- THE ONE VERIFIED WAY TO READ A TSoftObjectPtr IN UE4SS 3.0.1, KEPT BECAUSE NOTHING ELSE RECORDS IT.
-- (1.8.19 deleted the resolver probe that used it - its question was answered at retail 09:04:18: the AssetManager
-- resolves every one of our parts once they are RESIDENT - but the accessor chain cost a crashed game to find and
-- must not be lost with it.) UE4SS 3.0.1's TSoftObjectPtr userdata metatable registers EXACTLY
--     GetWeakPtr | GetTagAtLastTest | GetObjectID | type | __gc
-- (read out of UE4SS.dll's push_softobjectproperty, RVA 0x2cafe0, metatable block 0x2cb2b0-0x2cb478). There is NO
-- ToString and NO GetAssetPathString - 1.8.16 guessed both and printed an address for a whole session. GetObjectID
-- yields an FSoftObjectPath, whose shape the 196985 jmap gives:
--     FSoftObjectPath { AssetPath : FTopLevelAssetPath { PackageName : FName, AssetName : FName }, SubPathString }
-- so the VERIFIED chain is
--     sp:GetObjectID().AssetPath.PackageName:ToString()   ..  "."  ..  sp:GetObjectID().AssetPath.AssetName:ToString()
-- every step pcall'd, and a SUCCESSFUL read of an EMPTY name ("the manager holds no path") must be distinguished
-- from a FAILED read (which concludes nothing) - conflating those two is what made 1.8.16's output worthless.
-- An FPrimaryAssetId is read from its own members instead (FPrimaryAssetId { PrimaryAssetType { Name : FName },
-- PrimaryAssetName : FName }) - what slotState() below does - NOT through Conv_PrimaryAssetIdToString, which hands
-- back an FString USERDATA.

-- ---- 1.8.13: PER-PART RESIDENCY, BECAUSE THE THREE PINNED PARTS BEHAVED DIFFERENTLY ON ONE CALL ----
-- Retail 2026-09-13 05:30:21. Three `EquipCustomizationDefinition` calls, one per pinned part, each with that part's own
-- AllowedSlots container, each `returned true`:
--     Class   -> AFTER partDefinition=CPD_ZCSDK_Char_Class_Sith | 6 fragment instance(s) -> DELIVERED - FragmentInstances REPLACED
--     Weapon  -> not delivered, partDefinition still <null>, 7 fragment instance(s) unchanged
--     Tactical-> not delivered, partDefinition still <null>, 5 fragment instance(s) unchanged
-- THE CONTAINER REACHED THE NATIVE - the Class slot proves it, and with it that the marshalling question is closed. What
-- separates the three is the RESOLVER: `UCustomizationStatics::GetCustomizationPartDefinitionFromPartId` (RVA 0x8c46060)
-- asks the AssetManager for the LOADED object for that FPrimaryAssetId first, and falls back to its path map. An id the
-- manager has never SCANNED resolves through neither. All three parts live in /Game/ZCSDK and the loader rescans
-- `CustomizationPartDefinition` over exactly that path at startup, so a scan-path gap is INFERRED, not proven - which is
-- why this escalates one observable step at a time and PRINTS each one instead of guessing.
--
-- Cooked-asset evidence for why the three are not interchangeable (tagged-property decode of the deployed pak):
-- CPD_ZCSDK_Char_Class_Sith carries NO `AllowedSlots` tagged property at all (it equals the class default: an EMPTY
-- FGameplayTagContainer), while CPD_WeaponSpec_ZCSDK_SithSaber (size 12) and CPD_ZCSDK_TacticalSpec_Sith (size 20) both
-- carry a non-empty one. So the one call that DELIVERED is the one that passed an EMPTY container, and the two that
-- passed a populated container delivered nothing - consistent with the resolver failing for those two ids, and also
-- with an empty container meaning "every slot this definition names". Both readings are tested by the ladder below.
local partDiag = {}          -- part path -> the diagnostic line has been logged once this session
local partStep = {}          -- part path -> how far the residency ladder has been climbed
local partWhen = {}          -- part path -> the pass number the last step was taken on (1.8.15: a per-part timer)
local partHeld = {}          -- 1.8.16: the held-verdict line has been logged once
local partDriven = {}        -- 1.8.16: part path -> the pass its slot was last actually DRIVEN
local partWatch = {}         -- part path -> { want=, ptype= } for every pinned part seen, so the ladder ticks on its own
-- ---- 1.8.20: THE LADDER RE-RAN ON A PART THAT HAD ALREADY RESOLVED ----
-- Retail 2026-09-13, 23:00:38 -> 23:00:58, after all three slots read `finished`, the log alternated every pass:
--     23:00:53  part CPD_WeaponSpec_ZCSDK_SithSaber did not resolve — step 1: LoadAsset(...)      <- pass 57 tick
--     23:00:53  part CPD_WeaponSpec_ZCSDK_SithSaber resolved after step 1 of the residency ladder <- pass 57 drive
--     23:00:58  part CPD_WeaponSpec_ZCSDK_SithSaber did not resolve — step 1: LoadAsset(...)      <- pass 58 tick
-- THE CAUSE, exactly: the drive path clears `partStep[path]` when a part resolves but leaves `partWatch[path]` set,
-- and the per-pass tick loop treats `(partStep[path] or 0) == 0` as "not started" and climbs to step 1 again. It is
-- NOT a stale read and it is NOT a re-load of something absent: the tick's own precondition is that
-- StaticFindObject(path) returns a VALID object, so the part is demonstrably resident and the line contradicts the
-- test that produced it. The LoadAsset it issues is a real (and idempotent) request for an asset already loaded.
-- THE FIX is one flag: a part that has resolved once is SETTLED — off the watch list, and refused by
-- escalateResidency if anything puts it back. Nothing on the delivery path is touched (the 1.8.18 toggle route still
-- drives Class -> Weapon -> Tactical and still delivers), and `resolved after step N` now prints once instead of
-- once per pass, because the second print was the same re-climb wearing a success verb.
local partSettled = {}       -- part path -> this part resolved on a driven slot; the ladder is finished with it
local PART_STEP_PASSES = 3   -- ~15 s at the 5 s cadence: a step is given time to take before the next one is judged
local PART_CLASS = { CustomizationPartDefinition = "/Script/BitReactorCore.CustomizationPartDefinition",
                     CustomizationDefinition     = "/Script/BitReactorCore.CustomizationDefinition",
                     CharacterClass              = "/Script/BitReactorGame.CharacterClass" }

-- what the loader can actually see about one part, printed once so the next reader does not have to infer it
-- 1.8.28: handed the object the drive just found (the same frame), never a second StaticFindObject of its own
local function partReport(path, o)
    if partDiag[path] then return end
    partDiag[path] = true
    local found = (o ~= nil)
    local valid = false
    pcall(function() valid = (o and o.IsValid and o:IsValid()) and true or false end)
    local full = "<none>"
    if valid then pcall(function() local n = o:GetFullName(); if type(n) == "string" then full = n end end) end
    log(string.format("recruit pin: part %s: object=%s | valid=%s | %s",
        (path:match("([^/.]+)$") or path), found and "found" or "MISSING", valid and "y" or "n", full))
end

-- One step per pass, each one observable, for a part whose slot will not resolve. Nothing here is speculative: LoadAsset is
-- what the pin has always used, `loadpkg` is the bridge's synchronous LoadPackage, and `rescan` is the same
-- ScanPathsForPrimaryAssets the loader already runs at startup - re-aimed at this one package's own directory.
-- 1.8.15: a step is only taken when the PREVIOUS one has had time to land. In the 05:43 session steps 3 and 4 fired in
-- the same second (05:48:53), so the rescan was condemned before it could possibly have taken effect — the ladder was
-- measuring itself, not the game. `pass` is the pin pass number; PART_STEP_PASSES of them is roughly 15 s.
local function escalateResidency(path, want, ptype, pass)
    -- 1.8.20: a part that has already resolved on a driven slot never climbs again. Without this the ladder restarts
    -- at step 1 every pass for the rest of the session and prints `did not resolve` about a part it just proved
    -- resident (retail 23:00:38-23:00:58).
    if partSettled[path] then return end
    partWatch[path] = { want = want, ptype = ptype }
    local n = (partStep[path] or 0)
    if n > 0 and pass and (pass - (partWhen[path] or 0)) < PART_STEP_PASSES then return end
    n = n + 1
    partStep[path] = n
    partWhen[path] = pass or 0
    if n == 1 then
        log("recruit pin: part " .. want .. " did not resolve — step 1: LoadAsset(" .. path .. ")")
        pcall(LoadAsset, path)
    elseif n == 2 then
        local pkg = path:match("^(.-)%.[^%.]+$") or path
        log("recruit pin: part " .. want .. " did not resolve — step 2: bridge loadpkg " .. pkg)
        pcall(bridge, "ZCSDK:loadpkg|" .. pkg)
    elseif n == 3 then
        -- the coordinator's hypothesis, tested rather than argued: the part PICKER reads UCustomizationPartsTagSubsystem's
        -- maps, and BuildPartTagMaps ran at 05:44:51 — two minutes BEFORE any of our parts were resident. The resolver
        -- itself does not consult it (the whole of 0x8c46060..0x8c46209 touches only the AssetManager), so this should
        -- change nothing; if it DOES flip a part, that reading was right and this comment is wrong.
        log("recruit pin: part " .. want .. " did not resolve — step 3: bridge BuildPartTagMaps (the part tag cache was " ..
            "built before our parts were resident)")
        local sub = StaticFindObject("/Script/BitReactorCore.Default__CustomizationPartsTagSubsystem")
        local addr = nil
        pcall(function() local live = FindAllOf("CustomizationPartsTagSubsystem")
            if type(live) == "table" then for _, o in ipairs(live) do
                if o and o.IsValid and o:IsValid() then local a; pcall(function() a = o:GetAddress() end); if a then addr = a end end
            end end end)
        if addr then
            pcall(bridge, "ZCSDK:callthis|?BuildPartTagMaps@UCustomizationPartsTagSubsystem@@AEAAXXZ|" .. string.format("%x", addr))
        else
            log("recruit pin:   (no live CustomizationPartsTagSubsystem found — step skipped)")
        end
    elseif n == 4 then
        local pkg = path:match("^(.-)%.[^%.]+$") or path
        local dir = pkg:match("^(.*)/[^/]+$") or pkg
        local cls = PART_CLASS[ptype or ""] or PART_CLASS.CustomizationPartDefinition
        log("recruit pin: part " .. want .. " did not resolve — step 4: bridge rescan " ..
            tostring(ptype or "CustomizationPartDefinition") .. " over " .. dir ..
            " (the AssetManager has no NameData for this id, so GetPrimaryAssetObject cannot answer)")
        pcall(bridge, "ZCSDK:rescan|" .. tostring(ptype or "CustomizationPartDefinition") .. "|" .. dir .. "|" .. cls .. "|0")
    elseif n == 5 then
        -- 1.8.16: NO VERDICT WITHOUT A DRIVE. The 08:38 session printed `STILL does not resolve` for all three parts,
        -- two of which had already resolved and delivered minutes earlier, because the verdict was measured on a
        -- character the pin had stopped driving. A verdict now requires that this part's slot was actually driven
        -- recently; otherwise the ladder holds at step 4 and says so once.
        if not (partDriven[path] and pass and (pass - partDriven[path]) <= PART_STEP_PASSES * 2) then
            partStep[path] = 4
            if not partHeld[path] then
                partHeld[path] = true
                log("recruit pin: part " .. want .. " — holding the verdict: its slot has not been driven recently, so " ..
                    "'does not resolve' would be a statement about the pin, not the part (the 08:38 lesson)")
            end
            return
        end
        log("recruit pin: part " .. want .. " STILL does not resolve after LoadAsset, loadpkg, BuildPartTagMaps and a rescan " ..
            "of its own directory — the AssetManager will not carry this primary asset id, and no equip path can deliver its " ..
            "fragments until it does (this is now an asset-registration question, not a loader one)")
    end
end

-- 1.8.14: RE-FOUND EVERY PASS, NEVER CACHED. A UObject wrapper held across passes is a userdata whose object the
-- engine may have collected, and dereferencing one is a native access violation pcall cannot catch - which is what the
-- 05:50:58 crash was (43 frames, reading 0xffffffffffffffff, inside the Lua VM with no GetClass frame). Nothing in this
-- file survives a pass except strings and numbers.


-- THE ROUTE — the plain 1.4.0 setter, and since 1.8.19 the ONLY one in this file. Retail 2026-09-13 09:02 is the proof:
--   09:04:18  GetObjectFromPrimaryAssetId returned OUR OBJECT for all three parts once resident. The AssetManager was
--             never the problem. (That probe's path half was broken; that reading is discarded, and the probe is gone.)
--   09:04:40  PATH> SetCustomizationPartPrimaryAssetId (Specializations.Tactical.Primary)
--             BEFORE partId=CPD_TacticalSpec_Assault | partDefinition=CPD_TacticalSpec_Assault | 5 frag | 3 leveled tree(s)
--             AFTER  partId=CPD_ZCSDK_TacticalSpec_Sith | partDefinition=CPD_ZCSDK_TacticalSpec_Sith | 5 frag | 2 leveled tree(s)
--             DELIVERED — FragmentInstances REPLACED          <-- OUR TWO TREES, through the plain 1.4.0 setter
--   09:04:40  PATH> SetCustomizationPartPrimaryAssetId (Class) [re-drive: the id is already ours and its definition is null]
--   09:04:44+ every Tactical AFTER reads partDefinition=<null> | 0 leveled tree(s), and the FocusProbe finds the delivered
--             trees on STALE slot objects beside a live one at 0.
-- TWO FACTS, BOTH PROVEN BY THAT SEQUENCE:
--   (A) The setter's LoadCustomization rebuilds fragments only when the slot's id CHANGES. A slot that already holds our
--       id is a no-op for ever — which is why the Sith has been empty since the first session that wrote our id onto him,
--       and why every "re-drive" since 1.8.14 was wasted work.
--   (B) Driving the CLASS part re-creates the character's child slots, discarding whatever was just delivered into them
--       (the same mechanism that lost the identity at 07:52:26). So Class must be driven FIRST and then left alone —
--       1.8.15's "Class last" was exactly the wrong direction.
-- HENCE 1.8.18: order Class -> Weapon -> Tactical; deliver onto an "already ours, no fragments" slot by TOGGLING it to a
-- different id first and setting ours on the NEXT pass (LoadCustomization needs the change, and needs the tick); never
-- drive a slot again once it has delivered; stop when all of them have.
local function legacyOwner(owner, p)
    pinArm("SetCustomizationPartPrimaryAssetId", "1.4.0 setter: LoadCustomization rebuilds the fragments on an id CHANGE")
    -- (1) ORDER. Class first (it rebuilds the child slots), then Weapon, then Tactical and the rest, then the TALENT
    -- (1.8.27, G2): last, so the native voice writer (OnSpawnCharacterAsyncComplete sets the talent from the voice map)
    -- has already run and the Class's re-creation of the child slots, driven first and to completion, cannot erase it.
    -- The catch-all "" pass therefore skips the Talent.
    local ordered = {}
    local TALENT = "%.Specializations%.Talent$"
    -- 1.8.33: the VOICE first (PS.orderOf): it is not a Class child, and it is delivered before the Class re-creates the
    -- Specializations subtree, so nothing written after it can be undone by it
    for _, want in ipairs({ "%.Info%.Voiceover$", "%.Class$", "%.Specializations%.Weapon$", "", TALENT }) do
        for _, e in ipairs(p.list) do
            if not e.__ordered and ((want == "" and not e.tag:find(TALENT)) or (want ~= "" and e.tag:find(want))) then
                e.__ordered = true; ordered[#ordered + 1] = e
            end
        end
    end
    for _, e in ipairs(p.list) do e.__ordered = nil end

    -- 1.8.18b: "Class FIRST" means first TO COMPLETION, not merely first in the loop. Driving the Class part
    -- re-creates the character's child slots, so any spec delivered before the Class has finished is thrown away on
    -- the Class's next write — and the Class needs TWO passes when it has to be toggled. So while an undelivered
    -- Class slot is in this character's list, it is the only slot driven.
    local classPending = nil
    for _, e in ipairs(ordered) do
        if e.tag:find("%.Class$") and not pinDelivered[e.key] then classPending = e end
    end
    if classPending then
        if not pinQuiet[classPending.key .. "|first"] then
            pinQuiet[classPending.key .. "|first"] = true
            log("recruit pin: " .. shortOwner(owner) .. ": the Class slot is not delivered yet, so it is the ONLY " ..
                "slot driven — driving the Class re-creates this character's child slots and would discard anything " ..
                "already delivered into them (retail 09:04:40 -> 09:04:44)")
        end
        -- 1.8.33: ... except an undelivered VOICE, which goes first in the same frame (it is not a Class child)
        local keep = {}
        for _, e in ipairs(ordered) do
            if e.tag:find("%.Info%.Voiceover$") and not pinDelivered[e.key] then keep[#keep + 1] = e end
        end
        keep[#keep + 1] = classPending
        ordered = keep
    end
    for _, e in ipairs(ordered) do
        if pinDelivered[e.key] then
            -- (3) a delivered slot is never driven again, and the Class especially never: driving it rebuilds the
            -- children and throws away the specs that were just delivered into them.
            if not pinQuiet[e.key] then
                pinQuiet[e.key] = true
                log("recruit pin: " .. shortTag(e.tag) .. " on " .. shortOwner(owner) .. " is DELIVERED — never driven again")
            end
        else
            -- remember this slot's vanilla part the first time we see one, so the toggle has something real to use
            if e.cur ~= e.want and e.cur ~= "?" and e.cur ~= "None" then pinVanilla[e.key] = e.cur end
            local write, why, busy, merr = nil, nil, false, nil
            -- 1.8.28: the id is minted HERE, at the write, from an object THIS frame found (PS.mint: the frame's own
            -- lookup, within its budget). A spent budget is not a verdict: the write waits for the next drive frame.
            local ours = (e.cur ~= e.want) or (pinToggled[e.key] ~= nil)
            if ours then
                write, busy, merr = PS.mint(e.path)
                if pinToggled[e.key] and e.cur == e.want then
                    why = "toggle complete: the id differs again, so LoadCustomization will rebuild"
                    if write ~= nil then pinToggled[e.key] = nil end
                end
                if write == nil and not busy then
                    if merr then
                        log("recruit pin FAILED: " .. e.tag .. " on " .. owner .. ": GetPrimaryAssetIdFromObject: " .. merr)
                    else
                        -- resident when this pass judged it, gone at the write: ask again, and let the next pass decide
                        pcall(LoadAsset, e.path)
                        CP.once("gone|" .. e.path, "recruit pin: part " .. e.want .. " was resident when the pass " ..
                            "judged it and is not at the write — requested the load; the next pass decides")
                    end
                end
            else
                -- (2) THE TOGGLE. The id is already ours and nothing was delivered, so the setter would do nothing at
                -- all. Put a DIFFERENT id on the slot this pass; ours goes back on the NEXT one, and the change is what
                -- makes LoadCustomization run.
                local other = pinVanilla[e.key] or PIN_TOGGLE_DEFAULT[e.tag]
                if other == nil or other == e.want then
                    if not pinQuiet[e.key] then
                        pinQuiet[e.key] = true
                        log("recruit pin: " .. shortTag(e.tag) .. " on " .. shortOwner(owner) .. " holds " .. e.want ..
                            " with no fragments and there is no other id to toggle through — leaving it alone")
                    end
                    -- 1.8.33: and it is SETTLED (an attempt that cannot run is spent): 1.8.32 collected it again every
                    -- pass, so the episode never reached `done` (retail 18:22:54-18:26:09)
                    pinAttempts[e.key] = PIN_MAX_RETRY
                    pinGaveUp[e.key] = true
                else
                    local oid, b2 = PS.mint(PIN_TOGGLE_PATH[other] or "")
                    busy = b2
                    if oid == nil and not busy then
                        if not pinQuiet[e.key .. "|toggleload"] then
                            pinQuiet[e.key .. "|toggleload"] = true
                            log("recruit pin: " .. shortTag(e.tag) .. " toggle needs " .. tostring(other) ..
                                " resident (" .. tostring(PIN_TOGGLE_PATH[other]) .. ") — requested the load")
                        end
                        pcall(LoadAsset, PIN_TOGGLE_PATH[other] or "")
                    elseif oid ~= nil then
                        write, why = oid, "TOGGLE to " .. other .. " (the setter only rebuilds fragments on an id CHANGE; " ..
                            "ours goes back on the next pass)"
                        pinToggled[e.key] = pinPass
                    end
                end
            end
            if busy then
                -- the ORDER holds under the budget: nothing after this slot is written this frame either
                if PS.P then PS.P.again, PS.P.deferred = true, PS.P.deferred + 1 end
                break
            end
            if write ~= nil then
                -- 1.8.10: a retry is only spent when a route actually RAN on this slot (1.8.28: counted at the write
                -- itself, so a write the lookup budget deferred to the next frame costs nothing)
                if e.cur == e.want then pinAttempts[e.key] = (pinAttempts[e.key] or 0) + 1 end
                log("recruit pin: PATH> SetCustomizationPartPrimaryAssetId (" .. shortTag(e.tag) .. ") on " ..
                    shortOwner(owner) .. (why and (" [" .. why .. "]") or ""))
                local preV = e.tag:find("%.Info%.Voiceover$") and PS.readKin(p.byTag) or nil   -- 1.8.33 DIAGNOSTIC
                local ok, err = pcall(function() e.slot:SetCustomizationPartPrimaryAssetId(write) end)
                if not ok then
                    log("recruit pin FAILED: " .. e.tag .. " on " .. owner .. ": " .. tostring(err))
                    PS.noopNote(e.key, owner, e.cur)     -- 1.8.32 (a): a write that changed nothing is an attempt
                else
                    local after = slotState(e.slot)
                    log("recruit pin:   " .. shortTag(e.tag) .. " BEFORE " .. sigOf(e.before))
                    log("recruit pin:   " .. shortTag(e.tag) .. " AFTER  " .. sigOf(after))
                    local okD, whyD = deliveredTo(e.before, after)
                    -- 1.8.33 DIAGNOSTIC: did the VOICE write move the Class or the specs? (read back in this frame)
                    if preV then PS.afterVoice(owner, preV, PS.readKin(p.byTag)) end
                    -- a slot counts as SETTLED only when it ends up holding OUR part with a resolved definition and a
                    -- fragment set that moved. Anything else stays open for the next pass.
                    local nowOurs = ((after.id:match("([^:]+)$") or "") == e.want)
                    -- 1.8.31: the verb is the READ-BACK's. A write whose fragments moved but whose slot does not read our
                    -- id afterwards is not a delivery (a toggle-out write is named as one).
                    local verb = okD and "DELIVERED" or "not delivered"
                    if okD and not nowOurs then
                        if pinToggled[e.key] == pinPass then verb = "toggled out"
                        else
                            verb = "not delivered"
                            whyD = whyD .. ", but the slot reads " .. (after.id:match("([^:]+)$") or "?") ..
                                " after the write, not " .. e.want
                        end
                    end
                    log("recruit pin:   " .. shortTag(e.tag) .. " " .. verb .. " — " .. whyD)
                    -- 1.8.32 (a): a write that did not deliver is an attempt, counted per character per slot across
                    -- passes (PS.noopCapped reads it); a toggle-out is the toggle's own, bounded by PIN_MAX_RETRY
                    if verb == "not delivered" then PS.noopNote(e.key, owner, e.cur) end
                    if okD and nowOurs and after.defn ~= "<null>" then
                        pinDelivered[e.key] = true
                        pinToggled[e.key] = nil
                        log("recruit pin: " .. shortTag(e.tag) .. " " .. e.cur .. " -> " .. e.want .. " on " ..
                            shortOwner(owner) .. " (SetCustomizationPartPrimaryAssetId; DELIVERED, " ..
                            after.trees .. " leveled tree(s)) — this slot is finished")
                        -- 1.8.28 (fix 4): a delivered Class re-created this character's child slots; the SAME pass
                        -- re-finds and drives them a few frames from now (PS.drive), not 2.5 s+ later
                        if e.tag:find("%.Class$") and PS.P then PS.P.classDone[owner] = true end
                        -- 1.8.32 (c): a card's delivered Class is never toggled (PS.act)
                        if e.tag:find("%.Class$") and e.key:find("|card:", 1, true) then PS.cardClass[owner] = true end
                        -- 1.8.31: a CARD's Talent was delivered: this episode's `done` schedules the re-verify window
                        if e.tag:find("%.Specializations%.Talent$") and e.key:find("|card:", 1, true) then
                            PS.talentCard = true
                        end
                    end
                end
            end
        end
    end
end

-- one character, one decision — and since 1.8.19 there is only one route to decide on: the 1.4.0 setter.
local function applyOwner(owner, p)
    logCriterion()
    local hub, wname = strategySide()
    local gated = PIN_STRATEGY_ONLY and not hub
    if gated and not scopeLogged then
        scopeLogged = true
        log("recruit pin: world=" .. wname .. " is not the hub — in a mission the characters are rebuilt from save " ..
            "data and the game re-equips them during load (ZCSDKLoader.log 21:28:27 vs 21:28:30), so a pin here " ..
            "writes the id and nothing is expected to stick")
    end
    -- 1.8.10: a retry is only spent when a route actually RAN on this slot. 1.8.9 incremented in the collection loop, so two
    -- passes that returned "needs the definition resident" burned half the budget without calling anything (22:14:29-38).
    -- 1.8.28: counted at the write itself (legacyOwner), so an entry the Class-first rule or the lookup budget held back
    -- this frame spends nothing.
    legacyOwner(owner, p)
end

-- returns "pinned" (a slot was changed) / "targets" (pin-able characters are here, nothing to change) / "idle" (nothing to do),
-- which is what the loop below paces itself by.
--
-- 1.8.12 — THE UNIT OF IDENTITY IS THE CHARACTER, AND A CHARACTER IS ITS `UCustomizationInstance`.
-- 1.8.10/1.8.11 made it the slot's immediate parent object, and retail 2026-09-13 05:03 proved that unsatisfiable by
-- construction: `pass 39: 73 instance(s) seen, 73 candidate(s), 73 group(s), 0 pinned, 14 skipped, world=HUB_Root`, with every
-- character skipped three times — `no identity: it holds 1 pinned tag(s) | 2 pinned tag(s) | 2 pinned tag(s) … Info.Name reads
-- <not present>`. One character's slots are NOT siblings: `Class` hangs directly off the CustomizationInstance, the two
-- `Specializations.*` slots hang off a container slot (`…CustomizationFragmentInstanceSlot_11.CustomizationFragmentInstanceSlot_2`),
-- and `Info.Name` hangs off a third parent. No parent object can ever hold both a pinned tag and the identity, so the per-group
-- identity rule could only ever fail — silently in 1.8.10, loudly in 1.8.11, but always.
-- 1.8.7 — which pinned this recruit correctly — identified at INSTANCE level, and that is what is restored here:
--   * a character is OURS if its instance's own `GetDefaultCustomizationDefinition()` is the pin's, OR if ANY slot under that
--     instance whose `SlotNameTag` is the pin's `match` slot holds the pin's `match` part (the mod's own Info.Name part).
--     In this save Vex was built from the pool row, so his instance's default definition is generic — only the Name part finds him.
--   * the pinned tags' slots are then taken from ANYWHERE under that same instance, at any depth, across parent slots.
-- WHAT STOPS THE 22:15:47 MASS-PIN IS NOT THE GROUPING — IT IS THE CAP. That incident collected 21 slots belonging to seven
-- characters under ONE proxy instance, because a customization proxy accumulates the slot trees of everything it has previewed.
-- A real character has exactly ONE slot per pinned tag, so more matching slots than the pin declares means the instance holds
-- more than one character and NOTHING is written. That test is exact, cheap, and cannot be defeated by a tree shape.
local pinPass = 0
local pinCensus = ""
-- 1.8.26: `max` = passes the slot walk may be deferred while the instance census climbs (0 = off)
local pinSettle = { max = 6, last = 0, waits = 0 }
-- 1.8.28: the owning UCustomizationInstance OBJECT of a slot, for the one call that needs the object (RefreshCustomization):
-- walk GetOuter() (validity-checked at every step, and only ever asking IsValid / GetFullName — never GetClass, which faults
-- on a stale pointer) until the outer's full name IS `ipath`. Which instance owns a slot is decided by NAME (PS.ownerOf);
-- this walk only fetches the object, in the frame that uses it.
function PS.instOf(s, ipath)
    local cur, n = s, 0
    while n < 12 do
        local nxt = nil
        pcall(function() nxt = cur:GetOuter() end)
        if not (pinOk(nxt)) then break end
        local p = nil
        pcall(function() p = nxt:GetFullName() end)
        if type(p) ~= "string" then break end
        if (p:gsub("^[^ ]+ ", "")) == ipath then return nxt end
        cur = nxt; n = n + 1
    end
    return nil
end

-- ---- 1.8.28: THE FRAME-BOUNDED PASS (the 2.9 s frame) ----
-- THE EVIDENCE. Retail 2026-09-30 (ZCJediClass + ZCSithClass on 1.8.27, the hub): `pass 591 timing: 523 slice(s), 35647.0
-- ms total, max slice 2917.0 ms (act)`, `pass 592 … 2212.0 ms (act)`, `pass 599 … 1384.0 ms (act)`, and EVERY hub pass with
-- nothing of ours on it `~250 slice(s), 12-21 s total, max slice ~430 ms (act)` for 35 minutes. The Den (the saber
-- session): pass 610 `459 slice(s), 31728.0 ms total`, walk slices of ~69 ms against a 4 ms budget.
-- THE CAUSE: StaticFindObject IS NOT A HASH LOOKUP IN THIS UE4SS BUILD. It costs what a FindAllOf costs - a walk of the
-- whole object array: 28 ms in the main menu (`pump: task saber took 28 ms` - that task is ONE StaticFindObject of a class
-- that is not loaded, and nothing else), 50-90 ms in the hub (`pump: task rowfix took 80-90 ms` - one StaticFindObject
-- plus the cheap world read), ~69 ms per walk slice in the Den. 1.8.27's slicing rested on the opposite assumption: it
-- RE-FOUND EVERY SLOT BY PATH (one StaticFindObject per slot), so its 4 ms budget could never bind - every slice held
-- exactly one slot at 50-70 ms (254 slices = ~254 slots = 13 s per hub pass). And the act phase, which runs in ONE frame,
-- did ~9 of them with nothing of ours in the world (the KismetSystemLibrary CDO, plus one `/Game/ZCSDK/<id>` residency
-- probe per stale-slot candidate: `8 skipped` -> ~450 ms, the `max slice ~430 ms (act)` of every idle hub pass) and ~40
-- with three recruits to drive (per pinned slot: its re-find, its part, partReport's own lookup; per character its
-- instance; the ladder's watch list): 40 x ~70 ms = the 2.9 s frame. It matches pass for pass - 591: 11 slots, 2917 ms;
-- 592: 8, 2212 ms; 599: 11 delivered, 1384 ms. (The per-slot GetOuter walk itself is microseconds; it was the lookup.)
-- THE FIX, four rules:
--   (1) NO RE-FIND. A frame that needs slots makes its own FindAllOf and uses those objects in THAT frame only - the X1 rule
--       (no UObject crosses a frame) now holds by construction. The drive frame collects AND acts; there is no per-slot
--       StaticFindObject and no sliced walk left. (The instance comes from its slot by GetOuter: PS.instOf.)
--   (2) A LOOKUP BUDGET. At most PS.LOOKUPS object lookups (FindAllOf / StaticFindObject) per frame: the slot FindAllOf and
--       ONE part. A write whose part would be one more waits for the next drive frame (`again`), and the frame's cache
--       (P.fcache) serves every character that needs the same part. The KismetSystemLibrary CDO is looked up once a session.
--   (3) RESIDENCY IS A CACHED FACT. The ghost refusal's and the stale-slot rebuild's `/Game/ZCSDK/<id>` checks are asked ONCE
--       per id per world, one per frame, in lookup frames of their own (PS.look); until answered the slot is not judged this
--       pass, and a candidate on a slot of OURS is not driven either.
--   (4) OWNERS BY NAME. A slot's owner is found from its full name (a full name IS its outer chain: PS.ownerOf), with no UE
--       call per slot.
-- AND THE SCOPE (fix 2). When every pin has a `definition`, a pass after a world's first PS.SWEEP_PASSES collects only the
-- instances that are OURS (the default definition matched in `insts`, or identified before - pinKnown). The world-wide
-- sweep - the ghost refusal and the stale-slot rebuild on every character, and roster characters found by their Name part -
-- runs on those first passes and then once per PS.SWEEP_S. A world with nothing ours goes DORMANT once its sweeps are done
-- (`recruit pin: dormant — nothing ours …`); a Recruitment event, a recruit or a return to the hub re-arms it.
-- THE PASS: insts (FindAllOf CustomizationInstance) -> drive (FindAllOf the slots; collect; act) [-> look (one
-- StaticFindObject per frame) -> drive] [-> idle frames after a Class -> drive (its children)] -> the verdict.
-- WHAT DID NOT CHANGE: identity, the mass-pin cap, the ghost refusal's evidence rules, the stale-slot rebuild's fences, the
-- ORDER (Class to completion first, the Talent last), the toggle, the retry and residency bounds, `done`.

-- one COUNTED object lookup. Answers from this frame's cache first; `force` = not budgeted (the stale-slot rebuild, see
-- staleMint). Returns obj|nil, busy. Also records the residency as a BOOLEAN (PS.partRes) for later frames.
function PS.get(path, force)
    local P = PS.P
    local fc = P and P.fcache
    if fc and fc[path] ~= nil then return fc[path] or nil, false end
    if P and not force and P.lookups >= PS.LOOKUPS then return nil, true end
    if P then P.lookups, P.nLook = P.lookups + 1, P.nLook + 1 end
    PS.sfo = PS.sfo + 1
    local o = nil
    pcall(function() o = StaticFindObject(path) end)
    local ok = pinOk(o)
    if fc then fc[path] = ok and o or false end
    PS.partRes[path] = ok
    return ok and o or nil, false
end

-- the KismetSystemLibrary CDO. A class default object is never collected, so it is looked up ONCE a session (as UEHelpers
-- does) and re-validated on every use.
function PS.ksl()
    local k = PS.cdos.ksl
    if k ~= nil and pinOk(k) then return k end
    k = nil
    PS.sfo = PS.sfo + 1
    if PS.P then PS.P.nLook, PS.P.lookups = PS.P.nLook + 1, PS.P.lookups + 1 end   -- (once a session, budgeted too)
    pcall(function() k = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary") end)
    if pinOk(k) then PS.cdos.ksl = k; return k end
    return nil
end

-- a real FPrimaryAssetId for `path`, minted from an object THIS frame found. -> id | nil, busy, err
function PS.mint(path)
    if type(path) ~= "string" or path == "" then return nil, false end
    local o, busy = PS.get(path)
    if busy then return nil, true end
    if not pinOk(o) then return nil, false end
    local ksl = PS.ksl()
    if not pinOk(ksl) then return nil, false, "no KismetSystemLibrary CDO" end
    local ok, id = pcall(function() return ksl:GetPrimaryAssetIdFromObject(o) end)
    if ok and id then return id, false end
    return nil, false, tostring(id)
end

-- is `path` resident? A per-world cache of booleans; nil = not asked yet, and then it is QUEUED for a lookup frame.
function PS.resident(path)
    local v = PS.res[path]
    if v ~= nil then return v end
    local P = PS.P
    if P and not P.lookSet[path] then P.lookSet[path] = true; P.lookq[#P.lookq + 1] = path end
    return nil
end

-- which instance of this pass owns the slot `sname`? Its full name is its outer chain, so strip one `.`/`:` segment at a
-- time and look the prefix up (the 1.8.26 GetOuter walk, without a UE call per level).
function PS.ownerOf(P, sname)
    local p = sname
    for _ = 1, 14 do
        p = p:match("^(.*)[%.:][^%.:]*$")
        if not p then return nil end
        if P.inst[p] then return p end
    end
    return nil
end

function PS.census(P, extra)
    local line = string.format("pass %d: %d instance(s) seen, %d ours, %d with pinned slot(s), %d pinned, %d skipped, world=%s%s",
        P.pass, P.nInst, P.nOurs, P.nWith, P.nPinned, P.nSkip, P.wname, extra or "")
    local shape = line:gsub("^pass %d+: ", "")
    if shape ~= pinCensus or P.pass % 20 == 1 then
        pinCensus = shape
        P.printed = true
        log("recruit pin: " .. line)
    end
end

-- 1.8.15: dedup by (owner, REASON), not owner. In the 07:47 session the Sith stopped being identified at 07:52:26
-- and was skipped for a NEW reason for the rest of the session — invisibly, because the old dedup had already used up
-- his one line. A changed reason is the most informative line the pin can print; it must never be swallowed.
function PS.skip(P, owner, why)
    if P.skipped[owner] then return end
    P.skipped[owner] = true
    P.nSkip = P.nSkip + 1
    local k = owner .. "|" .. why
    if pinSkipLogged[k] then return end
    pinSkipLogged[k] = true
    log("recruit pin: skip " .. shortOwner(owner) .. ": " .. why)
end

-- 1.8.18 / 1.8.27 G2: the drive ORDER, as a rank (legacyOwner orders by it too): Class, Weapon, the rest, Talent
-- 1.8.33: the VOICE before everything (retail 18:26:09-18:26:28: a voice delivered after the Class and specs was followed
-- by a Class / spec revert and a full re-pin). Info.Voiceover is not a Class child, so the Class-first rule is unaffected.
function PS.orderOf(tag)
    if tag:find("%.Info%.Voiceover$") then return 0 end
    if tag:find("%.Class$") then return 1 end
    if tag:find("%.Specializations%.Weapon$") then return 2 end
    if tag:find("%.Specializations%.Talent$") then return 4 end
    return 3
end

-- 1.8.28 (fix 6): the two appearance slots whose part ids are echoed, read-only, once per character of ours
PS.FACE = "br.Customization.Slot.Character.Appearance.Humanoid.Head.Face.Mesh"
PS.HAIR = "br.Customization.Slot.Character.Hair.Hair.Mesh"

-- the slot tags a pass reads at all: every pinned tag, every `match` tag, the tags of slots a missing dependency
-- dropped (the ghost sweep still looks at them), the stale-slot rebuild's Weapon tag and - when a pin matches weapon
-- CLASSES by tag - the GearKit sub-slot; 1.8.28: and the two appearance slots of the echo. A slot with any other tag is
-- never named.
function PS.tags()
    local t = { [STALE_TAG] = true, [PS.FACE] = true, [PS.HAIR] = true }
    for _, rp in ipairs(recruitPins) do
        if rp.match then t[rp.match.slot] = true end
        for _, pin in ipairs(rp.slots) do
            t[pin.tag] = true
            if pin.acceptTags and #pin.acceptTags > 0 then t[CP.GEARKIT] = true end
        end
        for tg in pairs(rp.ghostTags or {}) do t[tg] = true end
    end
    return t
end

-- ---- 1.8.32: IDENTITY EVIDENCE AND THE CARD SET ----
-- THE EVIDENCE (retail 2026-10-02, loader 1.8.31; JediClass notes/RETAIL_2_TEO_SPEC.md §3/§4):
--   11:13:19 scoped to Char_Hero_Humanoid_C_3 by its Specializations.Talent already holds CPD_TalentSpec_TheColdBlooded
--   -> Class CPD_Char_Class_Hero_Humanoid -> CPD_ZCSith_Char_Class_Sith on a STOCK card (14 Talent-scoped, 5
--   Tactical-scoped such lines that day). Rank 1 identity accepted any part a pin declares, and a Sith pin's Talent is a
--   stock id the game's own VoiceOverToTalentMapping gives stock recruits.
--   11:18:17 RefreshCharacterVMs; 11:18:18 the PREVIOUS set's cards (alive) had their `|card:` state cleared, their
--   delivered Class read `ours, 0 trees` and was TOGGLED to CPD_Char_Class_Hero_Humanoid; every write back read
--   `Class not delivered — nothing on the slot changed` and the `cur ~= want` branch zeroed the attempts each pass:
--   1,597 such writes by 11:24, every pass 16 drive frames, the new cards one slot per 120 s sweep.
-- THE RULES.
--   * evidence = a pin part whose package lies in the pin's OWN namespace, and that is not an accept / escape id, a
--     fallback the dependency probe substituted, or a dead id of ANY pin. The `match` part and the definition are
--     ranks 2/3 and unaffected.
--   * a RefreshCharacterVMs (or the census refresh) retires every card instance seen so far: dropped from the pin set,
--     its keys and identity forgotten; the next pass sees only the new set. A world change forgets the retired set
--     (object names are per world).
--   * a write that delivers nothing is counted per character per slot (PS.noop), across passes; the count restarts
--     only when the slot is found holding something else. At PS.NOOP_MAX the slot is given up, once, with a line.
function PS.nsOf(p)
    if type(p) ~= "string" then return nil end
    local g = p:match("^(/Game/[^/]+/)")
    if g then
        if g == "/Game/Game/" then return nil end   -- the game's own content is never a mod's namespace
        return g
    end
    local r = p:match("^(/[^/]+/)")
    if r == "/Game/" or r == "/Script/" or r == "/Engine/" or r == "/Temp/" then return nil end
    return r                                        -- a game-feature plugin mount: /<modId>/
end

-- the leaves no pin may use as identity: every accept / escape id, every substituted fallback, every dead id
function PS.nonEvidence()
    local key = tostring(recruitPins[1]) .. "#" .. #recruitPins
    if PS.neKey == key and PS.neSet then return PS.neSet end
    local set = {}
    for _, rp in ipairs(recruitPins) do
        for _, pin in ipairs(rp.slots) do
            for n in pairs(pin.accept or {}) do set[n] = "an accept-set id" end
            for n in pairs(pin.rosterIds or {}) do set[n] = "an escape id" end
            for n in pairs(pin.dead or {}) do set[n] = "a dead id" end
            if pin.subst then set[pin.part:match("([^/.]+)$") or ""] = "a fallback" end
        end
    end
    PS.neKey, PS.neSet = key, set
    return set
end

-- CLASSES V2 #3 (ZCClassMods/_Shared/SDK_REQUEST_CLASSES_V2_2026-10-11.md; docs/recon/CLASSES_V2_RECON.md #3): A VOICE IS
-- NEVER IDENTITY. The class voices ship in the stock shape (no Class gate) so the Customize picker - which evaluates a
-- PROXY whose Class is always the stock hero class - lists them for every humanoid. A player who gives a stock operator
-- CPD_ZCSith_Voice_* (or a Customize Randomize that rolls one) must not make that operator "a Sith": rank 1 would scope it
-- by the voice and convert its Class, spec and saber (the 1.8.32 stock-recruit class of bug). So an Info.Voiceover pin
-- part - and any slot the manifest marks `evidence = false` - is never identity evidence. The voice is still DELIVERED to
-- the pin's own characters (found by rank 3 / 2 / another slot). tools/replay_pin.py VE1-VE3.
PS.VOICE_TAG = "br.Customization.Slot.Character.Info.Voiceover"

-- is `pin` (a slot of `rp`) identity evidence? -> true, or nil + why not. Cached on the pin.
function PS.evidence(rp, pin)
    if pin.__ev ~= nil then return pin.__ev or nil, pin.__evWhy end
    if pin.tag == PS.VOICE_TAG or pin.evidence == false then
        pin.__ev = false
        pin.__evWhy = (pin.tag == PS.VOICE_TAG) and "a voice part: voices list for every character, never identity"
            or "declared `evidence = false` by its manifest"
        return nil, pin.__evWhy
    end
    local own = {}
    for _, p in ipairs({ rp.definition, rp.match and rp.match.part }) do
        local n = PS.nsOf(p); if n then own[n] = true end
    end
    for _, n in ipairs(rp.ownNs or {}) do own[n] = true end
    local leaf = pin.part:match("([^/.]+)$") or ""
    local ns = PS.nsOf(pin.part)
    local why = nil
    if not ns or not own[ns] then
        why = (pin.part:find("^/Game/Game/") and "a stock part" or ("outside the mod's own namespace (" ..
            tostring(ns or pin.part) .. ")"))
    else
        why = PS.nonEvidence()[leaf]
    end
    pin.__ev, pin.__evWhy = (why == nil), why
    return (why == nil) or nil, why
end

-- a RefreshCharacterVMs: the cards seen so far are the PREVIOUS set. Retire them - whatever they hold, they are never
-- collected, driven, toggled or verified again in this world - and forget their state.
function PS.retireCards(why)
    PS.setT = PS.clock()
    local n = 0
    for ipath in pairs(PS.cards) do
        n = n + 1
        PS.retired[ipath] = true
        pinKnown[ipath], PS.knownRp[ipath], PS.firstSeen[ipath], PS.cardClass[ipath] = nil, nil, nil, nil
        PS.cardRp[ipath] = nil
        local tail = "|card:" .. ipath
        for _, t in ipairs({ pinDelivered, pinToggled, pinAttempts, pinExpected, pinGaveUp, PS.reverted, PS.accKey }) do
            for k in pairs(t) do if k:sub(-#tail) == tail then t[k] = nil end end
        end
        local at = "@" .. ipath
        for k in pairs(PS.noop) do if k:sub(-#at) == at then PS.noop[k] = nil end end
    end
    PS.cards = {}
    if n > 0 then
        log(("recruit pin: %s — %d card(s) of the previous set retired: never driven, toggled or verified again " ..
            "(their objects may still be alive)"):format(why, n))
    end
end

-- ---- 1.8.33: A RECRUITED CARD STAYS A CARD; THE SAVE LOAD; THE HUB COST; THE CUSTOMIZE DIAGNOSTIC ----
-- THE EVIDENCE (retail 2026-10-02 18:18-18:41, loader 1.8.32; SithClass notes/RETAIL_4_VOICES.md):
--   18:22:42 Kael (Char_Hero_Humanoid_C_16) first seen after the 18:22:38 refresh -> PS.cards. 18:23:47 RecruitCharacter:
--   the SAME actor joins the roster - and stayed in PS.cards, so CP.accepted refused his acceptOn "roster" voice set and
--   18:26:09 wrote CPD_H_Voiceover_Professional (the player's choice, an accept id) back to CPD_ZCSith_Voice_Inquisitor_M.
--   18:26:56 a save load: census 143 -> 29 under the SAME world name (HUB_Root), so PS.setT survived and the reloaded Kael
--   (C_2, 18:28:17) was a card again (his Weapon TOGGLED). Meanwhile 18:22:54-18:26:09 every pass re-collected his voice
--   ("holds Inquisitor_M ... no other id to toggle through") - `pinned` every 5 s, never `done`. And session 2 (18:39-18:41):
--   "0 ours, 14 with pinned slot(s), 14 skipped" every ~8 s with a 265-296 ms drive slice, the first 16 passes being sweeps.
-- THE RULES.
--   * RecruitCharacter DEMOTES the recruited card (PS.demoteCard): out of PS.cards for good (PS.recruited), its delivered
--     slots stay delivered under the roster key, nothing else carried. WHICH card: the actor's RecruitmentTime (set on a
--     recruit, 0 on a card), else the card of ours whose Name the recruitment view model no longer lists, else (nothing
--     readable) every card of ours - the safe side of the two errors.
--   * A SAVE LOAD is a new world under the same name: the world OBJECT's address changed (CP.pinTick), or the census fell
--     below PS.LOAD_FRAC of this world's high-water mark (PS.begin). Everything keyed by object name is reset as for a
--     world change (PS.worldReset; PS.setT = nil: nothing is a card until the next refresh) and the hub re-arms.
--   * A delivered slot that reads something else is checked against the accept-set first (a roster choice is left alone,
--     `holds accepted … — left as the player chose`); a voice holding ours, resolved, is settled (it has no leveled trees,
--     and no toggle id); a ROSTER Class holding ours, resolved and with fragments, is never toggled (the toggle re-creates
--     every child slot and resets the player's spec / saber choices).
--   * VOICE FIRST: Info.Voiceover is driven before the Class (it is not a Class child; a Class write re-creates only the
--     Specializations subtree), and the slots read right after a voice write say whether it moved the Class or specs.
--   * THE HUB COST: a sweep that reads a character's Name and finds it not ours caches the verdict (PS.notOurs) until a
--     re-arm or world reset; a stable, populated sweep with nothing ours goes DORMANT at once (1.8.28 waited 16 sweeps).
--   * DIAGNOSTIC (log only): a customization proxy of ours (and each character of ours, once) logs its Class part and the
--     required set of its Info.Voiceover and Specializations.Tactical.Primary slots: AllowedTags + SlotNameTag + the owner
--     tags (CustomizationInstance.CachedOwnedGameplayTags, reflected @672 = the +0x2a0 of customization_parts.md).
--
-- the cards of ours: which one did the player recruit? `ticks` = path -> RecruitmentTime.Ticks (nil = unreadable);
-- `vmNames` = the Name ids the view model still lists (nil = not read / unreadable). -> list of paths to demote, how;
-- or nil when the RecruitmentTime alone does not decide and the view model has not been read yet.
function PS.whichRecruited(ticks, vmNames, vmTried)
    local set, zero, pos = {}, 0, 0
    for ip in pairs(PS.cards) do
        local t = ticks[ip]
        if type(t) == "number" then
            if t > 0 then pos = pos + 1; set[#set + 1] = ip else zero = zero + 1 end
        end
    end
    if pos > 0 and zero > 0 then return set, "its RecruitmentTime is set; the other card(s) of ours read 0" end
    if not vmTried then return nil end
    if vmNames then
        local out = {}
        for ip in pairs(PS.cards) do
            local rp = PS.cardRp[ip]
            local nm = rp and rp.match and rp.match.part:match("([^/.]+)$")
            if nm and not vmNames[nm] then out[#out + 1] = ip end
        end
        if #out == 0 then return out, "the recruitment view model still lists every card of ours" end
        return out, "the recruitment view model no longer lists its Name"
    end
    if pos > 0 and zero == 0 then return set, "its RecruitmentTime is set (no card of ours reads 0; no readable view model)" end
    local all = {}
    for ip in pairs(PS.cards) do all[#all + 1] = ip end
    return all, "the recruited card could not be identified (no RecruitmentTime, no readable view model) - every card of " ..
        "ours is treated as recruited"
end

-- the Info.Name part ids the recruitment view model still lists (its remaining cards), or nil when nothing is readable.
-- ONE FindAllOf (counted against the frame's budget by the caller); property reads only.
function PS.vmNames(P)
    P.lookups, P.nLook = P.lookups + 1, P.nLook + 1
    PS.fao = PS.fao + 1
    local ok, vms = pcall(FindAllOf, "BrunoCharacterRecruitmentViewModel")
    if not ok or type(vms) ~= "table" then return nil end
    local names, any = {}, false
    local function walk(svm, depth)
        if depth > 4 or not pinOk(svm) then return end
        local tag = ""; pcall(function() tag = svm.SlotTag.TagName:ToString() end)
        if tag == "br.Customization.Slot.Character.Info.Name" then
            local id = nil
            pcall(function() id = svm.EquippedCustomizationPartViewModel.AssetId.PrimaryAssetName:ToString() end)
            if type(id) == "string" and id ~= "" then names[id] = true; any = true end
        end
        pcall(function() svm.CustomizationChildSlotViewModels:ForEach(function(_, e)
            local x = e; pcall(function() x = e:get() end); walk(x, depth + 1) end) end)
    end
    for _, vm in ipairs(vms) do
        local nm = nil; pcall(function() nm = vm:GetFullName() end)
        if pinOk(vm) and type(nm) == "string" and not nm:find("Default__", 1, true) then
            pcall(function() vm.CharacterViewModelsForRecruitment:ForEach(function(_, e)
                local cvm = e; pcall(function() cvm = e:get() end)
                pcall(function() cvm.CustomizationInstanceVM.SlotViewModels:ForEach(function(_, s)
                    local x = s; pcall(function() x = s:get() end); walk(x, 0) end) end)
            end) end)
        end
    end
    return any and names or nil
end

-- a recruited card becomes a ROSTER character: never a card again in this world; its DELIVERED (and accepted) slots stay
-- settled under the roster key (so its Class is not toggled and nothing is re-pinned); every other card state is dropped
function PS.demoteCard(ipath, how)
    PS.cards[ipath], PS.cardClass[ipath] = nil, nil
    PS.recruited[ipath] = true
    local tail = "|card:" .. ipath
    for _, t in ipairs({ pinDelivered, PS.accKey }) do
        local moved = {}
        for k in pairs(t) do if k:sub(-#tail) == tail then moved[#moved + 1] = k end end
        for _, k in ipairs(moved) do t[k] = nil; t[k:sub(1, #k - #tail)] = true end
    end
    for _, t in ipairs({ pinToggled, pinAttempts, pinExpected, pinGaveUp, PS.reverted }) do
        for k in pairs(t) do if k:sub(-#tail) == tail then t[k] = nil end end
    end
    local at = "@" .. ipath
    for k in pairs(PS.noop) do if k:sub(-#at) == at then PS.noop[k] = nil end end
    log(("recruit pin: RecruitCharacter: %s was recruited (%s) — a ROSTER character from now on: its acceptOn \"roster\" " ..
        "choices and its escape apply; its delivered slots stay delivered"):format(shortOwner(ipath), how))
end

-- 1.8.33: everything keyed by object NAME belongs to one world: a world change and a save load (a new world under the same
-- name) start it afresh. Session facts keyed by the pin's identity (`ident|tag`) are kept, as before.
function PS.worldReset(why)
    PS.worldPasses, PS.sweepAt = 0, nil
    PS.res, PS.partRes = {}, {}
    PS.cards, PS.retired, PS.noop, PS.cardClass = {}, {}, {}, {}
    PS.recruited, PS.notOurs, PS.firstSeen, PS.lookEchoed, PS.cardRp = {}, {}, {}, {}, {}
    PS.diagCharDone, PS.diagOwn, PS.diagDone, PS.diagTry = {}, {}, {}, {}
    PS.setT, PS.swept, PS.cHi, PS.demote, PS.oursSeen, PS.dgPolls = nil, false, 0, nil, false, 0
    for k in pairs(pinKnown) do pinKnown[k] = nil end
    for k in pairs(PS.knownRp) do PS.knownRp[k] = nil end
    for _, t in ipairs({ pinDelivered, pinToggled, pinAttempts, pinExpected, pinGaveUp, PS.reverted, PS.accKey }) do
        for k in pairs(t) do if k:find("|card:", 1, true) then t[k] = nil end end
    end
    if why then log("recruit pin: " .. why .. " — this world's character state starts afresh (no card until the next " ..
        "refresh; identity, the not-ours verdicts and the sweeps are re-read)") end
end

-- 1.8.33: the world OBJECT's address and name (a save load replaces the world under the same name), from the viewport's
-- world only - three property reads, never gameWorld()'s FindAllOf fallback. nil when unreadable (a loading screen).
function PS.worldAddr()
    local a, n = nil, nil
    pcall(function()
        local vp = UEHelpers.GetEngine().GameViewport
        local ww = vp and vp.World
        if ww and ww:IsValid() then a = ww:GetAddress(); n = ww:GetFullName() end
    end)
    if type(a) ~= "number" or a == 0 or type(n) ~= "string" or n == "" then return nil end
    return a, n
end

-- ---- 1.8.33 DIAGNOSTIC: THE CUSTOMIZE / CHANGE-SPECIALIZATION PROXY (log only; nothing here writes) ----
-- THE QUESTION (SithClass notes/RETAIL_4_VOICES.md (c); JediClass: the class-gated Master spec in Change Specialization).
-- A part lists in a slot only if every registry tag of it is in the slot's REQUIRED set = AllowedTags + SlotNameTag + the
-- owning instance's owned tags (+ OnAppendRequiredTags) - docs/recon/ghidra/customization_parts.md Q1/Q2. The class mods
-- gate their voices / Master spec on Part.Character.Class.<X>, which only OUR Class part's GameplayTags fragment adds to
-- the owner tags. Hypothesis: CUSTOMIZE edits a proxy whose Class is the STOCK CPD_Char_Class_Hero_Humanoid, so the gate
-- never passes there (and leaving CUSTOMIZE applies the stock class back). THE READ, once per proxy (and once per character
-- of ours, for comparison): its Class part, its Info.Name, the preview links, and for Info.Voiceover and
-- Specializations.Tactical.Primary the three readable sources of the required set. The owner tags are
-- CustomizationInstance.CachedOwnedGameplayTags (reflected, offset 672 = +0x2a0, rebuilt by every RefreshCustomization).
-- COST: property reads on objects the pass already holds; a proxy census while dormant only in a hub with something of
-- ours (PS.diagPoll). Capped: PS.DIAG_CAP lines-groups of ours, PS.DIAG_ANY_CAP one-liners for other proxies.
PS.DIAG_TAGS = {
    ["br.Customization.Slot.Character.Class"] = "Class",
    ["br.Customization.Slot.Character.Info.Name"] = "Name",
    ["br.Customization.Slot.Character.Info.Voiceover"] = "Voice",
    ["br.Customization.Slot.Character.Specializations.Tactical.Primary"] = "Tact",
}
PS.diagTry, PS.diagVoice = {}, 0

-- a tag container as short strings (the `br.Customization.` prefix dropped), or nil when unreadable
function PS.tagList(o, prop)
    local t = nil
    pcall(function() t = CP.tagsFrom(o[prop], 0) end)
    if type(t) ~= "table" then return nil end
    local out = {}
    for _, x in ipairs(t) do out[#out + 1] = (tostring(x):gsub("^br%.Customization%.", "")) end
    table.sort(out)
    return out
end
function PS.diagFmt(list) return list and ("{" .. table.concat(list, ", ") .. "}") or "<unreadable>" end
function PS.diagClassTags(a, b)
    local out, seen = {}, {}
    for _, list in ipairs({ a or {}, b or {} }) do
        for _, x in ipairs(list) do
            if x:find("Class%.") and not seen[x] then seen[x] = true; out[#out + 1] = x end
        end
    end
    return (#out > 0) and table.concat(out, ", ") or "none"
end
function PS.diagLink(inst, prop)
    local p = nil
    pcall(function()
        local o = inst[prop]
        if o and o:IsValid() then p = o:GetFullName() end
    end)
    return (type(p) == "string" and p ~= "") and shortOwner((p:gsub("^[^ ]+ ", ""))) or "none"
end

-- PS.begin: a proxy instance of this frame -> queued for its slot read (P.proxies) unless read before
function PS.diagProxy(P, inst, ipath, pat, dpath)
    if PS.diagDone[ipath] or (PS.diagTry[ipath] or 0) >= 3 then return end
    if PS.diagN >= PS.DIAG_CAP and PS.diagAny >= PS.DIAG_ANY_CAP then return end
    P.proxies = P.proxies or {}
    P.proxies[ipath] = { pat = pat, dpath = dpath, own = PS.tagList(inst, "CachedOwnedGameplayTags"),
                         static = PS.tagList(inst, "StaticTags"),
                         owning = PS.diagLink(inst, "OwningPreviewCustomizationInstance"),
                         preview = PS.diagLink(inst, "PreviewCustomizationInstance"), slots = {} }
end

function PS.diagWanted(P)
    return P.proxies ~= nil and next(P.proxies) ~= nil
end

-- PS.drive: one slot of a diag tag; kept when it belongs to a queued proxy (the live one = the highest object index)
function PS.diagSlot(P, s, sname, tag)
    local p = sname
    for _ = 1, 14 do
        p = p:match("^(.*)[%.:][^%.:]*$")
        if not p then return end
        local d = P.proxies[p]
        if d then
            local idx = tonumber(sname:match("_(%d+)$") or "0") or 0
            local h = d.slots[tag]
            d.n = (d.n or 0) + 1
            if not h or idx > h.idx then d.slots[tag] = { obj = s, idx = idx, n = (h and h.n or 0) + 1 }
            else h.n = h.n + 1 end
            return
        end
    end
end

function PS.diagId(s)
    local id = "?"
    pcall(function() id = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end)
    return tostring(id)
end

-- is a (proxy) reading OURS? -> why, or nil
function PS.diagOurs(dpath, nameId, classId, owning, preview)
    for _, rp in ipairs(recruitPins) do
        if rp.definition and dpath == rp.definition then return "its default definition" end
        if rp.match and nameId == rp.match.part:match("([^/.]+)$") then return "its Info.Name " .. nameId end
        for _, pin in ipairs(rp.slots) do
            if pin.tag == "br.Customization.Slot.Character.Class" and classId == pin.part:match("([^/.]+)$") then
                return "its Class " .. classId
            end
        end
    end
    for ip in pairs(pinKnown) do
        local so = shortOwner(ip)
        if so == owning or so == preview then return "it previews " .. so .. ", a character of ours" end
    end
    return nil
end

-- the two lines of one slot of interest: what it holds and the three readable sources of its required set
function PS.diagSlotLine(who, tag, h, own)
    if not h or not pinOk(h.obj) then
        log(("recruit pin: DIAG %s %s: no such slot under it"):format(who, shortTag(tag)))
        return
    end
    local s = h.obj
    local allowed = PS.tagList(s, "AllowedTags")
    log(("recruit pin: DIAG %s %s slot: holds %s; required set = AllowedTags %s + SlotNameTag %s + the owner tags " ..
        "(+ OnAppendRequiredTags, not readable); Class tags among them: %s%s"):format(who, shortTag(tag), PS.diagId(s),
        PS.diagFmt(allowed), (tag:gsub("^br%.Customization%.", "")), PS.diagClassTags(allowed, own),
        (h.n and h.n > 1) and (" (" .. h.n .. " slot objects of this tag; the highest index read)") or ""))
end

-- PS.drive (same frame): the queued proxies' lines
function PS.diagFlush(P)
    for ipath, d in pairs(P.proxies or {}) do
        if next(d.slots) == nil then
            PS.diagTry[ipath] = (PS.diagTry[ipath] or 0) + 1      -- no slot yet (mid-spawn): looked at again, up to 3 times
        else
            PS.diagDone[ipath] = true
            local cls = d.slots["br.Customization.Slot.Character.Class"]
            local nm = d.slots["br.Customization.Slot.Character.Info.Name"]
            local classId = cls and pinOk(cls.obj) and PS.diagId(cls.obj) or "<no Class slot>"
            local nameId = nm and pinOk(nm.obj) and PS.diagId(nm.obj) or "<no Info.Name slot>"
            local why = PS.diagOurs(d.dpath, nameId, classId, d.owning, d.preview)
            local who = "proxy " .. shortOwner(ipath)
            if why and PS.diagN < PS.DIAG_CAP then
                PS.diagN = PS.diagN + 1
                log(("recruit pin: DIAG %s (%s) of OURS (%s): Class=%s; Info.Name=%s; default definition %s; " ..
                    "OwningPreviewCustomizationInstance=%s; PreviewCustomizationInstance=%s"):format(who, d.pat, why, classId,
                    nameId, (d.dpath ~= "" and d.dpath:match("([^/.]+)$")) or "<none>", d.owning, d.preview))
                log(("recruit pin: DIAG %s owner tags (CachedOwnedGameplayTags, %s): %s; StaticTags %s"):format(who,
                    d.own and #d.own or "?", PS.diagFmt(d.own), PS.diagFmt(d.static)))
                PS.diagSlotLine(who, "br.Customization.Slot.Character.Info.Voiceover",
                    d.slots["br.Customization.Slot.Character.Info.Voiceover"], d.own)
                PS.diagSlotLine(who, "br.Customization.Slot.Character.Specializations.Tactical.Primary",
                    d.slots["br.Customization.Slot.Character.Specializations.Tactical.Primary"], d.own)
            elseif not why and PS.diagAny < PS.DIAG_ANY_CAP then
                PS.diagAny = PS.diagAny + 1
                log(("recruit pin: DIAG %s (%s): Class=%s Info.Name=%s previews %s — not ours"):format(who, d.pat, classId,
                    nameId, d.owning))
            end
        end
    end
    P.proxies = nil
end

-- PS.begin: a character of ours - its owner tags, read until its DIAG lines are written (they change with its Class)
function PS.diagOwnRead(inst, ipath)
    if PS.diagCharDone[ipath] or PS.diagN >= PS.DIAG_CAP then return end
    PS.diagOwn[ipath] = PS.tagList(inst, "CachedOwnedGameplayTags") or false
end

-- PS.act: a character of ours, ONCE per world, after its Class holds ours (its owner tags then carry the class's tags)
function PS.diagChar(P, ipath, c)
    if PS.diagCharDone[ipath] or PS.diagN >= PS.DIAG_CAP then return end
    local own = PS.diagOwn[ipath]
    if own == nil then return end
    local CLS = "br.Customization.Slot.Character.Class"
    local cls = c.slotsAll[CLS]
    local classId = cls and pinOk(cls.obj) and PS.diagId(cls.obj) or "<no Class slot>"
    -- after its Class AND its SPEC 1 hold ours (the required sets then are the ones the player's screens see), or at a
    -- verify pass whatever they hold
    for _, pin in ipairs(c.rp.slots) do
        if pin.tag == CLS or pin.tag:find("%.Tactical%.Primary$") then
            local h = c.slotsAll[pin.tag]
            local id = h and pinOk(h.obj) and PS.diagId(h.obj) or "?"
            if id ~= pin.part:match("([^/.]+)$") and not P.verify then return end   -- not ours yet: a later pass
        end
    end
    PS.diagCharDone[ipath] = true
    PS.diagN = PS.diagN + 1
    local who = "character " .. shortOwner(ipath)
    log(("recruit pin: DIAG %s (ours, %s): Class=%s; owner tags (CachedOwnedGameplayTags, %s): %s"):format(who,
        c.card and "a card" or "a roster character", classId, own and #own or "?", PS.diagFmt(own or nil)))
    for _, tag in ipairs({ "br.Customization.Slot.Character.Info.Voiceover",
                           "br.Customization.Slot.Character.Specializations.Tactical.Primary" }) do
        local h = c.slotsAll[tag]
        if h then PS.diagSlotLine(who, tag, { obj = h.obj, n = 1 + (c.dupesBy[tag] or 0) }, own or nil) end
    end
end

-- legacyOwner: the Class and spec ids of one character, read from this frame's slot objects (around a voice write)
function PS.readKin(byTag)
    local out = {}
    for tag, h in pairs(byTag or {}) do
        if not tag:find("%.Info%.") and pinOk(h.obj) then out[tag] = PS.diagId(h.obj) end
    end
    return out
end

function PS.afterVoice(owner, pre, post)
    if PS.diagVoice >= 10 then return end
    PS.diagVoice = PS.diagVoice + 1
    local same, moved, tags = true, {}, {}
    for tag in pairs(pre) do tags[#tags + 1] = tag end
    table.sort(tags)
    local now = {}
    for _, tag in ipairs(tags) do
        now[#now + 1] = shortTag(tag) .. "=" .. tostring(post[tag])
        if post[tag] ~= pre[tag] then same = false; moved[#moved + 1] = shortTag(tag) .. " " .. pre[tag] .. " -> " ..
            tostring(post[tag]) end
    end
    log(("recruit pin: DIAG after the Info.Voiceover write on %s: %s — %s"):format(shortOwner(owner),
        (#now > 0) and table.concat(now, ", ") or "<no Class / spec slot collected>",
        same and "unchanged (the voice write moved neither the Class nor a spec)" or
            ("CHANGED: " .. table.concat(moved, "; "))))
end

-- CP.pinTick while DORMANT: the proxy census (frame 1, one FindAllOf) and, only when a new proxy is there, its slot read
-- (frame 2, one FindAllOf). -> true when this frame made its lookup (the pin task then yields the frame: nothing else of
-- it may add a lookup to this one).
function PS.diagPoll(w)
    if PS.dg then
        local Pd = PS.dg
        PS.dg = nil
        PS.fao = PS.fao + 1
        local ok, slots = pcall(FindAllOf, "CustomizationFragmentInstanceSlot")
        if not ok or type(slots) ~= "table" then return true end
        for _, s in ipairs(slots) do
            if pinOk(s) then
                local tag = ""; pcall(function() tag = s.SlotNameTag.TagName:ToString() end)
                if PS.DIAG_TAGS[tag] then
                    local sname = nil; pcall(function() sname = s:GetFullName() end)
                    if type(sname) == "string" then PS.diagSlot(Pd, s, (sname:gsub("^[^ ]+ ", "")), tag) end
                end
            end
        end
        PS.diagFlush(Pd)
        return true
    end
    if PS.DIAG_POLLS <= 0 or not PS.oursSeen or PS.dgPolls >= PS.DIAG_POLLS or PS.diagN >= PS.DIAG_CAP then return false end
    if not (type(w) == "string" and w:find("HUB_Root", 1, true)) then return false end
    local now = PS.clock()
    if now < PS.dgNext then return false end
    PS.dgNext, PS.dgPolls = now + PS.DIAG_POLL_S, PS.dgPolls + 1
    PS.fao = PS.fao + 1
    local ok, insts = pcall(FindAllOf, "CustomizationInstance")
    if not ok or type(insts) ~= "table" then return true end
    local Pd = { proxies = {} }
    for _, inst in ipairs(insts) do
        if pinOk(inst) then
            local nm = nil; pcall(function() nm = inst:GetFullName() end)
            if type(nm) == "string" and not nm:find("Default__", 1, true) then
                local ipath = (nm:gsub("^[^ ]+ ", ""))
                local pat = isProxyOwner(ipath)
                if pat and not PS.diagDone[ipath] and (PS.diagTry[ipath] or 0) < 3 then
                    local dpath = ""
                    pcall(function() dpath = inst:GetDefaultCustomizationDefinition():GetFullName():gsub("^[^ ]+ ", "") end)
                    PS.diagProxy(Pd, inst, ipath, pat, dpath)
                end
            end
        end
    end
    if next(Pd.proxies) ~= nil then PS.dg = Pd end
    return true
end

-- a write that delivered nothing: count it against this character's slot (`cur` = what the slot held at the write)
function PS.noopNote(key, owner, cur)
    local k = key .. "@" .. owner
    local r = PS.noop[k]
    if not r or r.cur ~= cur then r = { n = 0, cur = cur }; PS.noop[k] = r end
    r.n = r.n + 1
end

-- has this character's slot spent its no-op writes? A slot found holding something else since starts afresh.
function PS.noopCapped(key, ipath, cur, tag)
    local k = key .. "@" .. ipath
    local r = PS.noop[k]
    if not r then return false end
    if r.cur ~= cur then PS.noop[k] = nil; return false end
    if r.n < PS.NOOP_MAX then return false end
    pinGaveUp[key] = true
    CP.once("noop|" .. k, ("recruit pin: %s on %s gave up — %d write(s) changed nothing on the slot (it still reads %s); " ..
        "not written again (1.8.32: the re-pin storm guard)"):format(shortTag(tag), shortOwner(ipath), r.n, tostring(cur)))
    return true
end

-- ---- 1.8.31: THE TALENT GATE (the recruit Talent-pin timing regression of 1.8.28-1.8.30) ----
-- THE EVIDENCE. Retail 2026-10-01 (ZCSithClass 1.0.1, loader 1.8.29/1.8.30 code; SithClass notes/TALENT_VOICE_FIX.md §2):
-- every Sith Talent pin logged DELIVERED 6-7 s after RefreshCharacterVMs, the one verify pass (+8 s after `done`) saw no
-- revert, and every card showed its CD voice's talent (DA_RecruitmentSettings.VoiceOverToTalentMapping: Mentor ->
-- Fortitude, Professional -> Grit, Bruiser -> A Life of Labor). On 1.8.27 the Jedi's net-new Talent pin landed ~101 s after
-- the refresh, on a card whose BEFORE was already voice-mapped, and HELD.
-- THE CAUSE. The card's second Talent writer is UBrunoCharacterRecruitmentViewModel::OnSpawnCharacterAsyncComplete
-- (Ghidra @0x149b774f0, docs/recon/ghidra/recruitment_classpool.md step 6): it maps the CD's authored voice through the
-- mapping, sets the live Talent slot, creates the card's view model and decrements RemainingCharactersToGenerate. 1.8.28's
-- urgent pass drives a card once it is PS.SPAWN_SETTLE_S (1.5 s) old - card AGE, not the game's completion - so the pin
-- could land BEFORE that write, and the game's write won. The single verify pass at +8 s was too early to see it.
-- THE FIX. OnSpawnCharacterAsyncComplete is NOT a UFunction (the 197649 jmap lists no such function; the spawn delegate
-- carries a payload, so it is a native TDelegate) - RegisterHook cannot reach it. Its counter IS reflected:
-- BrunoCharacterRecruitmentViewModel.RemainingCharactersToGenerate (IntProperty @216, BlueprintReadOnly). It is > 0 while
-- any card of the set is still spawning and reaches 0 only after the LAST card's voice->Talent write. So:
--   (a) after a Recruitment refresh, a CARD's Talent is held until that counter reads 0 (read ONCE per pass, in the insts
--       frame, as that frame's second and last object lookup - inside the 1.8.28 budget). Every other slot keeps 1.8.28's
--       timing. Bounded by PS.GEN_WAIT_S; with no view model in the world the gate opens and says so.
--   (b) after `done`, verify passes at PS.VERIFY_AT (8/30/60/120 s; a new card set ends the window) read the LIVE Talent
--       slot back, log what it reads (`verify Talent ...: HELD` / `OVERWRITTEN`), and re-pin a card's Talent up to
--       PS.REPIN_MAX times. A write is called DELIVERED only when the slot reads our id back.
-- (c) The voice pin does not move the talent: the writer reads the CD's AUTHORED voice, not the live slot (Ghidra, VERIFIED).
-- -> the largest RemainingCharactersToGenerate over the live view models, or nil when there is none. ONE FindAllOf, counted.
function PS.genRead(P)
    P.lookups, P.nLook = P.lookups + 1, P.nLook + 1
    PS.fao = PS.fao + 1
    local ok, vms = pcall(FindAllOf, "BrunoCharacterRecruitmentViewModel")
    if not ok or type(vms) ~= "table" then return nil end
    local n, seen = 0, false
    for _, vm in ipairs(vms) do
        if pinOk(vm) then
            local nm = nil; pcall(function() nm = vm:GetFullName() end)
            if type(nm) == "string" and not nm:find("Default__", 1, true) then
                local r = nil; pcall(function() r = vm.RemainingCharactersToGenerate end)
                if type(r) == "number" then
                    seen = true
                    if r > n then n = r end
                end
            end
        end
    end
    return seen and n or nil
end

-- the gate itself, once per pass (PS.begin): sets P.genBusy while a card's voice->Talent write may still be to come
function PS.genGate(P, now)
    local g = PS.gen
    if not g or g.done then return end
    local card = false
    for _, c in pairs(P.inst) do if c.card then card = true end end   -- 1.8.32: a CARD, not any pool-CD character
    if not card then return end
    if (now - g.t) > PS.GEN_WAIT_S then
        g.done = true
        log(("recruit pin: talent gate: RemainingCharactersToGenerate still above 0 %d s after %s — gave up waiting; " ..
            "the Talent is driven now and re-verified after `done`"):format(PS.GEN_WAIT_S, g.why))
        return
    end
    if P.lookups >= PS.LOOKUPS then P.genBusy = -1; return end   -- (never: the insts frame has made one lookup)
    local n = PS.genRead(P)
    if n == nil then
        g.done = true
        CP.once("genvm", "recruit pin: talent gate: no BrunoCharacterRecruitmentViewModel in this world — the gate is " ..
            "open; the re-verify window after `done` catches a late voice->Talent write")
    elseif n > 0 then
        P.genBusy = n
        if not g.said then
            g.said = true
            log(("recruit pin: talent gate: %s — RemainingCharactersToGenerate=%d: a card's voice->Talent write " ..
                "(OnSpawnCharacterAsyncComplete) is still to come, so a card's Talent waits; its other slots do not"):format(g.why, n))
        end
    else
        g.done = true
        log(("recruit pin: talent gate: RemainingCharactersToGenerate=0 %.1f s after %s — every card's voice->Talent " ..
            "write has run; the Talent is driven now"):format(now - g.t, g.why))
    end
end

-- PHASE insts (one frame). Returns a verdict when the pass ends here, nil to go on.
function PS.begin(P)
    if not pinLoadRequested then
        pinLoadRequested = true
        for _, rp in ipairs(recruitPins) do
            for _, s in ipairs(rp.slots) do pcall(LoadAsset, s.part) end
            if rp.match then pcall(LoadAsset, rp.match.part) end
            if rp.definition then pcall(LoadAsset, rp.definition) end
        end
    end
    local now = PS.clock()
    CP.foldEvents()     -- 1.8.27: a Recruitment event that arrived before this pass began is this pass's to see
    -- 1.8.28: a NEW WORLD starts its sweeps and its residency answers afresh (a mission and the hub load different things)
    if P.wname ~= PS.lastWorld then
        PS.lastWorld = P.wname
        -- 1.8.32: object names are per world - the retired card set and the no-op counts are this world's only
        -- 1.8.33: and so is everything else keyed by an object name (PS.worldReset); a save load comes here too
        PS.worldReset(PS.loadWhy)
        PS.loadWhy = nil
    end
    -- 1.8.28 (fix 3): an URGENT pass (a Recruitment event) bypasses the spawn-wave settle; it waits instead for the cards of
    -- OURS to exist and be PS.SPAWN_SETTLE_S old (below). Bounded: after PS.URGENT_WAIT_S it is an ordinary pass again.
    local urgent = PS.urgent
    if urgent and (now - urgent.t) > PS.URGENT_WAIT_S then
        log(("recruit pin: %s: no card of ours appeared within %d s — back to the normal cadence"):format(urgent.why,
            PS.URGENT_WAIT_S))
        PS.urgent, urgent = nil, nil
    end
    PS.fao = PS.fao + 1
    P.nLook, P.lookups = P.nLook + 1, P.lookups + 1   -- 1.8.31: counted against the frame's budget too (PS.genGate reads it)
    local okI, insts = pcall(FindAllOf, "CustomizationInstance")
    if not okI or type(insts) ~= "table" then
        PS.census(P, " (FindAllOf CustomizationInstance returned nothing usable)"); return "idle"
    end
    -- 1.8.26: THE SPAWN-WAVE SETTLE. Every Den crash landed while the census was CLIMBING (27 -> 73 -> 116 instances in
    -- a few seconds), which is when a pass is heaviest (a GetOuter walk of up to 12 levels per slot) and the game is
    -- busiest. While the raw instance count is still rising, this pass only counts and returns "settling" (the loop
    -- keeps its 2.5 s cadence). BOUNDED: at most pinSettle.max deferrals in a row, then the pass runs whatever the
    -- count does; a pass that sees the count NOT rising re-arms the budget for the next world. Nothing is read from a
    -- slot and nothing is written while settling, so no userdata is held across the deferral.
    -- 1.8.28: NOT for an urgent pass - a Recruitment refresh IS a spawn wave (118 -> 149 -> 153 at retail 05:12), and the
    -- three deferrals it cost were the first 15 s of T-G1's 70.
    if pinSettle.max > 0 then
        local nAll = #insts
        if not urgent and nAll > pinSettle.last and pinSettle.waits < pinSettle.max then
            local prev = pinSettle.last
            pinSettle.last, pinSettle.waits = nAll, pinSettle.waits + 1
            CP.noteCensus(P.wname, nil)
            PS.census(P, string.format(" (census climbing %d -> %d; slot walk deferred, %d of at most %d)",
                prev, nAll, pinSettle.waits, pinSettle.max))
            return "settling"
        end
        if nAll <= pinSettle.last then pinSettle.waits = 0 end
        pinSettle.last = nAll
    end
    -- every live instance is a CHARACTER. `byDefinition` already identifies some of them; the Name part identifies the rest.
    -- 1.8.33: the census FIRST - a census that collapsed under the same world name is a SAVE LOAD (retail 18:26:56,
    -- 143 -> 29 in HUB_Root): this world's names are reset (PS.worldReset) before any character is classified.
    local cn, csum, list = 0, 0, {}
    for _, inst in ipairs(insts) do
        if pinOk(inst) then
            local iname = nil; pcall(function() iname = inst:GetFullName() end)
            if type(iname) == "string" and iname ~= "" and not iname:find("Default__") then
                P.nInst = P.nInst + 1
                local ipath = (iname:gsub("^[^ ]+ ", ""))
                local proxy = isProxyOwner(ipath)
                if not proxy then
                    cn = cn + 1
                    csum = csum + (tonumber(shortOwner(ipath):match("_(%d+)$") or "0") or 0)
                end
                list[#list + 1] = { inst = inst, ipath = ipath, proxy = proxy }
            end
        end
    end
    if P.hub and PS.cHi >= PS.LOAD_MIN and cn < PS.cHi * PS.LOAD_FRAC then   -- (the hub only: a mission's dead leave)
        PS.loadN = PS.loadN + 1                     -- (CP.rearmReason re-arms the hub for it once the loop is dormant)
        PS.worldReset(("save load: the census fell %d -> %d under the same world name"):format(PS.cHi, cn))
    end
    if cn > PS.cHi then PS.cHi = cn end
    local dm = PS.demote                            -- 1.8.33: a RecruitCharacter this pass owes a demotion
    local ticks = {}
    for _, e in ipairs(list) do
        local inst, ipath, proxy = e.inst, e.ipath, e.proxy
        local dpath = ""
        local okD, def = pcall(function() return inst:GetDefaultCustomizationDefinition() end)
        if okD and pinOk(def) then
            pcall(function() dpath = def:GetFullName():gsub("^[^ ]+ ", "") end)
        end
        -- 1.8.27: WHICH PIN an instance belongs to is decided by IDENTITY (rank 3 its own default definition, 2 a
        -- pin's `match` Name part, 1 a slot already holding a pin's own part - PS.walkOne), never by the order
        -- of the pins. 1.4.0-1.8.26 attached every instance to the FIRST pin with a `match` rule, so with more
        -- than one pin (three recruits per class mod, two class mods) only the first pin's character could ever
        -- be identified (replay W-g). The instance starts on its definition's pin, else on the first `match` pin
        -- as a placeholder that identity replaces.
        local defRp, matchRp = nil, nil
        for _, rp in ipairs(recruitPins) do
            if not defRp and rp.definition ~= nil and dpath == rp.definition then defRp = rp end
            if not matchRp and rp.match then matchRp = rp end
        end
        if PS.retired[ipath] then
            -- 1.8.32: a card of a PREVIOUS set (PS.retireCards): never collected again, whatever it holds
        elseif proxy then
            if not pinSkipLogged[ipath .. "|proxy"] then
                pinSkipLogged[ipath .. "|proxy"] = true
                log("recruit pin: skip " .. shortOwner(ipath) .. ": preview/portrait proxy (" .. proxy ..
                    ") — not pinned; it is a transient preview of a character, not the character")
            end
            PS.diagProxy(P, inst, ipath, proxy, dpath)   -- 1.8.33 DIAGNOSTIC (reads only)
        elseif defRp or matchRp then
            if defRp and not PS.firstSeen[ipath] then PS.firstSeen[ipath] = now end
            if dm and PS.cards[ipath] then
                -- 1.8.33: which card was recruited? Its actor's RecruitmentTime (FDateTime, reflected)
                local t = nil
                pcall(function() t = inst:GetOuter().RecruitmentTime.Ticks end)
                ticks[ipath] = tonumber(t)
            end
            -- 1.8.32: a CARD is a pool-CD character the recruitment view model spawned: first seen at/after
            -- this world's latest refresh (PS.setT). A pool-CD character already there before it (a RECRUITED
            -- one, from the save) is identified the same way but is a ROSTER character (PS.isCard).
            -- 1.8.33: ... and a card the player recruited stays a roster character (PS.recruited)
            if defRp and not PS.cards[ipath] and not PS.recruited[ipath] and PS.setT
               and (PS.firstSeen[ipath] or -1) >= PS.setT then
                PS.cards[ipath] = true
                PS.cardRp[ipath] = defRp
            end
            P.inst[ipath] = { rp = defRp or matchRp, rp0 = defRp or matchRp, rank = defRp and 3 or 0,
                              byDefinition = (defRp ~= nil), card = (defRp ~= nil) and PS.cards[ipath] == true,
                              slotsAll = {}, dupesBy = {}, nameSeen = nil,
                              ident = (defRp ~= nil), how = defRp and "its own default CustomizationDefinition" or nil }
            if defRp then PS.diagOwnRead(inst, ipath) end   -- 1.8.33 DIAGNOSTIC (reads only, once per character)
        end
    end
    -- 1.8.33: THE RECRUIT. The recruited card becomes a roster character before anything of this pass reads card-ness.
    if dm then
        local set, how = nil, nil
        if next(PS.cards) == nil then
            set, how = {}, "no card of ours was alive"
        else
            set, how = PS.whichRecruited(ticks, nil, false)
            if not set and P.lookups < PS.LOOKUPS then set, how = PS.whichRecruited(ticks, PS.vmNames(P), true) end
        end
        if set and #set == 0 and how:find("view model still lists", 1, true) and (dm.tries or 0) < 1 then
            dm.tries = (dm.tries or 0) + 1         -- (the view model may drop the recruited card a frame late: once more)
            set = nil
        end
        if set then
            PS.demote = nil
            local tl = {}
            for ip in pairs(PS.cards) do tl[#tl + 1] = shortOwner(ip) .. "=" .. tostring(ticks[ip] or "unread") end
            table.sort(tl)
            log(("recruit pin: RecruitCharacter: RecruitmentTime.Ticks on the cards of ours: %s"):format(
                (#tl > 0) and table.concat(tl, " ") or "<no card of ours>"))
            for _, ip in ipairs(set) do
                PS.demoteCard(ip, how)
                if P.inst[ip] then P.inst[ip].card = false end
            end
            if #set == 0 then log("recruit pin: RecruitCharacter: no card of ours was recruited (" .. how .. ") — the cards " ..
                "of ours stay cards") end
        end
    end
    CP.noteCensus(P.wname, cn, csum)   -- 1.8.27: the census the Recruitment watcher's fallback trigger reads
    -- 1.8.28 (fix 2): THE SCOPE. A world's first PS.SWEEP_PASSES passes, and one pass per PS.SWEEP_S after them, sweep the
    -- whole world; every other pass collects only what is OURS. A pin without a `definition` can only be found by its
    -- Name part, so then every pass sweeps (the 1.8.27 shape, without its lookups).
    PS.worldPasses = PS.worldPasses + 1
    local scopable = true
    for _, rp in ipairs(recruitPins) do if not rp.definition then scopable = false end end
    P.full = (not scopable) or PS.forceFull or PS.worldPasses <= PS.SWEEP_PASSES
             or (PS.sweepAt ~= nil and (now - PS.sweepAt) >= PS.SWEEP_S)
    -- 1.8.33 THE HUB COST: a sweep due in a world whose stable, populated sweep found nothing ours, where every
    -- character is still a cached not-ours verdict (PS.notOurs: a sweep read its Name; a re-arm forgets them all), would
    -- read the same slots to the same verdict - the world is dormant instead, with no drive frame
    if P.full and PS.swept and CP.stable and not urgent and scopable then
        local fresh = false
        for ipath, c in pairs(P.inst) do if c.byDefinition or not PS.notOurs[ipath] then fresh = true end end
        if not fresh then P.inst, P.full = {}, false end
    end
    if P.full then
        PS.sweepAt, PS.forceFull = now, false
    else
        local keep = {}
        for ipath, c in pairs(P.inst) do
            if c.byDefinition or pinKnown[ipath] then keep[ipath] = c end
        end
        P.inst = keep
    end
    -- 1.8.33: a RecruitCharacter spawns no card - its urgent pass does not wait for one (1.8.28-1.8.32 looked again every
    -- 0.5 s for PS.URGENT_WAIT_S when no other card of ours was left)
    if urgent and urgent.why == "RecruitCharacter" then P.urgent, urgent = urgent, nil end
    if next(P.inst) == nil then
        if urgent then
            PS.census(P, string.format(" (%s: no card of ours yet; looking again in %.1f s)", urgent.why, PS.URGENT_STEP_S))
            return "urgent"
        end
        -- 1.8.33: and a FULL pass of a world whose stable, populated sweep found nothing ours (every character in it is a
        -- cached not-ours verdict) is dormant too (1.8.28 kept sweeping for PS.SWEEP_PASSES passes)
        local verdict, extra = "idle", nil
        if not P.full or (PS.swept and CP.stable) then
            verdict, extra = "none", " (nothing ours; this world's sweeps are done)"
        end
        if PS.diagWanted(P) then                   -- 1.8.33 DIAGNOSTIC: a proxy to read - one drive frame, reads only
            P.diagOnly, P.after, P.afterExtra, P.phase = true, verdict, extra, "drive"
            return nil
        end
        PS.census(P, extra); return verdict
    end
    -- 1.8.31: the talent gate (the frame's second lookup, when a refresh's card set may still be generating)
    PS.genGate(P, now)
    -- 1.8.28 (fix 3): the urgent pass drives once every card of OURS exists and is PS.SPAWN_SETTLE_S old
    if urgent then
        local ready, young = 0, 0
        for ipath, c in pairs(P.inst) do
            if c.card then          -- 1.8.32: the CARDS of ours (a recruited pool-CD character is not waited for)
                if (now - (PS.firstSeen[ipath] or now)) >= PS.SPAWN_SETTLE_S then ready = ready + 1 else young = young + 1 end
            end
        end
        if ready == 0 or young > 0 then
            PS.census(P, string.format(" (%s: %d card(s) of ours ready, %d still spawning; looking again in %.1f s)",
                urgent.why, ready, young, PS.URGENT_STEP_S))
            return "urgent"
        end
        P.urgent = urgent
    end
    P.phase = "drive"
    return nil
end

-- one slot of the collection: the 1.8.26 loop body. 1.8.28: `ipath` comes from the slot's NAME (PS.ownerOf), and the
-- two world-wide sweeps run only on a sweep pass (P.sweep).
function PS.walkOne(P, s, sname, tag, ipath)
    local instByPath = P.inst
    -- 1.8.19: THE GHOST SWEEP, before anything is driven and on EVERY character in the world, ours or not.
    -- Bounded to this pin's own declared tags and to real characters (a preview proxy is a transient copy
    -- of one, and would print the same ghost again under a new name every pass). Observable-only: the
    -- only thing it changes is `pinGhostSlot`, which stops a slot being COLLECTED, and so driven.
    -- 1.8.20: it runs AFTER the owner is known, because the OWNER is now part of the evidence — a slot with
    -- no owning CustomizationInstance is a slot mid-spawn, and mid-spawn is what produced all three of
    -- the 2026-09-13 false positives. The loop also stops at the FIRST matching pin so a tag two pins
    -- both declare cannot double-count the consecutive-pass rule.
    -- 1.8.27: a slot a missing dependency DROPPED from its pin (no fallback) is still swept (rp.ghostTags).
    -- 1.8.28: on a scoped pass only OUR characters' slots reach this line (PS.drive), so the refusal still guards
    -- every slot the pin could write.
    if tag ~= "" and not pinGhostSlot[sname] and not isProxyOwner(sname) then
        local matched = false
        for _, rp in ipairs(recruitPins) do
            local hit = false
            for _, pin in ipairs(rp.slots) do if tag == pin.tag then hit = true end end
            if not hit and rp.ghostTags and rp.ghostTags[tag] then hit = true end
            if hit and not matched then
                matched = true
                local g, dead, pend = ghostOf(s, tag)
                -- a pass that reads OTHERWISE resets the count: the rule is CONSECUTIVE checks
                if pend then P.ghostWait[sname] = true            -- 1.8.28: residency not known yet: not judged, not driven
                elseif g then ghostReport(sname, ipath, tag, g, pinPass, dead)
                else pinGhostSeen[sname] = nil end
            end
        end
    end
    -- 1.8.22: THE STALE-SLOT SWEEP, on the same footing as the ghost sweep — every character in the world,
    -- ours or not, read-only here. It runs AFTER the ghost sweep so a slot the ghost rule has just blocked
    -- can never be collected as a rebuild candidate; whether it is OURS is decided after this loop, when
    -- identity has stopped moving. 1.8.28: on a sweep pass only.
    if P.sweep then staleConsider(s, sname, ipath, tag) end
    local c = ipath and instByPath[ipath]
    if c then
        -- 1.8.28 (fix 6): the appearance echo's two slots, read-only; the live one is the highest object index
        if tag == PS.FACE or tag == PS.HAIR then
            local idx = tonumber(sname:match("_(%d+)$") or "0") or 0
            local prev = c.look[tag]
            if not prev or idx > prev.idx then
                local id = "?"
                pcall(function() id = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end)
                c.look[tag] = { idx = idx, id = tostring(id) }
            end
        end
        -- 1.8.27: identity over EVERY pin (see PS.begin), a higher rank never replaced by a lower one
        local cur = nil
        for _, rp in ipairs(recruitPins) do
            if rp.match and tag == rp.match.slot and tag ~= PS.VOICE_TAG then   -- classes v2 #3: a voice never matches
                if cur == nil then cur = ""; pcall(function() cur = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end) end
                c.nameSeen = (cur ~= "") and cur or "<none>"
                if c.rank < 2 and cur == rp.match.part:match("([^/.]+)$") then
                    c.rp, c.rank, c.ident = rp, 2, true
                    c.how = "its " .. shortTag(tag) .. " = " .. cur
                end
            end
        end
        -- 1.8.15 SECOND IDENTITY SOURCE: a slot already holding one of THIS pin's own parts is this pin's
        -- character. The Name slot can be re-created underneath us (equipping the definition replaces the
        -- class fragment, and the class fragment is what makes the child slots), and when it blinked the
        -- 07:47 session lost the Sith for the rest of the run.
        if c.rank < 1 then
            if cur == nil then cur = ""; pcall(function() cur = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end) end
            for _, rp in ipairs(recruitPins) do
                for _, pin in ipairs(rp.slots) do
                    if c.rank < 1 and tag == pin.tag and cur == pin.part:match("([^/.]+)$") then
                        -- 1.8.32: only a part of the mod's OWN namespace is evidence (PS.evidence): a stock Talent the
                        -- voice map hands stock recruits converted them into Sith (retail 2026-10-02 11:13:19)
                        local ok, whyNot = PS.evidence(rp, pin)
                        if ok then
                            c.rp, c.rank, c.ident = rp, 1, true
                            c.how = "its " .. shortTag(tag) .. " already holds " .. cur
                        else
                            CP.once("noevid|" .. cur, ("recruit pin: identity: %s (%s, %s) is not identity evidence — " ..
                                "a character holding it is not scoped by it (first seen on %s)"):format(cur,
                                shortTag(tag), tostring(whyNot), shortOwner(ipath)))
                        end
                    end
                end
            end
        end
        -- 1.8.27 (§5.6): the GearKit sub-slot, whose MODEL part carries the weapon class's identity tag. The live one
        -- is the highest object index, as for every other slot (1.8.16).
        if tag == CP.GEARKIT then
            local idx = tonumber(sname:match("_(%d+)$") or "0") or 0
            if not c.gear or idx > c.gear.idx then c.gear = { sname = sname, obj = s, idx = idx } end
        end
        -- 1.8.27: collected for EVERY pinned tag, keyed by tag; PS.act keeps the tags of the pin identity chose
        if P.pinTags[tag] and not pinGhostSlot[sname] and not P.ghostWait[sname] then
            -- 1.8.19: a GHOST slot is never collected, so it can never be driven — the refusal is
            -- structural, not a branch inside the write path.
            -- 1.8.16: EVERY EQUIP LEAVES THE OLD SLOT OBJECTS ALIVE BESIDE THE NEW ONES. Retail 08:38
            -- watched one character go 3 -> 6 -> 12 matching slots across three passes, and the old cap
            -- counted the corpses and refused him. A character has exactly one LIVE slot per tag: keep
            -- the highest object index (UE numbers each new object above the last) and count the rest
            -- as the stale duplicates they are.
            local idx = tonumber(sname:match("_(%d+)$") or "0") or 0
            local prev = c.slotsAll[tag]
            local entry = { sname = sname, obj = s, tag = tag, idx = idx }
            if P.verify and tag:find("%.Specializations%.Talent$") then
                -- 1.8.31 (b): every slot object of the Talent tag, for the verify read-back line (reads only)
                local id = "?"
                pcall(function() id = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end)
                c.dupIds[tag] = c.dupIds[tag] or {}
                table.insert(c.dupIds[tag], idx .. "=" .. tostring(id))
            end
            if prev == nil then
                c.slotsAll[tag] = entry
            else
                c.dupesBy[tag] = (c.dupesBy[tag] or 0) + 1
                if idx > prev.idx then c.slotsAll[tag] = entry end
            end
        end
    end
end

-- PHASE drive (one frame): ONE FindAllOf of the slots, the collection, and the act - on the objects of THIS frame only.
function PS.drive(P)
    P.drives = P.drives + 1
    P.sweep = P.full and not P.swept and not P.diagOnly
    P.lookups, P.nLook = P.lookups + 1, P.nLook + 1
    PS.fao = PS.fao + 1
    local okS, slots = pcall(FindAllOf, "CustomizationFragmentInstanceSlot")
    if not okS or type(slots) ~= "table" then
        PS.census(P, " (FindAllOf CustomizationFragmentInstanceSlot returned nothing usable)"); return "idle"
    end
    staleCand = {}      -- 1.8.22: re-collected every frame; no slot userdata survives one (the 05:50:58 rule)
    P.ghostWait = {}
    for _, c in pairs(P.inst) do
        c.slotsAll, c.dupesBy, c.gear, c.nameSeen, c.look, c.dupIds = {}, {}, nil, nil, {}, {}
        c.rp, c.rank, c.ident = c.rp0, c.byDefinition and 3 or 0, c.byDefinition
        c.how = c.byDefinition and "its own default CustomizationDefinition" or nil
    end
    local want = PS.tags()
    -- 1.8.33 DIAGNOSTIC: a proxy of this pass to read - its Class / Name / Voiceover / Tactical.Primary slots too
    local diag = (P.proxies ~= nil and next(P.proxies) ~= nil)
    if diag then
        local w2 = {}
        for k in pairs(want) do w2[k] = true end
        for k in pairs(PS.DIAG_TAGS) do w2[k] = true end
        want = w2
    end
    P.pinTags = {}
    for _, rp in ipairs(recruitPins) do for _, pin in ipairs(rp.slots) do P.pinTags[pin.tag] = true end end
    for _, s in ipairs(slots) do
        if pinOk(s) then
            local tag = ""; pcall(function() tag = s.SlotNameTag.TagName:ToString() end)
            if type(tag) == "string" and want[tag] then
                local sname = nil; pcall(function() sname = s:GetFullName() end)
                if type(sname) == "string" and sname ~= "" then
                    sname = (sname:gsub("^[^ ]+ ", ""))
                    if diag and PS.DIAG_TAGS[tag] then PS.diagSlot(P, s, sname, tag) end
                    local ipath = (not P.diagOnly) and PS.ownerOf(P, sname) or nil
                    -- a scoped pass reads only OUR characters' slots; a sweep reads every one (the ghost refusal and
                    -- the stale-slot rebuild look at characters that are not ours, and at slots with no owner yet)
                    if ipath or P.sweep then
                        PS.walked = PS.walked + 1
                        PS.walkOne(P, s, sname, tag, ipath)
                    end
                end
            end
        end
    end
    if diag then PS.diagFlush(P) end                 -- (this frame's objects, read in this frame)
    if P.diagOnly then
        PS.census(P, P.afterExtra)
        return P.after or "idle"
    end
    -- residency answers this collection needs and does not have: one lookup frame each, then a fresh drive frame
    if P.lookAt < #P.lookq and P.looks < PS.LOOK_MAX then
        P.phase = "look"
        return "more"
    end
    local r = PS.act(P)
    if P.sweep then P.swept = true end
    return r
end

-- PHASE look: ONE StaticFindObject per frame, answering the residency questions the collection queued.
function PS.look(P)
    P.looks = P.looks + 1
    local path = P.lookq[P.lookAt + 1]
    if path then
        P.lookAt = P.lookAt + 1
        if PS.res[path] == nil then
            P.lookups, P.nLook = P.lookups + 1, P.nLook + 1
            PS.sfo = PS.sfo + 1
            local o = nil
            pcall(function() o = StaticFindObject(path) end)
            PS.res[path] = pinOk(o)
        end
    end
    if P.lookAt >= #P.lookq or P.looks >= PS.LOOK_MAX then P.phase = "drive" end
    return "more"
end

-- 1.8.28 (fix 4): a character whose Class was delivered earlier in THIS pass: are its child slots the re-created ones yet?
-- true = hold it this frame. The children are the new objects when their live slot names differ from the ones read before
-- the Class write; after PS.CLASS_TRIES frames that still read the old ones they are driven as they are (and said so).
function PS.kidsHold(P, ipath, c)
    local ca = P.classAt[ipath]
    if not ca or ca.go then return false end
    ca.tries = ca.tries + 1
    local same = 0
    for tag, sn in pairs(ca.kids) do
        local h = c.slotsAll[tag]
        if h and h.sname == sn then same = same + 1 end
    end
    if same > 0 and ca.tries < PS.CLASS_TRIES then return true end
    ca.go = true
    if same > 0 then
        CP.once("kids|" .. ipath, "recruit pin: " .. shortOwner(ipath) .. ": " .. same .. " child slot(s) are still the " ..
            "same objects " .. ca.tries .. " drive frame(s) after its Class was delivered — driving them as they are")
    end
    return false
end

-- 1.8.28 (fix 6): ONE read-only line per character of ours: which head and hair its slots hold (analysis §3's question)
-- 1.8.28b: AND ONCE MORE AT THE VERIFY PASS (~VERIFY_S after `done`). Retail 1.8.28 read Face=CPD_H_Head_HM02 /
-- Hair=CPD_H_Human_Hair_None on all three cards of the FIRST set after load (none of the mod's CDs), and the right heads on
-- the second set. The verify read tells "read before the appearance settled" (CHANGED) from "spawned with the default
-- head" (unchanged). Same reads, same frame as the verify pass's own collection: no lookup of its own.
function PS.echoLook(P, ipath, c)
    local f, h = c.look[PS.FACE], c.look[PS.HAIR]
    local fid, hid = f and f.id or "<no slot>", h and h.id or "<no slot>"
    local body = shortTag(PS.FACE) .. "=" .. fid .. " " .. shortTag(PS.HAIR) .. "=" .. hid
    local first = PS.lookEchoed[ipath]
    if not first then
        PS.lookEchoed[ipath] = { face = fid, hair = hid }
        log("recruit pin: appearance " .. shortOwner(ipath) .. ": " .. body .. " (read-only)")
        return
    end
    if not P.verify or P.lookVerified[ipath] then return end
    P.lookVerified[ipath] = true
    local same = (first.face == fid and first.hair == hid)
    log("recruit pin: appearance (verify) " .. shortOwner(ipath) .. ": " .. body .. " (read-only) — " ..
        (same and "unchanged since the first read" or ("CHANGED since the first read (was " .. shortTag(PS.FACE) .. "=" ..
        first.face .. " " .. shortTag(PS.HAIR) .. "=" .. first.hair .. ")")))
end

-- 1.8.31 (b): a verify pass READS THE LIVE TALENT BACK and says what it read, matched or not, once per card per verify
-- pass (capped per session) - so a retail log tells "held" from "overwritten", and, with the other slot objects of the tag
-- listed (object index = part id; the live one is the highest index), "the game wrote another slot object" (SithClass
-- TALENT_VOICE_FIX.md H1) from "the slot we drive was overwritten". Reads only: this frame's own objects, no lookup.
function PS.verifyLine(P, ipath, c, tag, cur, want, nrev, cap)
    if PS.vlog >= PS.VLOG_CAP then return end
    PS.vlog = PS.vlog + 1
    local verdict
    if cur == want then verdict = "HELD"
    elseif nrev < cap then verdict = "OVERWRITTEN — re-pinning"
    else verdict = "OVERWRITTEN — re-pin cap (" .. cap .. ") reached; left as the game set it" end
    local others = ""
    local list = c.dupIds and c.dupIds[tag]
    if list and #list > 1 then others = "; slot objects of this tag (index=part): " .. table.concat(list, " ") end
    log(("recruit pin: verify %s on %s: reads %s (wanted %s) — %s%s"):format(shortTag(tag), shortOwner(ipath), cur, want,
        verdict, others))
end

-- PHASE act (inside the drive frame): the 1.8.26 judgement and drive, on objects this frame's FindAllOf returned.
-- returns "pinned" (a slot was changed) / "targets" (pin-able characters are here, nothing to change) / "idle" (nothing to do),
-- which is what the loop below paces itself by; "more" when the same pass drives again next frame (1.8.28).
--
-- 1.8.12 — THE UNIT OF IDENTITY IS THE CHARACTER, AND A CHARACTER IS ITS `UCustomizationInstance`.
-- 1.8.10/1.8.11 made it the slot's immediate parent object, and retail 2026-09-13 05:03 proved that unsatisfiable by
-- construction: `pass 39: 73 instance(s) seen, 73 candidate(s), 73 group(s), 0 pinned, 14 skipped, world=HUB_Root`, with every
-- character skipped three times — `no identity: it holds 1 pinned tag(s) | 2 pinned tag(s) | 2 pinned tag(s) … Info.Name reads
-- <not present>`. One character's slots are NOT siblings: `Class` hangs directly off the CustomizationInstance, the two
-- `Specializations.*` slots hang off a container slot (`…CustomizationFragmentInstanceSlot_11.CustomizationFragmentInstanceSlot_2`),
-- and `Info.Name` hangs off a third parent. No parent object can ever hold both a pinned tag and the identity, so the per-group
-- identity rule could only ever fail — silently in 1.8.10, loudly in 1.8.11, but always.
-- 1.8.7 — which pinned this recruit correctly — identified at INSTANCE level, and that is what is restored here:
--   * a character is OURS if its instance's own `GetDefaultCustomizationDefinition()` is the pin's, OR if ANY slot under that
--     instance whose `SlotNameTag` is the pin's `match` slot holds the pin's `match` part (the mod's own Info.Name part).
--     In this save Vex was built from the pool row, so his instance's default definition is generic — only the Name part finds him.
--   * the pinned tags' slots are then taken from ANYWHERE under that same instance, at any depth, across parent slots.
-- WHAT STOPS THE 22:15:47 MASS-PIN IS NOT THE GROUPING — IT IS THE CAP. That incident collected 21 slots belonging to seven
-- characters under ONE proxy instance, because a customization proxy accumulates the slot trees of everything it has previewed.
-- A real character has exactly ONE slot per pinned tag, so more matching slots than the pin declares means the instance holds
-- more than one character and NOTHING is written. That test is exact, cheap, and cannot be defeated by a tree shape.
function PS.act(P)
    local instByPath = P.inst
    -- 1.8.28: the CDO once a session (PS.ksl), not a StaticFindObject per act
    local ksl = PS.ksl()
    -- 1.8.22: the stale-slot rebuild, once identity has stopped moving for this pass and before anything of OURS is
    -- driven (different characters, different instances — the order is only so the two never interleave on one).
    -- 1.8.28: on a sweep pass (the candidates are collected only then), and on every pass while one is mid-flight.
    local staleBusy = P.sweep and staleDrive(instByPath, ksl, P.hub) or false
    if staleBusy then PS.forceFull = true end   -- the rebuild's second write needs the next pass to be a sweep too
    P.nOurs, P.nWith, P.nSkip, P.skipped = 0, 0, 0, {}

    local pending, refresh = {}, {}
    local waitingOnResidency = false   -- 1.8.19: a pinned part this pass was not resident yet; see the `done` gate
    -- 1.8.32 (d): THE ORDER of the characters, which is the order they get the frame's lookup budget in: the cards of the
    -- NEWEST set (first seen since the last refresh) first, then other cards, then the roster; a retired card not at all
    -- (a pass that began before the refresh may still hold one)
    local order = {}
    for ipath in pairs(instByPath) do if not PS.retired[ipath] then order[#order + 1] = ipath end end
    local function rankOf(ip)
        local c = instByPath[ip]
        if c.card then return 0 end            -- the current card set (cards are first seen after the latest refresh)
        return 2
    end
    table.sort(order, function(a, b)
        local ra, rb = rankOf(a), rankOf(b)
        if ra ~= rb then return ra < rb end
        return a < b
    end)
    P.order = order
    for _, ipath in ipairs(order) do
        local c = instByPath[ipath]
        -- 1.8.27: identity is sticky PER PIN too - an instance identified in an earlier pass keeps that pin, over a
        -- part match (rank 1): the rows of one class share their class/spec/weapon parts, so a part match alone
        -- cannot tell row A from row B when the Name slot blinks
        if c.rank < 2 and pinKnown[ipath] and PS.knownRp[ipath] then c.rp = PS.knownRp[ipath] end
        local rp = c.rp
        c.byTag, c.dupes = {}, 0
        for _, pin in ipairs(rp.slots) do
            local h = c.slotsAll[pin.tag]
            if h then
                c.byTag[pin.tag] = { sname = h.sname, obj = h.obj, tag = pin.tag, pin = pin, idx = h.idx }
                c.dupes = c.dupes + (c.dupesBy[pin.tag] or 0)
            end
        end
        c.hits = {}
        local distinct = 0
        for _, h in pairs(c.byTag) do c.hits[#c.hits + 1] = h; distinct = distinct + 1 end
        -- 1.8.28: in legacyOwner's ORDER (Class, Weapon, the rest, Talent). The Class-first rule is now enforced HERE too:
        -- a hit is only looked up / made pending after the Class is settled, because the lookup budget would otherwise
        -- let a child's part in first and leave the Class for a later frame - and the Class write would then discard it.
        table.sort(c.hits, function(a, b)
            local ra, rb = PS.orderOf(a.tag), PS.orderOf(b.tag)
            if ra ~= rb then return ra < rb end
            return a.tag < b.tag
        end)
        if #c.hits > 0 then
            P.nWith = P.nWith + 1
            if c.dupes > 0 and not pinSkipLogged[ipath .. "|dupes"] then
                pinSkipLogged[ipath .. "|dupes"] = true
                log("recruit pin: " .. shortOwner(ipath) .. ": " .. c.dupes .. " stale duplicate slot object(s) " ..
                    "ignored (" .. distinct .. " live pinned tag(s); every equip leaves the previous slot objects " ..
                    "alive beside the new ones)")
            end
            -- 1.8.15: identity is STICKY. Once this instance has been identified it stays identified for the session,
            -- because the game can re-create the slot that carried the identity while the pin is mid-flight.
            -- 1.8.16: an IDENTIFIED character is never refused by the cap. The cap exists to stop an instance
            -- nobody has identified from being pinned by accident; it must never fire on the recruit itself.
            if c.ident then pinKnown[ipath] = c.how or "identity"; PS.knownRp[ipath] = rp
            elseif pinKnown[ipath] then c.ident = true; c.how = pinKnown[ipath] .. " (remembered from an earlier pass)" end
            if not c.ident then
                -- 1.8.33: a sweep that READ this character's Name and found it not ours: the verdict is cached until a
                -- re-arm (a refresh, a recruit, a world change or a save load), so later passes do not collect it again
                if P.sweep and c.nameSeen and c.nameSeen ~= "<none>" then PS.notOurs[ipath] = true end
                PS.skip(P, ipath, "not ours: " .. #c.hits .. " slot(s) carry pinned tags but its default definition is not " ..
                    tostring(rp.definition and rp.definition:match("([^/.]+)$") or "<none>") ..
                    (rp.match and (" and its " .. shortTag(rp.match.slot) .. " reads " .. tostring(c.nameSeen or "<not present>") ..
                        " (wanted " .. rp.match.part:match("([^/.]+)$") .. ")") or " and this pin declares no `match` rule"))
            elseif distinct > #rp.slots then
                -- THE MASS-PIN GUARD. A character has one slot per pinned tag; more means this instance carries more than one
                -- character's slots (a customization proxy that has previewed several). Retail 2026-09-12 22:15:47: 21 slots,
                -- seven characters, 33 wrong writes. Nothing is written here, ever.
                PS.skip(P, ipath, distinct .. " LIVE distinct pinned tag(s) against this pin's " .. #rp.slots .. " under ONE CustomizationInstance — " ..
                    "it holds more than one character's slots, so nothing is written (this is the 2026-09-12 22:15:47 guard)")
            else
                P.nOurs = P.nOurs + 1
                PS.oursSeen = true
                PS.echoLook(P, ipath, c)
                PS.diagChar(P, ipath, c)                 -- 1.8.33 DIAGNOSTIC (once per character per world; reads only)
                local how = c.how or (c.byDefinition and "its own default CustomizationDefinition")
                    or (rp.match and ("its " .. shortTag(rp.match.slot) .. " = " .. rp.match.part:match("([^/.]+)$")))
                    or "identity"
                if PS.kidsHold(P, ipath, c) then
                    P.again, P.hold = true, PS.CLASS_HOLD          -- 1.8.28: its children are not re-created yet
                else
                local classBlock = nil       -- 1.8.28: "pending" / "held" while this character's Class needs a drive
                local blocked = false        -- 1.8.28: a slot of this character waits for the next frame's budget
                for _, hit in ipairs(c.hits) do
                    local s, tag, pin = hit.obj, hit.tag, hit.pin
                    if pinOk(s) then
                    local before = slotState(s)
                    local cur = (before.id:match("([^:]+)$") or "?")
                    local want = pin.part:match("([^/.]+)$")
                    local isTalent = (tag:find("%.Specializations%.Talent$") ~= nil)
                    -- 1.8.14: the retry bound is keyed by the character's STABLE identity (the pin's own Name part or
                    -- its definition), not the instance path — a proxy's path changes as the game recreates it, so the
                    -- old key made PIN_MAX_RETRY unreachable and the 05:43 session re-drove forever without one
                    -- `attempt` give-up line.
                    -- 1.8.27 (G1): ... EXCEPT a recruit CARD (identified by the pool definition). A card is a transient
                    -- instance and a Recruitment refresh spawns new ones, so a card's slot state is keyed by its instance
                    -- (`|card:<path>`): a card delivered before a refresh can never mark the NEXT card of the same row
                    -- delivered. Proxies are never pinned (1.8.14), so the 05:43 churn cannot come back through a card.
                    local ident = (rp.match and rp.match.part:match("([^/.]+)$"))
                        or (rp.definition and rp.definition:match("([^/.]+)$")) or "pin"
                    -- 1.8.32: keyed by CARD-ness, not by the definition match (a recruited character keeps its pool CD)
                    local key = ident .. "|" .. tag .. (c.card and ("|card:" .. ipath) or "")
                    pinExpected[key] = true
                    -- "the id already names our part" is NOT enough: that is the state the setter leaves when the part was not
                    -- resident — our id, a NULL definition, no leveled tree. Re-drive it, bounded by PIN_MAX_RETRY.
                    local need
                    if pinDelivered[key] then
                        need = false                 -- 1.8.18: finished; driving it again would undo it
                        -- 1.8.33: a DELIVERED slot that now reads something else is first a question for the accept-set:
                        -- a roster character's own choice (a recruited Sith's voice, retail 18:26:09) is left alone, said
                        -- once, and never re-pinned by a verify pass
                        if cur ~= want and not PS.accKey[key] then
                            local acc = CP.accepted(pin, cur, c.card, function(id) return CP.weaponTags(c, id, pin) end)
                            if acc then
                                PS.accKey[key] = true
                                CP.acceptLog(acc, pin, tag, ipath, cur)
                            end
                        end
                        -- 1.8.28 (fix 3): THE VERIFY PASS, once, VERIFY_S after an urgent episode's `done`: a slot that
                        -- DELIVERED and no longer holds ours (the spawn's voice writer, say) is driven again - once.
                        -- 1.8.31: a verify pass now runs at each PS.VERIFY_AT, and a CARD's Talent may be re-pinned up
                        -- to PS.REPIN_MAX times (the voice->Talent writer can land after the first one); other slots once.
                        local nrev = PS.reverted[key] or 0
                        if nrev == true then nrev = 1 end
                        local cap = (isTalent and c.card) and PS.REPIN_MAX or 1
                        if P.verify and isTalent and not PS.accKey[key] then PS.verifyLine(P, ipath, c, tag, cur, want, nrev, cap) end
                        if P.verify and cur ~= want and not PS.accKey[key] and nrev < cap then
                            PS.reverted[key] = nrev + 1
                            pinDelivered[key], pinAttempts[key] = nil, 0
                            P.reverts = P.reverts + 1
                            log("recruit pin: " .. shortTag(tag) .. " on " .. shortOwner(ipath) .. " reverted to " .. cur ..
                                " after it was DELIVERED — driving it again (verify pass" ..
                                ((cap > 1) and (", re-pin " .. (nrev + 1) .. "/" .. cap) or "") .. ")")
                            need = true
                        end
                    elseif pinToggled[key] then
                        -- 1.8.18: the toggle is mid-flight, put ours back - on a LATER pass (1.8.28: a pass now spans
                        -- several frames; LoadCustomization's tick between the two writes is kept as retail proved it)
                        need = (pinToggled[key] ~= pinPass)
                    elseif cur ~= want then
                        -- 1.8.27 (H1 / §5.6): a part the pin ACCEPTS is a player's choice (or the uninstall escape
                        -- hatch on a roster character): settled, never driven.
                        local acc = CP.accepted(pin, cur, c.card,   -- 1.8.32: card-ness, not the definition match
                            function(id) return CP.weaponTags(c, id, pin) end)
                        if acc then
                            need = false
                            pinDelivered[key] = true
                            PS.accKey[key] = true
                            CP.acceptLog(acc, pin, tag, ipath, cur)
                        elseif PS.noopCapped(key, ipath, cur, tag) then
                            -- 1.8.32 (a): PS.NOOP_MAX writes changed nothing on this slot, and it still reads the same:
                            -- given up (retail 2026-10-02: 1,597 such writes, the counter below zeroed every pass)
                            need = false
                        else
                            pinAttempts[key] = 0
                            need = true
                            if pin.dead and pin.dead[cur] then   -- §2d.3: the removed-pack case WITH a fallback
                                CP.once("deadfb|" .. ipath .. "|" .. tag .. "|" .. cur, "recruit pin: " .. shortOwner(ipath) ..
                                    " " .. shortTag(tag) .. " held " .. cur .. " from missing " .. tostring(pin.dep) ..
                                    " — delivering fallback " .. want)
                            end
                        end
                    elseif (pin.accept or pin.acceptTags) and not c.card and before.defn ~= "<null>"
                           and before.trees == 0 then
                        -- 1.8.27 (§5.6.1 a2): an ACCEPT-SET slot on a ROSTER character that already holds `want`,
                        -- resolved, is settled. The 1.8.18 re-drive below would toggle it (a Weapon part always reads 0
                        -- trees), and toggling the spec re-creates its GearKit sub-slot: a hilt the player re-picked
                        -- inside the class would be reset every session. (The cost, stated: such a slot no longer gets
                        -- the once-a-session toggle that also refreshes stale fragments - 1.8.22's Hawks case.)
                        need = false
                        pinDelivered[key] = true
                        PS.accKey[key] = true
                        CP.acceptLog("kept", pin, tag, ipath, cur)
                    elseif c.card and tag:find("%.Class$") and (PS.cardClass[ipath] or before.defn ~= "<null>") then
                        -- 1.8.32 (c): a CARD's Class that holds ours - delivered by us, or resolved - is never toggled. A
                        -- Class reads 0 leveled trees for ever, so the re-drive below would toggle it out, and on a card
                        -- that write may be the last that sticks (retail 2026-10-02 11:18:18, the storm's first write).
                        need = false
                        pinDelivered[key] = true
                        CP.once("cardcls|" .. ipath, "recruit pin: Class on " .. shortOwner(ipath) .. " holds " .. want ..
                            " — settled on this card, never toggled")
                    elseif not c.card and tag:find("%.Class$") and before.defn ~= "<null>" and (before.nfrag or 0) > 0 then
                        -- 1.8.33: nor a ROSTER character's Class that holds ours, resolved, with its fragments: the
                        -- toggle re-creates every Specializations slot and resets the player's spec / saber choices (a
                        -- reloaded or just-recruited Sith). The toggle stays for a Class with no definition or fragments.
                        need = false
                        pinDelivered[key] = true
                        CP.once("rostercls|" .. ipath, "recruit pin: Class on " .. shortOwner(ipath) .. " holds " .. want ..
                            " (resolved, " .. tostring(before.nfrag) .. " fragment(s)) — settled on this roster character, " ..
                            "not toggled")
                    elseif tag:find("%.Info%.Voiceover$") and before.defn ~= "<null>" then
                        -- 1.8.33: a VOICE holding ours, resolved, is delivered: a voice part has no leveled trees for
                        -- ever, and there is no stock id to toggle through - 1.8.32 re-collected it every pass
                        -- (retail 18:22:54-18:26:09: `1 slot(s) to drive`, `pinned`, never `done`)
                        need = false
                        pinDelivered[key] = true
                        CP.once("voiceok|" .. ipath, "recruit pin: Info.Voiceover on " .. shortOwner(ipath) .. " holds " ..
                            want .. " (resolved) — settled")
                    elseif before.defn == "<null>" or before.trees == 0 then
                        -- 1.8.14: the RE-DRIVE trigger is an UNRESOLVED definition, not a zero tree count. A part with no
                        -- leveled abilities at all (the Class and Weapon parts) legitimately has 0 trees for ever, and
                        -- keying on that re-drove them every pass — and because the setter replaces FragmentInstances on
                        -- every call, each re-drive read as DELIVERED and reset the retry counter, so the bound never bit.
                        -- That is the loop that ran 66 times and crashed. `partDefinition == <null>` is self-limiting:
                        -- it stops the moment the part resolves.
                        need = (pinAttempts[key] or 0) < PIN_MAX_RETRY
                        if not need and not pinGaveUp[key] then
                            pinGaveUp[key] = true
                            log("recruit pin: " .. shortTag(tag) .. " on " .. shortOwner(ipath) .. " already holds " .. want ..
                                " but its CustomizationPartDefinition never resolved after " .. PIN_MAX_RETRY ..
                            " attempt(s) — leaving it alone (" ..
                                sigOf(before) .. ")")
                        end
                    else
                        need = false
                    end
                    local isClass = (tag:find("%.Class$") ~= nil)
                    if need and not isClass and classBlock == "held" then
                        need = false                 -- 1.8.28: the Class is not settled and could not be driven this frame
                    elseif need and not isClass and classBlock == "pending" then
                        -- listed (legacyOwner drives the Class ALONE while it is undelivered - the 1.8.18b rule), and not
                        -- looked up: it is not written this frame
                        need = false
                        pending[ipath].list[#pending[ipath].list + 1] = { slot = s, tag = tag, cur = cur, want = want,
                            path = pin.part, key = key, before = before }
                    end
                    if need and blocked then
                        need = false                 -- 1.8.28: an earlier slot of this character waits for the budget
                    end
                    if need and isTalent and c.card and P.genBusy then
                        -- 1.8.31 (the talent gate): the card's own voice->Talent write is still to come; a pin now
                        -- would be overwritten by it (retail 2026-10-01). Held, not spent: nothing is looked up or written.
                        need = false
                        P.talentHeld = P.talentHeld + 1
                        CP.once("genhold|" .. key, "recruit pin: " .. shortTag(tag) .. " on " .. shortOwner(ipath) ..
                            " held — the game has not written this card's voice->Talent yet (RemainingCharactersToGenerate=" ..
                            tostring(P.genBusy) .. "); it is driven once that reads 0")
                    end
                    if need then
                        -- 1.8.28: RESIDENCY FIRST, from THIS frame's lookup, in the ORDER (so the lookup budget can never
                        -- let a later slot overtake an earlier one); the id is minted at the write (legacyOwner -> PS.mint)
                        -- from that same frame's object. A slot about to be TOGGLED writes the other id, not ours, so for
                        -- it a residency FACT from an earlier frame (a boolean, never an object) is enough - otherwise a
                        -- toggle, which needs ours resident AND the other part, could never fit one frame's budget.
                        local toggle = (cur == want) and not pinToggled[key]
                        local resident, busy = (toggle and PS.partRes[pin.part] == true), false
                        if isClass then classBlock = "held" end
                        if not resident and not P.absent[pin.part] then   -- (absent once this pass = absent this pass)
                            local partObj
                            partObj, busy = PS.get(pin.part)
                            resident = (partObj ~= nil)
                            if resident then partReport(pin.part, partObj)
                            elseif not busy then P.absent[pin.part] = true end
                        end
                        if busy then
                            P.again, P.deferred = true, P.deferred + 1   -- the frame's lookup budget: next drive frame
                            blocked = true
                        elseif resident and pinOk(ksl) then
                            local p = pending[ipath]
                            if not p then
                                p = { slot0 = s, rp = rp, scoped = how, list = {} }
                                pending[ipath] = p
                            end
                            p.list[#p.list + 1] = { slot = s, tag = tag, cur = cur, want = want, path = pin.part,
                                                    key = key, before = before }
                            if isClass then classBlock = "pending" end
                            -- a TOGGLE looks its other part up at the write: nothing after it may take that lookup first
                            -- (a toggle with no other part to look up - legacyOwner says so - blocks nothing)
                            if toggle then
                                local other = pinVanilla[key] or PIN_TOGGLE_DEFAULT[tag]
                                if other and other ~= want and PIN_TOGGLE_PATH[other] then blocked = true end
                            end
                        else
                            -- the resolver (UCustomizationStatics::GetCustomizationPartDefinitionFromPartId, RVA 0x8c46060) asks
                            -- the AssetManager for the LOADED object first, so residency is the whole variable: without it the
                            -- id is written and the definition stays null.
                            pcall(LoadAsset, pin.part)
                            waitingOnResidency = true
                            PS.skip(P, ipath .. "|" .. tag, "part " .. want .. " is not resident yet — requested the load, retrying")
                        end
                    end
                    end
                end
                end
            end
        end
    end
    -- 1.8.15: the ladder runs on its own clock. A part that will not resolve must keep climbing whether or not the
    -- pin managed to identify a character this pass — the 07:47 session stalled both specs at step 2 for a whole
    -- session because identification blinked and the ladder was only ever driven from inside a successful pin.
    -- 1.8.20: ... but a SETTLED part is off the list entirely. `(partStep[path] or 0) < 5` used to be true again the
    -- moment the drive path cleared partStep on a resolve, which is how the ladder re-climbed a delivered part.
    -- 1.8.28: PS.watchTick, AFTER this frame's writes (it must never spend the lookup a write needs); through the frame's
    -- lookup budget, so a part it cannot look at this frame is looked at on another.
    if next(pending) == nil then
        PS.watchTick(P)
        if P.again and P.drives < PS.DRIVE_MAX then return PS.again(P) end
        -- 1.8.33 THE HUB COST: a SWEEP of a populated world (characters with pinned slots), on a census that did not move,
        -- that found nothing ours and has no rebuild or residency wait in flight, is the world's verdict: DORMANT now.
        -- 1.8.28 kept sweeping for PS.SWEEP_PASSES (16) passes - retail session 2 (18:40-18:41): a 265-296 ms drive slice
        -- every ~8 s, "0 ours, 14 with pinned slot(s), 14 skipped".
        if P.sweep and P.nOurs == 0 and P.nWith > 0 and CP.stable and not staleBusy and not waitingOnResidency
           and P.talentHeld == 0 and not P.urgent then
            PS.swept = true
            PS.census(P, " (nothing ours; this world's sweeps are done)")
            return "none"
        end
        -- 1.8.31: a card's Talent is held by the talent gate: not `done` - look again in PS.GEN_STEP_S (bounded by
        -- PS.GEN_WAIT_S, after which the gate opens)
        if P.talentHeld > 0 then
            PS.census(P, string.format(" (%d Talent slot(s) wait for the game's voice->Talent write; looking again in %d s)",
                P.talentHeld, PS.GEN_STEP_S))
            return "gen"
        end
        -- 1.8.14: nothing to drive AND at least one real character was identified means every pinned slot is either
        -- delivered or has exhausted PIN_MAX_RETRY. There is nothing a 67th pass can do that the 66th did not, and the
        -- 05:43 session showed what endless passes cost: a stale userdata and a crash. Stop, and say so.
        -- 1.8.18: `done` is now a statement about DELIVERY, not about having nothing to do this pass.
        -- 1.8.27 (G1): `done` ends the EPISODE, not the session: the loop goes dormant and re-arms (CP.pinTick).
        local climbing = false
        for p2 in pairs(partWatch) do if (partStep[p2] or 0) > 0 and (partStep[p2] or 0) < 5 then climbing = true end end
        -- 1.8.18: delivery beats the ladder. Once every slot this pin wants has DELIVERED there is nothing left for a
        -- residency step to discover, so `done` is not held behind it.
        local allDelivered = next(pinExpected) ~= nil
        for k in pairs(pinExpected) do if not pinDelivered[k] then allDelivered = false end end
        -- 1.8.19: `done` MUST NOT mean "the parts had not finished loading yet". Found by replay scenario P, not in
        -- retail: with our parts still absent on pass 1 the pin has nothing pending, nothing is climbing the ladder
        -- (only a DRIVEN slot registers a part with it), and 1.8.18 would log `done — 0 slot(s) DELIVERED` and stop
        -- the loop for the whole session. LoadAsset is asynchronous (the oldest gotcha in this project), so a pass
        -- that is only waiting for a load is not a pass that has finished. The wait is BOUNDED - the 05:43 lesson is
        -- that an unbounded pin loop is what crashes the game - and when the budget runs out `done` fires anyway,
        -- with the honest count and a line saying which part it gave up waiting for.
        if waitingOnResidency and not allDelivered and pinWaited < PIN_RESIDENCY_PASSES then
            pinWaited = pinWaited + 1
            if not pinQuiet["waiting"] then
                pinQuiet["waiting"] = true
                log("recruit pin: holding `done` — a pinned part is not resident yet and LoadAsset is asynchronous; " ..
                    "waiting up to " .. PIN_RESIDENCY_PASSES .. " more pass(es) before giving a verdict")
            end
            PS.census(P); return (P.nWith > 0) and "targets" or "idle"
        end
        if waitingOnResidency and pinWaited >= PIN_RESIDENCY_PASSES and not pinQuiet["waitedout"] then
            pinQuiet["waitedout"] = true
            log("recruit pin: waited " .. PIN_RESIDENCY_PASSES .. " pass(es) and a pinned part is STILL not resident " ..
                "— the verdict below counts it as undelivered")
        end
        -- 1.8.22: `done` stops the loop for the session, so it must not fire with a stale-slot rebuild half done —
        -- the slot would be left on the toggle id. The wait is bounded by the rebuild's own PIN_MAX_RETRY /
        -- PIN_RESIDENCY_PASSES budgets, which is what keeps the 05:43 lesson (an unbounded pin loop) intact.
        if staleBusy and not pinDone and not pinQuiet["stalehold"] then
            pinQuiet["stalehold"] = true
            log("recruit pin: holding `done` — a stale-slot rebuild is mid-flight (the slot is on its toggle id " ..
                "until the next pass writes ours back)")
        end
        if P.nOurs > 0 and not pinDone and not staleBusy and (allDelivered or not climbing) then
            pinDone = true
            local settled, gaveup = 0, 0
            for k in pairs(pinDelivered) do settled = settled + 1 end
            for k in pairs(pinGaveUp) do gaveup = gaveup + 1 end
            log(string.format("recruit pin: done — %d character(s) ours, %d slot(s) DELIVERED, %d gave up after %d " ..
                "attempt(s); the pin loop is dormant (re-arms on a Recruitment refresh / recruit / world change, up to %d " ..
                "more time(s))", P.nOurs, settled, gaveup, PIN_MAX_RETRY, math.max(0, CP.PIN_REARM_MAX - CP.rearms)))
            staleSummary()
            CP.episodeDone(settled)
        end
        PS.census(P); return pinDone and "done" or ((P.nWith > 0) and "targets" or "idle")
    end
    for _, ipath in ipairs(order) do
      local p = pending[ipath]      -- 1.8.32 (d): the writes in the same order (the write's mint is a lookup too)
      if p then
        log("recruit pin: scoped to " .. shortOwner(ipath) .. " by " .. p.scoped .. "; " .. #p.list .. " slot(s) to drive")
        if not P.pinnedSet[ipath] then P.pinnedSet[ipath] = true; P.nPinned = P.nPinned + 1 end   -- characters, not frames
        -- 1.8.28 (fix 4): the child slots as they are BEFORE a Class write, so the next drive frame can tell the
        -- re-created ones from these
        local kids = {}
        for _, e in ipairs(p.list) do if not e.tag:find("%.Class$") then kids[e.tag] = true end end
        local c = instByPath[ipath]
        local before = {}
        -- 1.8.33: the Class's CHILDREN only (the Specializations subtree): the voice is not re-created by a Class write,
        -- and 1.8.28-1.8.32 counted it, so every Class delivery waited PS.CLASS_TRIES frames for a slot that never changes
        for tag, h in pairs(c and c.byTag or {}) do
            if tag:find("%.Specializations%.") then before[tag] = h.sname end
        end
        p.byTag = c and c.byTag                      -- 1.8.33: the read-back after a voice write (legacyOwner)
        applyOwner(ipath, p)
        if P.classDone[ipath] then
            P.classDone[ipath] = nil
            P.classAt[ipath] = { kids = before, tries = 0 }
            P.again, P.hold = true, PS.CLASS_HOLD
        end
        -- 1.8.13: a slot the equip AND the setter both left with a NULL CustomizationPartDefinition is not a marshalling
        -- failure — the Class part delivered through the same call in the same pass (retail 05:30:21). It is the resolver
        -- refusing THAT id, so the part's residency is escalated one observable step per pass.
        for _, e in ipairs(p.list) do
            partDriven[e.path] = pinPass
            local st = slotState(e.slot)
            if st.defn == "<null>" then
                escalateResidency(e.path, e.want, (st.id:match("^([^:]+)") or nil), pinPass)
            elseif partStep[e.path] then
                log("recruit pin: part " .. e.want .. " resolved after step " .. tostring(partStep[e.path]) ..
                    " of the residency ladder")
                partStep[e.path] = nil
                -- 1.8.20: SETTLED. Clearing partStep alone left the part on partWatch, where a step count of 0 reads
                -- as "not started" and the tick loop climbed it again next pass — the 23:00:38-23:00:58 alternation.
                partSettled[e.path] = true
                partWatch[e.path] = nil
            end
        end
        refresh[ipath] = p.slot0
      end
    end
    for ipath, s0 in pairs(refresh) do
        -- 1.8.28: the instance object is reached from its own slot, in this frame (no StaticFindObject)
        local inst = PS.instOf(s0, ipath)
        local ok, err = pcall(function() inst:RefreshCustomization() end)
        if not ok then log("recruit pin: RefreshCustomization failed on " .. ipath .. ": " .. tostring(err)) end
    end
    PS.watchTick(P)
    if P.again and P.drives < PS.DRIVE_MAX then return PS.again(P) end
    PS.census(P)
    return "pinned"
end

-- 1.8.15: the ladder runs on its own clock (see PS.act). 1.8.28: once per PASS (escalateResidency paces itself per pass
-- anyway), after the frame's writes, and only with lookup budget left - it never takes the lookup a write needs.
function PS.watchTick(P)
    if P.watched then return end
    for path, w in pairs(partWatch) do
        if not partSettled[path] and (partStep[path] or 0) < 5 then
            local o, busy = PS.get(path)
            if busy then return end
            if pinOk(o) then escalateResidency(path, w.want, w.ptype, pinPass) end
        end
    end
    P.watched = true
end

-- 1.8.28: the SAME pass drives again on a later frame (the children after a Class; a write the lookup budget deferred).
-- Only the characters identified as ours this frame are carried (by path); everything else is re-read by that frame.
function PS.again(P)
    local keep = {}
    for ipath, c in pairs(P.inst) do
        if (c.ident or pinKnown[ipath]) and not PS.retired[ipath] then keep[ipath] = c end   -- 1.8.32: not a retired card
    end
    P.inst = keep
    P.phase = "drive"
    P.againN = P.againN + 1
    return "more"
end

-- a pass's timing, printed with its census line (which prints on a change of shape and every 20th pass) and on any pass
-- whose largest slice passed PS.OVER_MS (capped). 1.8.28: and its object lookups (FindAllOf + StaticFindObject), which
-- are what a frame costs in this UE4SS build.
function PS.report(P, r)
    local over = P.max > PS.OVER_MS
    if over then PS.overLogged = PS.overLogged + 1 end
    if P.printed or (over and PS.overLogged <= PS.OVER_CAP) then
        log(string.format("recruit pin: pass %d timing: %d slice(s), %.1f ms total, max slice %.1f ms (%s), %d object " ..
            "lookup(s)%s -> %s", P.pass, P.slices, P.ms, P.max, P.maxAt, P.nLook,
            (P.drives > 1) and (", " .. P.drives .. " drive frame(s)") or "", tostring(r)))
    end
end

-- ONE CALL = ONE FRAME. Returns "more" while the pass is unfinished (the pin task then returns 0: again next frame), or
-- the pass's verdict. 1.8.28: every pass is frame-bounded (there is no "whole" first pass and no proof any more: nothing is
-- re-found by path), and an idle frame after a Class delivery (P.hold) touches nothing at all.
local function applyRecruitPins()
    if #recruitPins == 0 then return "idle" end
    local P = PS.P
    if P == nil then
        pinPass = pinPass + 1
        local hub, wname = strategySide()
        P = { pass = pinPass, nInst = 0, nOurs = 0, nWith = 0, nPinned = 0, pinnedSet = {}, nSkip = 0, skipped = {}, inst = {},
              hub = hub, wname = wname, world = wname, phase = "insts", slices = 0, ms = 0, max = 0, maxAt = "",
              nLook = 0, lookups = 0, drives = 0, looks = 0, lookq = {}, lookSet = {}, lookAt = 0, hold = 0,
              deferred = 0, againN = 0, reverts = 0, classDone = {}, classAt = {}, ghostWait = {}, fcache = {}, absent = {}, lookVerified = {},
              verify = PS.verifyNext, genBusy = nil, talentHeld = 0 }
        PS.verifyNext = false
        PS.P = P
    end
    if P.hold > 0 then P.hold = P.hold - 1; return "more" end
    local t0 = PS.clock()
    P.lookups, P.fcache, P.again = 0, {}, false
    local at = P.phase
    local r
    if at == "insts" then
        r = PS.begin(P)
        if r == nil then r = "more" end           -- the instance FindAllOf: its own frame
    elseif at == "drive" then
        r = PS.drive(P)
    elseif at == "look" then
        r = PS.look(P)
    else
        r = "idle"
    end
    local ms = (PS.clock() - t0) * 1000
    P.slices, P.ms = P.slices + 1, P.ms + ms
    if ms > P.max or P.maxAt == "" then P.max, P.maxAt = ms, at end
    P.fcache = {}                                 -- nothing of this frame's survives it
    if r ~= "more" then
        PS.P = nil
        PS.report(P, r)
        -- 1.8.28 (fix 3): T-G1's number, once per event: the first pass that DROVE a card after it
        local u = P.urgent or CP.epUrgent
        if u and P.nPinned > 0 and not u.logged then
            u.logged = true
            log(("recruit pin: %s -> %d character(s) driven %.1f s after the event (pass %d)"):format(u.why, P.nPinned,
                PS.clock() - u.t, P.pass))
        end
        if P.urgent and r ~= "urgent" then PS.urgent = nil; CP.epUrgent = CP.epUrgent or P.urgent end
        if P.reverts > 0 then pinDone = false; CP.pinDormant = false end   -- the verify pass re-opened the episode
    end
    return r
end

-- ---- 1.8.27: THE CLASS-MOD RUNTIME (ZCClassMods\_Shared\SDK_CHANGE_REQUEST.md §1b, §2d, §3 G1, §5.1 H1, §5.6) ----
-- THE DATA CONTRACT - ALIGNED WITH THE BUILD LANE (zcmod-build.js; docs/NETNEW_CLASS.md "The loader contract"). This block
-- is the ONLY reader of the 1.8.27 manifest keys in <Mod>.zcsdk.lua; if a spelling changes there, it changes HERE only:
--   recruitPins[].slots[] = { tag =, part = }                                 -- the short form, unchanged since 1.4.0
--                         | { tag =, part =, requires = "<id>"?, fallback = "<obj path>"?,
--                             accept = { "<obj path>", … }?, acceptTags = { "<tag>", … }?, acceptOn = "roster" | "any"?,
--                             escape = "<obj path>"? }
--     part / fallback / accept[] / escape are OBJECT paths, compared by their leaf (the short id) as `part` always was.
--     `part` is implicitly accepted and never repeated in `accept`; `acceptOn` is written whenever an accept-set exists.
--     `fallback` appears only with `requires`: delivered INSTEAD of `part` when the dependency is missing or too old; with no
--     `fallback` such a slot is dropped. On a missing dependency its `tags` are dropped from `acceptTags` too.
--     `escape` = the D6 fallbackSpec (Tactical.Primary) / §5.6.4 fallbackWeapon (Weapon): ACCEPTED on a roster character
--     only - never on a card, whatever `acceptOn` says - and NEVER delivered.
--   requires = { { id =, minVersion = ?, optional = <bool>, packages = { "<package path>" }, tags = { … },
--                  names = { <sorted leaf names> } } }                        -- names = the dead-id snapshot (name-based)
--   classPool = { schema = "zcsdk-classpool/1", table = "<obj path>", weighted = <bool>, exclusive = <bool>,
--                 settingsIni = <bool>, rows = { { row =, guid = "<32 upper hex>", cd = "<obj path>", recruitable = <bool>,
--                 weight = <0..1> } } }                                       -- recruitable = false always carries weight = 0
--     weighted = false = no weight anywhere: nothing is written - unless the PLAYER's settings.ini sets one (D2: it wins).
--   settings.ini (the player's copy; only settings.default.ini ships): gfp Mods/<Mod>/settings.ini, paks
--   Content/Paks/<Mod>.settings.ini; CRLF; ';' comments; [ClassPool] Weight= and <row>= lines; precedence row > Weight >
--   the manifest.
CP.GEARKIT = "br.Customization.Slot.Character.Specializations.Weapon.GearKit"
CP.PIN_REARM_MAX = 20        -- §3.1.4: re-arms per session, then the loop stops as 1.8.26 did
CP.REARM_GAP = 5             -- §3.1.2: at most one re-arm per 5 s
CP.MAX_ROLLS = 200           -- §1b.3: class-pool rolls per session
CP.RECRUIT_HOOK = true       -- §1b.2 kill switch: false = the census trigger only
CP.HUB_SETTLE_S = 10         -- §1b.2 (c): seconds the hub must have been up before a RegisterHook
CP.NAME_TAG_FALLBACK = true  -- §5.6: when no route can read a GearKit part's tags, match the pack's spec NAME instead
CP.rearms, CP.rolls, CP.pinDormant = 0, 0, false
CP.evt = { refresh = 0, recruit = 0, census = 0, fired = false, why = "" }
CP.pinSeen = { refresh = 0, recruit = 0, census = 0 }
CP.poolSeen, CP.poolSeenR, CP.seenLog = 0, 0, { refresh = 0, recruit = 0, lines = 0 }
CP.deps, CP.tagDep, CP.deadName = {}, {}, {}
CP.pool, CP.byGuid, CP.poolLive = {}, {}, false
CP.tagsOf, CP.tagCalls, CP.tagRoute = {}, 0, nil
CP.reqFinal, CP.reqDeadline = true, nil
CP.logged = {}
local recruitHookArmed = false   -- §1b.2: RegisterHook is NOT retry-safe (1.8.2): set BEFORE the first call, never cleared
-- the pin task's state (1.8.26 kept these beside the task; 1.8.27 moves them here, above every function that reads them)
local pinIdle, pinSkip, pinWorld = 0, 0, ""
local pinStop = false   -- 1.8.27: set only by the re-arm cap (1.8.14-1.8.26: by `done`)
-- 1.8.11: the pass runs under xpcall so a raise lands in the LOADER'S OWN log with a traceback instead of only in
-- UE4SS.log — which is the file nobody reads (v1.28.32). 1.8.26: the handler is hoisted (no closure per pass).
local function pinTraceback(e)
    return tostring(e) .. " | " .. tostring(debug and debug.traceback and debug.traceback("", 2) or "<no traceback>")
end


function CP.once(k, line) if CP.logged[k] then return end; CP.logged[k] = true; log(line) end
function CP.leaf(p) return (type(p) == "string") and p:match("([^/.]+)$") or nil end

-- semver-ish: every run of digits, compared left to right; a missing part is 0. nil minimum = anything passes.
function CP.verGE(a, b)
    if b == nil then return true end
    local function parts(v) local t = {}; for n in tostring(v or ""):gmatch("%d+") do t[#t + 1] = tonumber(n) end; return t end
    local x, y = parts(a), parts(b)
    for i = 1, math.max(#x, #y) do
        local p, q = x[i] or 0, y[i] or 0
        if p ~= q then return p > q end
    end
    return true
end

-- ---- §2d.1: requires[] ----
-- 2026-10-10: the id "ZCSDKLoader" is THIS loader (a mod that needs a loader FEATURE: the saber blade applier writes
-- `{ id = "ZCSDKLoader", minVersion = …, features = { "saberlook" } }`). It never has a manifest, so it is answered here:
-- `present` when this loader has every listed feature (CP.FEATURES), else `old`; with no features, by the version alone.
-- A loader older than this code knows no such id and logs it NOT FOUND - which is the right message for it, too.
CP.SELF_ID = "ZCSDKLoader"
CP.FEATURES = { saberlook = true, saberheadings = true, slotfix = true, saberrows = true, dualhex = true }   -- saberheadings: the MODS-page headings (2026-10-11)
function CP.selfState(d)
    d.ver = tostring(CP.SELF_VERSION or "?")
    local missing = {}
    for _, f in ipairs(d.features or {}) do if not CP.FEATURES[f] then missing[#missing + 1] = f end end
    if #(d.features or {}) > 0 then
        d.via = "this loader" .. (#missing > 0 and (", WITHOUT " .. table.concat(missing, ", ")) or (" (" .. table.concat(d.features, ", ") .. ")"))
        -- probe 2 (P2-4): a source / test loader can carry the feature before the release that minVersion names. The
        -- feature decides; the line says plainly that the VERSION did not match, so nobody reads it as a version pass.
        d.featureOnly = false
        if d.minVersion and not CP.verGE(CP.SELF_VERSION, d.minVersion) then
            d.featureOnly = (#missing == 0)
            d.via = d.via .. (#missing == 0 and " - passes on the FEATURE only" or "") .. ": v" .. d.ver ..
                " is OLDER than minVersion " .. d.minVersion .. (#missing == 0
                and " (a pre-release / test loader that already has the feature; install the loader release >= " .. d.minVersion .. " to match)"
                or " (install the loader release >= " .. d.minVersion .. ")")
        end
        return (#missing == 0) and "present" or "old"
    end
    d.via = "this loader"
    return CP.verGE(CP.SELF_VERSION, d.minVersion) and "present" or "old"
end
function CP.readRequires()
    CP.deps, CP.tagDep = {}, {}
    for _, mf in ipairs(manifests) do
        local m = mf.m
        for _, r in ipairs(type(m.requires) == "table" and m.requires or {}) do
            if type(r) == "table" and type(r.id) == "string" and r.id ~= "" then
                local d = CP.deps[r.id]
                if not d then
                    d = { id = r.id, packages = {}, tags = {}, names = {}, ns = {}, needers = {}, needSet = {}, optional = true }
                    CP.deps[r.id] = d
                end
                if type(r.minVersion) == "string" and (d.minVersion == nil or CP.verGE(r.minVersion, d.minVersion)) then
                    d.minVersion = r.minVersion
                end
                if r.optional == false then d.optional = false end
                local who = tostring(m.name)
                if not d.needSet[who] then d.needSet[who] = true; d.needers[#d.needers + 1] = who end
                for _, p in ipairs(type(r.packages) == "table" and r.packages or {}) do
                    if type(p) == "string" then
                        d.packages[#d.packages + 1] = p
                        local ns = p:match("^(/Game/[^/]+/)")
                        if ns then d.ns[ns] = true end
                    end
                end
                for _, t in ipairs(type(r.tags) == "table" and r.tags or {}) do
                    if type(t) == "string" then d.tags[#d.tags + 1] = t; CP.tagDep[t] = r.id end
                end
                for _, n in ipairs(type(r.names) == "table" and r.names or {}) do
                    if type(n) == "string" then d.names[#d.names + 1] = n end
                end
                d.features = d.features or {}
                for _, f in ipairs(type(r.features) == "table" and r.features or {}) do
                    if type(f) == "string" then d.features[#d.features + 1] = f end
                end
            end
        end
    end
    for id, d in pairs(CP.deps) do
        d.state = "missing"
        if id == CP.SELF_ID then d.state = CP.selfState(d) end
        for _, mf in ipairs((id == CP.SELF_ID) and {} or manifests) do
            if tostring(mf.m.name) == id then
                d.ver = tostring(mf.m.version)
                d.state = CP.verGE(mf.m.version, d.minVersion) and "present" or "old"
            end
        end
        -- no manifest: the LAST RESORT is the path of the first package it ships (a dependency with no manifest).
        -- The TAG route (§2d.1, GetCustomizationPartIds) is NOT used: it takes a Lua-built FGameplayTagContainer as
        -- INPUT, and every Lua-built container this runtime ever passed reached the native EMPTY (1.8.10).
        if d.state == "missing" and #d.packages > 0 then d.state = "probe" end
    end
end

function CP.objPath(pkg)
    if pkg:find(".", 1, true) then return pkg end
    return pkg .. "." .. (pkg:match("([^/]+)$") or pkg)
end

-- stage 1 (after the primary-asset rescan): request the load; stage 2 (after the cache refresh): look, then decide.
function CP.probeRequires(stage)
    if CP.reqFinal then return end
    for _, d in pairs(CP.deps) do
        if d.state == "probe" then
            local op = CP.objPath(d.packages[1])
            if stage == 1 then
                pcall(LoadAsset, op)
            else
                local o = nil
                pcall(function() o = StaticFindObject(op) end)
                if pinOk(o) then d.state, d.via = "present", op else d.state = "missing" end
            end
        end
    end
    if stage ~= 1 then CP.finalizeRequires() end
end

function CP.fallbacksOf(mod, depId)
    local out, seen, uses = {}, {}, 0
    for _, mf in ipairs(manifests) do
        if tostring(mf.m.name) == mod then
            for _, rp in ipairs(type(mf.m.recruitPins) == "table" and mf.m.recruitPins or {}) do
                for _, s in ipairs(type(rp.slots) == "table" and rp.slots or {}) do
                    if type(s) == "table" and s.requires == depId then uses = uses + 1 end
                    local n = (type(s) == "table" and s.requires == depId) and CP.leaf(s.fallback) or nil
                    if n and not seen[n] then seen[n] = true; out[#out + 1] = n end
                end
            end
        end
    end
    return out, uses
end

-- exactly one line per (needing mod, dependency)
function CP.logRequires()
    local ids = {}
    for id in pairs(CP.deps) do ids[#ids + 1] = id end
    table.sort(ids)
    for _, id in ipairs(ids) do
        local d = CP.deps[id]
        local need = d.minVersion and (" >= " .. d.minVersion) or ""
        for _, mod in ipairs(d.needers) do
            if d.state == "present" then
                log("requires: " .. mod .. " needs " .. id .. need .. " — found " ..
                    ((id == CP.SELF_ID) and ("v" .. tostring(d.ver) .. ", " .. tostring(d.via))
                     or d.ver and ("v" .. d.ver) or ("by its package " .. tostring(d.via) .. " (no manifest)")))
            else
                local fbs, uses = CP.fallbacksOf(mod, id)
                local what = (d.state == "old") and ("found v" .. tostring(d.ver) .. ", TOO OLD"
                    .. ((id == CP.SELF_ID) and (" - " .. tostring(d.via)) or "")) or "NOT FOUND"
                log("WARN: " .. mod .. " needs " .. id .. need .. " — " .. what .. "; " .. ((uses == 0)
                    and "no recruit pin of it depends on that mod"
                    or ("its pins into that mod " .. ((#fbs > 0) and ("use the fallback (" .. table.concat(fbs, ", ") .. ")")
                        or "are skipped"))))
            end
        end
    end
end

function CP.finalizeRequires(why)
    if CP.reqFinal then return end
    for _, d in pairs(CP.deps) do if d.state == "probe" then d.state = "missing" end end
    CP.reqFinal, CP.reqDeadline = true, nil
    if why then log("requires: the dependency probe did not finish (" .. why .. ") — an undecided dependency counts as missing") end
    CP.buildPins(true)
    CP.logRequires()
end

-- the dead-id set of ONE missing dependency, as seen from one slot: its name snapshot, its packages' leaves and the
-- pinned part itself. Registered in CP.deadName (id -> { dep, mod, fb = { [tag] = a fallback is delivered there } }).
function CP.markDead(d, depId, part, tag, hasFb, mod)
    local set = {}
    local function put(n)
        if not n then return end
        set[n] = true
        local x = CP.deadName[n]
        if not x then x = { dep = depId, mod = mod, fb = {} }; CP.deadName[n] = x end
        if hasFb then x.fb[tag] = true end
    end
    put(CP.leaf(part))
    if d then
        for _, n in ipairs(d.names) do put(CP.leaf(n)) end
        for _, p in ipairs(d.packages) do put(CP.leaf(p)) end
    end
    return set
end

-- is `p` (an id or a path) a part of a dependency that is not present? (by the dependency's package namespace)
function CP.isDeadPath(p)
    if type(p) ~= "string" then return false end
    local ns = p:match("^(/Game/[^/]+/)")
    if not ns then return false end
    for _, d in pairs(CP.deps) do if d.state ~= "present" and d.ns[ns] then return true end end
    return false
end

-- ONE manifest slot -> the pin's slot entry. Returns (entry, notes) or (nil, notes) when a missing dependency drops it.
function CP.slotOf(s, m)
    if type(s) ~= "table" or type(s.tag) ~= "string" or type(s.part) ~= "string" then return nil, nil end
    local mod = tostring(m.name)
    local e = { tag = s.tag, part = s.part }
    if s.evidence == false then e.evidence = false end   -- classes v2 #3: never identity evidence (PS.evidence)
    local notes = {}
    local depId = (type(s.requires) == "string" and s.requires ~= "") and s.requires or nil
    local fb = (type(s.fallback) == "string" and s.fallback ~= "") and s.fallback or nil
    if depId then
        local d = CP.deps[depId]
        e.dep = depId
        if not (d and d.state == "present") then
            e.depMissing = true
            e.dead = CP.markDead(d, depId, s.part, s.tag, fb ~= nil, mod)
            local st = d and ((d.state == "old") and "too old" or "missing") or "not declared in requires[]"
            if not fb then
                return nil, { shortTag(s.tag) .. ": dropped — " .. tostring(CP.leaf(s.part)) .. " needs " .. depId ..
                    " (" .. st .. ") and the slot declares no fallback" }
            end
            e.part, e.subst = fb, true
            notes[#notes + 1] = shortTag(s.tag) .. ": " .. tostring(CP.leaf(s.part)) .. " needs " .. depId .. " (" .. st ..
                ") — pinning the fallback " .. tostring(CP.leaf(fb))
        end
    elseif fb then
        notes[#notes + 1] = shortTag(s.tag) .. ": `fallback` without `requires` ignored (the contract pairs them)"
    end
    local nAcc, nTag, nDrop = 0, 0, 0
    if type(s.accept) == "table" then
        e.accept = {}
        for _, a in ipairs(s.accept) do
            local n = CP.leaf(a)
            if n and not (e.dead and e.dead[n]) and not CP.isDeadPath(a) then e.accept[n] = true; nAcc = nAcc + 1
            elseif n then nDrop = nDrop + 1 end
        end
    elseif type(s.accept) == "string" then
        notes[#notes + 1] = shortTag(s.tag) .. ": accept = \"" .. s.accept .. "\" was not expanded by the build — ignored"
    end
    if type(s.acceptTags) == "table" then
        e.acceptTags, e.acceptTagSet = {}, {}
        for _, t in ipairs(s.acceptTags) do
            if type(t) == "string" then
                local owner = CP.tagDep[t]
                local od = owner and CP.deps[owner]
                if owner and not (od and od.state == "present") then
                    nDrop = nDrop + 1                        -- §5.6.4: a missing dependency's classes are not a choice
                else
                    e.acceptTags[#e.acceptTags + 1] = t; e.acceptTagSet[t] = true; nTag = nTag + 1
                end
            end
        end
    end
    e.acceptOn = (s.acceptOn == "roster") and "roster" or "any"
    -- `escape`: the uninstall escape (D6 / §5.6.4), accepted on a ROSTER character only and never delivered
    local esc = CP.leaf(s.escape)
    if esc then e.rosterIds = { [esc] = "escape" } end
    if e.accept or e.acceptTags or e.rosterIds then
        local r = {}
        for n in pairs(e.rosterIds or {}) do r[#r + 1] = n end
        table.sort(r)
        notes[#notes + 1] = string.format("%s: accept-set %d id(s), %d tag(s)%s, on %s%s", shortTag(s.tag), nAcc, nTag,
            (nDrop > 0) and (" (" .. nDrop .. " dropped: their dependency is missing)") or "", e.acceptOn,
            (#r > 0) and ("; roster-only " .. table.concat(r, ", ")) or "")
    end
    return e, notes
end

-- the recruit pins, from every manifest. Re-run (quietly) once the dependency probe has decided.
function CP.buildPins(quiet)
    for i = #recruitPins, 1, -1 do recruitPins[i] = nil end
    pinKnownParts = nil          -- pinManifestParts() re-derives it from what is built here
    CP.deadName = {}
    for _, mf in ipairs(manifests) do
        local m = mf.m
        for _, rp in ipairs(type(m.recruitPins) == "table" and m.recruitPins or {}) do   -- 1.4.0; 1.5.0 adds `match`
            local match = (type(rp.match) == "table" and type(rp.match.slot) == "string" and type(rp.match.part) == "string")
                and { slot = rp.match.slot, part = rp.match.part } or nil
            if (type(rp.definition) == "string" or match) and type(rp.slots) == "table" then
                local slots, ghostTags, notes = {}, {}, {}
                for _, s in ipairs(rp.slots) do
                    local e, ns = CP.slotOf(s, m)
                    if e then slots[#slots + 1] = e elseif ns and type(s) == "table" then ghostTags[s.tag] = true end
                    for _, n in ipairs(ns or {}) do notes[#notes + 1] = n end
                end
                -- 1.8.32: the mod's OWN namespaces (identity evidence, PS.evidence): its primaryTypes roots and its gfp mount
                local ownNs = { "/" .. tostring(m.name) .. "/" }
                for _, pt in ipairs(type(m.primaryTypes) == "table" and m.primaryTypes or {}) do
                    local n = type(pt) == "table" and PS.nsOf(tostring(pt.path or "") .. "/") or nil
                    if n then ownNs[#ownNs + 1] = n end
                end
                recruitPins[#recruitPins + 1] = { definition = rp.definition, match = match, slots = slots,
                                                  ghostTags = ghostTags, from = tostring(m.name), ownNs = ownNs }
                if not quiet then
                    log("recruit pins: " .. (rp.definition and rp.definition:match("([^/]+)$") or "-") .. (match and (" | " .. match.slot:match("([^.]+)$") .. "=" .. match.part:match("([^/.]+)$")) or "") .. " -> " .. #slots .. " slot(s) (" .. tostring(m.name) .. ")")
                    for _, n in ipairs(notes) do log("recruit pins:   " .. n) end
                end
            end
        end
    end
end

-- a manifest that registers a pool table into DR_InitialCharacterPool but carries no `classPool` ships the pre-1.8.27
-- EXCLUSIVE source (POOL design B1 replaces it): whichever such mod mounts last hides the other class mods' recruits.
function CP.legacyWarn()
    for _, mf in ipairs(manifests) do
        local m = mf.m
        if m.classPool == nil then
            for _, r in ipairs(type(m.refreshers) == "table" and m.refreshers or {}) do
                if type(r) == "table" and r.name == "DR_InitialCharacterPool" and type(r.assets) == "table" and #r.assets > 0 then
                    log("WARN: " .. tostring(m.name) .. " v" .. tostring(m.version) .. " uses an exclusive recruit-pool " ..
                        "source (pre-classPool build); other class mods' recruits may be missing — rebuild or uninstall it" ..
                        ((m.name == "ZCSDK_Sith") and " (ZCSDK_Sith is retired: uninstall it, ZCSithClass replaces it)" or ""))
                    break
                end
            end
        end
    end
end

-- ---- §1b.4: settings.ini ----
-- -> { [section] = { { k =, v = }, … } } in file order, or nil when there is no file. ';' (and '#') start a comment.
function CP.readIni(path)
    local f = io.open(path, "r")
    if not f then return nil end
    local text = f:read(262144) or ""   -- 1.8.54 (L-3): at most 256 KB
    f:close()
    local t, sec = {}, ""
    for raw in (text .. "\n"):gmatch("([^\n]*)\n") do
        local line = raw:gsub("^\239\187\191", ""):gsub("[\r\n]+$", ""):gsub("%s*[;#].*$", "")
        line = line:match("^%s*(.-)%s*$") or ""
        if line ~= "" then
            local s = line:match("^%[%s*(.-)%s*%]$")
            if s then
                sec = s; t[sec] = t[sec] or {}
            else
                local k, v = line:match("^([^=]-)%s*=%s*(.*)$")
                if k and k ~= "" then t[sec] = t[sec] or {}; t[sec][#t[sec] + 1] = { k = k, v = v } end
            end
        end
    end
    return t
end

function CP.iniNum(v)
    local n = tonumber(v)
    if n and n >= 0 and n <= 1 then return n end
    return nil
end

function CP.fmtW(w) return (string.format("%.2f", w):gsub("0+$", ""):gsub("%.$", "")) end

-- the PLAYER'S settings.ini wins (D2): a row line, then the ini `Weight`, then the manifest's row weight.
function CP.applyIni(entry, ini, path)
    if not ini then
        log(("class pool: %s no settings.ini (manifest values)"):format(entry.mod))
        return
    end
    local sec = ini.ClassPool or {}
    local rowBy = {}
    for _, row in ipairs(entry.rows) do rowBy[row.row] = row end
    local W = nil
    for _, kv in ipairs(sec) do
        if kv.k:lower() == "weight" then
            local n = CP.iniNum(kv.v)
            if n then W = n else log("settings.ini: " .. kv.k .. "=" .. kv.v .. " ignored (0..1)") end
        elseif not rowBy[kv.k] then
            CP.once("ini|" .. path .. "|" .. kv.k, "settings.ini: unknown key " .. kv.k .. " ignored (" .. entry.mod .. ")")
        end
    end
    if W then for _, row in ipairs(entry.rows) do row.weight = W end end
    for _, kv in ipairs(sec) do
        local row = rowBy[kv.k]
        if row then
            local n = CP.iniNum(kv.v)
            if n then row.weight = n else log("settings.ini: " .. kv.k .. "=" .. kv.v .. " ignored (0..1)") end
        end
    end
    local ws = {}
    for _, row in ipairs(entry.rows) do ws[#ws + 1] = CP.fmtW(row.weight) end
    log(("class pool: %s settings.ini read (%d row(s), weights %s)"):format(entry.mod, #entry.rows, table.concat(ws, "/")))
end

function CP.readClassPool()
    CP.pool, CP.byGuid, CP.poolLive = {}, {}, false
    for _, mf in ipairs(manifests) do
        local m = mf.m
        local cpool = m.classPool
        if type(cpool) == "table" and type(cpool.rows) == "table" then
            local mod = tostring(m.name)
            local entry = { mod = mod, rows = {} }
            for _, r in ipairs(cpool.rows) do
                if type(r) == "table" and type(r.row) == "string" and type(r.guid) == "string" then
                    local g = r.guid:upper():gsub("[^0-9A-F]", "")
                    if #g == 32 then
                        local w = (r.recruitable == false) and 0 or (tonumber(r.weight) or 1)
                        if w < 0 then w = 0 elseif w > 1 then w = 1 end
                        local row = { mod = mod, row = r.row, guid = g, weight = w, cooked = (r.recruitable ~= false) }
                        entry.rows[#entry.rows + 1] = row
                        CP.byGuid[g] = row
                    else
                        log("class pool: " .. mod .. " row " .. r.row .. " has no usable GUID (" .. r.guid .. ") — skipped")
                    end
                end
            end
            local base = (tostring(mf.path or ""):match("([^/\\]+)%.zcsdk%.lua$")) or mod
            local ini = mf.gfp and (mf.dir .. "/settings.ini") or (mf.dir .. "/" .. base .. ".settings.ini")
            local iniT = CP.readIni(ini)
            CP.applyIni(entry, iniT, ini)
            -- LIVE = the loader has something to do for this mod: a row below 1, or a row the build cooked inactive
            -- that the player's ini re-enables (D2). With neither, nothing is ever written - and a manifest that says
            -- `weighted = false` with no player settings.ini is never live (the build's own statement).
            for _, row in ipairs(entry.rows) do
                if row.weight < 1 or (row.weight > 0 and not row.cooked) then entry.live = true end
            end
            if cpool.weighted == false and not iniT then entry.live = false end
            if entry.live then CP.poolLive = true end
            CP.pool[#CP.pool + 1] = entry
        end
    end
end

-- ---- §1b.1: the roll and the write ----
function CP.rollActive(w, rnd)
    if w >= 1 then return true end
    if w <= 0 then return false end
    return (rnd or math.random)() < w
end

-- an FGuid (a TMap key) -> "8X8X8X8X" (FGuid::ToString's Digits form, what the manifest carries)
function CP.guidHex(k)
    local g = k
    pcall(function() g = k:get() end)
    local parts = {}
    local ok = pcall(function()
        for _, f in ipairs({ "A", "B", "C", "D" }) do parts[#parts + 1] = math.tointeger(g[f]) end
    end)
    if not ok or #parts ~= 4 then return nil end
    for i = 1, 4 do
        if parts[i] == nil then return nil end
        parts[i] = parts[i] % 4294967296
    end
    return string.format("%08X%08X%08X%08X", parts[1], parts[2], parts[3], parts[4])
end

function CP.poolMgr()
    if CP.mgrPath then
        local o = nil
        pcall(function() o = StaticFindObject(CP.mgrPath) end)
        if pinOk(o) then return o end
    end
    local o = findLive("BitReactorCharacterPoolManager")
    if pinOk(o) then
        local n = nil
        pcall(function() n = o:GetFullName() end)
        if type(n) == "string" then CP.mgrPath = (n:gsub("^[^ ]+ ", "")) end
        return o
    end
    return nil
end

-- every character of every pool named InitialCharacterPool whose GUID a manifest lists: fn(guidHex, the value struct).
-- Only rows a manifest lists are ever handed out, so nothing else in the pool can be written (§1b.1.5).
function CP.poolEach(mgr, fn)
    return pcall(function()
        mgr.CharacterPools:ForEach(function(_, e)
            local p = e
            pcall(function() p = e:get() end)
            local nm = ""
            pcall(function() nm = p.CharacterPoolName:ToString() end)
            if nm == "InitialCharacterPool" then
                p.Characters:ForEach(function(k, v)
                    local g = CP.guidHex(k)
                    if g and CP.byGuid[g] then
                        local pc = v
                        pcall(function() pc = v:get() end)
                        fn(g, pc)
                    end
                end)
            end
        end)
    end)
end

function CP.poolRead(mgr)
    local cur = {}
    local ok, err = CP.poolEach(mgr, function(g, pc)
        local a = nil
        pcall(function() a = pc.bIsActive end)
        if type(a) == "boolean" then cur[g] = a end
    end)
    if not ok then CP.once("poolreaderr", "class pool: reading the live pool failed: " .. tostring(err)) end
    return cur
end

-- the write, and the proof: a SECOND walk of the map reads each value back. UE4SS's TMap value writes are unverified
-- (§1b), so a write that does not read back switches to the bridge verb `ZCSDK:poolactive` (NOT in bridge 0.5.3 - it
-- logs "unknown command" there - so until a bridge carries it the weight is reported as NOT applied, never assumed).
function CP.poolWrite(mgr, wrote, before)
    local addr = nil
    pcall(function() addr = mgr:GetAddress() end)
    if CP.writeRoute ~= "bridge" then
        CP.poolEach(mgr, function(g, pc) if wrote[g] ~= nil then pcall(function() pc.bIsActive = wrote[g] end) end end)
        local after = CP.poolRead(mgr)
        local bad = {}
        for g, a in pairs(wrote) do
            if after[g] == a then
                log(("class pool: poolactive %s %d->%d (%s; Lua, read back)"):format(g, before[g] and 1 or 0, a and 1 or 0,
                    CP.byGuid[g].row))
            else
                bad[g] = a
            end
        end
        if next(bad) == nil then CP.writeRoute = "lua"; return end
        CP.once("poolluafail", "class pool: the Lua write did not reach the pool (it read back unchanged) — using the " ..
            "bridge verb ZCSDK:poolactive from now on (bridge 0.5.3 does not implement it: until a bridge does, the " ..
            "weight is NOT applied)")
        CP.writeRoute = "bridge"
        wrote = bad
    end
    for g, a in pairs(wrote) do
        if addr then bridge(("ZCSDK:poolactive|%x|InitialCharacterPool|%s|%d"):format(addr, g, a and 1 or 0)) end
    end
    local after = CP.poolRead(mgr)
    for g, a in pairs(wrote) do
        if after[g] == a then
            log(("class pool: poolactive %s %d->%d (%s; bridge, read back)"):format(g, before[g] and 1 or 0, a and 1 or 0,
                CP.byGuid[g].row))
        else
            CP.once("poolna|" .. g, ("class pool: poolactive %s NOT applied (%s; the bridge did not change it)"):format(g,
                CP.byGuid[g].row))
        end
    end
end

-- ONE ROLL: decide every row first (roll-ahead: the roll made after refresh k governs refresh k+1), then read, then write
-- only what differs. A weight-0 row is written false ONCE and never rolled again; a weight-1 row that is already active
-- is never written.
function CP.poolRoll(reason, rnd)
    if not CP.poolLive then return end
    if CP.rolls >= CP.MAX_ROLLS then
        CP.once("rollcap", ("class pool: roll cap (%d) reached — the last state stays for this session"):format(CP.MAX_ROLLS))
        return
    end
    local mgr = CP.poolMgr()
    if not mgr then
        CP.once("nomgr", "class pool: no live BitReactorCharacterPoolManager — roll not applied (" .. tostring(reason) .. ")")
        return
    end
    CP.rolls = CP.rolls + 1
    local want = {}
    for _, e in ipairs(CP.pool) do
        if e.live then
            for _, row in ipairs(e.rows) do
                if not (row.weight <= 0 and row.zeroed) then want[row.guid] = CP.rollActive(row.weight, rnd) end
            end
        end
    end
    local cur = CP.poolRead(mgr)
    local wrote = {}
    for g, a in pairs(want) do
        local row = CP.byGuid[g]
        if cur[g] == nil then
            CP.once("noguid|" .. g, "WARN: class pool: " .. row.mod .. " row " .. row.row .. " (" .. g .. ") is not in " ..
                "the live InitialCharacterPool — skipped")
        else
            if row.weight <= 0 then row.zeroed = true end
            if cur[g] ~= a then wrote[g] = a end
        end
    end
    if next(wrote) then CP.poolWrite(mgr, wrote, cur) end
    for _, e in ipairs(CP.pool) do
        if e.live then
            local elig, ws, same = 0, {}, true
            for i, row in ipairs(e.rows) do
                local a = want[row.guid]
                if a == nil then a = cur[row.guid] end
                if a then elig = elig + 1 end
                ws[#ws + 1] = CP.fmtW(row.weight)
                if i > 1 and row.weight ~= e.rows[1].weight then same = false end
            end
            log(("class pool: %s %d/%d row(s) eligible (w=%s) [roll %d] (%s)"):format(e.mod, elig, #e.rows,
                same and (ws[1] or "?") or table.concat(ws, "/"), CP.rolls, tostring(reason)))
        end
    end
end

-- §1a loader census: a pool table the DataRegistry refused (`dtreg … = 0` in the bridge's own log) means another mod's
-- DR_InitialCharacterPool override is winning. Pool-table leaves only (the classPool naming, and the two legacy names).
function CP.dtregCensus()
    local want = {}
    for _, mf in ipairs(manifests) do
        for _, r in ipairs(type(mf.m.refreshers) == "table" and mf.m.refreshers or {}) do
            if type(r) == "table" and r.name == "DR_InitialCharacterPool" then
                for _, a in ipairs(type(r.assets) == "table" and r.assets or {}) do
                    local lf = CP.leaf(a)
                    if lf and (lf:find("_ZCSDKClassPool", 1, true) or lf:find("ZCSDK_Sith_Pool", 1, true)
                               or lf:find("ZCSDK_InitialCharacterPool", 1, true)) then want[a] = lf end
                end
            end
        end
    end
    if next(want) == nil then return end
    local f = io.open(UE4SS .. "ZCSDKBridge.log", "r")
    if not f then return end
    local size = f:seek("end") or 0
    f:seek("set", math.max(0, size - 262144))
    local text = f:read(262144) or ""
    f:close()
    local last = {}
    for a, res in text:gmatch("dtreg (%S+) %-> UDataRegistry::RegisterSpecificAsset on %S+ = (%-?%d+)") do last[a] = tonumber(res) end
    for a, lf in pairs(want) do
        if last[a] == 0 then log("WARN: no source accepts " .. lf .. " (another mod's DR_InitialCharacterPool override is winning?)") end
    end
end

-- the step after the follow-up (the pool has been re-run and deduped): the census, then the session's first roll
function CP.afterFollowups()
    CP.dtregCensus()
    CP.poolRoll("after the follow-up")
end

-- discover's tail: requires[] -> the pins -> the legacy warning -> classPool + settings.ini
function CP.afterDiscover()
    CP.readRequires()
    local pending = false
    for _, d in pairs(CP.deps) do if d.state == "probe" then pending = true end end
    CP.reqFinal = not pending
    CP.reqDeadline = pending and (PS.clock() + 60) or nil   -- the pin waits at most this long for the path probe
    CP.buildPins()
    if not pending then CP.logRequires() end
    CP.legacyWarn()
    CP.readClassPool()
end

-- ---- H1 / §5.6: the accept-set ----
-- the truth table (SDK_CHANGE_REQUEST §5.1 + §5.6.1): `cur` is not `want` - is it a choice the pin leaves alone?
--   a dead id of a missing dependency     never
--   acceptOn "roster" on a fresh card      never (a card always gets `part`)
--   an `accept` id                        yes (on a card too when acceptOn is "any")
--   the slot's `escape` (fallbackSpec/Weapon) on a roster character only (a card that rolled it is still pinned)
--   the equipped weapon's identity tag     yes when it is in `acceptTags`
-- -> "accept" | "escape" | "tag" | nil
-- 1.8.32: `card` = a recruitment CARD (PS.cards), NOT "identified by its pool definition": a RECRUITED character keeps
-- its pool CD as its default definition, and 1.8.27-1.8.31 treated it as a card for good - its `acceptOn = "roster"`
-- accept-sets and its escape never applied, and a player's own voice / saber change was pinned back.
function CP.accepted(pin, cur, card, tagsOf)
    if type(cur) ~= "string" or cur == "" or cur == "?" or cur == "None" then return nil end
    if pin.dead and pin.dead[cur] then return nil end
    local roster = not card
    if pin.acceptOn == "roster" and not roster then return nil end
    if pin.accept and pin.accept[cur] then return "accept" end
    if pin.rosterIds and pin.rosterIds[cur] and roster then return "escape" end
    if pin.acceptTags and #pin.acceptTags > 0 and tagsOf then
        local tags = tagsOf(cur)
        if type(tags) == "table" then
            for _, t in ipairs(tags) do if pin.acceptTagSet[t] then return "tag" end end
        end
    end
    return nil
end

function CP.acceptLog(kind, pin, tag, ipath, cur)
    local owner = shortOwner(ipath)
    local k = "acc|" .. owner .. "|" .. tag .. "|" .. cur
    if kind == "escape" then
        local line
        if tag:find("%.Tactical%.Primary$") then line = owner .. " SPEC 1 holds the fallback spec " .. cur
        elseif tag:find("%.Specializations%.Weapon$") then line = owner .. " Weapon holds the fallback weapon " .. cur
        else line = owner .. " " .. shortTag(tag) .. " holds the fallback " .. cur end
        CP.once(k, "recruit pin: " .. line .. " — left alone (uninstall / troubleshooting)")
    elseif kind == "kept" then
        CP.once(k, "recruit pin: " .. shortTag(tag) .. " on " .. owner .. " holds " .. cur .. " — not re-toggled (an " ..
            "accept-set slot on a roster character: a toggle would reset the model the player picked)")
    else
        CP.once(k, "recruit pin: " .. shortTag(tag) .. " on " .. owner .. " holds accepted " .. cur ..
            ((kind == "tag") and " (by its identity tag)" or "") .. " — left as the player chose")
    end
end

-- a part's tags as strings, from whatever a UE4SS call handed back: an FGameplayTagContainer (userdata or wrapped), or
-- a Lua table holding one (the out-param table). nil = nothing readable; {} = a container that holds no tag.
function CP.tagsFrom(v, depth)
    if v == nil or depth > 2 then return nil end
    local tags = {}
    local okc = pcall(function()
        v.GameplayTags:ForEach(function(_, e)
            local t = e
            pcall(function() t = e:get() end)
            tags[#tags + 1] = t.TagName:ToString()
        end)
    end)
    if okc then return tags end
    if type(v) == "table" then
        for _, x in pairs(v) do
            local y = x
            pcall(function() y = x:get() end)
            local r = CP.tagsFrom(y, depth + 1)
            if r then return r end
        end
    end
    return nil
end

-- route 1: UCustomizationStatics::GetCustomizationPartTagsForPartId(FPrimaryAssetId, out FGameplayTagContainer) on the
-- CDO, handed the GearKit slot's OWN id struct (never a Lua-built one). UNPROVEN: the out-param's shape in UE4SS 3.0.1.
function CP.tagsLua(gs)
    local st = StaticFindObject("/Script/BitReactorCore.Default__CustomizationStatics")
    if not pinOk(st) then return nil end
    local out = {}
    local ok, ret = pcall(function()
        return st:GetCustomizationPartTagsForPartId(gs.CustomizationPartPrimaryAssetId, out)
    end)
    if not ok then
        CP.once("tagslua", "recruit pin: parttags via Lua: GetCustomizationPartTagsForPartId raised (" .. tostring(ret) ..
            ") — the out-param route is unavailable")
        return nil
    end
    return CP.tagsFrom(out, 0)
end

-- route 2: the bridge verb ZCSDK:parttags|<type>|<name>, answered in ue4ss/ZCSDKBridge.parttags as line 1
-- "<type>:<name>" then one tag per line (the contract for the bridge; NOT implemented in bridge 0.5.3).
function CP.tagsBridge(ptype, name)
    local f = UE4SS .. "ZCSDKBridge.parttags"
    pcall(os.remove, f)
    bridge("ZCSDK:parttags|" .. ptype .. "|" .. name)
    local lines = readLines(f)
    if #lines == 0 or lines[1] ~= (ptype .. ":" .. name) then
        CP.once("tagsbridge", "recruit pin: parttags via the bridge: no answer in ZCSDKBridge.parttags (bridge 0.5.3 " ..
            "does not implement ZCSDK:parttags) — the bridge route is unavailable")
        return nil
    end
    local t = {}
    for i = 2, #lines do t[#t + 1] = lines[i] end
    return t
end

-- the GearKit part's identity tags, resolved ONCE per distinct part id per session (strings only: tagsOf[id])
function CP.gearTags(gs)
    local name, ptype = "", ""
    pcall(function()
        local id = gs.CustomizationPartPrimaryAssetId
        name = id.PrimaryAssetName:ToString()
        ptype = id.PrimaryAssetType.Name:ToString()
    end)
    if type(name) ~= "string" or name == "" or name == "None" then return nil end
    local hit = CP.tagsOf[name]
    if hit ~= nil then return hit or nil end
    CP.tagCalls = CP.tagCalls + 1
    local tags, route = nil, nil
    if CP.tagRoute == nil or CP.tagRoute == "lua" then
        tags = CP.tagsLua(gs)
        if tags then route = "lua" end
    end
    if tags == nil and (CP.tagRoute == nil or CP.tagRoute == "bridge") then
        tags = CP.tagsBridge(ptype, name)
        if tags then route = "bridge" end
    end
    if CP.tagRoute == nil then CP.tagRoute = route or "none" end   -- the first answer decides the session's route
    CP.tagsOf[name] = tags or false
    log("recruit pin: parttags " .. name .. " -> " .. (tags and (#tags .. " tag(s) via " .. route ..
        ((#tags > 0) and (": " .. table.concat(tags, ", ")) or "")) or "unreadable"))
    return tags
end

-- the last resort, logged once: the pack's naming convention (spec CPD_WeaponSpec_<class> for tag …Melee.<class>).
function CP.nameTags(cur, pin)
    if not CP.NAME_TAG_FALLBACK then return nil end
    CP.once("nametags", "recruit pin: acceptTags: the GearKit part's tags could not be read — matching the weapon SPEC " ..
        "by the pack's naming convention (CPD_WeaponSpec_<class> for tag …Weapon.Melee.<class>) instead")
    local out = {}
    for _, t in ipairs(pin.acceptTags or {}) do
        local lf = t:match("([^.]+)$")
        if lf and cur == "CPD_WeaponSpec_" .. lf then out[#out + 1] = t end
    end
    return out
end

-- one character's weapon-class tags, for `acceptTags`: its GearKit part (collected THIS frame) or the name convention
function CP.weaponTags(c, cur, pin)
    local tags = nil
    if c.gear then
        local gs = c.gear.obj
        if pinOk(gs) then tags = CP.gearTags(gs) end
    end
    if tags == nil then tags = CP.nameTags(cur, pin) end
    return tags
end

-- ---- §1b.2: the Recruitment watcher (shared by the class-pool roll and G1) ----
-- the hook callback's ENTIRE body: count the event and note its time. No UObject, no log, no I/O - the pump reads the
-- counters later (roll-ahead, and the pin's re-arm).
function CP.onEvent(kind)
    local rn = CP.raceNote
    if rn then rn("hook") end
    local e = CP.evt
    if kind == "RecruitCharacter" then e.recruit = e.recruit + 1 else e.refresh = e.refresh + 1 end
    e.fired, e.t = true, PS.clock()
    -- 1.8.28 (fix 3): and make the pin task due on the next frame (one table write: its next-run time)
    local w = CP.wake
    if w then w() end
end

-- the 1.8.23 discipline: ONCE per process, flag set BEFORE the first call, a failure logged and never retried
function CP.armHooks(why)
    if recruitHookArmed then return end
    recruitHookArmed = true
    log("recruit watch: arming (" .. why .. ")")
    for _, fn in ipairs({ "RefreshCharacterVMs", "RecruitCharacter" }) do
        local kind = fn
        local ok, err = pcall(RegisterHook, "/Script/Bruno.BrunoCharacterRecruitmentViewModel:" .. fn, function() CP.onEvent(kind) end)
        if ok then log("recruit watch: hook armed on " .. fn)
        else
            log("recruit watch: RegisterHook FAILED on " .. fn .. " (not retrying, by design): " .. tostring(err))
            -- 1.8.28 (fix 5): the ONE case the census trigger stands in for a refresh
            if fn == "RefreshCharacterVMs" then
                CP.hookFailed = true
                log("recruit watch: RefreshCharacterVMs could not be hooked — using the census trigger")
            end
        end
    end
end

-- 1.8.28 (fix 5): is the census trigger in use? ONLY when RefreshCharacterVMs could not be hooked (RegisterHook failed)
-- or the kill switch is off - never because no refresh has happened yet (1.8.27 declared the hook "silent" 27 s after
-- arming, and every ordinary hub census drop after that was rolled as a refresh: rolls 3-5 of retail 2026-09-30). Off
-- for good once the hook has fired.
function CP.censusOn()
    if CP.evt.fired then return false end
    return (not CP.RECRUIT_HOOK) or (CP.hookFailed == true)
end

-- (a) something to watch, (b) the hub, (c) the census settled AND the hub up HUB_SETTLE_S; the kill switch first
function CP.armReady(hub, now)
    if not CP.RECRUIT_HOOK then return false, "RECRUIT_HOOK is off (the census trigger only)" end
    if not (CP.poolLive or #recruitPins > 0) then return false, "nothing to watch" end
    if not hub then return false, "not the hub" end
    if not CP.stable then return false, "the census is still climbing" end
    if not CP.hubSince or (now - CP.hubSince) < CP.HUB_SETTLE_S then
        return false, "the hub is younger than " .. CP.HUB_SETTLE_S .. " s"
    end
    return true
end

-- the census, from a pin pass (free) or the watcher's own poll: n = non-proxy instances, sum = their actor numbers
-- (a refresh that swaps cards keeps n and changes sum). nil n = the pin saw the census climbing. A change AFTER it has
-- settled, in the same world, is a Recruitment refresh - 1.8.28: only while the census trigger is in use (CP.censusOn:
-- the hook could not be registered, or the kill switch). It always feeds CP.stable (the arming rule and the hub roll).
function CP.noteCensus(w, n, sum)
    if n == nil then CP.stable = false; return end
    local sig = n .. "/" .. tostring(sum)
    if CP.cWorld ~= w then CP.cWorld, CP.cSig, CP.cN, CP.stable = w, sig, n, false; return end
    if sig == CP.cSig then CP.stable = true; return end
    if CP.stable and CP.censusOn() then
        local e = CP.evt
        e.census = e.census + 1
        e.why, e.t = tostring(CP.cN) .. "->" .. n, PS.clock()
    end
    CP.stable = (n <= (CP.cN or 0))
    CP.cSig, CP.cN = sig, n
end

function CP.censusPoll(w)
    local ok, insts = pcall(FindAllOf, "CustomizationInstance")
    if not ok or type(insts) ~= "table" then return end
    local n, sum = 0, 0
    for _, inst in ipairs(insts) do
        if pinOk(inst) then
            local nm = nil
            pcall(function() nm = inst:GetFullName() end)
            if type(nm) == "string" and not nm:find("Default__") then
                nm = (nm:gsub("^[^ ]+ ", ""))
                if not isProxyOwner(nm) then
                    n = n + 1
                    sum = sum + (tonumber(shortOwner(nm):match("_(%d+)$") or "0") or 0)
                end
            end
        end
    end
    CP.noteCensus(w, n, sum)
end

-- the watcher task (a pump task, 2.5 s): log the hook's firings, roll the pool per event, roll once per hub entry,
-- arm the hooks when the rule allows, and poll the census while nothing else feeds it and the hook has not fired.
function CP.watchTick()
    if not injected then return false end
    if not (CP.poolLive or #recruitPins > 0) then return true end     -- nothing to watch: stop for good
    local w = pinWorldName()
    local hub = (w:find("HUB_Root", 1, true) ~= nil)
    local now = PS.clock()
    if w ~= CP.wWorld then CP.wWorld, CP.hubSince, CP.hubRolled = w, hub and now or nil, false end
    local e, L = CP.evt, CP.seenLog
    for _, kv in ipairs({ { "refresh", "RefreshCharacterVMs" }, { "recruit", "RecruitCharacter" } }) do
        while L[kv[1]] < e[kv[1]] do
            L[kv[1]] = L[kv[1]] + 1
            L.lines = L.lines + 1
            if L.lines <= 200 then log("recruit watch: PATH> " .. kv[2] .. " (#" .. L[kv[1]] .. ")") end
        end
    end
    local tot = e.refresh + e.census
    if tot > CP.poolSeen then
        local why = (e.refresh > CP.poolSeenR) and "RefreshCharacterVMs" or ("census " .. e.why)
        CP.poolSeen, CP.poolSeenR = tot, e.refresh
        CP.poolRoll(why)
    end
    if hub and CP.stable and not CP.hubRolled then CP.hubRolled = true; CP.poolRoll("hub entry") end
    if not recruitHookArmed then
        local ok = CP.armReady(hub, now)
        if ok then
            CP.armHooks(("hub up %.0f s, census settled at %d instance(s)"):format(now - CP.hubSince, CP.cN or 0))
        end
    end
    CP.wTick = (CP.wTick or 0) + 1
    -- the watcher's own census poll (a FindAllOf) runs only while no pin pass feeds the census, and 1.8.28: only while
    -- something still needs it - the hooks are not armed yet (the arming rule and the hub roll read CP.stable), or the
    -- census trigger is in use. With the hooks armed, a dormant hub costs no FindAllOf at all.
    if hub and (CP.pinDormant or pinStop or #recruitPins == 0) and CP.wTick % 2 == 0
       and ((not recruitHookArmed and CP.RECRUIT_HOOK) or CP.censusOn() or not CP.hubRolled) then
        CP.censusPoll(w)
    end
    return false
end

-- ---- §3 G1: the pin task, dormant after `done` ----
function CP.foldEvents()
    local e = CP.evt
    CP.pinSeen = { refresh = e.refresh, recruit = e.recruit, census = e.census }
end

-- a world change re-arms only when it lands in the HUB: a mission rebuilds its characters from the save and a pin there
-- only writes ids (1.8.9), so re-arming into one would spend two of the 20 re-arms on every hub <-> mission round trip.
-- The mission world is still RECORDED, so the return to the hub (the same world name as before) reads as a change.
function CP.rearmReason(w)
    if w ~= pinWorld and w ~= "<none>" then
        if w:find("HUB_Root", 1, true) then return "world " .. (w:match("([^%.]+)$") or w) end
        pinWorld = w
    end
    local e, s = CP.evt, CP.pinSeen
    -- 1.8.33: a SAVE LOAD is a new world under the same name (PS.worldAddr / the census collapse in PS.begin)
    if PS.loadN > PS.loadSeen and w:find("HUB_Root", 1, true) then return "save load" end
    if e.refresh > s.refresh then return "RefreshCharacterVMs" end
    if e.recruit > s.recruit then return "RecruitCharacter" end
    if e.census > s.census then return "census " .. tostring(e.why) end
    return nil
end

-- a new EPISODE. Reset: the episode's verdict state and one-shot lines. Kept (session facts): delivered / known / ghost /
-- gave-up / vanilla - except a CARD's state on a refresh (a refresh re-rolls the cards; `|card:` keys, see PS.act).
function CP.rearm(reason, w)
    CP.rearms = CP.rearms + 1
    CP.lastRearm = PS.clock()
    CP.pinDormant = false
    pinDone = false
    pinWorld, pinIdle, pinSkip, pinWaited = w, 0, 0, 0
    pinSettle.last, pinSettle.waits = 0, 0
    for _, k in ipairs({ "waiting", "waitedout", "stalehold" }) do pinQuiet[k] = nil end
    for k in pairs(pinExpected) do pinExpected[k] = nil end
    -- 1.8.32 (b): a card's state is no longer cleared here. 1.8.27-1.8.31 cleared every `|card:` key on any non-world
    -- re-arm, while the previous set's cards were still alive: their delivered Class was then toggled out and re-driven
    -- forever (retail 2026-10-02 11:18:18). A refresh RETIRES the previous set instead (PS.retireCards, at the event in
    -- CP.pinTick; here for the census refresh, which has no event); a recruit leaves the live cards' state alone.
    if reason:find("^census ") then PS.retireCards("the census refresh") end
    if reason:find("^world ") or reason == "save load" then
        PS.lastWorld = nil   -- 1.8.28: a return to the hub is a NEW world for the sweeps, under the same name
    end
    -- 1.8.33: a save load is folded here (its reset runs in the next pass's PS.begin, as a world change's does)
    if reason == "save load" then PS.loadSeen = PS.loadN; PS.gen = nil end
    -- 1.8.33: every re-arm re-reads every character (a refresh / recruit / world brings new ones or changes old ones)
    PS.notOurs, PS.swept = {}, false
    PS.dgPolls = 0       -- 1.8.33 DIAGNOSTIC: a Recruitment event / world restarts the dormant proxy census's budget
    CP.epUrgent, CP.verifyAt, CP.verifyQ, PS.talentCard = nil, nil, nil, nil   -- 1.8.31: a new card set ends the window
    if reason:find("^world ") then PS.gen = nil end
    -- 1.8.31: a census-triggered refresh (no hook) gets the talent gate too; the hook path arms it in CP.pinTick
    if reason:find("^census ") then PS.gen = { t = PS.clock(), why = "the census refresh" } end
    CP.foldEvents()
    log(("recruit pin: re-armed (%s) [%d/%d]"):format(reason, CP.rearms, CP.PIN_REARM_MAX))
end

-- 1.8.28 (fix 3): an urgent episode reached `done`: say how long after the EVENT (T-G1's number), and schedule ONE
-- verify pass (the card's async spawn writes its Talent from the voice map at its end; a slot that reverts is re-driven)
-- 1.8.31: a WINDOW of verify passes (PS.VERIFY_AT after `done`), not one at +8 s: the card's voice->Talent write can land
-- later than that. Scheduled after an urgent episode, and after any episode that delivered a CARD's Talent. A verify pass
-- that re-pins re-opens the episode; its `done` does not restart the window (a new card set does, through CP.rearm).
function CP.episodeDone(settled)
    local u = CP.epUrgent or (PS.P and PS.P.urgent)
    local tc = PS.talentCard
    PS.talentCard = nil
    if not u and not (tc and not CP.verifyQ) then return end
    CP.epUrgent = nil
    local now = PS.clock()
    local at = {}
    for _, d in ipairs(PS.VERIFY_AT) do at[#at + 1] = tostring(d) end
    if u then
        log(("recruit pin: %s -> done %.1f s after the event (%d slot(s) DELIVERED this session); verify passes in %s s")
            :format(u.why, now - u.t, settled, table.concat(at, "/")))
    else
        log(("recruit pin: done with a card's Talent delivered; verify passes in %s s"):format(table.concat(at, "/")))
    end
    CP.verifyQ = {}
    for i = 2, #PS.VERIFY_AT do CP.verifyQ[#CP.verifyQ + 1] = now + PS.VERIFY_AT[i] end
    CP.verifyAt = now + (PS.VERIFY_AT[1] or PS.VERIFY_S)
    CP.verifyN = 0
end

function CP.runPass()
    local ok, r = xpcall(applyRecruitPins, pinTraceback)
    if not ok then log("recruit pin error: " .. tostring(r)); PS.P = nil; r = "idle" end
    return r
end

-- the tiers, by what the pass actually found:
--   "more"     1.8.27: the pass is unfinished -> again on the NEXT frame (return 0)
--   "urgent"   1.8.28: a Recruitment event, and the cards of ours are not all there yet -> look again in URGENT_STEP_S
--   "pinned"   a slot was just changed -> 5 s, more re-rolls usually follow
--   "targets"  pin-able characters are here and already correct (the squad in a mission) -> 7.5 s
--   "settling" 1.8.26: the census is still climbing, nothing was read -> look again at the next 2.5 s tick
--   "idle"     nothing this pin could ever apply to in this world -> back off to 10 then 20 s
--   "none"     1.8.28: nothing is ours and this world's sweeps are done -> DORMANT
--   "done"     1.8.27: the episode is over -> DORMANT (1.8.14-1.8.26: the loop stopped for the session)
function CP.afterPass(r)
    if r == "more" then return 0 end
    if r == "urgent" then return PS.URGENT_STEP_S end
    if r == "gen" then pinIdle = 0; return PS.GEN_STEP_S end   -- 1.8.31: a card's Talent waits for the talent gate
    if r == "done" then
        if not CP.pinDormant then                       -- (a verify pass that found nothing to do is still dormant)
            CP.pinDormant = true
            log("recruit pin: dormant")
        end
    elseif r == "none" then
        CP.pinDormant = true
        log("recruit pin: dormant — nothing ours in this world after its sweeps; re-arms on a Recruitment refresh / " ..
            "recruit / world change")
    elseif r == "pinned" then
        pinIdle = 0
        pinSkip = CP.epUrgent and 0 or 1                     -- 1.8.14: 5 s, not 3 s; 1.8.28: 2.5 s in an urgent episode
    elseif r == "targets" then pinIdle = 0; pinSkip = 2
    elseif r == "settling" then pinSkip = 0
    else
        pinIdle = pinIdle + 1
        pinSkip = (pinIdle < 4) and 0 or ((pinIdle < 12) and 3 or 7)
    end
    return false
end

-- the pin task's body (a pump task, 2.5 s). DORMANT is O(1): the world name (the cheap read) and three counters -
-- no FindAllOf, no slot walk.
function CP.pinTick()
    if not injected then return false end
    if #recruitPins == 0 then return true end
    if not CP.reqFinal then
        if CP.reqDeadline and PS.clock() > CP.reqDeadline then CP.finalizeRequires("60 s after discover") else return false end
    end
    if pinStop then log("recruit pin: loop stopped"); return true end
    -- 1.8.28 (fix 3): a Recruitment event (the hook, not the census) since the last pass began is URGENT: the next pass
    -- runs now (the hook made this task due on the next frame, CP.wake), bypasses the spawn-wave settle and drives the
    -- cards of ours as soon as they exist - and a dormant loop re-arms for it below.
    local e, s = CP.evt, CP.pinSeen
    -- 1.8.31: every RefreshCharacterVMs event (re-)arms the talent gate: a card's Talent waits for the game's own
    -- voice->Talent write (RemainingCharactersToGenerate = 0; PS.genGate). A recruit spawns no card: no gate.
    if e.refresh > PS.genN then
        PS.genN = e.refresh
        PS.gen = { t = e.t or PS.clock(), why = "RefreshCharacterVMs" }
        -- 1.8.32 (b): the cards seen so far are the PREVIOUS set - retired before any pass can see the new one
        PS.retireCards("RefreshCharacterVMs")
    end
    -- 1.8.33: every RecruitCharacter owes a DEMOTION: the recruited card is a roster character from now on (PS.begin
    -- identifies it on the next pass and calls PS.demoteCard)
    if e.recruit > PS.recruitN then
        PS.recruitN = e.recruit
        PS.demote = { t = e.t or PS.clock() }
    end
    -- 1.8.33: a SAVE LOAD keeps the world's NAME (HUB_Root) but replaces the world OBJECT: one cheap read per tick
    do
        local wa, wn = PS.worldAddr()
        if wa and PS.wAddr and wa ~= PS.wAddr and wn == PS.wAddrName then
            PS.loadN = PS.loadN + 1
            PS.loadWhy = "save load: the world object was replaced under the same name"
            PS.lastWorld = nil                       -- the next pass resets this world's names (PS.begin)
            if not CP.pinDormant then PS.loadSeen = PS.loadN end   -- (an awake loop needs no re-arm for it)
            log(("recruit pin: %s (%s)"):format(PS.loadWhy, wn:match("([^%.]+)$") or wn))
        end
        if wa then PS.wAddr, PS.wAddrName = wa, wn end
    end
    if (e.refresh > s.refresh or e.recruit > s.recruit) and not PS.urgent then
        PS.urgent = { t = e.t or PS.clock(), why = (e.refresh > s.refresh) and "RefreshCharacterVMs" or "RecruitCharacter" }
        pinSkip = 0
        log(("recruit pin: %s — an urgent pass: the spawn-wave settle is bypassed, the cards of ours are driven as soon as " ..
            "they exist"):format(PS.urgent.why))
    end
    if PS.P then
        local w = pinWorldName()
        if w == PS.P.world then return CP.afterPass(CP.runPass()) end
        log("recruit pin: pass " .. PS.P.pass .. " abandoned — the world changed mid-pass")
        PS.P = nil
    end
    if CP.pinDormant then
        local w = pinWorldName()
        local reason = CP.rearmReason(w)
        if not reason then
            -- 1.8.28: the ONE verify pass of an urgent episode (CP.episodeDone); dormant it stays unless a slot reverted
            -- 1.8.31: one of a WINDOW of verify passes (PS.VERIFY_AT)
            -- 1.8.33 DIAGNOSTIC: while dormant in a hub with something of ours, a customization proxy is looked for
            -- every PS.DIAG_POLL_S (one FindAllOf; a slot read only when a new proxy is there), PS.DIAG_POLLS per world
            if PS.diagPoll(w) then return 0 end
            if CP.verifyAt and PS.clock() >= CP.verifyAt then
                CP.verifyN = (CP.verifyN or 0) + 1
                CP.verifyAt = CP.verifyQ and table.remove(CP.verifyQ, 1) or nil
                PS.verifyNext = true
                log(("recruit pin: verify pass — re-reading the slots this episode DELIVERED (%d/%d; the live Talent is " ..
                    "read back)"):format(CP.verifyN, #PS.VERIFY_AT))
                return CP.afterPass(CP.runPass())
            end
            return false
        end
        -- §3.1.2: at most one re-arm per REARM_GAP; an event inside the gap WAITS for it (it is never lost). 1.8.28: the
        -- 1.8.27 fold ("an event within the gap belongs to the last re-arm") is gone: an episode now ends in seconds, so
        -- a second refresh inside the gap can bring cards the first episode never saw. Events that arrive before the
        -- episode's first pass still share one re-arm (the pass folds them all).
        if CP.lastRearm and (PS.clock() - CP.lastRearm) < CP.REARM_GAP then return false end
        if CP.rearms >= CP.PIN_REARM_MAX then
            log(("recruit pin: re-arm cap (%d) reached — dormant until the next launch"):format(CP.PIN_REARM_MAX))
            pinStop = true
            return true
        end
        CP.rearm(reason, w)
    end
    if pinSkip > 0 then pinSkip = pinSkip - 1; return false end
    -- 1.8.11: the world read goes through the same nil-hardening as the pin itself (GetFullName on an invalid world
    -- returns nil WITHOUT raising)
    local w = pinWorldName()
    if w ~= pinWorld then pinWorld = w; pinIdle = 0 end
    return CP.afterPass(CP.runPass())
end
-- ---- recruit pins (end) ----

-- ---- 1.8.26: THE GAME-THREAD PUMP (begin; tools/replay_pump.py extracts this block verbatim) ----
-- WHY. UE4SS 3.0.1 runs `LoopAsync` and `ExecuteWithDelay` bodies on its ASYNC thread, and calls queued
-- `ExecuteInGameThread` actions on the GAME thread with its action mutex already released (UE4SS+0x2f92a0: _Mtx_lock
-- on 0x1348db0, move the queue vector out, _Mtx_unlock, THEN call each action and luaL_unref it). One mod has ONE
-- lua_State, so every LoopAsync tick that overlapped a game-thread closure was two OS threads inside the same Lua VM.
-- The 2026-09-28 21:51 minidump caught the result: `L->top` lowered underneath a running IsValid. No amount of
-- thinning the async bodies closes that; only running no Lua there does.
-- HOW. `PUMP.fn` is ONE function value, queued ONCE from the end of the main chunk (`startPump`). Each run re-queues
-- that SAME value first (no closure is created per frame; each queue takes one registry ref that the runner unrefs
-- after the call, all on the game thread now). Because the runner has already moved its queue out before calling,
-- the re-queue lands in the fresh vector and runs on the NEXT engine tick — once per frame, never recursively. UE4SS
-- also sets a busy byte (0x1348d71) around each action and defers nested runs, and `PUMP.busy` below refuses a
-- re-entry without queuing a second chain.
-- WHAT RUNS IN IT. Periodic tasks (`addTask`, LoopAsync semantics: return true = stop for good, a number = run again
-- in that many seconds, anything else = run again after the period) and one-shot timers (`after`). Time is
-- os.clock() — on the Windows CRT that is WALL time since process start (not CPU time), 1 ms resolution. After a
-- stall (a loading screen) a task runs ONCE, never a catch-up burst: the next run is always measured from the end of
-- the last one, as LoopAsync did.
-- BUDGET. At most PUMP.TASKS_PER_TICK periodic tasks run per frame, picked round-robin, so the pin, ROWFIX and the
-- grants can never stack into one frame during a Den load. A task that raises is logged (capped) and keeps its
-- schedule; the pump itself cannot be killed by a task, because the re-queue happens before any task runs.
-- STATE. One table, because the main chunk sits at Lua's 200-local limit (every file-scope `local` counts).
local PUMP = {
    VERSION        = "1.8.54",  -- 1.8.28: the loader version the startup line prints (tools/selftest_loader.py checks it
                                -- against the header, the load line and modinfo.json - it cannot go stale again)
    TASKS_PER_TICK = 1,     -- periodic tasks per frame (one-shot timers are not counted; they are tiny)
    SLOW_MS        = 16,    -- a task that takes longer than this in one frame is logged (capped PER TASK), so a hitch
                            -- has a name. 1.8.27: 50 -> 16 (one 60 Hz frame), because the Den-pause check reads these lines
    LOG_CAP        = 20,    -- per-task error lines, and per-task slow-task lines, per session
    HEARTBEAT_S    = 300,   -- "pump: alive" cadence
    RACEPROBE      = false, -- ONE-LAUNCH PROBE (default OFF): count loader Lua that runs off the game thread
    clock = os.clock,
    tasks = {}, timers = {},
    cursor = 0, ticks = 0, runs = 0, errors = 0, slow = 0,
    busy = false, started = false, announced = false, nextBeat = 0,
    race = { entries = 0, off = 0, reentry = 0, threads = {}, where = {}, gt = nil, nextLog = 0 },
}

-- RACEPROBE: called at the top of every piece of loader Lua that UE4SS invokes after start-up (the pump, and each
-- RegisterHook callback). With the switch OFF it is one table read. With it ON it asks UE4SS which thread this is
-- (`IsInGameThread` / `GetCurrentThreadId` / `GetGameThreadId` exist in this UE4SS build; all are pcall'd, so a build
-- without them only loses the evidence, never the loader). The reading the retail check wants is `OFF the game
-- thread=0`, `pump re-entries=0` and ONE thread id in the braces.
local function raceNote(where)
    if not PUMP.RACEPROBE then return end
    local race = PUMP.race
    race.entries = race.entries + 1
    local tid, inGT = nil, nil
    pcall(function() tid = GetCurrentThreadId() end)
    pcall(function() inGT = IsInGameThread() end)
    local key = tostring(tid)
    race.threads[key] = (race.threads[key] or 0) + 1
    if where == "pump" and race.gt == nil then race.gt = key end
    local off = (inGT == false) or (inGT == nil and race.gt ~= nil and key ~= race.gt)
    if off then
        race.off = race.off + 1
        race.where[where] = (race.where[where] or 0) + 1
    end
end
function PUMP.raceReport(now)
    local race = PUMP.race
    if not PUMP.RACEPROBE or now < race.nextLog then return end
    race.nextLog = now + 10
    local th, wh = {}, {}
    for k, n in pairs(race.threads) do th[#th + 1] = k .. "=" .. n end
    for k, n in pairs(race.where) do wh[#wh + 1] = k .. "=" .. n end
    table.sort(th); table.sort(wh)
    local gid = "?"; pcall(function() gid = tostring(GetGameThreadId()) end)
    log(("RACEPROBE: loader Lua entries=%d, OFF the game thread=%d%s, pump re-entries=%d, threads {%s}, game thread=%s")
        :format(race.entries, race.off, (#wh > 0) and (" (" .. table.concat(wh, ", ") .. ")") or "", race.reentry,
                table.concat(th, ", "), gid))
end

-- a periodic task. `firstS` = seconds until its first run (default: one period; math.huge = dormant until `wake`)
local function addTask(name, periodS, fn, firstS)
    local t = { name = name, period = periodS, fn = fn, nextAt = PUMP.clock() + (firstS or periodS),
                runs = 0, errs = 0, done = false, slow = 0, maxMs = 0 }
    PUMP.tasks[#PUMP.tasks + 1] = t
    return t
end
local function wake(t, inS) t.nextAt = PUMP.clock() + (inS or 0) end
-- a one-shot timer, run inside the pump on the game thread (replaces ExecuteWithDelay + ExecuteInGameThread)
local function after(ms, fn, tag)
    PUMP.timers[#PUMP.timers + 1] = { at = PUMP.clock() + ms / 1000, fn = fn, tag = tag or "timer" }
end

function PUMP.runTask(t)
    local clock = PUMP.clock
    local t0 = clock()
    local ok, r = pcall(t.fn)
    local t1 = clock()
    t.runs = t.runs + 1; PUMP.runs = PUMP.runs + 1
    if not ok then
        t.errs = t.errs + 1; PUMP.errors = PUMP.errors + 1
        if t.errs <= PUMP.LOG_CAP then
            log("pump: task " .. t.name .. " raised (it keeps its schedule): " .. tostring(r))
        end
        t.nextAt = t1 + t.period
    elseif r == true then
        t.done = true
    elseif type(r) == "number" then
        t.nextAt = t1 + r
    else
        t.nextAt = t1 + t.period
    end
    local ms = (t1 - t0) * 1000
    local newMax = ms > t.maxMs
    if newMax then t.maxMs = ms end
    if ms > PUMP.SLOW_MS then
        PUMP.slow = PUMP.slow + 1
        t.slow = t.slow + 1
        -- 1.8.27: capped PER TASK, so a noisy startup task cannot use up the lines the pin's Den check needs
        if t.slow <= PUMP.LOG_CAP then
            log(("pump: task %s took %.0f ms in one frame"):format(t.name, ms))
        elseif newMax then
            -- 1.8.45 (retail 10-22: the heartbeat's "saberlook 692" / "saber 239" maxima had no line saying WHEN - each task's 20
            -- slow lines were spent in the first minutes): past the cap, a frame that sets the task's NEW session maximum is still
            -- said (a maximum only grows, so these lines stay few)
            log(("pump: task %s took %.0f ms in one frame (a new maximum for it; its slow-frame lines are past the cap of %d)"):format(t.name, ms, PUMP.LOG_CAP))
        end
    end
end

function PUMP.body()
    PUMP.ticks = PUMP.ticks + 1
    local now = PUMP.clock()
    local tasks, timers = PUMP.tasks, PUMP.timers
    if not PUMP.announced then
        PUMP.announced = true; PUMP.nextBeat = now + PUMP.HEARTBEAT_S
        local names = {}
        for _, t in ipairs(tasks) do
            names[#names + 1] = t.name .. ((t.nextAt == math.huge) and " (on demand)" or ("/" .. t.period .. "s"))
        end
        log("pump: running on the game thread (" .. PUMP.VERSION .. "; no LoopAsync, no ExecuteWithDelay) — " .. #tasks ..
            " task(s): " .. table.concat(names, ", ") .. "; at most " .. PUMP.TASKS_PER_TICK .. " per frame" ..
            (PUMP.RACEPROBE and "; RACEPROBE ON" or ""))
    end
    -- one-shot timers: every due one, in order; a timer may add timers (1.8.54, security review I-5: the due ones are taken
    -- out FIRST, so a timer added while they run - even after(0) - waits for the next frame and can never spin this one)
    local due, i = nil, 1
    while i <= #timers do
        if now >= timers[i].at then due = due or {}; due[#due + 1] = table.remove(timers, i) else i = i + 1 end
    end
    for _, tm in ipairs(due or {}) do
        local ok, err = pcall(tm.fn)
        if not ok then log("pump: timer " .. tm.tag .. " raised: " .. tostring(err)) end
    end
    -- periodic tasks: round-robin from the one after the last that ran, at most TASKS_PER_TICK of them
    local n, ran = #tasks, 0
    for k = 1, n do
        if ran >= PUMP.TASKS_PER_TICK then break end
        local idx = ((PUMP.cursor + k - 1) % n) + 1
        local t = tasks[idx]
        if not t.done and now >= t.nextAt then
            PUMP.cursor = idx
            PUMP.runTask(t)
            ran = ran + 1
        end
    end
    if now >= PUMP.nextBeat then
        PUMP.nextBeat = now + PUMP.HEARTBEAT_S
        local live = 0
        for _, t in ipairs(tasks) do if not t.done then live = live + 1 end end
        -- 1.8.27: and each task's largest single frame so far, so the heartbeat alone answers "is anything still slow?"
        local mx = {}
        for _, t in ipairs(tasks) do if t.maxMs >= 1 then mx[#mx + 1] = ("%s %.0f"):format(t.name, t.maxMs) end end
        log(("pump: alive — %d frame(s), %d task run(s), %d task error(s), %d live task(s); max ms per frame: %s")
            :format(PUMP.ticks, PUMP.runs, PUMP.errors, live, (#mx > 0) and table.concat(mx, ", ") or "none >= 1"))
    end
    PUMP.raceReport(now)
end

-- THE pump: one function value for the whole session (PUMP.fn), so every re-queue hands UE4SS the same function
function PUMP.fn()
    raceNote("pump")
    if PUMP.busy then PUMP.race.reentry = PUMP.race.reentry + 1; return end   -- a nested run is not the chain: queue nothing
    PUMP.busy = true
    -- FIRST: keep the chain alive, whatever the tasks below do
    local okQ, errQ = pcall(ExecuteInGameThread, PUMP.fn)
    local ok, err = pcall(PUMP.body)
    if not ok then log("pump: body raised (the pump keeps running): " .. tostring(err)) end
    if not okQ then
        -- one more try at the end of the frame's work; if that fails too there is no thread left to retry from
        local ok2, err2 = pcall(ExecuteInGameThread, PUMP.fn)
        if not ok2 then
            log("pump: STOPPED — ExecuteInGameThread refused the re-queue twice: " .. tostring(errQ) .. " / " .. tostring(err2))
        end
    end
    PUMP.busy = false
end

-- called ONCE, as the last statement of the main chunk
local function startPump()
    if PUMP.started then return end
    PUMP.started = true
    if PUMP.RACEPROBE then
        local tid = "?"; pcall(function() tid = tostring(GetCurrentThreadId()) end)
        log("RACEPROBE: main chunk on thread " .. tid .. " (UE4SS's mod-start thread; this is before the pump starts)")
    end
    local ok, err = pcall(ExecuteInGameThread, PUMP.fn)
    if not ok then log("pump: could NOT be started — ExecuteInGameThread failed: " .. tostring(err)) end
end
CP.raceNote = raceNote   -- 1.8.27: the Recruitment hooks' callbacks (defined in the pin block, above this) note their thread too
-- ---- 1.8.26: THE GAME-THREAD PUMP (end) ----
CP.SELF_VERSION = PUMP.VERSION   -- requires[] id "ZCSDKLoader" (CP.readRequires): this loader's own version, never a literal

-- ---- 1.8.48: COMPOSITE PARENTS / STATUSFX (begin) ----
-- THE SYMPTOM (SithClass _reports/2026-10-22_operator_visuals/SHOCK_FX_FIX.md): Force Shock's victim overlay never drew on
-- 199049. Every offline link is intact: the GE grants BitReactor.Status.Character.ZCSithLightningShock, the tag is registered,
-- the mod's DT_StatusFX copy has ParentTables = [DT_StatusFX_Base, DT_ZCSith_StatusFX], the overlay row ZCSith_LightningShock
-- binds the tag to BP_StatusFX_ZCSith_LightningShock_C, and BP_AbilityEffectFXComponent reads the composite DT_StatusFX.
-- THE CAUSE IT FITS (candidate 1 there). A mod extends a composite by shipping a copy at the game's path. If the game already
-- loaded the composite before the mod's container mounted, the live one is the stock copy ([Base] only) and the mod's copy is
-- never read: stock rows (Shocked, Drained) work, the mod's never fire. DT_StatusFX IS a UCompositeDataTable (jmap: its class,
-- ParentTables @176; docs/CAPABILITY_B_STATUS.md), so the route is the engine's own runtime one:
-- UCompositeDataTable::AppendParentTables (bridge 0.7.2 `ZCSDK:dtparent`) adds the overlay table, then OnParentTablesUpdated
-- re-merges every parent's rows. A row copy is NOT a route: UCompositeDataTable::AddRow is a no-op by design, and the next
-- re-merge would drop copied rows anyway. Characters spawned after the append watch the new tags (the host builds its tag
-- watches from the table at BeginPlay), so a character already on the map at the append keeps the old set until it respawns.
-- WHAT IT DOES. After the follow-ups, and again on every new world (a pass ~SETTLE_S after the world changes; a world we have
-- passed is never passed twice): for each manifest `composites` entry (zcmod-build 2026-10-28) find the live composite and the
-- overlay table (one FindAllOf each, a bridge loadpkg for a table not yet loaded), refuse a RowStruct mismatch (the composite
-- would skip that parent and log an error), append the table when it is not a parent (verified by re-reading ParentTables),
-- and log one line per expected row: `STATUSFX row <Name> live|MISSING (table <path>)` (COMPOSITE <DT_X> for the other ten).
-- A manifest built before the field (no `composites`) gets the DT_StatusFX check only, at /Game/<ns>/DT_<ns>_StatusFX for each
-- primaryTypes path, with its rows read from the table itself (GetDataTableRowNames WITH its out-array).
-- RULES. No TSoftObjectPtr is read (ParentTables / RowStruct are hard refs). Every step is pcall'd; a failure logs and that
-- entry stands down for the world. Idempotent: an existing parent is never re-added (checked here and refused by the bridge).
-- settings.ini [COMPOSITES] Append = 0 = verify only (log the rows, append nothing).
CP.CF = {
    POLL_S = 5, SETTLE_S = 4, PARENT_OFFSET = 176,   -- jmap 199049: CompositeDataTable.ParentTables @ 176 (an ArrayProperty, 16 bytes)
    INI = "Mods/ZCSDKLoader/settings.ini", DTFL = "/Script/Engine.Default__DataTableFunctionLibrary",
    entries = nil, append = true, ready = false, world = nil, seenWorld = nil, pending = nil, passes = 0, verdict = {},
}
function CP.CF.label(target)
    local short = tostring(target):match("([^/%.]+)$") or tostring(target)
    return short == "DT_StatusFX" and "STATUSFX" or ("COMPOSITE " .. short)
end
function CP.CF.pathOf(o)   -- "Class /Game/A/B.B" -> "/Game/A/B.B"
    local fn = nil; pcall(function() fn = o:GetFullName() end)
    return type(fn) == "string" and (fn:match("^%S+%s+(.+)$") or fn) or nil
end
function CP.CF.collect()
    local CF = CP.CF
    local list, seen = {}, {}
    local function add(e) local k = e.target .. "|" .. e.table; if not seen[k] then seen[k] = true; list[#list + 1] = e end end
    for _, mf in ipairs(manifests) do
        local m = mf.m or {}
        if type(m.composites) == "table" then
            for _, c in ipairs(m.composites) do
                if type(c) == "table" and type(c.target) == "string" and type(c.table) == "string" then
                    local rows = {}
                    for _, r in ipairs(type(c.rows) == "table" and c.rows or {}) do rows[#rows + 1] = tostring(r) end
                    add({ mod = tostring(m.name), target = c.target, table = c.table, rows = rows })
                end
            end
        else   -- a manifest from before the field: the DT_StatusFX overlay at its default place, rows read from the table
            for _, pt in ipairs(m.primaryTypes or {}) do
                local ns = type(pt.path) == "string" and pt.path:match("^/Game/([^/]+)$")
                if ns then
                    local pkg = "/Game/" .. ns .. "/DT_" .. ns .. "_StatusFX"
                    add({ mod = tostring(m.name), target = "/Game/Game/FX/Blueprints/Status/DT_StatusFX.DT_StatusFX",
                          table = pkg .. ".DT_" .. ns .. "_StatusFX", rows = nil, legacy = true })
                end
            end
        end
    end
    return list
end
function CP.CF.config()
    local CF = CP.CF
    local v = CP.zcuIni(CP.zcuText(UE4SS .. CF.INI) or "", "COMPOSITES", "Append")
    if v ~= nil then CF.append = not (v == "0" or v:lower() == "false" or v:lower() == "off") end
end
-- the parent tables of a live composite: count, and whether `addr` is one of them
function CP.CF.parents(comp, addr)
    local n, has = 0, false
    local arr = comp.ParentTables
    n = arr:GetArrayNum()
    arr:ForEach(function(_, e)
        local p = e:get()
        if p and p:IsValid() and p:GetAddress() == addr then has = true end
    end)
    return n, has
end
function CP.CF.rowNames(dtfl, tbl)   -- legacy entries only: the table's own row names (the out-array is passed: never without it)
    local out, names = {}, {}
    dtfl:GetDataTableRowNames(tbl, out)
    for _, v in ipairs(out) do
        local s = nil
        pcall(function() s = v:get():ToString() end)
        if not s then pcall(function() s = v:ToString() end) end
        if s and s ~= "" and s ~= "None" then names[#names + 1] = s end
    end
    return names
end
function CP.CF.say(label, row, state, tpath, why)
    local CF = CP.CF
    local k = label .. "|" .. row .. "|" .. tpath
    local line = ("%s row %s %s (table %s)%s"):format(label, row, state, tpath, why and ("; " .. why) or "")
    if CF.verdict[k] ~= line then CF.verdict[k] = line; log(line); return true end
    return false
end
-- one entry: find, check, append when needed, report its rows. `comps` / `tbls` = this pass's walks (path -> object).
function CP.CF.one(e, comps, tbls, dtfl)
    local CF = CP.CF
    local label = CF.label(e.target)
    local live, total = 0, 0
    local comp = comps[e.target]
    if not comp then
        log(("%s %s is not loaded (yet) - %s's overlay checked again on the next world"):format(label, e.target, e.mod))
        return 0, 0
    end
    local tbl = tbls[e.table]
    if not tbl and e.absent then return 0, e.legacy and 0 or #e.rows end   -- asked for twice already: not in any mounted pak
    if not tbl then
        e.loads = (e.loads or 0) + 1
        if e.loads >= 2 then e.absent = true end   -- one load request per world, at most two in a session
        local pkg = e.table:match("^(.-)%.[^%.]+$")
        if pkg then bridge("ZCSDK:loadpkg|" .. pkg) end
        local ok, o = pcall(StaticFindObject, e.table)
        if ok and o and o:IsValid() then tbl, e.loads = o, 0 end
    end
    if not tbl then
        if e.legacy then return 0, 0 end   -- no overlay at the default place: this mod has none (nothing to say)
        for _, r in ipairs(e.rows) do CF.say(label, r, "MISSING", e.table, "the overlay table is not loaded (is " .. e.mod .. "'s pak mounted?)") end
        return 0, #e.rows
    end
    local rows = e.rows
    if e.legacy then
        local ok, names = pcall(CF.rowNames, dtfl, tbl)
        rows = ok and names or {}
        if not ok then log(label .. " " .. e.table .. ": its row names could not be read: " .. tostring(names)) end
    end
    total = #rows
    -- a parent whose RowStruct differs is skipped by UpdateCachedRowMap (a pointer compare): appending it would only log an error
    local same = nil
    pcall(function() same = comp.RowStruct:GetAddress() == tbl.RowStruct:GetAddress() end)
    if same == false then
        for _, r in ipairs(rows) do CF.say(label, r, "MISSING", e.table, "its RowStruct is not the live composite's (not appended)") end
        return 0, total
    end
    local tAddr = tbl:GetAddress()
    local okP, n, has = pcall(CF.parents, comp, tAddr)
    if not okP then log(label .. " " .. e.target .. ": ParentTables unreadable (" .. tostring(n) .. ") - stood down for this world"); return 0, total end
    if not has then
        if not CF.append then
            log(("%s %s is NOT a parent of the live %s ([COMPOSITES] Append = 0: verify only)"):format(label, e.table, e.target))
        else
            local arrAddr = nil
            pcall(function() arrAddr = comp.ParentTables:GetArrayAddress() end)
            if type(arrAddr) ~= "number" or arrAddr == 0 then arrAddr = comp:GetAddress() + CF.PARENT_OFFSET end
            bridge(("ZCSDK:dtparent|%x|%x|%x|%d"):format(comp:GetAddress(), arrAddr, tAddr, n))
            local ok2, n2, has2 = pcall(CF.parents, comp, tAddr)
            if ok2 and has2 then
                log(("%s appended %s (%s) to the live %s: %d -> %d parent(s)"):format(label, e.table, e.mod, e.target, n, n2))
            else
                log(("%s the bridge did not append %s to %s (ParentTables %s) - ZCSDKBridge older than 0.7.2? Update the ZCSDK Runtime; " ..
                     "ZCSDKBridge.log has the dtparent line"):format(label, e.table, e.target, ok2 and tostring(n2) or "unreadable"))
            end
        end
    end
    for _, r in ipairs(rows) do
        local ok, yes = pcall(function() return dtfl:DoesDataTableRowExist(comp, FName(r)) end)
        if ok and yes then live = live + 1; CF.say(label, r, "live", e.table)
        else CF.say(label, r, "MISSING", e.table, ok and "not in the live " .. e.target or ("row read failed: " .. tostring(yes))) end
    end
    return live, total
end
function CP.CF.pass(why)
    local CF = CP.CF
    CF.passes = CF.passes + 1
    local comps, tbls = {}, {}
    local okC, all = pcall(FindAllOf, "CompositeDataTable")
    for _, o in ipairs(okC and all or {}) do
        if o:IsValid() then local p = CF.pathOf(o); if p and not p:find("Default__", 1, true) then comps[p] = o end end
    end
    local okT, allT = pcall(FindAllOf, "DataTable")
    for _, o in ipairs(okT and allT or {}) do
        if o:IsValid() then local p = CF.pathOf(o); if p and not p:find("Default__", 1, true) then tbls[p] = o end end
    end
    local okD, dtfl = pcall(StaticFindObject, CF.DTFL)
    if not (okD and dtfl and dtfl:IsValid()) then log("COMPOSITES: DataTableFunctionLibrary CDO not found - stood down for this world"); return end
    local live, total = 0, 0
    for _, e in ipairs(CF.entries) do
        local ok, l, t = pcall(CF.one, e, comps, tbls, dtfl)
        if ok then live, total = live + (l or 0), total + (t or 0)
        else log("COMPOSITES: " .. e.target .. " / " .. e.table .. " raised (stood down for this world): " .. tostring(l)) end
    end
    log(("COMPOSITES pass %d (%s): %d/%d overlay row(s) live, %d entr%s%s"):format(CF.passes, why, live, total, #CF.entries,
        #CF.entries == 1 and "y" or "ies", CF.append and "" or ", verify only"))
end
function CP.CF.tick()
    local CF = CP.CF
    if not CF.ready then return CF.POLL_S end
    if CF.entries == nil then
        CF.entries = CF.collect()
        if #CF.entries == 0 then return true end   -- no mod extends a composite: stopped for good, never a lookup
        CF.config()
        log(("COMPOSITES armed: %d overlay table(s) to keep in their live composite(s)%s"):format(#CF.entries,
            CF.append and "" or " ([COMPOSITES] Append = 0: verify only)"))
    end
    local a = PS.worldAddr()
    if not a then return CF.POLL_S end                     -- a loading screen
    if a == CF.world then return CF.POLL_S end             -- this world is done
    if CF.pending ~= a then CF.pending = a; return CF.SETTLE_S end   -- a new world: let it settle, then one pass
    CF.world, CF.pending = a, nil
    CF.pass(CF.passes == 0 and "after the follow-ups" or "a new world")
    return CF.POLL_S
end
CP.CF.task = addTask("composites", CP.CF.POLL_S, function() return CP.CF.tick() end, math.huge)
function CP.CF.start() CP.CF.ready = true; wake(CP.CF.task, 0) end
-- ---- 1.8.48: COMPOSITE PARENTS / STATUSFX (end) ----

-- ---- sequencing ----
-- 1.8.26: the startup steps are one pump task, dormant until the arm task wakes it; each step's `delay` is the wait
-- before the NEXT step, exactly as runSteps' ExecuteWithDelay chain had it.
local steps = {}
local function addStep(d, fn) steps[#steps + 1] = { delay = d, fn = fn } end
local stepTask
stepTask = addTask("steps", 1.0, function()
    local s = steps[stepTask.i]; if not s then return true end
    local ok, err = pcall(s.fn); if not ok then log("STEP ERROR: " .. tostring(err)) end
    if ok and type(err) == "number" then return err end   -- 1.8.54: a waiting step (the bridge ack) runs again after err seconds
    stepTask.i = stepTask.i + 1
    if not steps[stepTask.i] then return true end
    return s.delay / 1000
end, math.huge)
stepTask.i = 1
addStep(3000, function() log("=== ZCSDKLoader start ==="); setTrigger() end)
addStep(0, function() return CP.BR.waitAck() end)   -- 1.8.54: the bridge 0.7.3 arm ack (at most CP.BR.ACK_S, on the pump)
addStep(1000, function() discover() end)
addStep(1000, function() CP.registerTags() end)   -- 1.8.42: gfp Config/Tags inis -> the tag manager, BEFORE the rescans / cache refresh
addStep(1000, function() bridge("ZCSDK:byclass|/Script/Bruno|BrunoModificationInventoryItem") end)
addStep(1000, function() injectRegistries() end)
addStep(3000, function() bridge("ZCSDK:byclass|/Script/Bruno|BrunoModificationInventoryItem") end)
addStep(1000, function() preloadPackages() end)
addStep(1000, function() rescanPrimaryTypes(); CP.probeRequires(1) end)   -- 1.8.27: a manifest-less dependency: request its package
addStep(3000, function() refreshCaches(); CP.probeRequires(2) end)         -- 1.8.27: ... and decide (then the requires lines)
addStep(2000, function() applyRefreshers() end)     -- 1.3.0: manifest refreshers (data registries re-scan the injected registry)
addStep(6000, function() applyFollowups() end)      -- ... then what the game built from them once at startup (character pools)
addStep(1000, function() CP.afterFollowups() end)   -- 1.8.27: the pool-table dtreg census, then the first class-pool roll
addStep(1000, function() CP.CF.start() end)        -- 1.8.48: mod overlay tables into their live composites (DT_StatusFX)
if DIAG then
    local REAL = "/Game/Game/GameData/ItemData/Modifications/Modification_Scope_LongRange_T1.Modification_Scope_LongRange_T1"
    addStep(1000, function() pcall(LoadAsset, REAL) end)
    addStep(5000, function()
        local o = StaticFindObject(REAL)
        if o and o:IsValid() then dumpObject(o, "REAL scope item") else log("real scope item not loaded (yet)") end
        for _, g in ipairs(grants) do
            pcall(LoadAsset, g.item); local pkg = g.item:match("^(.-)%.[^%.]+$"); if pkg then bridge("ZCSDK:loadpkg|" .. pkg) end
        end
    end)
    addStep(5000, function()
        for _, g in ipairs(grants) do
            local o = StaticFindObject(g.item)
            if o and o:IsValid() then dumpObject(o, "MOD item") else log("mod item not loaded: " .. g.item) end
        end
    end)
end
-- 1.8.19 (session_audit.py's own recommendation, CHANGELOG v1.28.32): only say "waiting" when there is something to
-- wait FOR. With no grants declared this banner was a gate that could never pass, and the audit charged it as one —
-- seven sessions' worth of open gates that were all vacuous.
addStep(1000, function()
    if #grants > 0 then
        log("=== ZCSDKLoader ready; waiting for an HQ inventory to apply " .. #grants .. " grant(s) ===")
    else
        log("=== ZCSDKLoader ready; 0 grant(s) declared, so no HQ inventory is needed ===")
    end
end)

-- the ARM check: every 3 s until a real world with a player controller is up (or 40 checks), then the steps start 8 s
-- later. 1.8.26: it now reads the player controller and the world ON THE GAME THREAD (it used to do both from
-- LoopAsync, i.e. UObject reads off-thread).
local ticks, armed = 0, false
addTask("arm", 3.0, function()
    if armed then return true end
    ticks = ticks + 1
    -- 1.8.27: the world through gameWorld() and the player controller through UGameplayStatics::GetPlayerController on
    -- its CDO (a static UFunction, the same call shape as GrantItem on BrunoGameStatics) - no FindAllOf unless that fails.
    local w = gameWorld()
    local pc = nil
    pcall(function() pc = StaticFindObject("/Script/Engine.Default__GameplayStatics"):GetPlayerController(w, 0) end)
    if not pinOk(pc) then local okP, pc2 = pcall(UEHelpers.GetPlayerController); if okP then pc = pc2 end end
    local wname = ""; pcall(function() wname = w:GetFullName() end)
    if type(wname) ~= "string" then wname = "" end
    if (pinOk(pc) and wname ~= "" and not wname:find("PSOLoader")) or ticks >= 40 then
        armed = true; log("armed: world=" .. wname); wake(stepTask, 8.0); return true
    end
    return false
end)
-- GRANTS: every 4 s once the registries are injected, until a pass reports done. 1.8.26: the pass runs in the pump
-- itself, so the 1.8.25 one-closure-in-flight guard (grantQueued / grantQueuedFor) and its 10-tick watchdog are gone:
-- there is no queue left for a closure to wait in, and no stale `done` to read.
-- 1.8.36: a pass that did item work and left some returns its own delay (CP.GR.NEXT_S), so the queue drains a few items a
-- pass over consecutive passes instead of 145 in one frame (the GRANT QUEUE block).
addTask("grants", 4.0, function()
    if not injected then return false end
    local ok, r = pcall(applyGrants)
    if not ok then log("grant loop error: " .. tostring(r)) end
    if ok and r == true then return true end                     -- a pass reported done: stop for good
    if ok and type(r) == "number" then return r end              -- 1.8.36: work remains, the next pass sooner
    return false
end)
-- 1.4.0: recruit pins, for as long as any manifest carries them. 1.7.0: paced — 3 s while it is doing something, backing off to
-- 24 s while it is not, and back to 3 s the moment the world changes or a pin lands. Everything that touches a UObject runs on the
-- game thread (reading the world off-thread through UE4SS's Lua binding is the kind of call that has faulted inside UE4SS before).
-- 1.8.26: the 2.5 s tick and the pinSkip tiers are unchanged; the tick is now a pump task.
-- 1.8.27: the body is CP.pinTick (in the recruit-pin block, so tools/replay_pin.py replays it): a sliced pass returns 0
-- ("again next frame"), `done` goes DORMANT and re-arms (G1). The Recruitment watcher (§1b.2) is its own task.
-- 1.8.28: the task is kept on CP (no new file-scope local: the main chunk sits at Lua's 200-local limit) so a Recruitment
-- hook can make it due on the NEXT frame (CP.wake: one field write; the hook callback itself still only counts).
CP.pinTask = addTask("pin", 2.5, function() return CP.pinTick() end)
CP.wake = function() CP.pinTask.nextAt = 0 end
addTask("recruit", 2.5, function() return CP.watchTick() end)
-- ---- the VAULT saber fix (loader 1.8.2; the diagnosis is CHANGELOG v1.28.4, the arming is the v1.28.6 lesson) ----
-- THE BUG: after a scripted traversal (a mantle / vault) the blade goes out and never comes back, on every saber on
-- 196985 — the game's own and the SDK's alike, so the hilt was never the variable. ZCUnlocked 1.4.1 reads it as the
-- humanoid ABP failing to re-fire OnLightSaberActivate after the landing. This does it from the other end, needing no
-- delegate access: the saber ACTOR already caches the decision.
--
-- VERIFIED OFFLINE before shipping (the thing v1.28.4 did not do — its own note says it "had no offline verification at
-- all"). From the cooked BP_FX_LightSaber_Base.uasset (tools/recon/pkgdump.py + bpclass.py):
--   * Activate  -> exp[13], a real UFunction on BP_FX_LightSaber_Base_C   (so it is callable)
--   * Deactivate-> exp[27], a real UFunction on BP_FX_LightSaber_Base_C   (so it is hookable)
--   * bIsActive, bSaberAutoActivateForCombat -> BoolProperty variables of the class
--   * "Cached Humanoid ABP" -> ObjectProperty typed exactly ABP_BR_Humanoid_Base_C
-- and from the cooked ABP_BR_Humanoid_Base.uasset: SetHasMantled is a real UFunction and HasMantled is in the class's
-- name table. CAVEAT, stated rather than hidden: bpclass.py MISREADS an AnimBlueprintGeneratedClass (it reports
-- ABP_BR_Humanoid_Base_C as "5 functions, 0 variables" — the same silently-wrong shape v1.28.4 hardened it against for
-- the saber), so HasMantled's type and semantics are CORROBORATED, not proven. Hence every read below is pcall'd and a
-- nil/garbage answer means DO NOTHING.
--
-- THE ARMING, which is the part that crashed last time. v1.8.0 retried RegisterHook every 5 s while the class was not
-- loaded and piled bad entries into UE4SS's Lua function registry until the game aborted at the main menu. Here
-- RegisterHook is called AT MOST ONCE: a flag guards it, and it is only reached after StaticFindObject proves the class
-- object is actually loaded (if the class is loaded, so is its Deactivate UFunction export). The loop only ever LOOKS;
-- it never registers speculatively, and it stops for good on the first success. StaticFindObject + LoopAsync +
-- ExecuteInGameThread are all APIs this loader already uses, so nothing unproven is introduced into a runtime that has
-- faulted twice. (1.8.26: the look is now a pump task on the game thread; LoopAsync is gone from the loader.)
local SABER_CLASS = "/Game/Game/FX/Blueprints/Lightsaber/BP_FX_LightSaber_Base.BP_FX_LightSaber_Base_C"
local SABER_FUNC  = "/Game/Game/FX/Blueprints/Lightsaber/BP_FX_LightSaber_Base.BP_FX_LightSaber_Base_C:Deactivate"
local saberHookArmed = false        -- RegisterHook has been called; never call it again, whatever happens next

-- ---- 1.8.3 DIAGNOSTICS: why did nothing happen? ----
-- 2026-09-11 retail: the hook ARMED and the blade still went out on a vault, with no other line in the log. That is
-- five different bugs wearing the same silence, because every guard below is a bare `return`:
--   (1) Deactivate is never called on a vault at all - the blade goes out by some other path
--   (2) bSaberAutoActivateForCombat is false        (3) the Cached Humanoid ABP is not valid
--   (4) HasMantled is false at that instant         (5) relight ran but the blade was already lit
-- The handoff claimed the log distinguished the outcomes; it distinguished armed / re-lit / neither, which is one
-- level too coarse to act on. These lines name the branch. Capped, because Deactivate fires on every legitimate
-- sheath too and an uncapped log would bury the answer - this is a diagnostic, not telemetry.
local vaultDiagN, VAULT_DIAG_MAX = 0, 60
local function vdiag(msg)
    if vaultDiagN >= VAULT_DIAG_MAX then return end
    vaultDiagN = vaultDiagN + 1
    log("vault saber: " .. msg .. (vaultDiagN == VAULT_DIAG_MAX and "   [further diagnostics suppressed]" or ""))
end

-- ---- 1.8.21: THE RELIGHT SWITCH, and the evidence that closed it ----
-- RETAIL 2026-09-14 04:53, loader 1.8.20 deployed, one second into a mission:
--     04:53:30  vault saber: PATH> DeactivateLightsaber
--     04:53:30  vault saber: DeactivateLightsaber: relighting through ActivateSaberCheck (HasMantled=true)
--     04:53:30  vault saber: relight (350ms) -> ActivateSaberCheck(1) [target from Owning Saber Position]
--     04:53:30  main.lua:2011: [Lua::Registry::get_function_ref] Ref was not function
--                   traceback: [C]: in method 'ActivateSaberCheck'
--     04:53:31  vault saber: PATH> ActivateSaberCheck  ... RELIGHT VERIFIED (900ms) - bIsActive=true |
--                   Activated Lightsaber Blade=set | Sheath=0.000
--   and the operator reports EVERY CHARACTER RUNNING IN PLACE at mission start — the insertion sequence never
--   completed. `ActivateSaberCheck` is a function THIS SAME MOD has RegisterHook'd (the log-only `[state]` probe of
--   1.8.6), so calling it from Lua made UE4SS's hook dispatcher fail to find its own Lua callback ref and throw
--   INSIDE the game's call frame. INFERRED: that exception, mid-`ActivateSaberCheck` during the insertion mantle,
--   broke the mission's start sequence. The inference may be imprecise; the two rules it produced are not:
--     (A) NEVER call a UFunction this runtime has hooked.  (B) NEVER drive the saber during the insertion mantle.
-- Hence OFF by default. The handlers keep every read and every diagnostic — they are how the next vault is judged —
-- and schedule nothing. If this is ever flipped true, `armPathProbe` refuses to register the `[state]` hooks on
-- ActivateSaberCheck/DeactivateSaberCheck, so rule (A) cannot be broken by a switch.
local RELIGHT_ENABLED = false
-- the one line a disabled deactivation prints, so a retail log still says what the loader decided and what to grep
-- for next. `which` names the path that reached it (Deactivate vs DeactivateLightsaber).
local function relightDisabledNotice(which)
    log("vault saber: relight DISABLED (1.8.21) [" .. which .. "] — leaving the blade to the game's own " ..
        "ActivateSaberCheck at the next turn; watch for `ActivateSaberCheck state: ... bIsActive=false` followed " ..
        "by `PATH> ActivateLightsaber`")
end

-- one re-light attempt: only if the blade is still out and the wielder is still mid-traversal
-- 1.8.5: calls ActivateLightsaber, NOT Activate. `Activate` is the generic component method and is not on the blade
-- path at all - the 2026-09-12 probe caught `ActivateLightsaber` lighting the blade at mission start while `Activate`
-- fired separately a third of a second earlier. Four versions of this fix called the wrong one.
-- 1.8.6: THE RELIGHT CALL IS WITHDRAWN. 1.8.5 called ActivateLightsaber() with no arguments and UE4SS threw
-- "UFunction expected 4 parameters, received 0" on every vault. I checked that the function EXISTED in the export
-- table and never checked its SIGNATURE - the same mistake this project keeps writing gotchas about, made one step
-- after the probe was built specifically to stop guessing. A Blueprint UFunction's parameters are serialised inside
-- the function export's own data, not as separate exports, so the signature needs real work to read offline; until
-- it IS read, this calls nothing. A throwing hook on a gameplay function is not something to leave deployed.
-- 1.8.7: RELIGHT BY REPLAYING THE EXTINGUISH ARGUMENTS.
-- The signature was finally READ rather than guessed (v1.28.29, tools/recon/bpclass.py against the cooked package):
--     ActivateLightsaber(Lightsaber Blade : StaticMeshComponent,
--                        BladeLight       : PointLightComponent,
--                        WeaponInteractionCollision : BoxComponent,
--                        Target Saber     : Enum_LightsaberStateTarget)
-- and DeactivateLightsaber takes THE IDENTICAL FOUR. That is what makes this safe: the hook is handed exactly the
-- arguments the relight needs, so nothing has to be reconstructed from the actor's variables or guessed - which is
-- what went wrong in 1.8.0-1.8.5 (four versions called the no-arg `Activate`; 1.8.5 called this one with none and
-- UE4SS threw "expected 4 parameters, received 0").
-- The captured values are resolved with :get() INSIDE the hook, because a RemoteUnrealParam wrapper is only valid for
-- the duration of the callback - the UObjects it yields stay valid afterwards, the wrapper does not.
-- 1.8.9 (the 2026-09-12 crash analysis): the three captured COMPONENTS are held across 350 ms and 900 ms of game
-- time, which is long enough for the wielder to be destroyed, the saber to be unequipped, or a level transition to
-- collect them. `args ~= nil` only says the capture happened; it says nothing about whether the objects it points at
-- are still alive. Passing a stale UObject into a UFunction call is a native fault that pcall cannot catch, so each
-- one is re-validated here and the stale one is NAMED - the same rule as GetClass: IsValid first, then use.
--
-- ================================================================================================================
-- 1.8.20: THE REPLAY IS WITHDRAWN. THE RELIGHT GOES THROUGH THE GAME'S OWN `ActivateSaberCheck`, AND `bIsActive`
--         IS NO LONGER ALLOWED TO REPORT SUCCESS.
--
-- WHAT RETAIL 2026-09-13 22:52 SHOWED (log ZCSDKLoader.log):
--   23:17:41  Hawks vaulted, DeactivateLightsaber fired (HasMantled=true, bSaberAutoActivateForCombat=true), the
--             1.8.19 relight replayed the four captured arguments into ActivateLightsaber and logged
--             `re-lit (350ms) - bIsActive now true`.
--   the operator reports THE BLADE WAS NEVER VISIBLE AGAIN for the rest of the mission, and
--   23:21:16  the game's OWN ActivateSaberCheck logged `HasMantled=false bIsActive=true` and DID NOTHING.
-- So 1.8.19 did not fix the blade; it set the flag that stops the game fixing the blade. v1.28.30's "RETAIL
-- CONFIRMED" confirmed the FLAG, never the blade.
--
-- WHY, PROVEN from the cooked class with tools/recon/kismet.py against
-- build/_retail/SWZeroCompany/Content/Game/FX/Blueprints/LightSaber/BP_FX_LightSaber_Base.uasset (re-run it; every
-- offset below is an offset into ExecuteUbergraph_BP_FX_LightSaber_Base, 1389 opcodes, CLEAN):
--   * `ActivateLightsaber` is ubergraph entry 864 (`+864 EX_Jump -> +520`). At `+521` it sets `Self.bIsActive = true`,
--     stores the three components into `Activated Lightsaber Blade` / `Activated Blade Light` / `Activated Weapon
--     Interaction Collision`, `+621 SetCollisionEnabled(5)`, `+659 Timeline_Blade::PlayFromStart`.
--     `DeactivateLightsaber` is entry 869 (`+869 EX_Jump -> +692`), the mirror with `ReverseFromEnd`.
--   * The 4th parameter `Target Saber` lands in the ubergraph locals `K2Node_CustomEvent_Target_Saber_2` / `_3` and
--     is NEVER READ as an operand anywhere in those 1389 opcodes. It is DEAD on both paths — which is why replaying
--     it changed nothing.
--   * The VISIBLE blade is produced ONLY by `Timeline_Blade__UpdateFunc` (entry 4198):
--     `SetScalarParameterValueOnMaterials("Sheath", ...)` on the blade mesh, and the light values via `+3111`.
--     `bIsActive` is read in exactly THREE places — `+1876` (DeactivateSaberCheck), `+2091` (ActivateSaberCheck) and
--     the `IsActive` getter — and drives NO visual state at all.
--   * `ActivateSaberCheck` is entry 1890. After `Trilla Alt Saber Override` (`+1890`, CDO false) it matches
--     `TargetSaber == 2` (`+1979`) OR `TargetSaber == Self.Owning Saber Position` (`+2010..+2048`), bails at `+2076`,
--     and then **`+2086 EX_JumpIfNot Self.bIsActive -> +1904`**, where `+1904` calls
--     `ActivateLightsaber(Self.Lightsaber_Blade, Self.BladeLight, WeaponInteractionCollision, TargetSaber)` from LIVE
--     component reads. If `bIsActive` is ALREADY true it falls into `+2100 EX_PopExecutionFlow` and does nothing.
--     `DeactivateSaberCheck` (entry 1679) mirrors it at `+1875`. Both are bound to the ABP's
--     OnLightSaberActivate / OnLightSaberDeactivate delegates at entry 964.
-- INFERRED, retail-only and stated as such: the blade stayed dark because `PlayFromStart` 350 ms into the mantle
-- montage did not advance the Sheath curve. What is PROVEN is that setting `bIsActive=true` turned the game's own
-- next-turn recovery at `+2086` into a no-op.
--
-- THE SIGNATURE, READ NOT GUESSED (v1.28.29's lesson, and this is the third function in this file to need it).
-- `python tools/recon/kismet.py <the cooked asset> --function ActivateSaberCheck` prints:
--     ### ActivateSaberCheck  (36 code / 48 archive bytes, 8 opcodes) CLEAN
--     #   params/locals: TargetSaber:ByteProperty
--     +0  EX_LetValueOnPersistentFrame ...:K2Node_CustomEvent_TargetSaber ; +18 call ubergraph, +27 EX_IntConst 1890
-- ONE parameter, `TargetSaber : ByteProperty` (Enum_LightsaberStateTarget). Not four. Not zero.
--
-- THE TARGET VALUE. `GetTargetLightsaber` is `State = Self.Owning Saber Position` and nothing else (6 opcodes), and
-- the base CDO's `Owning Saber Position` is 0; the game itself passes literal 1 at mission start (`+88`) and at
-- `+502`. Enum_LightsaberStateTarget (jmap, UserDefinedEnum): NewEnumerator0=0, NewEnumerator1=1, NewEnumerator2=2
-- ("both/any"), Enum_MAX=3. So the saber's OWN position always satisfies the `+2010` equality; the property is read
-- first, `GetTargetLightsaber()` is the fallback, and 2 ("both") is the last resort because `+1979` accepts it
-- unconditionally.
--
-- AND `bIsActive` IS NO LONGER A SUCCESS REPORT. It is the flag the old fix set while the blade stayed dark, so a
-- line saying "bIsActive now true" is exactly the line that misled v1.28.30. The call logs the flag, and then ONE
-- delayed read ~600 ms later reports the actual VISUAL state: `Activated Lightsaber Blade` non-null (the ubergraph
-- writes it at `+521`, so it is the cheapest proof ActivateLightsaber really ran) and, if it can be read at all, the
-- blade material's `Sheath` scalar — which is the single value `Timeline_Blade__UpdateFunc` drives. A relight that
-- flips the flag and leaves the blade dark reads `RELIGHT UNVERIFIED`, never as a success.
-- ================================================================================================================

-- the saber's own target enum, by the three routes in descending order of directness. Reads only, every step pcall'd.
local function saberTarget(saber)
    local v = nil
    pcall(function() v = saber["Owning Saber Position"] end)
    if type(v) == "number" then return v, "Owning Saber Position" end
    pcall(function() v = saber:GetTargetLightsaber() end)
    if type(v) == "number" then return v, "GetTargetLightsaber()" end
    return 2, "the enum's 'both' member (2) — neither the property nor the getter could be read"
end

-- the VISUAL state, read ~600 ms after the call. A FAILED read is reported as `<unreadable: why>` and concludes
-- NOTHING (1.8.16's lesson); only a successful read of a null/!IsValid `Activated Lightsaber Blade` means the blade
-- is not there.
local function bladeState(saber)
    local activated = "<unreadable>"
    local okA, blade = pcall(function() return saber["Activated Lightsaber Blade"] end)
    if not okA then activated = "<unreadable: " .. tostring(blade) .. ">"
    elseif blade == nil then activated = "null"
    elseif uvalid(blade) then activated = "set"
    else activated = "stale" end
    -- the Sheath scalar is what Timeline_Blade__UpdateFunc actually writes. `Blade materials` is an
    -- ArrayProperty<MaterialInstanceDynamic> on the class (recon/bpclass.py), and K2_GetScalarParameterValue is
    -- UMaterialInstanceDynamic's own BlueprintCallable getter — but neither the array accessor nor that call has
    -- ever been exercised from Lua in this runtime, so a failure here is REPORTED, never concluded from.
    local sheath = "<unreadable: not attempted>"
    pcall(function()
        local mats = saber["Blade materials"]
        if mats == nil then sheath = "<unreadable: 'Blade materials' is null>"; return end
        local mid = nil
        pcall(function() mid = mats[1] end)
        if not uvalid(mid) then
            mid = nil
            pcall(function()
                mats:ForEach(function(_, e)
                    if mid == nil then
                        local g = nil
                        pcall(function() g = e:get() end)
                        if uvalid(g) then mid = g end
                    end
                end)
            end)
        end
        if not uvalid(mid) then sheath = "<unreadable: no live MaterialInstanceDynamic in 'Blade materials'>"; return end
        local okS, v = pcall(function() return mid:K2_GetScalarParameterValue(FName("Sheath")) end)
        sheath = (okS and type(v) == "number") and string.format("%.3f", v)
                 or ("<unreadable: K2_GetScalarParameterValue failed: " .. tostring(v) .. ">")
    end)
    return activated, sheath
end

-- one re-light attempt, through the game's own check. 1.8.20: no captured components, so nothing stale can be
-- passed into a UFunction; the only UObject held across the delay is the saber, and it is re-validated here.
local function relight(saber, tag)
    local ok, err = pcall(function()
        if not uvalid(saber) then vdiag("relight (" .. tag .. "): saber no longer valid"); return end
        local target, how = saberTarget(saber)
        -- Announced BEFORE the call, deliberately: the 1.8.4 path probe hooks ActivateSaberCheck too, so the
        -- `vault probe: PATH> ActivateSaberCheck` line that follows this one is OURS, not the game's. Without this
        -- line the log cannot tell the two apart, and telling them apart is the whole retail check.
        log(("vault saber: relight (%s) -> ActivateSaberCheck(%s) [target from %s]"):format(tag, tostring(target), how))
        -- ActivateSaberCheck is SELF-IDEMPOTENT: +2086 makes it a no-op when bIsActive is already true, so the
        -- 350/900 ms pair costs nothing and the "already lit, leaving alone" early-out of 1.8.7 is not needed.
        -- 1.8.21 RULE (A) — DO NOT CALL A UFUNCTION THIS MOD HAS HOOKED. This line is only ever reached with
        -- RELIGHT_ENABLED true, and in that case `armPathProbe` has REFUSED to register the `[state]` hooks on
        -- ActivateSaberCheck/DeactivateSaberCheck. Retail 04:53:30 is what happens when both exist: UE4SS throws
        -- `[Lua::Registry::get_function_ref] Ref was not function` inside the game's own call frame. Anyone adding
        -- a call here must check PROBE_FUNCS first — a hooked callee is a fault, not a slow path.
        saber:ActivateSaberCheck(target)
        after(600, function()   -- 1.8.26: a pump timer, on the game thread (was ExecuteWithDelay + ExecuteInGameThread)
            local ok2, err2 = pcall(function()
                if not uvalid(saber) then
                    log("vault saber: RELIGHT UNVERIFIED (" .. tag .. ") - the saber went away before the check"); return end
                local activated, sheath = bladeState(saber)
                -- VERIFIED requires the VISUAL state, not the flag: `Activated Lightsaber Blade` is written at
                -- ubergraph +521, so it proves ActivateLightsaber really ran — but 1.8.19 got that far and the
                -- blade still stayed dark, so it is not sufficient on its own. A Sheath scalar that can actually
                -- be READ is the second half. The POLARITY of that number is not yet known (nothing offline says
                -- whether an extended blade is Sheath=0 or Sheath=1), so it is PRINTED and not judged: the first
                -- retail vault establishes it by comparing this line with a mission-start relight.
                local lit = (activated == "set") and (tonumber(sheath) ~= nil)
                log(("vault saber: %s (%s) - bIsActive=%s | Activated Lightsaber Blade=%s | Sheath=%s")
                    :format(lit and "RELIGHT VERIFIED" or "RELIGHT UNVERIFIED", tag,
                            tostring(saber.bIsActive), activated, sheath))
            end)
            if not ok2 then log("vault saber: RELIGHT UNVERIFIED (" .. tag .. ") - the check itself failed: " ..
                                tostring(err2)) end
        end, "relight check " .. tag)
    end)
    if not ok then log("vault saber: relight failed (" .. tag .. "): " .. tostring(err)) end
end

-- ---- 1.8.5: THE FIX, on the PROVEN trigger ----
-- Retail 2026-09-12 named the whole sequence. On the first vault: DeactivateLightsaber + DeactivateSaberCheck. On
-- every later vault: DeactivateSaberCheck alone (already out, nothing to do). At the next turn: ActivateSaberCheck
-- fires and DECLINES, then DeactivateSaberCheck again. ActivateLightsaber never runs after mission start, which is
-- exactly why the blade never returns on its own and why waiting for the game to recover was never going to work.
-- The gameplay side is unaffected throughout - the strike still animates, sounds and kills - so this is the blade's
-- visual/lit state alone.
--
-- THE DISCRIMINATOR, and why it is `bSaberAutoActivateForCombat` rather than `HasMantled`:
-- DeactivateLightsaber must also fire on a LEGITIMATE sheath (combat over, a cinematic), and re-lighting there would
-- be a new bug. `bSaberAutoActivateForCombat` is the game's OWN answer to "should this blade be lit for combat right
-- now", so deferring to it means a legitimate sheath is left alone without us having to model when one happens.
-- `HasMantled` was the plan for four versions and has never once been observed true at the moment of the call - so it
-- is LOGGED here, not trusted. If the log shows it reliably true on a vault, a later version can tighten on it.
local function onDeactivateLightsaber(saber)
    local ok, err = pcall(function()
        if not (saber and saber:IsValid()) then vdiag("DeactivateLightsaber: saber not valid"); return end
        -- The discriminator is the game's OWN answer to "should this blade be lit for combat right now". A legitimate
        -- sheath (combat over, a cinematic) clears it, so deferring to it means we never re-light over the game's
        -- intent. Retail 2026-09-12 measured it TRUE on a vault while bIsActive was false - exactly the stuck state.
        if not saber.bSaberAutoActivateForCombat then
            vdiag("DeactivateLightsaber: SKIP, bSaberAutoActivateForCombat=false (a legitimate sheath)"); return end
        local abp = saber["Cached Humanoid ABP"]
        local mantled = "ABP null"
        if abp and abp:IsValid() then mantled = tostring(abp.HasMantled) end
        -- 1.8.20: no `args captured=` any more — the relight replays nothing, so there is nothing to capture.
        vdiag("DeactivateLightsaber: state at the extinguish (HasMantled=" .. mantled .. ")")
        -- 1.8.21: reads and diagnostics above are UNCHANGED; only the scheduling is gated. Nothing is queued here.
        if not RELIGHT_ENABLED then relightDisabledNotice("DeactivateLightsaber"); return end
        vdiag("DeactivateLightsaber: relighting through ActivateSaberCheck (HasMantled=" .. mantled .. ")")
        after(350, function() relight(saber, "350ms") end, "relight 350ms")   -- 1.8.26: a pump timer (game thread)
        after(900, function() relight(saber, "900ms") end, "relight 900ms")
    end)
    if not ok then log("vault saber: DeactivateLightsaber handler error: " .. tostring(err)) end
end

local function onSaberDeactivate(saber)
    local ok, err = pcall(function()
        if not (saber and saber:IsValid()) then vdiag("Deactivate: saber not valid"); return end
        vdiag("PATH> Deactivate")                               -- (1) if this never appears, the blade goes out elsewhere
                                                                -- (1.8.19: was "Deactivate FIRED"; one firing verb now)
        -- should this saber be lit at all? a legitimate sheath (combat over, a cinematic) says no, and is left alone
        if not saber.bSaberAutoActivateForCombat then
            vdiag("  SKIP: bSaberAutoActivateForCombat=false (a legitimate sheath)"); return end
        local abp = saber["Cached Humanoid ABP"]
        if not (abp and abp:IsValid()) then
            vdiag("  SKIP: 'Cached Humanoid ABP' is null/invalid on this saber"); return end
        if not abp.HasMantled then                              -- not a traversal: a real deactivate, leave it alone
            vdiag("  SKIP: HasMantled=false (the discriminator says this is not a traversal)"); return end
        vdiag("  MATCH: HasMantled=true (the traversal shape)")
        -- 1.8.21: every read and every SKIP line above is unchanged; only the scheduling is gated.
        if not RELIGHT_ENABLED then relightDisabledNotice("Deactivate"); return end
        vdiag("  -> scheduling relight at 350ms and 900ms")
        after(350, function() relight(saber, "350ms") end, "relight 350ms")   -- 1.8.26: a pump timer (game thread)
        after(900, function() relight(saber, "900ms") end, "relight 900ms")
    end)
    if not ok then log("vault saber: hook body error: " .. tostring(err)) end
end

-- ---- 1.8.4: THE PATH PROBE. Which function actually extinguishes the blade? ----
-- 2026-09-12 retail, loader 1.8.3: the hook ARMED on `Deactivate` and `Deactivate FIRED` never appeared, so that
-- function is simply not on the vault path. Decoding the cooked class explains why - it exports FIFTY UFunctions
-- including BOTH a generic pair and a saber-specific pair:
--     Activate / Deactivate                 <- what 1.8.0-1.8.3 hooked, and what relight() called
--     ActivateLightsaber / DeactivateLightsaber
--     ActivateSaberCheck / DeactivateSaberCheck
--     Cinematic_Activate / Cinematic_Deactivate
-- The fix has been aimed at the generic pair for four versions. Rather than guess again, this registers a LOG-ONLY
-- hook on every candidate and prints which fires, in order, on a real vault. No relight is attempted here on purpose:
-- a probe that also acts cannot tell you whether it was right.
-- SAFETY: each RegisterHook is still called AT MOST ONCE, from the same one-shot arming path, and only after
-- StaticFindObject proves the class is loaded. The 1.8.0 abort came from RETRYING failed registrations on a timer,
-- not from registering several real ones - so N one-shot hooks carry the same risk as the one 1.8.2 already shipped.
-- NOTE: "Deactivate" is deliberately absent - SABER_FUNC already hooks it and logs "PATH> Deactivate". Registering
-- the same UFunction twice is an unknown, and this probe must not add a new failure mode to a runtime that has
-- already faulted twice.
local PROBE_FUNCS = {
    "DeactivateLightsaber", "DeactivateSaberCheck", "Cinematic_Deactivate",
    "Activate", "ActivateLightsaber", "ActivateSaberCheck", "Cinematic_Activate",
}
local probeArmed = false            -- same discipline as saberHookArmed: RegisterHook is NOT retry-safe
-- 1.8.21 RULE (A): the relight CALLS ActivateSaberCheck, and a UFunction this mod has HOOKED cannot be called from
-- Lua — retail 04:53:30 threw `[Lua::Registry::get_function_ref] Ref was not function` inside the game's own call
-- frame and the mission's insertion sequence never completed. So with the relight ON, the two `[state]` check hooks
-- are NOT registered. With the default (RELIGHT_ENABLED false) nothing is skipped and all 8 hooks arm as in 1.8.20.
local PROBE_SKIP = "vault probe: NOT hooking %s — the relight calls it and UE4SS cannot dispatch a hook from " ..
                   "inside a Lua-initiated call (1.8.21)"
local function armPathProbe(classPath)
    if probeArmed then return end   -- re-entry is impossible, whatever calls this and however often
    probeArmed = true               -- set BEFORE any RegisterHook: even if one throws, never retry
    for _, fn in ipairs(PROBE_FUNCS) do
        local target = classPath .. ":" .. fn
        local isFixTarget = (fn == "DeactivateLightsaber")     -- 1.8.5: the proven extinguish path
        -- 1.8.6: the SABER-CHECK functions are the ones worth watching now. At the start of the next turn the game
        -- runs ActivateSaberCheck and DECLINES to re-light. The hypothesis is that `HasMantled` is never CLEARED
        -- after a scripted traversal, so the check still believes the wielder is mid-vault - which would also
        -- explain why it was true when DeactivateLightsaber fired. Log the state at every check and find out.
        local isCheck = (fn == "ActivateSaberCheck" or fn == "DeactivateSaberCheck")
        if isCheck and RELIGHT_ENABLED then log(PROBE_SKIP:format(fn)); goto continue end   -- 1.8.21 rule (A), above
        local ok, err = pcall(RegisterHook, target, function(ctx)
            raceNote("hook")                    -- 1.8.26 RACEPROBE (one boolean test while it is OFF)
            vdiag("PATH> " .. fn)
            if isFixTarget or isCheck then
                local ok2, s = pcall(function() return ctx:get() end)
                if ok2 and isFixTarget then
                    -- 1.8.20: the four DeactivateLightsaber parameters are NOT captured any more. The relight calls
                    -- ActivateSaberCheck(TargetSaber), which reads Self.Lightsaber_Blade / Self.BladeLight /
                    -- WeaponInteractionCollision LIVE at ubergraph +1904 — so there is nothing to hold across the
                    -- 350/900 ms wait, and with it goes the whole stale-component failure mode of 1.8.7-1.8.19.
                    onDeactivateLightsaber(s)
                end
                if ok2 and isCheck then
                    local ok3, err3 = pcall(function()
                        if not (s and s:IsValid()) then return end
                        local abp = s["Cached Humanoid ABP"]
                        local m = (abp and abp:IsValid()) and tostring(abp.HasMantled) or "ABP null"
                        vdiag(("   %s state: HasMantled=%s bIsActive=%s autoCombat=%s"):format(
                            fn, m, tostring(s.bIsActive), tostring(s.bSaberAutoActivateForCombat)))
                    end)
                    if not ok3 then vdiag("   " .. fn .. " state read failed: " .. tostring(err3)) end
                end
            end
        end)
        -- 1.8.19 VOCABULARY: one arming verb for the whole runtime — `hook armed on <class>:<fn>` — so session_audit
        -- reads the probe's hooks exactly as it reads the fix's, and the FAILURE line names the function too.
        if ok then log("vault probe: hook armed on " .. target .. (isFixTarget and "  [handler]" or (isCheck and "  [state]" or "")))
        else log("vault probe: could NOT hook " .. target .. " (" .. tostring(err) .. ")") end
        ::continue::
    end
end

-- LOOK for the class; register exactly once when it is really there. Deliberately NOT a per-frame hook:
-- ABP_BR_Humanoid_Base_C:SetHasMantled is the obvious trigger but is driven by the anim graph, and putting Lua on the
-- frame path is exactly what this runtime must not do after the 2026-09-09/10 UE4SS Lua faults. One hook covers every
-- saber: each saber Blueprint is a data-only child of BP_FX_LightSaber_Base_C, so the base's UFunction is shared.
--
-- 1.8.23: RESIDENT IS NOT ENOUGH — WAIT FOR A MISSION, AND LET IT SETTLE. Two EXCEPTION_ACCESS_VIOLATIONs inside
-- UE4SS (2026-09-13 22:51:55 and 2026-09-15 08:58:38.9) landed at exactly this point: the class went resident during
-- the HUB's spawn wave, the loop began RegisterHooking, and the process died with UE4SS-only top frames. So the gate
-- is now three-part — a MISSION world (the TurnProbe's `/Maps/Skirmish/` marker, which `HUB_Root` and `MainMenu`
-- never match), the class resident, and SABER_HOOK_SETTLE seconds since that mission world was FIRST seen. Still
-- exactly one registration per process: `saberHookArmed` is the same one-shot guard and a failed RegisterHook is
-- still never retried.
local SABER_MISSION_MARK  = "/Maps/Skirmish/"   -- the mission test the TurnProbe uses (TurnProbe main.lua MISSION_MARK)
local SABER_HOOK_SETTLE   = 8                   -- seconds a mission world must have been up before any RegisterHook
local saberMissionWorld   = nil                 -- the mission world currently being waited on
local saberMissionSeenAt  = nil                 -- os.time() it was first seen
local saberDeferNoticed   = false               -- the "deferred to a mission world" line is logged once per process
-- 1.8.26: a PUMP task (5 s, unchanged), so the class look-up, the world read and the RegisterHook calls below all run
-- on the GAME thread. Until 1.8.25 this body ran on UE4SS's async thread (StaticFindObject every 5 s, and
-- pinWorldName() for the rest of the hub session once the class was resident) — the busiest async Lua in the loader
-- at exactly the moment of the Den crashes. The 1.8.23 mission gate, the settle and the one-shot guard are unchanged.
addTask("saber", 5.0, function()
    if saberHookArmed then return true end                      -- stop the loop for good
    local cls = StaticFindObject(SABER_CLASS)
    if not pinOk(cls) then return false end                     -- not loaded yet: LOOK again, register nothing
    local wname = pinWorldName()
    if not wname:find(SABER_MISSION_MARK, 1, true) then         -- the hub / the menu: LOOK again, register nothing
        if not saberDeferNoticed then
            saberDeferNoticed = true
            log("vault saber: arming deferred to a mission world (1.8.23) — the hub's spawn wave crashed UE4SS " ..
                "twice during RegisterHook")
        end
        saberMissionWorld, saberMissionSeenAt = nil, nil        -- the clock only ever runs in a mission world
        return false
    end
    if saberMissionWorld ~= wname then                          -- first sight of THIS mission world: start the clock
        saberMissionWorld, saberMissionSeenAt = wname, os.time()
        log(("vault saber: mission world seen at %s; arming in %d s"):format(os.date("%H:%M:%S"), SABER_HOOK_SETTLE))
        return false
    end
    if os.difftime(os.time(), saberMissionSeenAt) < SABER_HOOK_SETTLE then return false end   -- the burst is not over
    saberHookArmed = true                                       -- set BEFORE the call: even if it throws, never retry
    local ok, err = pcall(RegisterHook, SABER_FUNC, function(ctx)
        raceNote("hook")                        -- 1.8.26 RACEPROBE (one boolean test while it is OFF)
        local ok2, s = pcall(function() return ctx:get() end)
        if ok2 then onSaberDeactivate(s) end
    end)
    if ok then log("vault saber: hook armed on " .. SABER_FUNC)
    else log("vault saber: RegisterHook FAILED on " .. SABER_FUNC .. " (not retrying, by design): " .. tostring(err)) end
    armPathProbe(SABER_CLASS)           -- 1.8.4: log-only, tells us which function is really on the vault path
    return true
end)

-- ---- 1.8.29: ROWFIX (begin; tools/replay_pump.py extracts this block verbatim) ----
-- ---- 1.8.24: THE ARMOURY MODEL LIST'S BLANK ROWS (a latent game bug that a long weapon list exposes) ----
-- THE BUG (decoded from the retail paks, BF2BlasterPack notes/U_blank_tiles.md): the weapon MODEL list is
-- WBP_Customization_BoxList.PartList, a virtualised BitReactorListView of WBP_Customization_WeaponBox entries. The entry's
-- Construct and PreConstruct play its BuildOn animation at label "Off", which keys the entry's root panel (Overlay_0) to
-- RenderOpacity 0. Only the entry's own PlayBuildOn(Delay) plays "On" (opacity 1), and only BoxList.BuildOnTiles calls it:
-- once per page build, over PartList.GetDisplayedEntryWidgets() at that moment. A row the list generates LATER (scrolled
-- into view; the list shows about 7 rows) gets a fresh entry, or a pooled one that was itself fresh, and stays at opacity 0:
-- drawn as nothing, but still Visible, so it takes clicks. Hover and selection play "States" (colours), never BuildOn.
-- Stock weapon lists hold at most about 6 player-facing parts, so they never scroll and never hit this. A mod that adds
-- weapons makes the list scroll, and then stock rows and the mod's rows alike can go blank.
-- THE FIX: find every stuck entry (CONTENT - Overlay_0 - opacity < 0.05, the entry NOT Hidden - PlayBuildOn hides it for its delay - and
-- BuildOn not playing) and call the entry's OWN PlayBuildOn(0). If UE4SS cannot make that call, fall back to setting the
-- content's RenderOpacity to 1. A row must be seen stuck on two passes in a row (>= 1 s), and nothing is touched while any
-- entry of the same list is mid-cascade (Hidden), so the game's own build-on is never raced. In a list the game builds
-- correctly (every stock list) no entry is ever stuck, so this never fires there.
-- COST / SAFETY (the 1.7.0 and 1.8.x lessons): no RegisterHook and no NotifyOnNewObject; FindAllOf only, plus two UFunction
-- calls on widgets the SAME pass just found. All UObject access happens on the game thread (a pump task), every call pcall'd.
--
-- 1.8.29: THE ROWFIX STUTTER (support 2026-09-30: loader 1.8.26 + ZC Ultimate Blaster pack 1.0.0 + ZCUnlocked 1.4.72, game
-- 197649; ue4ss_stutter_log.log). After `ROWFIX armed (mode entry)` the hub logged `pump: task rowfix took 60-73 ms in one
-- frame` every 5.08 s for as long as the player stayed there, and never one `ROWFIX healed` line. The cause, in 1.8.24-1.8.28:
-- every pass in the hub began with `StaticFindObject(<the WeaponBox class>)` - in this UE4SS build a walk of the whole object
-- array, 50-90 ms in the hub (see THE FRAME-BOUNDED PASS) - and when the class was not resident (the page closed, or never
-- opened) the pass set rowSkip = 4, so it paid that walk again every fifth second, forever; while rows existed it paid the
-- walk AND a FindAllOf every second. None of it was needed with ZCUnlocked, whose `vm-blank` / `listfix` heal the same rows.
-- 1.8.29, four rules:
--   (a) NO CLASS LOOKUP, NO RE-FIND WITHIN A PASS. The class probe is gone: FindAllOf(<the row class>) answers "is the page
--       open" and "which rows" in ONE walk (no instance = not open; the class need not be looked up to know that). No widget is
--       cached ACROSS passes - UE4SS's IsValid() only tests the wrapped pointer for NULL (FocusProbe v1.28.34 disassembly,
--       UE4SS+0x2ad930), so a cached row the list destroyed and GC'd would read "valid" and PlayBuildOn would run on freed
--       memory (the X1 rule). What IS cached across passes is facts: the stuck keys, the busy lists, the counters.
--   (b) BACK OFF. While no row exists in the hub the probe backs off RF.PROBE_S (5 -> 10 -> 20 -> 30 s, reset on each hub
--       entry). On the page, after RF.CLEAN_PASSES (3) clean passes in a row (nothing stuck, nothing mid-cascade, 0 heals) the
--       1 s pass backs off to RF.ON_PAGE_S (2 -> 4 -> 8 s): each of those checks is the page-close detector and the scroll
--       detector at once, and a stuck or animating row brings the 1 s pass back. A probe that finds no row = the page closed:
--       DISARMED, and the probe schedule starts again. Leaving the hub disarms; the task then reads only the cheap world name.
--   (c) ZCUNLOCKED FIRST. If ZCUnlocked is installed and enabled (ue4ss/Mods/ZCUnlocked/dlls/main.dll, and mods.txt
--       `ZCUnlocked : 1` or its enabled.txt) and its blank-row healers are on (ZCUnlocked.log: `vm-blank: InitializeViewModel
--       detour armed` or its polling backstop, `listfix: armed`; with no log yet, both are on by default), ROWFIX makes NO
--       object lookup at all this session and says why ONCE. Only file reads, once, at the first hub pass. The player's
--       switch, ue4ss/Mods/ZCSDKLoader/settings.ini `[ROWFIX] Enabled = auto | on | off` (no file = auto): `on` runs both,
--       `off` runs neither. Without ZCUnlocked (or with both of its healers off) ROWFIX heals exactly as 1.8.24 did.
--   (d) ONE LOOKUP PER PASS. A pass makes at most ONE object lookup in "entry" mode (the row FindAllOf; "list" mode adds its
--       ListView FindAllOf = 2, PS.LOOKUPS), never a StaticFindObject; RF.maxLook records the worst pass. One log line per
--       arm, per back-off and per disarm (resumes capped at RF.RESUME_LOG_CAP), never one per pass.
local ROWFIX = true                 -- kill switch
-- WHICH repair, set from the round-6 experiment (BF2BlasterPack notes/U_blank_tiles.md section 9):
--   "entry" = Ctrl+F9 filled the blank slots (entries whose CONTENT sits at BuildOn "Off"): re-show stuck entries;
--   "list"  = Ctrl+F8 closed them (the list's layout / scroll state is off): after the MODEL list settles on a new
--             selection or item count, RequestRefresh() it, then BP_ScrollItemIntoView(selected) - what the list's own
--             PartViewModels handler does at build, re-done once the entries have their real size.
local ROWFIX_MODE = "entry"
-- 1.8.29: all ROWFIX state in ONE table (the main chunk sits at Lua's 200-local limit; 1.8.28 spent 13 locals here)
local RF = {
    LOG_CAP        = 500,       -- "ROWFIX healed <name> via PlayBuildOn|opacity" lines per session
    ROW_CLASS      = "WBP_Customization_WeaponBox_C",   -- the Armoury weapon page's row (FindAllOf short name)
    CLEAN_PASSES   = 3,         -- (b) clean passes in a row on the page before the 1 s pass backs off
    ON_PAGE_S      = { 2, 4, 8 },          -- (b) backed-off checks while rows exist (the last value repeats)
    PROBE_S        = { 5, 10, 20, 30 },    -- (b) probes in the hub while no row exists (reset on each hub entry)
    OFF_HUB_S      = 4,         -- away from the hub: the cheap world read only
    RESUME_LOG_CAP = 10,        -- "ROWFIX resumed" lines per session
    INI            = "Mods/ZCSDKLoader/settings.ini",   -- (c) [ROWFIX] Enabled = auto | on (run beside ZCUnlocked) | off
    -- state
    state = "off",              -- off (not the hub) | wait (hub, no rows) | active (1 s) | backoff | skip (ZCUnlocked)
    world = nil, probeN = 0, clean = 0, backN = 0, zcu = nil, waitLogged = false,
    stuck = {}, busy = {}, healed = 0, visitHeals = 0, visitPasses = 0, resumes = 0,
    passes = 0, look = 0, maxLook = 0, lookups = 0, arms = 0, disarms = 0,
    list = { sig = {}, pending = {} },
}
-- 1.8.26: one GUARDED IsValid (it was `o.IsValid ~= nil and o:IsValid()`, unguarded, on the loader's second-hottest path)
local function rowValid(o)
    if o == nil then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return (ok and v) and true or false
end
-- the CONTENT root. WeaponBox is a CommonButtonBase (via WBP_BrunoListButtonBase), whose WidgetTree.RootWidget is the
-- runtime wrapper "InternalRootButtonBase"; BuildOn fades the designer root Overlay_0 inside it (round 5b measured the
-- wrapper by mistake). Overlay_0 is a BP variable; else the wrapper's GetContent().
local function rowRoot(w)
    local c = nil; pcall(function() c = w.Overlay_0 end)
    if rowValid(c) then return c end
    local r = nil; pcall(function() r = w.WidgetTree.RootWidget end)
    if rowValid(r) then pcall(function() c = r:GetContent() end) end
    return rowValid(c) and c or nil
end
local function rowState(w)          -- -> "stuck" | "building" | "ok" | "?" (+ root)
    local r = rowRoot(w); if not r then return "?", nil end
    local vis = -1; pcall(function() vis = w:GetVisibility() end)
    if vis == 2 then return "building", r end                     -- ESlateVisibility::Hidden = inside PlayBuildOn's delay
    local playing = false; pcall(function() playing = w:IsAnimationPlaying(w.BuildOn) end)
    if playing then return "building", r end
    local op = 1; pcall(function() op = r:GetRenderOpacity() end)
    return (op < 0.05) and "stuck" or "ok", r
end
local function rowOwner(w)          -- the entry's outer is the BoxList's WidgetTree; ITS outer is the BoxList
    local o = nil; pcall(function() o = w:GetOuter():GetOuter() end)
    return rowValid(o) and o or nil
end
-- (d) the ONE counted object lookup of a pass. -> the live rows of THIS pass (never kept past it)
function RF.find(cls)
    RF.look, RF.lookups = RF.look + 1, RF.lookups + 1
    local ok, list = pcall(FindAllOf, cls)
    return (ok and type(list) == "table") and list or {}
end
function RF.scan()
    local rows = {}
    for _, w in ipairs(RF.find(RF.ROW_CLASS)) do
        if rowValid(w) then
            local n = ""; pcall(function() n = w:GetFullName() end)
            if type(n) == "string" and not n:find("Default__", 1, true) then rows[#rows + 1] = w end
        end
    end
    return rows
end
-- one "entry" pass over THIS pass's rows. -> true when there is work (a row stuck or mid-cascade, or a heal this pass)
local function rowPass(rows)
    local work = false
    -- group by owning list; a list with any entry mid-cascade is left alone this pass
    local byOwner, busy = {}, {}
    for _, w in ipairs(rows) do
        local o = rowOwner(w); local okey = "?"
        if o then pcall(function() okey = o:GetFullName() or "?" end) end
        local st, r = rowState(w)
        if st == "building" then busy[okey] = true end
        byOwner[okey] = byOwner[okey] or {}
        table.insert(byOwner[okey], { w = w, st = st, r = r })
    end
    -- a list counts as mid-cascade for at most 5 passes (an entry left Hidden for good must not block the fix forever)
    -- (a list mid-cascade is work - the 1 s pass waits it out - but only for those 5 passes, so a row Hidden for good
    -- cannot hold the pass at 1 s either)
    for okey in pairs(byOwner) do
        RF.busy[okey] = busy[okey] and ((RF.busy[okey] or 0) + 1) or nil
        if busy[okey] and RF.busy[okey] <= 5 then work = true end
    end
    local seen = {}
    for okey, list in pairs(byOwner) do
        if not (busy[okey] and RF.busy[okey] <= 5) then
            for _, e in ipairs(list) do
                if e.st == "stuck" then
                    work = true
                    local key = ""; pcall(function() key = e.w:GetFullName() end)
                    seen[key] = (RF.stuck[key] or 0) + 1
                    if seen[key] >= 2 then
                        seen[key] = nil
                        local how = "PlayBuildOn"
                        if not pcall(function() e.w:PlayBuildOn(0.0) end) then
                            how = pcall(function() e.r:SetRenderOpacity(1.0) end) and "opacity" or "FAILED (PlayBuildOn and opacity both raised)"
                        end
                        RF.healed, RF.visitHeals = RF.healed + 1, RF.visitHeals + 1
                        -- one line per healed row (the retail proof); capped so a pathological session cannot flood the log
                        if RF.healed <= RF.LOG_CAP then
                            local nm = "?"; pcall(function() nm = e.w.ModelText:GetText():ToString() end)
                            log("ROWFIX healed " .. tostring(nm) .. " via " .. how)
                        elseif RF.healed == RF.LOG_CAP + 1 then
                            log("ROWFIX: " .. RF.LOG_CAP .. " rows healed this session; further heals are not logged")
                        end
                    end
                end
            end
        end
    end
    RF.stuck = seen
    return work
end
-- "list" mode: per weapon MODEL list (a BitReactorListView under a ...ModelSlot... path) longer than the ~7 visible rows,
-- watch (item count, selected index); when it changes, wait 2 passes for the list to generate and size its rows, then
-- RequestRefresh() and, on the next pass, BP_ScrollItemIntoView(selected). Stock lists (<= 7 items) are never touched.
-- 1.8.29: the lists are found in the pass that uses them (1.8.24 kept them for 3 ticks - the X1 rule), the second lookup.
local function listPass()
    local work, L = false, RF.list
    for _, v in ipairs(RF.find("BitReactorListView")) do
        local key = ""; pcall(function() key = v:GetFullName() end)
        if rowValid(v) and type(key) == "string" and key:find("%.ModelSlot%.") then
            local n, sel, selIdx = 0, nil, -1
            pcall(function() n = v:GetNumItems() end)
            pcall(function() sel = v:BP_GetSelectedItem() end)
            if rowValid(sel) then pcall(function() selIdx = v:GetIndexForItem(sel) end) end
            if n > 7 then
                local sig = n .. "#" .. selIdx
                if L.sig[key] ~= sig then L.sig[key] = sig; L.pending[key] = 2 end
                local p = L.pending[key]
                if p then
                    work = true
                    if p > 1 then L.pending[key] = p - 1
                    elseif p == 1 then
                        pcall(function() v:RequestRefresh() end); L.pending[key] = 0
                    else
                        if rowValid(sel) then pcall(function() v:BP_ScrollItemIntoView(sel) end) end
                        L.pending[key] = nil; RF.healed, RF.visitHeals = RF.healed + 1, RF.visitHeals + 1
                        if RF.healed <= RF.LOG_CAP then log("ROWFIX re-laid-out a " .. n .. "-item MODEL list (selected index " .. selIdx .. ")") end
                    end
                end
            end
        end
    end
    return work
end
-- (c) is ZCUnlocked installed, enabled and healing these rows itself? File reads only (no UObject), once a session.
-- -> a reason string (skip ROWFIX) | nil (run ROWFIX), plus a note for the log
function RF.read(path, max)
    local f = io.open(path, "rb"); if not f then return nil end
    local s = f:read(max or 262144); f:close()
    return s or ""
end
-- the value of `key` in an ini text (in [section] when given, else in any section); nil when absent. ';' / '#' comments.
function RF.iniGet(text, section, key)
    local sec = ""
    local found = nil
    for raw in ((text or "") .. "\n"):gmatch("([^\r\n]*)\r?\n") do
        local line = raw:gsub("^\239\187\191", ""):gsub("%s*[;#].*$", ""):match("^%s*(.-)%s*$") or ""
        local s = line:match("^%[%s*(.-)%s*%]$")
        if s then sec = s:lower()
        elseif section == nil or sec == section:lower() then
            local k, v = line:match("^([^=]-)%s*=%s*(.*)$")
            if k and k:lower() == key:lower() then found = v end
        end
    end
    return found
end
function RF.zcuCheck()
    local dir = UE4SS .. "Mods/ZCUnlocked/"
    if not RF.read(dir .. "dlls/main.dll", 2) then return nil, "ZCUnlocked is not installed" end
    local how = nil
    local mt = RF.iniGet((RF.read(UE4SS .. "Mods/mods.txt") or ""):gsub("(%w+)%s*:%s*(%d)", "%1=%2"), nil, "ZCUnlocked")
    if mt == "1" then how = "mods.txt" end
    if not how and RF.read(dir .. "enabled.txt", 1) then how = "enabled.txt" end
    if not how then return nil, "ZCUnlocked is installed but not enabled (no `ZCUnlocked : 1` in mods.txt, no enabled.txt)" end
    -- 1.8.53: THIS session's part of the appended log (CP.zcuSession; the head of the file is weeks old, retail 2026-11-10)
    local zst, lg = CP.zcuSession()
    if zst == "refused" then
        return nil, "ZCUnlocked is installed and enabled (ue4ss/Mods/ZCUnlocked via " .. how ..
            ") but refused this game build (its log: `refused: unsupported game build`) - its healers are not armed this session"
    end
    local ini = RF.read(dir .. "dlls/settings.ini") or ""
    local lfIni, vbIni = RF.iniGet(ini, nil, "listfix"), RF.iniGet(ini, nil, "vm_blank_refresh") or RF.iniGet(ini, nil, "vm-blank-refresh")
    local vm, lf = nil, nil
    if lg then                                     -- this launch's own account (ZCUnlocked starts before any Lua mod)
        vm = (lg:find("vm-blank: InitializeViewModel detour armed", 1, true) and "vm-blank armed")
          or (lg:find("vm-blank: InitializeViewModel detour FAILED", 1, true) and "vm-blank polling backstop") or nil
        local lfOff = lfIni == "0" or lg:find("listfix: off by ini", 1, true) or lg:find("listfix: quiet for the session", 1, true)
            or lg:find("listfix: the Blueprint-aware object walk is unavailable", 1, true)
        if not lfOff then lf = lg:find("listfix: armed", 1, true) and "listfix armed" or "listfix on (the default)" end
    else                                           -- no log yet: its ini, both on by default
        if vbIni ~= "0" then vm = "vm-blank (on by default; no ZCUnlocked.log yet)" end
        if lfIni ~= "0" then lf = "listfix (on by default)" end
    end
    local src = "ue4ss/Mods/ZCUnlocked via " .. how
    if not vm and not lf then
        return nil, "ZCUnlocked is installed (" .. src .. ") but its blank-row healers are off (no vm-blank line in its log, listfix off)"
    end
    local heals = (vm and lf) and (vm .. ", " .. lf) or (vm or lf)
    return "ZCUnlocked is installed and enabled (" .. src .. ") and heals the Armoury rows itself (" .. heals ..
        ") - no object lookup from ROWFIX this session ([ROWFIX] Enabled=on in ZCSDKLoader/settings.ini runs both)", nil
end
-- the player's switch: ue4ss/Mods/ZCSDKLoader/settings.ini  [ROWFIX] Enabled = auto (default) | on | off
function RF.mode()
    local v = (RF.iniGet(RF.read(UE4SS .. RF.INI) or "", "ROWFIX", "Enabled") or "auto"):lower()
    if v == "off" or v == "0" or v == "false" then return "off" end
    if v == "on" or v == "1" or v == "true" then return "on" end
    if v ~= "auto" then log("ROWFIX: settings.ini [ROWFIX] Enabled=" .. v .. " is not auto|on|off; auto is used") end
    return "auto"
end
function RF.disarm(why)
    if RF.state == "active" or RF.state == "backoff" then
        RF.disarms = RF.disarms + 1
        log(("ROWFIX disarmed: %s (%d heal(s), %d pass(es) this visit)"):format(why, RF.visitHeals, RF.visitPasses))
    end
    RF.stuck, RF.busy, RF.list = {}, {}, { sig = {}, pending = {} }
    RF.clean, RF.backN = 0, 0
end
-- the pass (a pump task). Returns the seconds until the next pass (LoopAsync-style `number`), or true = stopped for good.
function RF.task()
    if not ROWFIX then return true end
    RF.look = 0
    local hub, wname = strategySide()
    if not hub then                                               -- (b) mode exit: the cheap world read only
        if RF.state ~= "off" then RF.disarm("left the hub"); RF.state = "off"; RF.world = nil end
        return RF.OFF_HUB_S
    end
    if RF.zcu == nil then                                         -- (c) once a session, at the first hub pass
        local mode = RF.mode()
        if mode == "off" then
            RF.zcu, RF.state = "off", "skip"
            log("ROWFIX OFF for the session: ZCSDKLoader/settings.ini [ROWFIX] Enabled=off")
            return true
        end
        local skip, note = RF.zcuCheck()
        RF.zcu = skip or false
        if skip and mode == "auto" then
            RF.state = "skip"
            log("ROWFIX skipped: " .. skip)
            return true
        end
        log("ROWFIX: " .. (skip and ("runs beside ZCUnlocked (settings.ini [ROWFIX] Enabled=on): " .. skip) or (note or "no ZCUnlocked")))
    end
    if RF.world ~= wname then                                     -- (b) (re-)entered the hub: a fresh probe schedule
        RF.disarm("world change"); RF.world, RF.state, RF.probeN = wname, "wait", 0
    end
    RF.passes = RF.passes + 1
    local rows = RF.scan()                                        -- (a)(d) the ONE lookup: page open? which rows?
    local nxt
    if #rows == 0 then
        if RF.state == "active" or RF.state == "backoff" then RF.disarm("the Armoury weapon page closed (no rows)") end
        if not RF.waitLogged then
            RF.waitLogged = true
            log(("ROWFIX waiting: no Armoury weapon row in the hub; one row lookup every %d-%d s until the page opens")
                :format(RF.PROBE_S[1], RF.PROBE_S[#RF.PROBE_S]))
        end
        RF.state = "wait"
        RF.probeN = RF.probeN + 1
        nxt = RF.PROBE_S[math.min(RF.probeN, #RF.PROBE_S)]
    else
        if RF.state == "wait" then
            RF.state, RF.clean, RF.backN, RF.visitHeals, RF.visitPasses = "active", 0, 0, 0, 0
            RF.arms = RF.arms + 1
            log(("ROWFIX armed (mode %s): %d Armoury weapon row(s) on screen; 1 s passes until %d clean pass(es) in a row")
                :format(ROWFIX_MODE, #rows, RF.CLEAN_PASSES))
        end
        RF.visitPasses = RF.visitPasses + 1
        local work = rowPass(rows)
        if ROWFIX_MODE == "list" then work = listPass() or work end
        if work then
            if RF.state == "backoff" then
                RF.resumes = RF.resumes + 1
                if RF.resumes <= RF.RESUME_LOG_CAP then log("ROWFIX resumed 1 s passes: a row is stuck or mid build-on") end
            end
            RF.state, RF.clean, RF.backN = "active", 0, 0
            nxt = 1.0
        else
            RF.clean = RF.clean + 1
            if RF.state == "active" and RF.clean >= RF.CLEAN_PASSES then
                RF.state, RF.backN = "backoff", 0
                log(("ROWFIX backed off: %d clean pass(es) in a row, %d heal(s) this visit; checking every %d-%d s while the page is open")
                    :format(RF.clean, RF.visitHeals, RF.ON_PAGE_S[1], RF.ON_PAGE_S[#RF.ON_PAGE_S]))
            end
            if RF.state == "backoff" then
                RF.backN = RF.backN + 1
                nxt = RF.ON_PAGE_S[math.min(RF.backN, #RF.ON_PAGE_S)]
            else
                nxt = 1.0
            end
        end
    end
    if RF.look > RF.maxLook then RF.maxLook = RF.look end
    return nxt
end
-- 1.8.25 HARDENING kept ONE ROWFIX closure in UE4SS's game-thread queue at a time; 1.8.26 made the tick a PUMP task on the
-- game thread. 1.8.29: the task returns its own next delay (1 s working, RF.ON_PAGE_S backed off, RF.PROBE_S waiting,
-- RF.OFF_HUB_S off the hub); `true` (ZCUnlocked heals, or the kill switch) stops it for the session.
RF.taskRef = addTask("rowfix", 1.0, function()
    local ok, r = pcall(RF.task)
    if not ok then log("ROWFIX error (the loop keeps running): " .. tostring(r)); return 5 end
    return r
end)
-- ---- 1.8.29: ROWFIX (end) ----

-- ---- 2026-10-10: SABERLOOK (begin; tools/replay_saberlook.py extracts this block verbatim) ----
-- THE BLADE APPLIER (SDK weapons[].customization, stage B0; docs/recon/SABER_BLADE_LOOK.md Q5 route (c), kept thin).
-- WHAT. A saber of a mod with a `sabers = { ... }` manifest block has its own CustomizationDefinition (a crystal slot and a
-- blade-shade slot per blade). The native tag gate decides which shades LIST; nothing native paints the blade: its colour is
-- the actor's BladeOuterColor / BladeInnerColor (written into the blade's two dynamic MIs by the construction script) and its
-- light, and opacity / glow / chaos are scalars on those MIs (M_FX_Lightsaber_01_Body, M_FX_LightSaber_01_CrossPlane). So a
-- pass reads each saber actor's equipped crystal + shade part ids from its own CustomizationInstance (FragmentInstances: the
-- top-level slot instances, read by property - no lookup per slot) and writes:
--   * colour (unless ZC Unlocked owns it, below): BladeOuterColor / BladeInnerColor / "Blade Light Color" on the actor, the
--     OuterColor / InnerColor vectors on its "Blade materials" MIDs, the BladeLight's colour;
--   * opacity: the shade's own k -> Body Opacity 0.45 k, CrossPlane Opacity 1.0 k (the stock defaults; the BP never writes them);
--   * the crystal's look scalars (Inner/Outer Glow Strength, Alpha Fresnel Exp, Blade Noise Amount, Chaos Frequency,
--     Disturbance Strength) and its hum (LightsaberSound.PlayIdleAudioEvent; from the next ignite).
-- A DUAL's left blade actor (blades[], listed per primary class) takes the LEFT crystal / shade slots of its PRIMARY's
-- instance (every slot sits on the primary's CD: the equip reads only the primary weapon); a "mirror" blade (a staff's second
-- blade) takes the right one's. The two are paired by owner (the character both gear items hang on), then the attach parent,
-- and last (probe 2, P2-3: neither) by the nearest self-keyed saber of ours / spawn order (SL.pairSelfKeyed).
-- A shade that is not one the equipped crystal unlocks (UnequipInvalidParts may be off on weapons), or the neutral
-- "Crystal Color" default, resolves to the crystal's default shade.
-- HOW CHEAP (rewritten after the B0 probe, 2026-10-10: `task saberlook took 60-100 ms` every pass, 299-342 ms while NO saber
-- existed). A pump task, no hook, no UObject kept across passes (UE4SS IsValid() only tests the pointer: ROWFIX 1.8.29 (a)).
-- What costs is the LOOKUP: one FindAllOf (or StaticFindObject - not a hash lookup in this UE4SS build, 1.8.28) walks the
-- whole object array, 50-90 ms in the hub; nothing else here costs a millisecond. So:
--   * a SCAN is exactly ONE walk (FindAllOf of the saber base class; it matches subclasses, TurnProbe 2026-09-14 and the B0
--     probe's two sessions). The per-manifest-class fallback walks run at most ONCE per world and only until the base walk
--     has answered once in the session (B0 session 2's 300 ms passes were that fallback, every pass, while no saber existed);
--     probe 2 (241 ms at world start): never on a world's first scan, ONE class per scan after it;
--   * a scan does at most WALK_CAP (2) object-array walks (its walk + one discovery class OR one hum StaticFindObject) and
--     APPLY_CAP applies; an apply over the cap waits for the next scan (ACTIVE_S) (probe 2: 117-123 ms on a 2-apply scan);
--   * between scans the task only POLLS (POLL_S): the cheap world name and the pin census signature - no lookup at all;
--   * a scan is due on a new world (FIRST_S 6 s after entry, past the load hitch; then SETTLE_S 2, 4, 8 s, the spawn wave), 3 s after a scan that applied
--     something, on a pin-census change (CP.cSig: a character / weapon instance came or went), and otherwise on a backoff:
--     5 -> 10 -> 20 -> 40 -> 60 s while a saber of ours exists (settings.ini [SABERLOOK] IdleMax caps it, 10..300),
--     10 -> 20 -> 40 -> 60 -> 120 s while none does; dormant (never a lookup) without a manifest that has `sabers`;
--   * the facts of an actor (its class, its owner key, ours or not) are cached by its full name for the world, so a stock
--     saber costs one GetFullName per scan and ours skip the class / owner calls after their first sighting.
-- An actor is written only when its (crystal, shade) pair changed: one log line per apply. A scan whose shape changed (how
-- many sabers of ours, how many paired blades) logs one `scan` line; a blade of a manifest blade class with no saber of ours
-- under its owner logs one `unpaired` line (per actor per world) - the line that would have named B0 session 1's no-apply.
-- NO SOFT POINTERS (retail-proven, UE4SS 3.0.1, the UI window's two crashes 2026-10-10): reading ANY TSoftObjectPtr field from
-- Lua crashes the game inside UE4SS (even a struct member such as SkeletalMeshOptions[i].SkeletalMesh), and so did handing one
-- to KismetSystemLibrary LoadAsset_Blocking. So the parts are identified ONLY by their FPrimaryAssetId names
-- (slot.CustomizationPartPrimaryAssetId.PrimaryAssetName) and every value comes from the build's table (the manifest, keyed by
-- part name); a slot's SlotIcon / DefaultCustomizationPartId-adjacent soft fields, a part's fragments and its CustomizationPartDefinition
-- are never read; the hum event is found by its path STRING (StaticFindObject). Every field this block reads: CustomizationInstance,
-- FragmentInstances, SlotNameTag, CustomizationPartPrimaryAssetId, "Blade materials", BladeLight, Lightsaber_Blade,
-- LightsaberSound (hard object / struct properties); tools/replay_saberlook.py SL8 fails on a read of any other field.
-- SPLIT ROWS (saber stage E, OPERATOR DECISION 2026-10-11; docs/recon/SABER_COLOR_ROWS.md; feature "saberrows"). A hand row may
-- also name `core` = its INNER row's slot tag: a core part ({ core = {r,g,b} } in `shades`, every color, not gated) replaces the
-- inner color of the shade the OUTER row resolved (`color`, crystal-gated as before); the neutral "Crystal Core"
-- ({ coreDefault = true }) or no pick keeps the shade's own inner. An actor row's `nest` names the Pattern-section container
-- slot (...PaintMask.SaberBlades) whose nested row slots live in ITS FragmentInstances (a hard UObject array on the slot
-- instance): the pass reads that one container one level deep, no other slot.
-- ZC UNLOCKED. Installed + enabled (ue4ss/Mods/ZCUnlocked/dlls/main.dll, mods.txt `ZCUnlocked : 1` or enabled.txt): its
-- Blade Color picker detours the colour writes, so SABERLOOK stands down on COLOUR (logged once) and still writes opacity
-- and the look. ue4ss/Mods/ZCSDKLoader/settings.ini [SABERLOOK] Enabled = on | off, Color = auto | ours | zcu.
do
local SL = {
    BASE_CLASS   = "BP_FX_LightSaber_Base_C",
    BODY_OPACITY = 0.45, XPLANE_OPACITY = 1.0,   -- the stock Opacity of M_FX_Lightsaber_01_Body / M_FX_LightSaber_01_CrossPlane
    -- FIRST_S 6 (probe 2, B5: 241 ms at world start): a new world's first scan waits out the load hitch, and is ONE walk
    ACTIVE_S     = 3, FIRST_S = 6, MENU_S = 10, WAIT_S = 5, POLL_S = 5,
    SETTLE_S     = { 2, 4, 8 },              -- the scans after a world's first one (its spawn wave)
    IDLE_S       = { 5, 10, 20, 40, 60 },    -- scans while a saber of ours exists and nothing changes (IdleMax caps them)
    NONE_S       = { 10, 20, 40, 60, 120 },  -- scans while no saber of ours exists
    -- a scan's work cap (probe 2, B5: 117-123 ms on a scan that applied 2 sabers): WALK_CAP object-array walks per scan (the
    -- scan's own walk + one more: a per-class discovery walk OR a hum StaticFindObject), APPLY_CAP applies; the rest wait for
    -- the next scan (ACTIVE_S later)
    WALK_CAP     = 2, APPLY_CAP = 8,
    PAIR_DIST    = 300, PAIR_READS = 8,      -- the self-keyed pair fallback: max distance (uu), location reads per scan
    LOG_CAP      = 200, UNPAIRED_CAP = 20,
    INI          = "Mods/ZCSDKLoader/settings.ini",
    loaded = false, live = false, actors = {}, blades = {}, shades = {}, crystals = {}, nActors = 0, nests = {},
    colorOn = true, sig = {}, world = nil, idleN = 0, noneN = 0, settleN = 0, due = 0, nextIn = 0, idleMax = 60,
    facts = {}, unpaired = {}, nUnpaired = 0, perClassTried = false, pcIdx = 0, wScans = 0, cSig = nil, shape = nil, budget = 0,
    unknown = {}, deferred = 0, locReads = 0,
    passes = 0, scans = 0, polls = 0, applied = 0, lookups = 0, logged = 0,
}
function SL.log(m) if SL.logged < SL.LOG_CAP then SL.logged = SL.logged + 1; log("SABERLOOK " .. m) end end
-- ---- the manifest: every mod's `sabers` block merged (a later mod's row of the same name wins, said once)
function SL.merge(m, from)
    local s = m and m.sabers
    if type(s) ~= "table" or (tonumber(s.schema) or 0) < 1 then return 0 end
    local n = 0
    for cls, a in pairs(s.actors or {}) do
        if type(a) == "table" then
            SL.actors[cls] = a; n = n + 1
            if type(a.nest) == "string" then SL.nests[a.nest] = true end
            for _, b in ipairs(a.blades or {}) do
                if type(b) == "table" and type(b.cls) == "string" then
                    SL.blades[b.cls] = SL.blades[b.cls] or {}
                    SL.blades[b.cls][cls] = b.hand or "mirror"
                end
            end
        end
    end
    for k, v in pairs(s.shades or {}) do SL.shades[k] = v end
    for k, v in pairs(s.crystals or {}) do SL.crystals[k] = v end
    SL.nActors = SL.nActors + n
    return n
end
-- ---- pure: the (crystal, shade) of one blade from its slot parts {[slot tag] = part name}
-- probe 2 (B8): an old save keeps the part ids of an earlier build. A crystal id this build's table does not know draws the
-- slot's DEFAULT crystal (the row's `default`, from the CD) instead of nothing, and a shade id it does not know counts as no
-- pick (the crystal's default shade). Each unknown id is logged once a session.
function SL.noteUnknown(part, slot, instead)
    if SL.unknown[part] then return end
    SL.unknown[part] = true
    SL.log(("unknown part %s in %s: not in this build's table (an old save, or a renamed part) - drawing %s; re-equip to pick"):format(
        part, slot, instead))
end
function SL.pick(parts, row, hand)
    local h = row and row[hand == "left" and "left" or "right"]
    if type(h) ~= "table" then return nil, nil end
    local cr, sh = h.crystal and parts[h.crystal] or nil, h.color and parts[h.color] or nil
    if cr and not SL.crystals[cr] and type(h.default) == "string" and SL.crystals[h.default] then
        SL.noteUnknown(cr, h.crystal, "the slot default " .. h.default)
        cr = h.default
    end
    if sh and not SL.shades[sh] then SL.noteUnknown(sh, h.color, "the crystal's default shade"); sh = nil end
    -- split rows: the INNER (core) pick; an unknown id or a non-core part counts as no pick (the shade's own inner)
    local co = h.core and parts[h.core] or nil
    if co and not (SL.shades[co] and (SL.shades[co].core or SL.shades[co].coreDefault)) then SL.noteUnknown(co, h.core, "the shade's own inner color"); co = nil end
    return cr, sh, co
end
-- -> { crystal = name|nil, shade = name|nil, core = name|nil, why = string } : the shade actually drawn (+ the core that recolors its inner)
function SL.resolve(crystalName, shadeName, coreName)
    local core = coreName and SL.shades[coreName] and SL.shades[coreName].core and coreName or nil
    local res
    local cr = crystalName and SL.crystals[crystalName] or nil
    if not cr then
        if shadeName and SL.shades[shadeName] and not SL.shades[shadeName].crystalDefault then
            res = { crystal = nil, shade = shadeName, why = "no crystal of ours: the shade as picked" }
        else res = { crystal = nil, shade = nil, why = "no crystal of ours and no shade" } end
    else
        local sh = shadeName and SL.shades[shadeName] or nil
        if sh and not sh.crystalDefault then
            for _, s in ipairs(cr.shades or {}) do
                if s == shadeName then res = { crystal = crystalName, shade = shadeName, why = "picked" }; break end
            end
            res = res or { crystal = crystalName, shade = cr.default, why = "the picked shade is not one this crystal unlocks: its default" }
        else res = { crystal = crystalName, shade = cr.default, why = sh and "Crystal Color: the crystal's default" or "no shade picked: the crystal's default" } end
    end
    if core then res.core = core; res.why = res.why .. "; core " .. core end
    return res
end
-- -> the writes for one blade: { color = { inner, outer, light } | nil, opacity = { body, xplane } | nil, scalars = {}, hum }
function SL.plan(res, colorOn)
    local p = { scalars = {} }
    local sh = res.shade and SL.shades[res.shade] or nil
    if sh and not sh.crystalDefault then
        local co = res.core and SL.shades[res.core] or nil
        if colorOn then p.color = { inner = (co and co.core) or sh.inner, outer = sh.outer, light = sh.light or sh.outer } end
        local k = tonumber(sh.opacity) or 1
        p.opacity = { body = SL.BODY_OPACITY * k, xplane = SL.XPLANE_OPACITY * k }
    end
    local cr = res.crystal and SL.crystals[res.crystal] or nil
    if cr then
        for name, v in pairs(cr.look or {}) do p.scalars[name] = v end
        p.hum = cr.hum
    end
    return p
end
function SL.sigOf(res, colorOn) return tostring(res.crystal) .. "|" .. tostring(res.shade) .. "|" .. tostring(res.core) .. "|" .. tostring(colorOn) end
-- ---- the colour switch (file reads only, once a session)
function SL.readFile(path, max)
    local f = io.open(path, "rb"); if not f then return nil end
    local s = f:read(max or 262144); f:close(); return s or ""
end
function SL.iniGet(text, section, key)
    local sec, found = "", nil
    for raw in ((text or "") .. "\n"):gmatch("([^\r\n]*)\r?\n") do
        local line = raw:gsub("^\239\187\191", ""):gsub("%s*[;#].*$", ""):match("^%s*(.-)%s*$") or ""
        local s = line:match("^%[%s*(.-)%s*%]$")
        if s then sec = s:lower()
        elseif sec == section:lower() then
            local k, v = line:match("^([^=]-)%s*=%s*(.*)$")
            if k and k:lower() == key:lower() then found = v end
        end
    end
    return found
end
function SL.zcuActive(root)
    local dir = root .. "Mods/ZCUnlocked/"
    if not SL.readFile(dir .. "dlls/main.dll", 2) then return false, "ZC Unlocked is not installed" end
    local mods = SL.readFile(root .. "Mods/mods.txt") or ""
    if mods:match("ZCUnlocked%s*:%s*1") or SL.readFile(dir .. "enabled.txt", 1) then return true, "ZC Unlocked is installed and enabled" end
    return false, "ZC Unlocked is installed but not enabled"
end
-- -> "on" | "off", and whether WE write colour
function SL.settings(root)
    local ini = SL.readFile(root .. SL.INI) or ""
    local im = tonumber(SL.iniGet(ini, "SABERLOOK", "IdleMax") or "")   -- the longest idle gap between scans (s)
    if im then SL.idleMax = math.max(10, math.min(300, im)) end
    local en = (SL.iniGet(ini, "SABERLOOK", "Enabled") or "on"):lower()
    if en == "off" or en == "0" or en == "false" then return "off", false, "settings.ini [SABERLOOK] Enabled=off" end
    local cm = (SL.iniGet(ini, "SABERLOOK", "Color") or "auto"):lower()
    if cm == "ours" then return "on", true, "settings.ini [SABERLOOK] Color=ours: our colour even beside ZC Unlocked" end
    if cm == "zcu" then return "on", false, "settings.ini [SABERLOOK] Color=zcu: colour left to ZC Unlocked (or the actor's defaults)" end
    local on, note = SL.zcuActive(root)
    if on then return "on", false, note .. ": its Blade Color owns the blade colour - SABERLOOK stands down on colour, still writes opacity and the look" end
    return "on", true, note
end
-- ---- impure: one actor
function SL.valid(o)
    if o == nil then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return (ok and v) and true or false
end
function SL.str(f) local ok, v = pcall(f); if ok and type(v) == "string" then return v end; return nil end
function SL.readSlots(actor)
    local parts = {}
    -- one array of fragment instances: every slot's (tag -> part); a slot whose tag is a manifest `nest` (split rows' Pattern
    -- container) is read one level deeper, through its own FragmentInstances (hard UObject array), and never deeper
    local function walk(arr, depth)
        arr:ForEach(function(_, e)
            local fi = e
            local okG, g = pcall(function() return e:get() end)
            if okG and g then fi = g end
            if not SL.valid(fi) then return end
            local tag = SL.str(function() return fi.SlotNameTag.TagName:ToString() end)
            local part = SL.str(function() return fi.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end)
            if tag and part and part ~= "None" and part ~= "" then parts[tag] = part end
            if depth == 0 and tag and SL.nests[tag] then pcall(function() walk(fi.FragmentInstances, 1) end) end
        end)
    end
    pcall(function()
        local inst = actor.CustomizationInstance
        if not SL.valid(inst) then return end
        walk(inst.FragmentInstances, 0)
    end)
    return parts
end
function SL.fname(s) local ok, n = pcall(FName, s); if ok and n then return n end; return s end
function SL.lc(v) return { R = v[1], G = v[2], B = v[3], A = 1.0 } end
function SL.apply(actor, p)
    local wrote = {}
    local mids = {}
    pcall(function()
        actor["Blade materials"]:ForEach(function(_, e)
            local m = e; local okG, g = pcall(function() return e:get() end)
            if okG and g then m = g end
            if SL.valid(m) then mids[#mids + 1] = m end
        end)
    end)
    if p.color then
        local c = p.color
        pcall(function() actor.BladeOuterColor = SL.lc(c.outer) end)
        pcall(function() actor.BladeInnerColor = SL.lc(c.inner) end)
        pcall(function() actor["Blade Light Color"] = SL.lc(c.light) end)
        for _, m in ipairs(mids) do
            pcall(function() m:SetVectorParameterValue(SL.fname("OuterColor"), SL.lc(c.outer)) end)
            pcall(function() m:SetVectorParameterValue(SL.fname("InnerColor"), SL.lc(c.inner)) end)
        end
        if #mids == 0 then
            pcall(function() actor.Lightsaber_Blade:SetVectorParameterValueOnMaterials(SL.fname("OuterColor"), { X = c.outer[1], Y = c.outer[2], Z = c.outer[3] }) end)
            pcall(function() actor.Lightsaber_Blade:SetVectorParameterValueOnMaterials(SL.fname("InnerColor"), { X = c.inner[1], Y = c.inner[2], Z = c.inner[3] }) end)
        end
        pcall(function() local L = actor.BladeLight; if SL.valid(L) then L:SetLightColor(SL.lc(c.light), true) end end)
        wrote[#wrote + 1] = "colour"
    end
    if p.opacity then
        if #mids >= 2 then   -- UpdateBladeMaterials adds the CrossPlane MID (slot 0) first, then the Body (slot 1)
            pcall(function() mids[1]:SetScalarParameterValue(SL.fname("Opacity"), p.opacity.xplane) end)
            pcall(function() mids[2]:SetScalarParameterValue(SL.fname("Opacity"), p.opacity.body) end)
        else
            pcall(function() actor.Lightsaber_Blade:SetScalarParameterValueOnMaterials(SL.fname("Opacity"), p.opacity.body) end)
        end
        wrote[#wrote + 1] = ("opacity %.2f/%.2f"):format(p.opacity.body, p.opacity.xplane)
    end
    local ns = 0
    for name, v in pairs(p.scalars) do
        ns = ns + 1
        if #mids > 0 then for _, m in ipairs(mids) do pcall(function() m:SetScalarParameterValue(SL.fname(name), v) end) end
        else pcall(function() actor.Lightsaber_Blade:SetScalarParameterValueOnMaterials(SL.fname(name), v) end) end
    end
    if ns > 0 then wrote[#wrote + 1] = ns .. " look scalar(s)" end
    if p.hum then
        local ev = nil
        if p.hum ~= "silent" then   -- one counted lookup, only on an apply (a crystal / shade change), never kept
            SL.lookups = SL.lookups + 1
            local okF, o = pcall(StaticFindObject, p.hum)
            if okF and SL.valid(o) then ev = o end
        end
        if p.hum == "silent" or ev then
            pcall(function() actor.LightsaberSound.PlayIdleAudioEvent = (p.hum == "silent") and nil or ev end)
            wrote[#wrote + 1] = "hum " .. ((p.hum == "silent") and "silent" or p.hum:match("([^./]+)$"))
        else
            wrote[#wrote + 1] = "hum " .. tostring(p.hum) .. " NOT resident (not set)"
        end
    end
    return table.concat(wrote, ", ")
end
function SL.classList()
    if SL.clsCache then return SL.clsCache end
    local seen, out = {}, {}
    for cls in pairs(SL.actors) do if not seen[cls] then seen[cls] = true; out[#out + 1] = cls end end
    for cls in pairs(SL.blades) do if not seen[cls] then seen[cls] = true; out[#out + 1] = cls end end
    table.sort(out)
    SL.clsCache = out
    return out
end
function SL.short(o) return ((SL.str(function() return o:GetFullName() end) or "?"):gsub("^[^ ]+ ", ""):gsub("^.*PersistentLevel%.", "")) end
function SL.shortName(full) return ((full or "?"):gsub("^[^ ]+ ", ""):gsub("^.*PersistentLevel%.", "")) end
-- the pin census signature (count / actor-number sum of the non-proxy CustomizationInstances, CP.noteCensus) - a free
-- "something spawned or went" signal while the pin task runs; nil without it (the offline replay has no CP)
function SL.censusSig()
    if type(CP) ~= "table" then return nil end
    return CP.cSig
end
-- the facts of one actor, once per world: { cls, owner, kind = "prim" | "extra" | false }. The owner key: Owner -> the
-- attach parent (B0 probe: in the HQ both blades have Owner None and share the character as attach parent) -> its own name.
function SL.factsOf(a, full)
    local f = SL.facts[full]
    if f then return f end
    local cls = SL.str(function() return a:GetClass():GetFName():ToString() end)
    f = { cls = cls, kind = false }
    if cls and SL.actors[cls] then f.kind = "prim" elseif cls and SL.blades[cls] then f.kind = "extra" end
    if f.kind then
        local function nameOf(get) return SL.str(function() local o = get(); if not SL.valid(o) then return nil end; return o:GetFullName() end) end
        f.owner = nameOf(function() return a:GetOwner() end) or nameOf(function() return a:GetAttachParentActor() end) or ("?" .. full)
    end
    if cls then SL.facts[full] = f end   -- a class read that failed is asked again next scan
    return f
end
-- ONE object-array walk: the saber base class. The per-class walks only while the base walk has never answered this
-- session, each manifest class at most once per world (SL.perClassTried), and (probe 2, B5) ONE class per scan from the
-- world's second scan on: never on the first scan (world start), never more than WALK_CAP walks in a scan.
function SL.walk()
    local list = {}
    if SL.lookMode ~= "perclass" then
        SL.lookups = SL.lookups + 1; SL.budget = SL.budget - 1
        local okL, l = pcall(FindAllOf, SL.BASE_CLASS)
        if okL and type(l) == "table" and #l > 0 then
            if SL.lookMode == nil then SL.lookMode = "base" end
            return l
        end
        if SL.lookMode == "base" or SL.perClassTried then return list end
        if SL.wScans <= 1 or SL.budget <= 0 then return list end   -- the world's first scan: the base walk only
        local cl = SL.classList()
        SL.pcIdx = SL.pcIdx + 1
        if SL.pcIdx >= #cl then SL.perClassTried = true end
        local cls = cl[SL.pcIdx]
        if not cls then return list end
        SL.lookups = SL.lookups + 1; SL.budget = SL.budget - 1
        local okC, lc = pcall(FindAllOf, cls)
        if okC and type(lc) == "table" and #lc > 0 then
            SL.lookMode = "perclass"
            SL.log(("the base class %s answered no instance; walking the manifest classes from now on (%s=%d found)"):format(
                SL.BASE_CLASS, cls, #lc))
            for _, a in ipairs(lc) do list[#list + 1] = a end
        end
        return list
    end
    -- "perclass" mode (never seen in retail: the base walk answered in every probe session): every manifest class, every scan
    local counts = {}
    for _, cls in ipairs(SL.classList()) do
        SL.lookups = SL.lookups + 1
        local okC, lc = pcall(FindAllOf, cls)
        local n = 0
        if okC and type(lc) == "table" then for _, a in ipairs(lc) do list[#list + 1] = a; n = n + 1 end end
        counts[#counts + 1] = cls .. "=" .. n
    end
    if #list > 0 and SL.lookMode ~= "perclass" then
        SL.lookMode = "perclass"
        SL.log(("the base class %s answered no instance; walking the manifest classes from now on (%s)"):format(
            SL.BASE_CLASS, table.concat(counts, ", ")))
    end
    return list
end
-- ---- the LAST pairing fallback (probe 2, P2-3): a blade with neither an Owner nor an attach parent is keyed by its own name
-- ("?<full>"), and so is its primary, so the owner match can never meet them. Such a blade pairs with a self-keyed primary of
-- a class it pairs with: the NEAREST one within PAIR_DIST uu (K2_GetActorLocation, at most PAIR_READS reads a scan); when no
-- location reads at all, by SPAWN ORDER (the name numbers), only when the counts match. A pair found is kept in the
-- blade's facts for the world, so it costs its location reads once; one not found is asked again next scan (it is cheap: only
-- self-keyed blades read anything). Never a lookup.
function SL.selfKeyed(owner) return type(owner) == "string" and owner:sub(1, 1) == "?" end
function SL.locOf(a)
    SL.locReads = SL.locReads + 1
    local ok, x, y, z = pcall(function() local v = a:K2_GetActorLocation(); return v.X, v.Y, v.Z end)
    if ok and type(x) == "number" and type(y) == "number" and type(z) == "number" then return { x, y, z } end
    return nil
end
function SL.suffix(full) return tonumber(((full or ""):match("_(%d+)$"))) or math.huge end
-- -> { [blade full] = { p = <primary entry>, why = string } }
function SL.pairSelfKeyed(orphans, prim)
    local out, taken, byFull, rest = {}, {}, {}, {}
    for _, p in ipairs(prim) do byFull[p.full] = p end
    local function take(e, p, why)
        out[e.full] = { p = p, why = why }; taken[p.full .. "|" .. e.cls] = true
        local f = SL.facts[e.full]; if f then f.pairWith, f.pairWhy = p.full, why end
    end
    for _, e in ipairs(orphans) do   -- the pairs already found this world
        local f = SL.facts[e.full]
        local p = f and f.pairWith and byFull[f.pairWith] or nil
        if p and not taken[p.full .. "|" .. e.cls] then take(e, p, f.pairWhy) else rest[#rest + 1] = e end
    end
    local groups, order, reads, locs = {}, {}, 0, {}
    for _, e in ipairs(rest) do
        if not groups[e.cls] then groups[e.cls] = {}; order[#order + 1] = e.cls end
        local g = groups[e.cls]; g[#g + 1] = e
    end
    local function loc(x)
        if locs[x.full] == nil then
            if reads >= SL.PAIR_READS then return nil end
            reads = reads + 1; locs[x.full] = SL.locOf(x.a) or false
        end
        return locs[x.full] or nil
    end
    for _, cls in ipairs(order) do
        local bl, cands = groups[cls], {}
        for _, p in ipairs(prim) do
            if SL.selfKeyed(p.owner) and SL.blades[cls][p.cls] and not taken[p.full .. "|" .. cls] then cands[#cands + 1] = p end
        end
        if #cands > 0 then
            local anyLoc = false
            for _, e in ipairs(bl) do
                local le = loc(e)
                if le then
                    anyLoc = true
                    local best, bd = nil, SL.PAIR_DIST * SL.PAIR_DIST
                    for _, p in ipairs(cands) do
                        local lp = (not taken[p.full .. "|" .. cls]) and loc(p) or nil
                        if lp then
                            local d = (le[1] - lp[1]) ^ 2 + (le[2] - lp[2]) ^ 2 + (le[3] - lp[3]) ^ 2
                            if d <= bd then best, bd = p, d end
                        end
                    end
                    if best then take(e, best, ("no owner: the nearest saber of ours, %.0f uu"):format(math.sqrt(bd))) end
                end
            end
            if not anyLoc then
                local free = {}
                for _, p in ipairs(cands) do if not taken[p.full .. "|" .. cls] then free[#free + 1] = p end end
                if #free == #bl then
                    table.sort(bl, function(a, b) return SL.suffix(a.full) < SL.suffix(b.full) end)
                    table.sort(free, function(a, b) return SL.suffix(a.full) < SL.suffix(b.full) end)
                    for i, e in ipairs(bl) do take(e, free[i], "no owner, no location: spawn order") end
                end
            end
        end
    end
    return out
end
-- ---- the scan. -> seconds until the next scan
function SL.pass()
    SL.passes = SL.passes + 1; SL.scans = SL.scans + 1; SL.wScans = SL.wScans + 1
    SL.budget, SL.deferred = SL.WALK_CAP, 0
    local list = SL.walk()
    local prim, extra = {}, {}
    for _, a in ipairs(list) do
        if SL.valid(a) then
            local full = SL.str(function() return a:GetFullName() end)
            if full and not full:find("Default__", 1, true) then
                local f = SL.factsOf(a, full)
                if f.kind == "prim" then prim[#prim + 1] = { a = a, cls = f.cls, owner = f.owner, full = full }
                elseif f.kind == "extra" then extra[#extra + 1] = { a = a, cls = f.cls, owner = f.owner, full = full } end
            end
        end
    end
    local changed = 0
    local function one(actor, full, label, res)
        local s = SL.sigOf(res, SL.colorOn)
        if SL.sig[full] == s then return end
        local p = SL.plan(res, SL.colorOn)
        -- the work cap (probe 2, B5): an apply past APPLY_CAP, or one whose hum needs a lookup (StaticFindObject walks the
        -- object array in this UE4SS build) once the scan's walks are spent, waits for the next scan: its signature is not kept
        local needHum = p.hum ~= nil and p.hum ~= "silent"
        if changed >= SL.APPLY_CAP or (needHum and SL.budget <= 0) then SL.deferred = SL.deferred + 1; return end
        if needHum then SL.budget = SL.budget - 1 end
        SL.sig[full] = s
        local did = SL.apply(actor, p)
        changed = changed + 1; SL.applied = SL.applied + 1
        SL.log(("applied %s (%s): crystal %s, shade %s [%s] -> %s%s"):format(SL.shortName(full), label, tostring(res.crystal), tostring(res.shade),
            res.why, did ~= "" and did or "nothing to write", SL.colorOn and "" or " (colour: ZC Unlocked / defaults)"))
    end
    local byOwner = {}
    for _, e in ipairs(prim) do
        local row = SL.actors[e.cls]
        local parts = SL.readSlots(e.a)
        local rc, rs, rco = SL.pick(parts, row, "right")
        local res = SL.resolve(rc, rs, rco)
        one(e.a, e.full, "right", res)
        byOwner[e.owner] = { cls = e.cls, parts = parts, row = row, right = res }
    end
    local paired = 0
    local function paint(e, P, hand, how)
        paired = paired + 1
        local res = P.right
        if hand == "left" then local lc, ls, lco = SL.pick(P.parts, P.row, "left"); res = SL.resolve(lc, ls, lco) end
        one(e.a, e.full, (hand == "left" and "left blade" or "mirrored blade") .. (how and (", " .. how) or ""), res)
    end
    local function unpaired(e, P)
        if SL.unpaired[e.full] or SL.nUnpaired >= SL.UNPAIRED_CAP then return end
        -- B0 session 1 (2026-10-10): the left crystal equipped, the padawan blade had Owner None and was keyed by its own
        -- name, so it never met its primary and nothing was written - silently. This line names that case.
        SL.unpaired[e.full] = true; SL.nUnpaired = SL.nUnpaired + 1
        local keys = {}
        for k in pairs(byOwner) do keys[#keys + 1] = SL.shortName(k) end
        table.sort(keys)
        SL.log(("unpaired %s (%s): %s under its owner %s - not painted (owners with a saber of ours: %s)"):format(
            SL.shortName(e.full), e.cls, P and "the saber there is not one it pairs with" or "no saber of ours",
            SL.shortName(e.owner), #keys > 0 and table.concat(keys, ", ") or "none"))
    end
    local orphans = {}
    for _, e in ipairs(extra) do
        local P = byOwner[e.owner]
        local hand = P and SL.blades[e.cls][P.cls] or nil
        if hand then paint(e, P, hand)
        elseif not P and SL.selfKeyed(e.owner) then orphans[#orphans + 1] = e   -- no Owner, no attach parent: the last fallback
        else unpaired(e, P) end
    end
    if #orphans > 0 then
        local pairs_ = SL.pairSelfKeyed(orphans, prim)
        for _, e in ipairs(orphans) do
            local m = pairs_[e.full]
            if m then paint(e, byOwner[m.p.owner], SL.blades[e.cls][m.p.cls], m.why) else unpaired(e, nil) end
        end
    end
    -- 2026-10-11: SLOTFIX rides this scan (CP.slOnScan, set by the SLOTFIX block: the wielders' fixed mod-slot counts)
    -- 2026-10-12: a number back = a wielder's count GE is PENDING (its class not resident yet / its apply raised): scan again
    -- that soon instead of the idle back-off (SLOTFIX bounds how many times in a row it asks)
    local onScan = type(CP) == "table" and CP.slOnScan or nil
    local slSoon = nil
    if onScan then
        local okS, eS = pcall(onScan, prim, SL.world)
        if not okS then SL.log("slotfix error: " .. tostring(eS)) elseif type(eS) == "number" and eS > 0 then slSoon = eS end
    end
    -- 2026-10-12: DUALHEX rides it too (CP.dhOnScan: a dual saber's hexes 1-3 right / 4-6 left; its scan fix-up fallback)
    local onDh = type(CP) == "table" and CP.dhOnScan or nil
    if onDh then
        local okD, eD = pcall(onDh, prim, SL.world)
        if not okD then SL.log("dualhex error: " .. tostring(eD)) elseif type(eD) == "number" and eD > 0 and (slSoon == nil or eD < slSoon) then slSoon = eD end
    end
    local shape = ("%d of ours, %d paired blade(s), %d saber(s) walked"):format(#prim, paired, #list)
    if shape ~= SL.shape then
        SL.shape = shape
        SL.log(("scan %d in %s: %s (%s)"):format(SL.scans, SL.shortName(SL.world), shape, SL.lookMode or "base walk, no answer yet"))
    end
    local nextS
    if changed > 0 or SL.deferred > 0 then SL.idleN, SL.noneN = 0, 0; nextS = SL.ACTIVE_S
    elseif SL.settleN < #SL.SETTLE_S then SL.settleN = SL.settleN + 1; nextS = SL.SETTLE_S[SL.settleN]
    elseif #prim > 0 then
        SL.noneN = 0; SL.idleN = SL.idleN + 1
        nextS = math.min(SL.IDLE_S[math.min(SL.idleN, #SL.IDLE_S)], SL.idleMax)
    else
        SL.idleN = 0; SL.noneN = SL.noneN + 1
        nextS = SL.NONE_S[math.min(SL.noneN, #SL.NONE_S)]
    end
    if slSoon and slSoon < nextS then return slSoon end
    return nextS
end
-- 2026-10-12 (probe 4c): SLOTFIX's equip hook asks for a scan NOW (an Armory equip / weapon swap) instead of the idle back-off
if type(CP) == "table" then CP.slPoke = function() SL.due = 0 end end
function SL.newWorld(w)
    SL.world, SL.sig, SL.facts, SL.unpaired = w, {}, {}, {}
    SL.idleN, SL.noneN, SL.settleN, SL.due, SL.shape, SL.perClassTried = 0, 0, 0, 0, nil, false
    SL.pcIdx, SL.wScans = 0, 0
    SL.cSig = SL.censusSig()
end
function SL.task()
    if not SL.loaded then
        if not injected then return SL.WAIT_S end            -- the manifests are read by then
        SL.loaded = true
        local n = 0
        for _, mf in ipairs(manifests) do   -- 1.8.54 (M-3): one manifest at a time
            local ok, r = pcall(SL.merge, mf.m, mf.path)
            if ok then n = n + (tonumber(r) or 0) else log("SABERLOOK: " .. tostring(mf.m.name) .. "'s sabers block failed: " .. tostring(r)) end
        end
        if n == 0 then return true end                        -- no saber of ours anywhere: stopped for good, never a lookup
        local mode, colorOn, note = SL.settings(UE4SS)
        SL.colorOn = colorOn
        if mode == "off" then log("SABERLOOK OFF for the session: " .. note); return true end
        SL.live = true
        log(("SABERLOOK armed: %d saber actor class(es), %d shade part(s); %s; scans back off to %d s idle"):format(SL.nActors,
            (function() local c = 0; for _ in pairs(SL.shades) do c = c + 1 end; return c end)(), note, SL.idleMax))
    end
    local w = pinWorldName()
    if w == "<none>" or w:find("MainMenu", 1, true) or w:find("PSOLoader", 1, true) then return SL.MENU_S end
    if SL.world ~= w then SL.newWorld(w); return SL.FIRST_S end   -- a new world: new actors (its first scan in FIRST_S)
    -- a POLL: no lookup. A pin-census change makes the scan due now.
    local cs = SL.censusSig()
    if cs ~= SL.cSig then SL.cSig = cs; if cs ~= nil then SL.due = 0 end end
    if SL.due > 0 then
        SL.polls = SL.polls + 1
        local d = math.min(SL.due, SL.POLL_S)
        SL.due = SL.due - d
        return d
    end
    SL.nextIn = SL.pass()
    SL.due = SL.nextIn
    local d = math.min(SL.due, SL.POLL_S)
    SL.due = SL.due - d
    return d
end
SL.taskRef = addTask("saberlook", 5.0, function()
    local ok, r = pcall(SL.task)
    if not ok then log("SABERLOOK error (the loop keeps running): " .. tostring(r)); return 10 end
    return r
end)
if SABERLOOK_EXPORT then SABERLOOK_EXPORT(SL) end              -- tools/replay_saberlook.py only (a nil global in the game)
end
-- ---- 2026-10-10: SABERLOOK (end) ----

-- ---- 2026-10-11: SABERHEADINGS (begin; tools/replay_saberheadings.py extracts this block verbatim) ----
-- THE ARMORY MODS PAGE WHILE A SABER OF OURS IS THE SELECTED WEAPON (route (b) of the saber-headings scope; the def key
-- `saberModsPage`, tools/zcmod-sabercust.js (5); NOT retail-proven: docs/recon/SABER_B0_PROBE_CHECKLIST.md, probe 4 H1-H6).
-- WHY LUA. The page (WBP_Menu_Armory_WeaponMods) builds its 4 sections ONCE from VM_ArmoryMods.GroupQueries (a Blueprint CDO
-- array: Barrel, Cell, Scope, Stock), with no weapon key anywhere; the heading is the section's QueryIdTag tag-UI entry. A data
-- route means overriding VM_ArmoryMods or a UITagData_* set: whole-asset overrides of stock assets (operator rule: never - any
-- other mod shipping the same asset would collide). So the headings are set at run time, on the live widgets, and no stock
-- asset is touched. While a saber OF OURS (a manifest `sabers.actors` class) is the selected weapon:
--   * Barrel -> the def's crystal heading (CRYSTAL), Cell -> POWER CELL, Scope -> EFFECTS (WBP_SectionSubHeader.SetHeaderText;
--     an optional icon borrowed from an EXISTING tag's tag-UI entry, through the section's own TagData handler - the brush is
--     resolved by the game, Lua never reads it);
--   * Stock (STABILIZER) collapsed;
--   * every grid keeps only saber mods (the `sabers.mods` item names, else a ...Slot.Weapon.<X>.Saber* tag on the item).
-- Any other weapon (a blaster, a stock saber): the stock headings back (the section's own TagData handler with its own
-- TagData) and the reverse filter - no saber mod lists. No weapon read (no loadout view-model): nothing filtered.
-- HOW (the hooks and widget names it relies on, decoded from the cooked BPs, scratchpad kismet 2026-10-11):
--   * WBP_InventoryGridGroup_C:UpdateItemGrid (POST hook = a UE4SS hook on a BP function; ZCUI retail-proved the pattern): the
--     section just ran GetOwnedItemsMatchingQuery -> ItemGridMod:BP_SetListItems. We then filter ItemGridMod (GetNumItems /
--     GetItemAt / RemoveItem - one object per call, no TArray built in Lua) and mirror the stock empty state (ItemGridMod
--     Collapsed, EmptyText SelfHitTestInvisible).
--   * WBP_Menu_Armory_WeaponMods_C:NavigateToFirstItem (POST): the page runs it after BOTH character / loadout paths (the
--     loadout view-model BndEvt -> DelayUntilNextTick -> +359, and OnCharacterLoadoutChanged -> +6425 -> +15 -> +359), so it is
--     the "the selected weapon may have changed" signal. A section whose mode changed re-runs its OWN UpdateItemGrid (the game
--     re-queries; the hook above filters).
--   * the selected weapon: MDViewModelFunctionLibrary:GetViewModel(page, BrunoCharacterLoadoutViewModel, "Default") (the
--     page's own assignment; ZCUI calls GetViewModel in retail) -> .GearActor (hard) -> its class (+ GetSuperStruct chain).
--   * a section's kind: GetViewModel(section, <the class of the Sectioned list's item 0>, "Default") -> VM_InventoryItemGroup
--     .ItemQuery.TagDictionary (hard FGameplayTag array) -> br.Customization.Slot.Weapon.<Barrel|Cell|Scope|Stock>.
--   * the page: section:GetOuter() x N (WidgetTree -> WBP_InventoryGrid_Sectioned -> WidgetTree -> the page), by class name.
--   * per item: the item view-model's AssetId.PrimaryAssetName (hard FPrimaryAssetId), else its Tags.GameplayTags.
-- HOW CHEAP. Dormant (never a lookup, never a hook) without a manifest `sabers.modsPage`. In the hub, after HUB_SETTLE_S: the
-- MDViewModel library CDO and the loadout class (both /Script/, never collected: kept for the session) are looked up ONE per
-- pass; then a COUNT-ONLY native hook on BrunoInventoryViewModel:GetOwnedItemsMatchingQuery (every armory section calls it)
-- marks "an inventory page is up", and only then ONE FindAllOf of the page class runs (at most one per PROBE_GAP_S). When the
-- page is found the two BP hooks are registered ONCE (flag before the call, never retried) and the task STOPS for good: from
-- then on the work happens only inside the hooks, i.e. only while the page is building or switching characters - no polling,
-- no object-array walk, no UObject kept across calls (only strings / numbers: H.touched). [SABERHEADINGS] Trigger = probe
-- replaces the count hook with a backed-off probe (PROBE_S). Page closed = the hooks never fire = no work.
-- NO SOFT POINTERS: every field read is a hard object / struct / text property (see the list above); never GearKit,
-- AssociatedGearKit, SmallImage / LargeImage / TagBrush (BitReactorSoftBrush), no LoadAsset. tools/replay_saberheadings.py SH7.
-- A widget or field missing ON A SABER PAGE (a game patch renamed it) logs ONCE and stands the feature down for the session.
-- 2026-10-12 (retail 2026-10-11 20:57:16: ONE nil GetViewModel(section, VM_InventoryItemGroup) on a BLASTER page stood the
-- feature down for the whole session). Now:
--   * a page whose weapon is not a saber of ours never looks a section view-model up (the filter needs none) and never stands
--     down; a stock heading is put back through the view-model only when this section was relabelled before;
--   * the section view-model: MDViewModel keys a widget's view-model by the class the widget DECLARES (an exact match; the
--     BndEvt name says WBP_InventoryGridGroup declares VM_ItemGroup_C), and the list item is a subclass instance
--     (VM_InventoryItemGroup_C), so the item's class AND its supers are tried (the depth that answered is kept, a number);
--   * on a saber page a nil is TRANSIENT: the section stays stock, a miss is counted at most once per MISS_GAP_S, a bounded
--     backed-off retry (RETRY_MS, one FindAllOf each) re-applies the page, and only VM_MISS_MAX counted misses in a row (no
--     success between) stand the feature down, naming the classes tried.
-- ue4ss/Mods/ZCSDKLoader/settings.ini [SABERHEADINGS] Enabled = on | off, Trigger = poke | probe, Filter = on | off.
do
local H = {
    PAGE_CLASS   = "WBP_Menu_Armory_WeaponMods_C",
    SECT_CLASS   = "WBP_InventoryGrid_Sectioned_C",
    PAGE_PKG     = "/Game/Game/UI/Strategy/Armory/WBP_Menu_Armory_WeaponMods.",   -- the class's own package (templates)
    HOOK_UPDATE  = "/Game/Game/UI/Strategy/Armory/Widgets/WBP_InventoryGridGroup.WBP_InventoryGridGroup_C:UpdateItemGrid",
    HOOK_NAV     = "/Game/Game/UI/Strategy/Armory/WBP_Menu_Armory_WeaponMods.WBP_Menu_Armory_WeaponMods_C:NavigateToFirstItem",
    POKE_FN      = "/Script/Bruno.BrunoInventoryViewModel:GetOwnedItemsMatchingQuery",
    LIB_CDO      = "/Script/MDViewModel.Default__MDViewModelFunctionLibrary",
    LOADOUT_CLS  = "/Script/Bruno.BrunoCharacterLoadoutViewModel",
    TAGDATA_FN   = "BndEvt__WBP_InventoryGridGroup_VM_ItemGroup_C_MDVMNode_ViewModelFieldNotify_1_TagData",
    SABER_BASE   = "BP_FX_LightSaber_Base_C",
    SLOT         = "br.Customization.Slot.Weapon.",
    KIND_OF      = { crystal = "Barrel", cell = "Cell", effects = "Scope" },
    HUB_SETTLE_S = 10, STEP_S = 2, POLL_S = 2, PROBE_GAP_S = 5, MENU_S = 10, WAIT_S = 5,
    PROBE_S      = { 10, 20, 40, 60, 120 },
    VIS_VISIBLE  = 0, VIS_COLLAPSED = 1, VIS_SHT_INVISIBLE = 4,
    OUTER_MAX    = 6, SUPER_MAX = 12, LOG_CAP = 120,
    INI          = "Mods/ZCSDKLoader/settings.ini",
    loaded = false, cfg = nil, mods = {}, ours = {}, nMods = 0, trigger = "poke", filterOn = true,
    world = nil, settled = false, lib = nil, libTried = false, loadCls = nil, clsTried = false,
    pokeArmed = false, pokeOk = false, pokes = 0, pokesSeen = 0, probeN = 0,
    hooksArmed = false, updOk = false, navOk = false, armed = false, down = nil,
    touched = {}, notOurs = {}, modeSeen = {}, itemKind = {}, noted = {},
    twins = {}, nTwins = 0, kinds = {}, dhActors = {}, twinsHidden = 0,   -- 2026-10-12 DUALHEX: the left twins never list
    logged = 0, lookups = 0, hookCalls = 0, applies = 0, removed = 0, relabels = 0,
    VM_MISS_MAX  = 4, MISS_GAP_S = 1, RETRY_MS = { 1500, 4000, 10000 },
    vmDepth = nil, misses = 0, missAt = nil, retryArmed = false, retries = 0,
    KTL_CDO      = "/Script/Engine.Default__KismetTextLibrary",
    textCands = nil, textBad = {}, textHow = nil, ktl = nil, noHeadings = nil,
    UNKNOWN_MAX  = 3, unkN = 0, unkArmed = false,
    now = function() return (os.clock and os.clock()) or 0 end,   -- wall time on the Windows CRT (see PUMP.clock)
    after = after,                                                -- the pump's one-shot timer (game thread)
}
function H.log(m) if H.logged < H.LOG_CAP then H.logged = H.logged + 1; log("SABERHEADINGS " .. m) end end
function H.once(key, m) if not H.noted[key] then H.noted[key] = true; H.log(m) end end
function H.valid(o)
    if o == nil then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return (ok and v) and true or false
end
function H.str(f) local ok, v = pcall(f); if ok and type(v) == "string" then return v end; return nil end
function H.full(o) return H.str(function() return o:GetFullName() end) or "?" end
function H.cls(o) return H.str(function() return o:GetClass():GetFName():ToString() end) end
function H.fname(s) local ok, n = pcall(FName, s); if ok and n then return n end; return s end
-- an array a UFunction returned / a property: a Lua table or a UE4SS TArray (ForEach, elements maybe wrapped) -> a Lua list
function H.list(arr)
    local out = {}
    if type(arr) == "table" then for _, e in ipairs(arr) do out[#out + 1] = e end; return out end
    pcall(function()
        arr:ForEach(function(_, e)
            local o = e; local okG, g = pcall(function() return e:get() end)
            if okG and g ~= nil then o = g end
            out[#out + 1] = o
        end)
    end)
    return out
end
-- the stand-down: a widget / field / call the code relies on is missing (a game patch). Once, then every hook returns.
function H.standDown(why)
    if H.down then return end
    H.down = why
    H.log("STANDS DOWN for the session (the MODS page stays stock): " .. why)
end
-- ---- the manifest: every mod's `sabers.modsPage` / `sabers.mods` / `sabers.actors` merged
function H.merge(m)
    local s = m and m.sabers
    if type(s) ~= "table" or (tonumber(s.schema) or 0) < 1 then return false end
    for cls, a in pairs(s.actors or {}) do H.ours[cls] = true; if type(a) == "table" then H.kinds[cls] = a.kind end end
    for _, n in ipairs(s.mods or {}) do if not H.mods[n] then H.mods[n] = true; H.nMods = H.nMods + 1 end end
    -- 2026-10-12 (DUALHEX, operator decision: "a crystal is just a crystal"): a dualHex mod's left twins are never listed - the
    -- hex group decides the blade, and the loader routes an item into hex 4-6 to its twin
    if type(s.dualHex) == "table" then
        for _, t in pairs(s.dualHex.twins or {}) do if type(t) == "string" and not H.twins[t] then H.twins[t] = true; H.nTwins = H.nTwins + 1 end end
        for _, c in ipairs(s.dualHex.actors or {}) do if type(c) == "string" then H.dhActors[c] = true end end
    end
    local p = s.modsPage
    if type(p) ~= "table" then return false end
    if H.cfg then H.once("cfg2", "two mods declare sabers.modsPage: the later one's headings are used") end
    H.cfg = { headings = {}, icons = {}, hideStock = p.hideStock ~= false, filter = p.filter ~= false }
    for kind, sec in pairs(H.KIND_OF) do
        local hd = p.headings and p.headings[kind]
        if type(hd) == "string" and hd ~= "" then H.cfg.headings[sec] = hd end
        local ic = p.icons and p.icons[kind]
        if type(ic) == "string" and ic ~= "" then H.cfg.icons[sec] = ic end
    end
    return true
end
function H.settings(root)
    local text = ""
    local f = io.open(root .. H.INI, "rb")
    if f then text = f:read(262144) or ""; f:close() end
    local function get(key)
        local sec, found = "", nil
        for raw in (text .. "\n"):gmatch("([^\r\n]*)\r?\n") do
            local line = raw:gsub("^\239\187\191", ""):gsub("%s*[;#].*$", ""):match("^%s*(.-)%s*$") or ""
            local s = line:match("^%[%s*(.-)%s*%]$")
            if s then sec = s:lower()
            elseif sec == "saberheadings" then
                local k, v = line:match("^([^=]-)%s*=%s*(.*)$")
                if k and k:lower() == key:lower() then found = v:lower() end
            end
        end
        return found
    end
    local en = get("Enabled") or "on"
    if en == "off" or en == "0" or en == "false" then return false end
    H.trigger = (get("Trigger") == "probe") and "probe" or "poke"
    local fl = get("Filter")
    H.filterOn = not (fl == "off" or fl == "0" or fl == "false") and H.cfg.filter
    return true
end
-- ---- the selected weapon of a page -> "saber" (ours) | "blaster" (anything else, a stock saber too) | nil (unknown)
function H.isSaberClass(c)
    for _ = 1, H.SUPER_MAX do
        if not H.valid(c) then return false end
        if H.str(function() return c:GetFName():ToString() end) == H.SABER_BASE then return true end
        local okS, s = pcall(function() return c:GetSuperStruct() end)
        c = okS and s or nil
    end
    return false
end
-- the page's loadout view-model. 2026-10-12 (retail probe 4b, 04:15:32-04:15:48 and 04:18:44): the page's OWN assignment
-- answered nothing for 16 s on the Jae / Gia pages (3 retries), while the locked-slots list of the same page had one (the SLOTFIX
-- teaser read its GearActor at 04:15:01). The page and its widgets each declare the view-model (WBP_Menu_Armory_WeaponMods,
-- WBP_Armory_ItemSlots and VM_ArmoryLockedSlotsList all bind BrunoCharacterLoadoutViewModel "Default"), so the slot widget is
-- asked next. A miss on both is described ONCE (which holders were there) for the next retail read.
function H.loadoutOf(page)
    local vm = nil
    pcall(function() vm = H.lib:GetViewModel(page, H.loadCls, H.fname("Default")) end)
    if H.valid(vm) then return vm end
    local w = nil; pcall(function() w = page.WBP_Armory_ItemSlots end)
    if H.valid(w) then
        pcall(function() vm = H.lib:GetViewModel(w, H.loadCls, H.fname("Default")) end)
        if H.valid(vm) then H.once("lo2", "the page's own loadout view-model answered nothing; its WBP_Armory_ItemSlots widget had one (used from now on when the page has none)"); return vm end
    end
    H.once("lo0", ("no loadout view-model on the page (%s) nor on its WBP_Armory_ItemSlots widget (%s)"):format(
        "WBP_Menu_Armory_WeaponMods", H.valid(w) and "present" or "missing"))
    return nil
end
function H.modeOf(page)
    local vm = H.loadoutOf(page)
    if not H.valid(vm) then return nil, "no loadout view-model on the page" end
    local gear = nil; pcall(function() gear = vm.GearActor end)
    if not H.valid(gear) then return nil, "the loadout has no gear actor" end
    local c = nil; pcall(function() c = gear:GetClass() end)
    local cn = H.valid(c) and H.str(function() return c:GetFName():ToString() end) or nil
    if not cn then return nil, "the gear actor's class is unreadable" end
    if H.ours[cn] then return "saber", cn end
    return "blaster", cn .. (H.isSaberClass(c) and " (a stock saber: stock page)" or "")
end
-- ---- a section (WBP_InventoryGridGroup) -> its page, its view-model, its kind
function H.pageOf(entry)
    local o = entry
    for _ = 1, H.OUTER_MAX do
        local okO, p = pcall(function() return o:GetOuter() end)
        if not okO or not H.valid(p) then return nil end
        if H.cls(p) == H.PAGE_CLASS then return p end
        o = p
    end
    return nil
end
function H.sectioned(page)
    local s = nil; pcall(function() s = page.WBP_InventoryGrid_Sectioned end)
    if not H.valid(s) then return nil end
    local l = nil; pcall(function() l = s.InventoryGroupList end)
    return H.valid(l) and l or nil
end
function H.vmOf(entry, page)
    local l = H.sectioned(page)
    if not l then return nil, "WBP_Menu_Armory_WeaponMods.WBP_InventoryGrid_Sectioned.InventoryGroupList is missing" end
    local first = nil; pcall(function() first = l:GetItemAt(0) end)
    if not H.valid(first) then return nil, "the section list has no item yet" end
    -- the item's class, then its supers: /Game/ classes used in this call only, never kept (H.vmDepth is a number)
    local chain, names = {}, {}
    local c = nil; pcall(function() c = first:GetClass() end)
    for _ = 1, H.SUPER_MAX do
        if not H.valid(c) then break end
        local cn = H.str(function() return c:GetFName():ToString() end) or "?"
        if cn == "MDViewModelBase" or cn == "Object" then break end
        chain[#chain + 1] = c; names[#names + 1] = cn
        local okS, s = pcall(function() return c:GetSuperStruct() end)
        c = okS and s or nil
    end
    local function at(d)
        local vm = nil
        pcall(function() vm = H.lib:GetViewModel(entry, chain[d], H.fname("Default")) end)
        return H.valid(vm) and vm or nil
    end
    if H.vmDepth and chain[H.vmDepth] then
        local vm = at(H.vmDepth); if vm then return vm end
    end
    for d = 1, #chain do
        if d ~= H.vmDepth then
            local vm = at(d)
            if vm then
                if H.vmDepth ~= d then
                    H.vmDepth = d
                    H.once("vmd|" .. d, ("section view-model answers as %s (class depth %d of the list item %s)"):format(names[d], d - 1, names[1]))
                end
                return vm
            end
        end
    end
    return nil, ("MDViewModel GetViewModel(section, {%s}, Default) answered nothing"):format(#names > 0 and table.concat(names, " > ") or "no item class")
end
-- a section view-model missed ON A SABER PAGE: transient until VM_MISS_MAX counted misses in a row (one per MISS_GAP_S at most)
function H.vmMissed(err, ef)
    local now = H.now()
    if H.missAt and now - H.missAt < H.MISS_GAP_S then return end   -- the same pass / burst: counted once
    H.misses = H.misses + 1; H.missAt = now
    if H.misses >= H.VM_MISS_MAX then
        H.standDown(("saber page: %d consecutive saber-page attempts found no section view-model (last: %s; %s)"):format(
            H.misses, tostring(err), (ef or "?"):match("([^%.]+)$") or "?"))
        return
    end
    H.log(("saber page: section view-model not found yet (%s); attempt %d of %d, the section stays stock and is retried"):format(
        tostring(err), H.misses, H.VM_MISS_MAX))
    if not H.retryArmed and type(H.after) == "function" then
        H.retryArmed = true
        pcall(H.after, H.RETRY_MS[math.min(H.misses, #H.RETRY_MS)], function() local okR, e = pcall(H.retry); if not okR then H.once("er", "retry error: " .. tostring(e)) end end, "saberheadings")
    end
end
-- 2026-10-12 (retail 03:24:01 "weapon no loadout view-model on the page -> unknown: stock, unfiltered" at page open): the
-- loadout view-model is assigned a tick after the sections build, so an unknown weapon is retried like a section miss - a
-- bounded backed-off retry (RETRY_MS, UNKNOWN_MAX tries, one FindAllOf each, outside every hook). Never a stand-down.
function H.unknownMissed(how)
    if H.unkArmed or type(H.after) ~= "function" then return end
    if H.unkN >= H.UNKNOWN_MAX then H.once("unkmax", "the weapon is still unknown after " .. H.UNKNOWN_MAX .. " retries (" .. tostring(how) .. "): stock until the next page update"); return end
    H.unkN = H.unkN + 1; H.unkArmed = true
    H.log(("weapon unknown (%s): page retried in %.1f s (attempt %d of %d)"):format(tostring(how), H.RETRY_MS[math.min(H.unkN, #H.RETRY_MS)] / 1000, H.unkN, H.UNKNOWN_MAX))
    pcall(H.after, H.RETRY_MS[math.min(H.unkN, #H.RETRY_MS)], function()
        H.unkArmed = false
        local okR, e = pcall(H.retry); if not okR then H.once("eru", "unknown-weapon retry error: " .. tostring(e)) end
    end, "saberheadings")
end
function H.vmFound()
    if H.misses > 0 then H.log(("saber page: section view-model found after %d miss(es): headings apply"):format(H.misses)) end
    H.misses, H.missAt = 0, nil
end
-- the backed-off retry (a pump timer, game thread; NOT a hook path): one FindAllOf, then the page pass
function H.retry()
    H.retryArmed = false
    if H.down then return end
    H.retries = H.retries + 1
    local page = H.findPage()
    if page then H.applyPage(page, "retry " .. H.retries) end
end
function H.kindOf(vm)
    local kind = nil
    pcall(function()
        for _, t in ipairs(H.list(vm.ItemQuery.TagDictionary)) do
            local n = H.str(function() return t.TagName:ToString() end)
            local k = n and n:sub(1, #H.SLOT) == H.SLOT and n:sub(#H.SLOT + 1) or nil
            if k == "Barrel" or k == "Cell" or k == "Scope" or k == "Stock" then kind = k end
        end
    end)
    return kind
end
-- ---- one item view-model: a saber mod?
function H.isSaberItem(item)
    local n = H.str(function() return item.AssetId.PrimaryAssetName:ToString() end)
    if n and H.itemKind[n] ~= nil then return H.itemKind[n] end
    local yes = (n ~= nil and H.mods[n]) and true or false
    if not yes then
        pcall(function()
            for _, t in ipairs(H.list(item.Tags.GameplayTags)) do
                local tn = H.str(function() return t.TagName:ToString() end)
                if tn and tn:sub(1, #H.SLOT) == H.SLOT and tn:sub(#H.SLOT + 1):match("^%a+%.Saber") then yes = true end
            end
        end)
    end
    if n then H.itemKind[n] = yes end
    return yes
end
-- the grid filter: keep = saber mods on a saber page, everything else on any other page; on a saber page the DUALHEX left
-- twins go too (2026-10-12), except on a DUAL of ours without dualHex (its left slots are still filled by the twins themselves)
function H.hidesTwins(mode, cls)
    if mode ~= "saber" or H.nTwins == 0 then return false end
    if not (type(CP) == "table" and CP.dhLive) then return false end    -- DUALHEX off (settings / not armed): the twins list, as B0
    return not (cls and H.kinds[cls] == "dual" and not H.dhActors[cls])
end
-- the page's re-filter key: a switch between a dualHex dual and a dual without it (both "saber") must re-filter the grids
function H.modeKey(mode, cls)
    if mode == "saber" and H.nTwins > 0 and not H.hidesTwins(mode, cls) then return "saber+twins" end
    return tostring(mode)
end
function H.isTwin(item)
    local n = H.str(function() return item.AssetId.PrimaryAssetName:ToString() end)
    return n ~= nil and H.twins[n] == true
end
function H.filter(entry, mode, kind, cls)
    local grid = nil; pcall(function() grid = entry.ItemGridMod end)
    if not H.valid(grid) then
        if mode == "saber" then H.standDown("WBP_InventoryGridGroup.ItemGridMod is missing")
        else H.once("nogrid", "WBP_InventoryGridGroup.ItemGridMod is missing on a " .. tostring(mode) .. " page: left stock (no stand-down)") end
        return
    end
    local n = 0; pcall(function() n = grid:GetNumItems() end)
    if type(n) ~= "number" or n <= 0 then return end
    local gone, twins = 0, 0
    local hideT = H.hidesTwins(mode, cls)
    for i = n - 1, 0, -1 do
        local it = nil; pcall(function() it = grid:GetItemAt(i) end)
        if H.valid(it) then
            local drop = H.isSaberItem(it) ~= (mode == "saber")
            local twin = (not drop) and hideT and H.isTwin(it)
            if (drop or twin) and pcall(function() grid:RemoveItem(it) end) then gone = gone + 1; if twin then twins = twins + 1 end end
        end
    end
    if twins > 0 then
        H.twinsHidden = H.twinsHidden + twins
        H.once("tw|" .. tostring(kind), ("saber page: %s hides %d left twin(s) (DUALHEX: the hex group decides the blade; logged once per section)"):format(tostring(kind), twins))
    end
    if gone == 0 then return end
    H.removed = H.removed + gone
    if gone >= n then   -- the stock empty state (UpdateItemGrid +823): the grid Collapsed, EmptyText SelfHitTestInvisible
        pcall(function() grid:SetVisibility(H.VIS_COLLAPSED) end)
        pcall(function() entry.EmptyText:SetVisibility(H.VIS_SHT_INVISIBLE) end)
    end
    H.once("f|" .. mode .. "|" .. tostring(kind), ("%s page: %s keeps %s (%d of %d removed; logged once per section and mode)"):format(
        mode, tostring(kind), mode == "saber" and "saber mods only" or "no saber mod", gone, n))
end
-- the heading of one section: ours (text + optional borrowed icon) or the stock one (its own TagData through its own handler)
function H.header(entry, vm, kind, mode)
    local td = nil; pcall(function() td = vm.TagData end)
    if mode ~= "saber" then   -- the stock heading: no sub-header read, never a stand-down
        if H.valid(td) then return pcall(function() entry[H.TAGDATA_FN](entry, td) end) end
        return false
    end
    local sub = nil; pcall(function() sub = entry.WBP_SectionSubHeader end)
    if not H.valid(sub) then H.standDown("WBP_InventoryGridGroup.WBP_SectionSubHeader is missing"); return false end
    local icon = H.cfg.icons[kind]
    if icon and H.valid(td) then
        local ivm = nil
        pcall(function() ivm = td:FindOrCreateTagUIDataViewModel(entry, { TagName = H.fname(icon) }) end)
        if H.valid(ivm) then pcall(function() entry[H.TAGDATA_FN](entry, ivm) end)
        else H.once("icon|" .. icon, "icon tag " .. icon .. " has no tag-UI view-model: the stock icon stays") end
    end
    local text = H.cfg.headings[kind]
    if not text then return true end
    return H.writeText(sub, text, kind)
end
-- ---- the heading text (2026-10-12, retail 03:31:05: "UE4SS has no FText constructor" stood the whole feature down). The
-- routes to an FText, probed at arm time (H.probeText), first that works: the FText global (UE4SS builds that have it), then
-- KismetTextLibrary:Conv_StringToText (a /Script/ CDO, looked up at arm time, kept), then the plain Lua string (UE4SS converts
-- a string for a TextProperty parameter). A route whose SetHeaderText raises is dropped (logged) and the next one is tried
-- in the same call; only when NONE works do the headings stay stock - the filter and the Stabilizer hiding keep running.
function H.probeText()
    local c, tried = {}, {}
    if FText ~= nil then
        local ok, t = pcall(FText, "ZCSDK")
        if ok and t ~= nil then c[#c + 1] = "FText" else tried[#tried + 1] = "FText global raised / answered nil" end
    else tried[#tried + 1] = "no FText global" end
    if H.valid(H.ktl) then
        local ok, t = pcall(function() return H.ktl:Conv_StringToText("ZCSDK") end)
        if ok and t ~= nil then c[#c + 1] = "Conv_StringToText" else tried[#tried + 1] = "Conv_StringToText " .. (ok and "answered nil" or "raised") end
    else tried[#tried + 1] = "no KismetTextLibrary CDO" end
    c[#c + 1] = "string"
    H.textCands = c
    H.log(("heading text routes: %s (in that order)%s"):format(table.concat(c, " > "),
        #tried > 0 and ("; not available: " .. table.concat(tried, ", ")) or ""))
end
function H.mkText(how, text)
    if how == "FText" then return FText(text) end
    if how == "Conv_StringToText" then return H.ktl:Conv_StringToText(text) end
    return text
end
function H.writeText(sub, text, kind)
    if H.noHeadings then return false end
    if not H.textCands then H.probeText() end
    local errs = {}
    for _, how in ipairs(H.textCands) do
        if not H.textBad[how] then
            local ok, e = pcall(function() sub:SetHeaderText(H.mkText(how, text)) end)
            if ok then
                if H.textHow ~= how then H.textHow = how; H.log(("headings written through %s (first: %s = %s)"):format(how, tostring(kind), text)) end
                return true
            end
            H.textBad[how] = true
            errs[#errs + 1] = how .. ": " .. tostring(e)
            H.log(("heading text route %s FAILED (dropped for the session): %s"):format(how, tostring(e)))
        end
    end
    H.noHeadings = "no heading text route works" .. (#errs > 0 and (" (" .. table.concat(errs, "; ") .. ")") or "")
    H.log("HEADINGS OFF for the session (the sections keep their stock names; the filter and the Stabilizer hiding still run): " .. H.noHeadings)
    return false
end
-- ---- one section: header, visibility, filter. -> true when it was ours to handle
function H.applyGroup(entry, page, why)
    if H.down then return false end
    local ef = H.full(entry)
    if H.notOurs[ef] then return false end
    page = page or H.pageOf(entry)
    if not page then H.notOurs[ef] = true; return false end   -- a section of another page (utility, shop): never ours
    local mode, how = H.modeOf(page)
    local pf = H.full(page)
    if H.modeSeen[pf] ~= tostring(mode) then
        H.modeSeen[pf] = tostring(mode)
        H.log(("page %s: weapon %s -> %s (%s)"):format(pf:match("([^%.]+)$") or pf, tostring(how), mode and (mode .. " page") or "unknown: stock, unfiltered", why))
    end
    if mode == nil then H.unknownMissed(how) elseif H.unkN > 0 then H.unkN = 0 end
    if mode ~= "saber" then return H.applyStock(entry, page, ef, mode) end
    -- a saber page: the section's kind comes from its view-model (a nil here is transient: the section stays stock, retried)
    local vm, err = H.vmOf(entry, page)
    if not vm then H.vmMissed(err, ef); return false end
    H.vmFound()
    local kind = H.kindOf(vm)
    if not kind then H.once("kind|" .. ef, "a section with no Barrel/Cell/Scope/Stock slot tag in its query: left alone (" .. ef .. ")"); return false end
    local t = H.touched[ef]
    if not t then
        local v = H.VIS_VISIBLE; pcall(function() v = entry:GetVisibility() end)
        t = { vis = v }; H.touched[ef] = t
    end
    if kind == "Stock" then
        if H.cfg.hideStock and t.hidden ~= true then pcall(function() entry:SetVisibility(H.VIS_COLLAPSED) end); t.hidden = true end
    elseif t.hdr ~= "saber" and H.header(entry, vm, kind, "saber") then t.hdr = "saber"; H.relabels = H.relabels + 1 end
    if H.filterOn then H.filter(entry, mode, kind, how) end
    t.mode = H.modeKey(mode, how)
    H.applies = H.applies + 1
    return true
end
-- a page whose weapon is NOT a saber of ours (a blaster, a stock saber, unknown): the stock section back, the reverse filter. No
-- section view-model lookup unless THIS section was relabelled before (its stock TagData), and never a stand-down: a miss there
-- leaves t.mode unset, so the next UpdateItemGrid / NavigateToFirstItem tries again.
function H.applyStock(entry, page, ef, mode)
    local t = H.touched[ef]
    local done = true
    if t then
        if t.hidden then pcall(function() entry:SetVisibility(t.vis or H.VIS_VISIBLE) end); t.hidden = false end
        if t.hdr == "saber" then
            local vm, err = H.vmOf(entry, page)
            if vm and H.header(entry, vm, nil, "stock") then t.hdr = "stock"
            else done = false; H.once("rs|" .. ef, "the stock heading is not back yet on " .. ((ef:match("([^%.]+)$")) or ef) .. " (" .. tostring(err or "TagData") .. "): retried at the next update, no stand-down") end
        end
    end
    if mode and H.filterOn then H.filter(entry, mode, nil) end
    if t then if done then t.mode = tostring(mode) end
    elseif mode then H.touched[ef] = { mode = tostring(mode) } end
    H.applies = H.applies + 1
    return true
end
-- ---- the whole page (arming, NavigateToFirstItem, a retry): every section whose mode changed re-runs its own UpdateItemGrid
function H.applyPage(page, why)
    if H.down then return end
    local mode, how = H.modeOf(page)
    if mode == nil then H.unknownMissed(how) elseif H.unkN > 0 then H.unkN = 0 end
    local l = H.sectioned(page)
    if not l then
        if mode == "saber" then H.standDown("WBP_Menu_Armory_WeaponMods.WBP_InventoryGrid_Sectioned.InventoryGroupList is missing")
        else H.once("nolist", "WBP_InventoryGrid_Sectioned.InventoryGroupList is missing on a " .. tostring(mode) .. " page: left stock (no stand-down)") end
        return
    end
    local entries = {}; pcall(function() entries = H.list(l:GetDisplayedEntryWidgets()) end)
    for _, e in ipairs(entries) do
        if H.valid(e) and not H.down then
            local ef = H.full(e)
            local t = H.touched[ef]
            local mk = H.modeKey(mode, how)
            if (t and t.mode or "nil") ~= mk then
                -- the section re-queries natively (its list back to stock); the UpdateItemGrid hook then filters it. If the
                -- call raised, or the hook did not see a Lua-made call, the section is handled here directly.
                if H.updOk then pcall(function() e:UpdateItemGrid() end) end
                t = H.touched[ef]
                if (t and t.mode or "nil") ~= mk then H.applyGroup(e, page, why) end
            end
        end
    end
end
-- ---- the hooks' callbacks (game thread; each guarded)
function H.onPoke() H.pokes = H.pokes + 1 end
function H.onUpdate(ctx)
    H.hookCalls = H.hookCalls + 1
    if H.down then return end
    local okE, e = pcall(function() return ctx:get() end)
    if okE and H.valid(e) then H.applyGroup(e, nil, "UpdateItemGrid") end
end
function H.onNav(ctx)
    H.hookCalls = H.hookCalls + 1
    if H.down then return end
    local okP, p = pcall(function() return ctx:get() end)
    if okP and H.valid(p) then H.applyPage(p, "NavigateToFirstItem") end
end
-- ---- arming
function H.findPage()
    H.lookups = H.lookups + 1
    local ok, list = pcall(FindAllOf, H.PAGE_CLASS)
    if not ok or type(list) ~= "table" then return nil end
    for _, p in ipairs(list) do
        local pf = H.valid(p) and H.full(p) or ""
        if pf ~= "" and not pf:find("Default__", 1, true) and not pf:find(H.PAGE_PKG, 1, true) then return p end
    end
    return nil
end
-- the count-only hook (the CP.onEvent discipline: its callback touches no UObject, logs nothing, calls nothing)
function H.armPoke()
    if H.pokeArmed then return end
    H.pokeArmed = true                                    -- set BEFORE the call: never retried
    local okR, err = pcall(RegisterHook, H.POKE_FN, function() H.onPoke() end)
    H.pokeOk = okR
    if okR then H.log("count hook ok on " .. H.POKE_FN .. " (the page is looked for only after an inventory section queried)")
    else H.trigger = "probe"; H.log("count hook FAILED (not retried; probing instead): " .. tostring(err)) end
end
function H.armHooks()
    if H.hooksArmed then return end
    H.hooksArmed = true                                   -- set BEFORE the calls: never retried, whatever happens
    local ok1, e1 = pcall(RegisterHook, H.HOOK_UPDATE, function(ctx) local okC, err = pcall(H.onUpdate, ctx); if not okC then H.once("eu", "UpdateItemGrid hook error: " .. tostring(err)) end end)
    H.updOk = ok1
    local ok2, e2 = pcall(RegisterHook, H.HOOK_NAV, function(ctx) local okC, err = pcall(H.onNav, ctx); if not okC then H.once("en", "NavigateToFirstItem hook error: " .. tostring(err)) end end)
    H.navOk = ok2
    H.log(("hooks: UpdateItemGrid %s, NavigateToFirstItem %s (registered once, never retried)"):format(
        ok1 and "ok" or ("FAILED: " .. tostring(e1)), ok2 and "ok" or ("FAILED (character switches are seen at the next section update): " .. tostring(e2))))
    if not ok1 and not ok2 then H.standDown("neither hook could be registered") end
end
function H.task()
    if not H.loaded then
        if not injected then return H.WAIT_S end
        H.loaded = true
        local any = false
        for _, mf in ipairs(manifests) do   -- 1.8.54 (M-3): one manifest at a time
            local ok, r = pcall(H.merge, mf.m)
            if ok and r then any = true elseif not ok then log("SABERHEADINGS: " .. tostring(mf.m.name) .. "'s sabers block failed: " .. tostring(r)) end
        end
        if not any then return true end                   -- no mod asks for saber headings: stopped for good, never a lookup
        if not H.settings(UE4SS) then log("SABERHEADINGS OFF for the session: settings.ini [SABERHEADINGS] Enabled=off"); return true end
        if type(CP) == "table" then CP.shLive = true end      -- SLOTFIX waits for this block's page instead of probing itself
        H.log(("armed: %d saber mod item(s), %d saber class(es); headings %s; filter %s; trigger %s"):format(H.nMods,
            (function() local c = 0; for _ in pairs(H.ours) do c = c + 1 end; return c end)(),
            table.concat({ H.cfg.headings.Barrel or "-", H.cfg.headings.Cell or "-", H.cfg.headings.Scope or "-" }, " / "),
            H.filterOn and "on" or "off", H.trigger))
    end
    if H.armed or H.down then return true end              -- the hooks do the rest (or nothing, when stood down)
    local hub, w = strategySide()
    if not hub then H.world, H.settled = nil, false; return H.MENU_S end
    if H.world ~= w then H.world, H.settled, H.probeN = w, false, 0; return H.HUB_SETTLE_S end   -- past the hub's spawn wave
    -- one object-array walk per pass at most, each step once a session
    if not H.lib then
        if H.libTried then H.standDown("the MDViewModel library is not loaded (" .. H.LIB_CDO .. ")"); return true end
        H.libTried = true; H.lookups = H.lookups + 2
        local okL, o = pcall(StaticFindObject, H.LIB_CDO)
        if okL and H.valid(o) then H.lib = o end
        local okK, k = pcall(StaticFindObject, H.KTL_CDO)      -- the heading text route (a /Script/ CDO: kept)
        if okK and H.valid(k) then H.ktl = k end
        H.probeText()
        return H.lib and H.STEP_S or 0.1
    end
    if not H.loadCls then
        if H.clsTried then H.standDown("the loadout view-model class is not loaded (" .. H.LOADOUT_CLS .. ")"); return true end
        H.clsTried = true; H.lookups = H.lookups + 1
        local okC, o = pcall(StaticFindObject, H.LOADOUT_CLS)
        if okC and H.valid(o) then H.loadCls = o end
        return H.loadCls and H.STEP_S or 0.1
    end
    if H.trigger == "poke" then
        if not H.pokeArmed then H.armPoke(); return H.POLL_S end
        if H.pokes == H.pokesSeen then return H.POLL_S end   -- no armory section has queried since: no lookup
        H.pokesSeen = H.pokes
    end
    local page = H.findPage()
    if not page then
        if H.trigger == "poke" then return H.PROBE_GAP_S end
        H.probeN = H.probeN + 1
        return H.PROBE_S[math.min(H.probeN, #H.PROBE_S)]
    end
    H.armHooks()
    H.armed = true
    if type(CP) == "table" then CP.shPageSeen = true end   -- SLOTFIX arms its teaser hook on it (the armory classes are resident)
    if not H.down then H.applyPage(page, "the page was found") end
    return true
end
H.taskRef = addTask("saberheadings", 5.0, function()
    local ok, r = pcall(H.task)
    if not ok then log("SABERHEADINGS error (the loop keeps running): " .. tostring(r)); return 10 end
    return r
end)
if SABERHEADINGS_EXPORT then SABERHEADINGS_EXPORT(H) end    -- tools/replay_saberheadings.py only (a nil global in the game)
end
-- ---- 2026-10-11: SABERHEADINGS (end) ----

-- ---- 2026-10-11: SLOTFIX (begin; tools/replay_slotfix.py extracts this block verbatim) ----
-- FIXED MOD-SLOT COUNTS FOR SABERS OF OURS (the override-free route, §6 of the saber fixed-slots scope; the def key
-- `saberSlotFix`, tools/zcmod-sabercust.js (6); NOT retail-proven: docs/recon/SABER_B0_PROBE_CHECKLIST.md probe 5, G1-G3 first).
-- THE COUNT (ABrunoHQInventory::GetEquipmentSlotAmount 0x9ad0360): T (the HQ team bonus, when the class UseTeamBonusSlots)
-- + (the class's EquipableItemLimits HAS BitReactor.ItemType.Modification ? K + trunc(BonusModificationSlots + 0.5) : 1).
-- Stock heroes / recruits run Class_Default, which has NO such key: the attribute is never read and the count is 1 + T.
-- So, with no stock asset overridden or shipped:
--   1. THE KEY, IN MEMORY: a class asset a wielder of ours runs gets EquipableItemLimits[Modification] = 1 through UE4SS's
--      TMap binding, ONCE per class per session and ONLY when the key is missing (a class that has it - the Jedi / Sith
--      class mods' classModSlots - is never touched). Count-neutral for every other unit of that class (1 + T + 0 with stock
--      A = 0: probe G3). The write is read back by iterating the map; if the Add raises or the read-back does not show the
--      key with value 1, it is logged ONCE and SLOTFIX stands down for the session (nothing else is written).
--   2. THE COUNT GE, ON WIELDERS ONLY: one of the def's generated Override GEs on BitReactorCombatSet.BonusModificationSlots
--      (GE_<ns>_SaberSlots_M3 .. _P5; a negative v stored as v - 0.5 for the trunc(x + 0.5) read). The value is
--      self-correcting: v' = v + (want - GetEquipmentSlotAmount), so K, T and UseTeamBonusSlots are never read; want = the
--      def's count for the saber's kind (single 3 / staff 3 / dual 6). A wielder that no longer holds a saber of ours loses
--      the GE (its count goes back to 1 + T).
--   2b. THE HQ SLOT LIST (2026-10-12, retail probe 4b + the decode in docs/recon/SABER_SLOTS_OPENHEX_RECON.md): the page does NOT
--      draw GetEquipmentSlotAmount. Its open hexes are UBrunoItemSlotListViewModel.ItemSlots (UpdateItemSlots 0x9b3e3b0), one per
--      entry of the HQ's PERSISTED per-character slot array (GetSpecificEquipmentSlotsForCharacter), and that array is resized to
--      the amount only by ABrunoHQInventory::InitializeEquipmentSlots (0x9ad1700) - called from RefreshEquipmentSlots, an equip
--      (EquipItemIDToCharacter), SetBonusEquipmentSlots and HandleOnCharacterReturned. A GE alone moves the amount, not the array:
--      probe 4b drew 1 hex with an amount of 3 / 6, and a Z-6 equipped while the dual's GE was still on drew 6 (that equip ran
--      InitializeEquipmentSlots at 6). So after EVERY apply / removal / stale-array find SLOTFIX calls the BlueprintCallable
--      ABrunoHQInventory:RefreshEquipmentSlots(char, Modification): InitializeEquipmentSlots (a shrink also unequips the mods past
--      the new count: the game's own rule) + the HQ's slot-count delegate, which the list view-model is bound to
--      (OnEquipmentSlotBonusChanged -> UpdateItemSlots -> the ItemSlots broadcast the page redraws on).
--      HandleOnCharacterReturned (a unit back from being sent away: the roster's OnCharacterSentAway / OnCharacterReturned) re-
--      initializes the arrays from the amount at that moment: a pre-hook on it puts a remembered wielder's GE back FIRST, so its
--      saber mods are not unequipped by a count of 1.
--   3. THE TEASER: a hook on VM_ArmoryLockedSlotsList_C:SetupLists empties its LockedSlots array (+ a field-notify
--      broadcast) when the view-model's loadout holds a saber of ours, any kind (the locked hexes are the ceiling fact
--      MaximumModSlotCount 4 minus the open count, so a 3-hex saber would always show one locked hex). 2026-10-12: the
--      probe-4 hook on GetLockedSlotCount could not work (its out param is written into the caller's frame; section 3 below).
--      2026-10-12 (probe 4b): emptying LockedSlots is not enough - the page (WBP_Armory_ItemSlots ubergraph +987) COPIES
--      LockedSlots into its lockedSlotList only when ItemSlots broadcasts, and SetupLists runs only at the view-model's init. So
--      after an empty the list view-model's ItemSlots is re-broadcast (the page re-copies both lists), and after a count change
--      every live Modification locked list re-runs SetupLists first (a blaster after a saber gets its stock locked hexes back).
-- WHEN. It rides SABERLOOK's scan (CP.slOnScan: the scan already holds the saber actors of ours), in the HUB only, and works
-- only when the wielder set changed or every REASSERT_S (a GE that did not survive a load is put back). A check costs ONE
-- FindFirstOf (the HQ inventory); a GE class lookup (StaticFindObject) is capped at one per check; /Script/ objects (the ASC
-- library CDO, the CharacterClassComponent class) are looked up once a session; /Game/ classes are never kept (ZCUI's
-- execGetViewModel crash: a cached Blueprint class freed by a load). No UObject is kept across checks: wielders are
-- remembered by full name (+ their class short name, for the one FindAllOf that finds a former wielder to strip its GE).
-- NO SOFT POINTERS: CharacterClassComponent.CharacterClass (hard), EquipableItemLimits (a TMap<FGameplayTag,int32>), the
-- ASC, GearActor (hard), ints. ue4ss/Mods/ZCSDKLoader/settings.ini [SLOTFIX] Enabled = on | off, Teaser = on | off.
do
local F = {
    MOD_TAG      = "BitReactor.ItemType.Modification",
    CCC_CLASS    = "/Script/BitReactorGame.CharacterClassComponent",
    ASCLIB_CDO   = "/Script/GameplayAbilities.Default__AbilitySystemBlueprintLibrary",
    LIB_CDO      = "/Script/MDViewModel.Default__MDViewModelFunctionLibrary",
    LOADOUT_CLS  = "/Script/Bruno.BrunoCharacterLoadoutViewModel",
    LIST_CLS     = "/Script/Bruno.BrunoItemSlotListViewModel",
    RETURN_FN    = "/Script/Bruno.BrunoHQInventory:HandleOnCharacterReturned",
    EQUIP_FN     = "/Script/Bruno.BrunoHQInventory:EquipItemIDToCharacter",
    TEASER_FN    = "/Game/Game/UI/Strategy/Armory/BP/VM_ArmoryLockedSlotsList.VM_ArmoryLockedSlotsList_C:SetupLists",
    TEASER_CLASS = "VM_ArmoryLockedSlotsList_C",
    FNLIB_CDO    = "/Script/Engine.Default__FieldNotificationLibrary",
    REASSERT_S   = 60, LOG_CAP = 200, WAIT_S = 5, MENU_S = 10, HUB_SETTLE_S = 10,
    TEASER_PROBE_S = { 10, 20, 40, 60, 120 },
    PENDING_S    = 2, PENDING_MAX = 8, TEASER_LATER_MS = 100, PKG_RETRY_S = 10,
    INI          = "Mods/ZCSDKLoader/settings.ini",
    loaded = false, live = false, down = nil, cfg = nil, kinds = {}, ours = {},
    keyed = {}, applied = {}, charCls = {}, sig = nil, lastCheck = -1e9, now = 0,
    ascLib = nil, cccCls = nil, mdLib = nil, loadCls = nil, fnLib = nil, tried = {}, pkgTried = {}, pendingN = 0,
    teaserOn = true, teaserArmed = false, teaserOk = false, teaserProbeN = 0, teaserZeroed = 0, teaserLaterArmed = false,
    world = nil, settled = false,
    listCls = nil, dirty = false, refreshes = 0, redraws = 0, kindShort = {}, returnArmed = false, returnOk = false, returnCalls = 0,
    equipArmed = false, equipOk = false, equipCalls = 0,
    -- 2026-10-12 (probe 4e): the key re-verified on the live class object every check (F.keyed only says "logged"), the
    -- clamp / "nothing to change" path re-applies (F.stuck counts the tries), the gear-kit hooks and the watch window (C3)
    GEAR_FNS     = { "/Script/Bruno.BrunoCharacterLoadoutViewModel:HandleOnGearKitsChanged", "/Script/Bruno.BrunoItemSlotListViewModel:OnGearKitsChanged" },
    STUCK_MAX    = 3, WATCH_S = 3, WATCH_N = 10, REFUSE_SLOT = 99,
    -- 1.8.45: F.gaveUp (full name -> "kind|class": a unit whose count does not follow the GE), F.noMove (tries in a row that moved nothing)
    NOMOVE_MAX   = 2, gaveUp = {}, noMove = {}, gaveUps = 0,
    stuck = {}, keyReAdds = 0, gearArmed = false, gearOk = 0, gearCalls = 0, watchN = 0, preCalls = 0, preFixes = 0, refused = 0,
    -- 1.8.37: a former wielder is not stripped while a saber of ours of its kind is ownerless (a load re-attaching it), up to
    -- STRIP_DEFER_S (F.goneAt: full name -> when it was first missed); an equip that does not land is said (NOTE_MS later)
    STRIP_DEFER_S = 30, NOTE_MS = 150, goneAt = {}, deferred = 0, notLanded = 0,
    clock = function() return (os.clock and os.clock()) or 0 end,   -- the replay drives its own clock
    logged = 0, noted = {}, checks = 0, lookups = 0, applies = 0, removes = 0, keyAdds = 0,
    after = after,                                         -- the pump's one-shot timer (game thread)
}
function F.log(m) if F.logged < F.LOG_CAP then F.logged = F.logged + 1; log("SLOTFIX " .. m) end end
function F.once(k, m) if not F.noted[k] then F.noted[k] = true; F.log(m) end end
function F.valid(o)
    if o == nil then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return (ok and v) and true or false
end
function F.str(f) local ok, v = pcall(f); if ok and type(v) == "string" then return v end; return nil end
function F.full(o) return F.str(function() return o:GetFullName() end) or "?" end
function F.cname(o) return F.str(function() return o:GetClass():GetFName():ToString() end) end
function F.fname(s) local ok, n = pcall(FName, s); if ok and n then return n end; return s end
function F.tag() return { TagName = F.fname(F.MOD_TAG) } end
function F.standDown(why)
    if F.down then return end
    F.down = why
    F.log("STANDS DOWN for the session (no key, no count GE written from now on; GEs already applied stay until the next load): " .. why)
end
-- ---- the manifest: sabers.slotFix (counts, the GE paths by value) + the actors' kinds
function F.merge(m)
    local s = m and m.sabers
    if type(s) ~= "table" or (tonumber(s.schema) or 0) < 1 then return false end
    for cls, a in pairs(s.actors or {}) do
        if type(a) == "table" then F.ours[cls] = true; F.kinds[cls] = (a.kind == "dual" or a.kind == "staff") and a.kind or "single" end
    end
    local p = s.slotFix
    if type(p) ~= "table" or type(p.ges) ~= "table" then return false end
    if F.cfg then F.once("cfg2", "two mods declare sabers.slotFix: the later one's counts and GEs are used") end
    F.cfg = { counts = { single = tonumber(p.counts and p.counts.single) or 3, staff = tonumber(p.counts and p.counts.staff) or 3,
                         dual = tonumber(p.counts and p.counts.dual) or 6 },
              min = tonumber(p.min) or -3, max = tonumber(p.max) or 5, ges = {}, teaser = p.teaser ~= false }
    for v, path in pairs(p.ges) do if tonumber(v) and type(path) == "string" then F.cfg.ges[tonumber(v)] = path end end
    return true
end
function F.settings(root)
    local text = ""
    local f = io.open(root .. F.INI, "rb")
    if f then text = f:read(262144) or ""; f:close() end
    local vals, sec = {}, ""
    for raw in (text .. "\n"):gmatch("([^\r\n]*)\r?\n") do
        local line = raw:gsub("^\239\187\191", ""):gsub("%s*[;#].*$", ""):match("^%s*(.-)%s*$") or ""
        local s = line:match("^%[%s*(.-)%s*%]$")
        if s then sec = s:lower()
        elseif sec == "slotfix" then
            local k, v = line:match("^([^=]-)%s*=%s*(.*)$")
            if k then vals[k:lower()] = v:lower() end
        end
    end
    local off = function(v) return v == "off" or v == "0" or v == "false" end
    if off(vals.enabled) then return false end
    F.teaserOn = F.cfg.teaser and not off(vals.teaser)
    return true
end
-- a /Script/ object, looked up ONCE a session (never collected: kept). -> obj | nil
function F.script(key, path)
    if F[key] then return F[key] end
    if F.tried[key] then return nil end
    F.tried[key] = true; F.lookups = F.lookups + 1
    local ok, o = pcall(StaticFindObject, path)
    if ok and F.valid(o) then F[key] = o; return o end
    F.once("miss|" .. key, "not found: " .. path)
    return nil
end
-- ---- 1. the key. -> true when the class has EquipableItemLimits[Modification] (found, or added and read back)
function F.readKey(map)
    local val = nil
    local ok = pcall(function()
        map:ForEach(function(k, v)
            local kk = k; pcall(function() local g = k:get(); if g ~= nil then kk = g end end)
            local n = F.str(function() return kk.TagName:ToString() end)
            if n == F.MOD_TAG then
                local vv = v; pcall(function() local g = v:get(); if g ~= nil then vv = g end end)
                val = tonumber(vv)
            end
        end)
    end)
    return ok, val
end
-- 1.8.45: the class object of a unit (hard property reads only) | nil (said once). Split from F.ensureKey so a unit SLOTFIX gave up
-- on (F.gaveUp) is recognised by its class WITHOUT the class map being touched again.
function F.classOf(char)
    local ccc = nil
    local cc = F.script("cccCls", F.CCC_CLASS)
    if not cc then F.standDown("the CharacterClassComponent class is not loaded"); return nil end
    pcall(function() ccc = char:GetComponentByClass(cc) end)
    if not F.valid(ccc) then F.once("noccc|" .. F.full(char), "no CharacterClassComponent on " .. F.full(char) .. ": skipped"); return nil end
    local cls = nil; pcall(function() cls = ccc.CharacterClass end)
    if not F.valid(cls) then F.once("nocls|" .. F.full(char), "no CharacterClass on " .. F.full(char) .. ": skipped"); return nil end
    return cls
end
function F.ensureKey(char, cls)
    cls = cls or F.classOf(char)
    if not cls then return false end
    local cf = F.full(cls)
    -- 2026-10-12 (retail probe 4e C7, 22:48:59 save load -> 22:49:48 "count GE v nil -> 5, read back 1 hexes - NOT the wanted
    -- count"): the key was cached by the class's NAME ("once a session"), but a load brings a FRESH class object under the same
    -- name without the in-memory key, so the GE landed and the amount stayed the flat 1 (no key = the attribute is never read).
    -- The key is now READ on the live class object at EVERY check (a TMap of a few entries: no lookup); F.keyed only remembers
    -- what was logged ("found" | "added"), and a key that went missing after "added" is re-added and said so.
    local map = nil; pcall(function() map = cls.EquipableItemLimits end)
    if map == nil then F.standDown("CharacterClass.EquipableItemLimits is unreadable on " .. cf); return false end
    local okR, val = F.readKey(map)
    if not okR then F.standDown("EquipableItemLimits cannot be iterated (TMap:ForEach raised) on " .. cf); return false end
    local short = cf:match("([^%./]+)$") or cf
    if val ~= nil then
        if F.keyed[cf] == nil then
            F.keyed[cf] = "found"
            F.log(("class %s already has %s = %d: left untouched"):format(short, F.MOD_TAG, val))
        end
        return true
    end
    local again = F.keyed[cf] == "added"
    local okA, err = pcall(function() map:Add(F.tag(), 1) end)
    local _, back = F.readKey(map)
    if not okA or back ~= 1 then
        F.standDown(("TMap:Add of %s = 1 on %s %s (read back: %s)"):format(F.MOD_TAG, cf,
            okA and "did not stick" or ("raised: " .. tostring(err)), tostring(back)))
        return false
    end
    F.keyed[cf] = "added"; F.keyAdds = F.keyAdds + 1
    if again then
        F.keyReAdds = F.keyReAdds + 1
        F.log(("class %s: %s was GONE (a fresh class object after a load / a world change: the in-memory key does not survive it) - re-added IN MEMORY (read back 1; re-add %d)"):format(
            short, F.MOD_TAG, F.keyReAdds))
    else
        F.log(("class %s: %s = 1 added IN MEMORY (read back 1; re-checked at every check; count-neutral for its other units)"):format(short, F.MOD_TAG))
    end
    return true
end
-- ---- 2. the count GE
-- 2026-10-12 (retail probe 4, 03:24:48): "GE class not resident yet, loading ... _P5" and then NOTHING - the GE was never
-- applied and nothing said why. Two causes: (a) LoadAsset was handed "<pkg>.GE_X" (the Blueprint object, which a cooked
-- package does not contain), so the class never became resident; (b) a miss still consumed the check (F.sig / F.lastCheck),
-- so the apply was not tried again until the wielder set changed or REASSERT_S passed, and the retry's miss was silent (a
-- once-per-v line). Now: the GE packages are loaded with the bridge's SYNCHRONOUS loadpkg at arm time and again on a miss
-- (the class is then found in the same check); a wielder whose GE is not resident (or whose apply raised) is PENDING: the
-- check is not consumed and SABERLOOK re-scans in PENDING_S (at most PENDING_MAX times in a row). Every return on the apply
-- path logs its reason once per unit and reason (F.skip), and an apply is read back (GetEquipmentSlotAmount) and logged.
function F.findGE(path)
    F.lookups = F.lookups + 1
    local ok, o = pcall(StaticFindObject, path)          -- a /Game/ class: used now, never kept
    if ok and F.valid(o) then return o end
    return nil
end
function F.pkgOf(path) return (path:match("^(.-)%.[^%.]+$")) end
-- the class for v, loading its package when it is not resident. -> class | nil, why
function F.geClass(v)
    local path = F.cfg.ges[v]
    if not path then return nil, ("the manifest has no count GE for v %s (range %d..%d)"):format(tostring(v), F.cfg.min, F.cfg.max) end
    local c = F.findGE(path)
    if c then return c end
    if F.inHook then return nil, "GE class not resident (inside the return-from-away hook: no load there; the next scan loads it)" end
    -- 2026-10-12 (retail probe 4c, 08:35:29): the GE classes loaded at arm time were COLLECTED after the hub reloaded (nothing
    -- references a GE class once no actor has the effect), and the one-shot loadpkg ("pkgTried") was never sent again, so every
    -- later check stayed "not resident" for the rest of the session. The synchronous loadpkg is now re-sent per package at most
    -- once per PKG_RETRY_S.
    local pkg = F.pkgOf(path)
    local tNow = F.clock()
    if pkg and (F.pkgTried[pkg] == nil or tNow - F.pkgTried[pkg] >= F.PKG_RETRY_S) then
        F.pkgTried[pkg] = tNow
        pcall(bridge, "ZCSDK:loadpkg|" .. pkg)            -- the bridge's synchronous LoadPackage
        c = F.findGE(path)
        if c then F.log("GE class resident after loadpkg: " .. path); return c end
    end
    pcall(LoadAsset, path)                               -- the async fallback (registry-resolved): a later check finds it
    F.once("load|" .. v, "GE class not resident yet (loadpkg did not make it resident; LoadAsset requested, retried every " .. F.PENDING_S .. " s): " .. path)
    return nil, "GE class not resident: " .. path
end
-- arm time: every count GE package, loaded once with the synchronous loadpkg, so the first check finds them
function F.preloadGEs()
    local n, have, pk = 0, 0, {}
    for _, path in pairs(F.cfg.ges) do
        local pkg = F.pkgOf(path)
        if pkg and not pk[pkg] then pk[pkg] = true; n = n + 1; pcall(bridge, "ZCSDK:loadpkg|" .. pkg) end
    end
    for _, path in pairs(F.cfg.ges) do if F.findGE(path) then have = have + 1 end end
    F.log(("count GEs: %d of %d resident after loadpkg at arm time%s"):format(have, n,
        have < n and " (the rest are loaded again on demand)" or ""))
end
function F.asc(char)
    local lib = F.script("ascLib", F.ASCLIB_CDO)
    if not lib then F.standDown("the AbilitySystemBlueprintLibrary CDO is not loaded"); return nil end
    local a = nil; pcall(function() a = lib:GetAbilitySystemComponent(char) end)
    return F.valid(a) and a or nil
end
-- -> true | false, why
function F.removeGE(asc, v)
    -- 2026-10-12 (retail probe 4c, 08:37:50 "its count GE could not come off: GE class not resident"): an ACTIVE effect holds its
    -- GameplayEffect (the spec's Def, a UPROPERTY of the ASC's active container), which keeps the class resident. So a class that
    -- StaticFindObject cannot find has no active effect anywhere: there is nothing to remove (no load needed, safe in a hook).
    local path = F.cfg.ges[v]
    if path and not F.findGE(path) then return true, "not active (its class is not resident)" end
    local c, why = F.geClass(v)
    if not c then return false, why end
    local ok, e = pcall(function() asc:RemoveActiveGameplayEffectBySourceEffect(c, nil, -1) end)
    if not ok then                                       -- a nil object param refused: the instigator is the ASC itself
        local e1 = e
        ok, e = pcall(function() asc:RemoveActiveGameplayEffectBySourceEffect(c, asc, -1) end)
        if ok then F.once("rmshape", "RemoveActiveGameplayEffectBySourceEffect took the ASC as instigator (nil raised: " .. tostring(e1) .. ")") end
    end
    if ok then F.removes = F.removes + 1; return true end
    return false, "RemoveActiveGameplayEffectBySourceEffect raised: " .. tostring(e)
end
-- -> true | false, why, pending (true: worth a quick retry)
function F.applyGE(asc, v)
    local c, why = F.geClass(v)
    if not c then return false, why, true end
    local ok, e = pcall(function() local ctx = asc:MakeEffectContext(); asc:BP_ApplyGameplayEffectToSelf(c, 1.0, ctx) end)
    if ok then F.applies = F.applies + 1; return true end
    local e1 = e                                         -- the engine makes a context itself when the handle is invalid
    ok, e = pcall(function() asc:BP_ApplyGameplayEffectToSelf(c, 1.0, {}) end)
    if ok then
        F.applies = F.applies + 1
        F.once("applyshape", "BP_ApplyGameplayEffectToSelf took an empty context (with MakeEffectContext it raised: " .. tostring(e1) .. ")")
        return true
    end
    return false, ("BP_ApplyGameplayEffectToSelf raised (with MakeEffectContext: %s; with an empty context: %s)"):format(tostring(e1), tostring(e)), true
end
-- an early return on the apply path: logged ONCE per unit and reason
function F.skip(cf, key, m) F.once(key .. "|" .. cf, (cf:match("([^%.:]+)$") or cf) .. ": " .. m) end
function F.amount(hq, char)
    local cur = nil
    pcall(function() cur = hq:GetEquipmentSlotAmount(char, F.tag()) end)
    return type(cur) == "number" and cur or nil
end
-- 2b. the HQ's persisted slot array for Modification (what the page draws): its length | nil (unreadable)
function F.slotsLen(hq, char)
    local arr = nil
    local ok = pcall(function() arr = hq:GetSpecificEquipmentSlotsForCharacter(char, F.tag()) end)
    if not ok or arr == nil then return nil end
    if type(arr) == "table" then return #arr end
    local n = nil
    pcall(function() n = arr:GetArrayNum() end)
    if type(n) ~= "number" then pcall(function() n = #arr end) end
    return type(n) == "number" and n or nil
end
-- RefreshEquipmentSlots: the array resized to the amount + the slot-count delegate (the list view-model redraws).
-- -> "<n> open" text for the log (never raises; a failure is logged once per unit and said in the text)
-- 2026-10-12 (retail probe 4e C7, 22:49:48 "read back 1 hexes - NOT the wanted count ... HQ slot list refreshed: 6 -> 1 open"):
-- a refresh resizes the persisted array to the LIVE amount and the game unequips every mod past it, so a wielder's refresh
-- (want given) runs ONLY when the live amount IS the wanted count; otherwise the array (and the mods in it) is left alone.
-- want = nil: a former wielder going back to its stock count (F.strip: the shrink is the point).
function F.refresh(hq, char, cf, want)
    local before = F.slotsLen(hq, char)
    if want ~= nil then
        local amt = F.amount(hq, char)
        if amt ~= want then
            F.refused = F.refused + 1
            return ("HQ slot list NOT refreshed (the live amount %s is not the wanted %d: a refresh would resize the list of %s to %s and unequip the mods past it)"):format(
                tostring(amt), want, tostring(before), tostring(amt))
        end
    end
    local ok, e = pcall(function() hq:RefreshEquipmentSlots(char, F.tag()) end)
    if not ok then
        F.skip(cf, "rfx", "RefreshEquipmentSlots raised (the page keeps its old hex count until the next equip): " .. tostring(e))
        return "NOT refreshed (" .. tostring(e) .. ")"
    end
    F.refreshes = F.refreshes + 1; F.dirty = true
    local n = F.slotsLen(hq, char)
    return ("HQ slot list refreshed: %s -> %s open"):format(tostring(before), tostring(n))
end
-- is count GE v still active on this ASC? true | false | nil (unknown: GetGameplayEffectCount unreadable)
function F.geLive(asc, v)
    local path = F.cfg.ges[v]
    if not path then return nil end
    local c = F.findGE(path)
    -- 2026-10-12 (retail probe 4c): a class that is not resident has no active effect (F.removeGE). Before, this answered
    -- "unknown" and the remembered v was KEPT after the hub reloaded: "v 10 ... clamped - the clamped v 5 is the one applied:
    -- nothing to change" while the new actor had no GE (Gia stayed at 1 hex), and Jae's v 2 could "not come off before v 4".
    if not c then return false end
    local n = nil
    local ok = pcall(function() n = asc:GetGameplayEffectCount(c, nil, false) end)
    if not ok then pcall(function() n = asc:GetGameplayEffectCount(c, asc, false) end) end
    if type(n) ~= "number" then return nil end
    return n > 0
end
-- one wielder: key, then count, then the HQ slot list. -> "done" | "skip" | "pending"
function F.wielder(hq, char, kind)
    local cf = F.full(char)
    local short = cf:match("([^%.:]+)$") or cf
    -- 1.8.45 (retail 10-22, 03:54-04:08, Gia = a story Mentor whose pawn runs Class_Default WITHOUT a BitReactorCombatSet): the
    -- count GE edits CombatSet.BonusModificationSlots, which that pawn does not have, so GetEquipmentSlotAmount never moved (2) and
    -- every hub load re-ran the whole retry ladder: "count GE v nil -> 4 ... v 4 -> 5 ... (try 52 .. 57 of 3)". F.stuck was never
    -- reset and only its "pending" return was capped, so the cap capped nothing across checks. Now a unit whose count does not
    -- follow the GE is GIVEN UP (F.giveUp: its GE comes off, ONE line) for the session, per (unit, saber kind, class): a later
    -- check returns at once (no class-map write, no GE, no line); a different kind or class (a real class swap) tries it again.
    local cls = F.classOf(char)
    if not cls then F.skip(cf, "nokey", "no count GE: the class key is not in place (the line above says why)"); return "skip" end
    local gsig = kind .. "|" .. (F.full(cls):match("([^%./]+)$") or "?")
    local gu = F.gaveUp[cf]
    if gu ~= nil then
        if gu == gsig then return "done" end
        F.gaveUp[cf] = nil; F.stuck[cf] = nil; F.noMove[cf] = nil
        F.log(("%s: was given up as %s, now %s (a saber kind or class change) - tried again"):format(short, gu, gsig))
    end
    if not F.ensureKey(char, cls) then F.skip(cf, "nokey", "no count GE: the class key is not in place (the line above says why)"); return "skip" end
    local want = F.cfg.counts[kind] or 3
    local cur = F.amount(hq, char)
    if not cur then F.skip(cf, "cur", "no count GE: GetEquipmentSlotAmount(Modification) is unreadable"); return "skip" end
    local v = F.applied[cf]
    if v ~= nil then
        -- a load / a mission makes NEW actors (often under the same name): a remembered v whose GE is gone would be stacked on
        local a0 = F.asc(char)
        if a0 and F.geLive(a0, v) == false then
            F.log(("%s: count GE v %d is no longer active on it (a new actor after a load, a mission or an away assignment) - recomputed from its own count"):format(short, v))
            F.applied[cf] = nil; v = nil
        end
    end
    F.kindShort[short] = kind
    if cur == want and v ~= nil then
        F.stuck[cf] = nil
        local n = F.slotsLen(hq, char)
        if n ~= nil and n ~= want then
            F.log(("%s (%s): count %d holds but the HQ slot list has %d - %s"):format(short, kind, cur, n, F.refresh(hq, char, cf, want)))
        end
        return "done"
    end
    local nv = (v or 0) + (want - cur)
    if nv < F.cfg.min or nv > F.cfg.max then
        F.skip(cf, "clamp", ("%d hexes wanted, %d now; v %d is outside the def's GE range %d..%d - clamped"):format(want, cur, nv, F.cfg.min, F.cfg.max))
        nv = math.max(F.cfg.min, math.min(F.cfg.max, nv))
    end
    -- 2026-10-12 (retail probe 4e C7, 22:51:29 "v 10 ... clamped" / "the clamped v 5 is the one applied: nothing to change", then
    -- stuck at 1 until the end): an applied v that does not move the count is NOT "nothing to change" - the GE (or the key under
    -- it) went stale. The key was re-verified above (F.ensureKey); the GE comes off and the count is recomputed from scratch on
    -- the next quick re-check (at most STUCK_MAX tries in a row, then left as it is: never a refresh below the wanted count).
    if nv == v then return F.unstick(hq, char, cf, short, kind, cur, want, v, gsig) end
    local asc = F.asc(char)
    if not asc then F.skip(cf, "asc", "no count GE: no ability system component (GetAbilitySystemComponent answered nothing)"); return "pending" end
    if v ~= nil then
        local okR, whyR = F.removeGE(asc, v)
        if not okR then F.skip(cf, "rm", ("count GE v %d could not come off before v %d: %s"):format(v, nv, tostring(whyR))); return "pending" end
    end
    local okA, whyA, pend = F.applyGE(asc, nv)
    if not okA then
        if v ~= nil then F.applied[cf] = nil end         -- the old one came off
        F.skip(cf, "apply|" .. nv, ("count GE v %d NOT applied: %s"):format(nv, tostring(whyA)))
        return pend and "pending" or "skip"
    end
    F.applied[cf] = nv
    F.charCls[cf] = F.cname(char)
    local back = F.amount(hq, char)
    if back == want then
        F.stuck[cf] = nil
        F.log(("%s (%s): %d hexes -> want %d: count GE v %s -> %d, read back %s hexes (fixed count holds); %s"):format(short, kind, cur, want,
            tostring(v), nv, tostring(back), F.refresh(hq, char, cf, want)))
        return "done"
    end
    -- below (or off) the wanted count: NO refresh (it would shrink the HQ slot list and unequip mods); the key + GE are re-checked
    -- at the next quick re-check (a second step of the self-correcting math, or a key that went stale under the GE)
    local n = (F.stuck[cf] or 0) + 1
    F.stuck[cf] = n
    -- 1.8.45: a GE that moved the count by NOTHING (read back == the count before it) twice in a row cannot be helped by the
    -- self-correcting second step (it only walks v up to the clamp: the 10-22 "v 4 -> 5"; an Override, never stacked)
    if back == cur then F.noMove[cf] = (F.noMove[cf] or 0) + 1 else F.noMove[cf] = nil end
    local why = nil
    if (F.noMove[cf] or 0) >= F.NOMOVE_MAX then why = ("the count GE moved the count by nothing on %d tries in a row"):format(F.noMove[cf])
    elseif n > F.STUCK_MAX then why = ("the count is still %s after %d tries"):format(tostring(back), F.STUCK_MAX) end
    if why then return F.giveUp(char, cf, short, kind, gsig, cur, want, why) end
    F.log(("%s (%s): %d hexes -> want %d: count GE v %s -> %d, read back %s hexes - NOT the wanted count: %s; the class key and the count GE are re-checked (try %d of %d)"):format(
        short, kind, cur, want, tostring(v), nv, tostring(back), F.refresh(hq, char, cf, want), n, F.STUCK_MAX))
    return "pending"
end
-- 1.8.45: GIVE UP on one unit for the session (per unit, saber kind and class; F.wielder tries it again on another kind / class):
-- its count GE comes off (an Override left on a pawn whose count does not read it would land on a later class change), the HQ
-- slot list is NOT refreshed (never below the wanted count: no mod is unequipped), F.applied forgets it (no strip later), ONE line.
function F.giveUp(char, cf, short, kind, gsig, cur, want, why)
    local v = F.applied[cf]
    local off = "none on"
    if v ~= nil then
        local asc = F.asc(char)
        local okR, whyR = false, "no ability system component"
        if asc then okR, whyR = F.removeGE(asc, v) end
        off = okR and ("v " .. v .. " taken off") or ("v " .. v .. " could not come off: " .. tostring(whyR))
    end
    F.applied[cf] = nil; F.charCls[cf] = nil; F.goneAt[cf] = nil
    F.stuck[cf] = nil; F.noMove[cf] = nil
    F.gaveUp[cf] = gsig; F.gaveUps = F.gaveUps + 1
    F.log(("%s (%s): GIVEN UP for the session - %s (%d hexes, want %d): its count does not follow BitReactorCombatSet.BonusModificationSlots (no CombatSet on this pawn, e.g. a story Mentor on %s); count GE %s; the HQ slot list is left as it is (no mod unequipped); tried again only if its saber kind or class changes"):format(
        short, kind, why, cur, want, gsig:match("|(.*)$") or "?", off))
    return "done"
end
-- the applied v does not move the count (the clamp path): the GE off, the count recomputed from scratch at the next quick re-check
function F.unstick(hq, char, cf, short, kind, cur, want, v, gsig)
    local n = (F.stuck[cf] or 0) + 1
    F.stuck[cf] = n
    if n > F.STUCK_MAX then
        return F.giveUp(char, cf, short, kind, gsig, cur, want, ("count %d with count GE v %d on, still not moved after %d re-applies"):format(cur, v, F.STUCK_MAX))
    end
    local asc = F.asc(char)
    local okR, whyR = true, nil
    if asc then okR, whyR = F.removeGE(asc, v) end
    F.applied[cf] = nil
    F.log(("%s (%s): count %d (want %d) with count GE v %d already on - the GE does not move the count (a stale effect or class key): key re-verified, GE v %d %s, the count recomputed at the next re-check (try %d of %d)"):format(
        short, kind, cur, want, v, v, okR and "taken off" or ("could not come off: " .. tostring(whyR)), n, F.STUCK_MAX))
    return "pending"
end
-- former wielders (no saber of ours this check): their GE comes off and the HQ slot list is refreshed (back to the stock count;
-- the game unequips the mods past it). ONE FindAllOf per class short name, only then.
function F.strip(gone, hq)
    local byCls = {}
    for cf in pairs(gone) do local c = F.charCls[cf] or "?"; byCls[c] = byCls[c] or {}; byCls[c][cf] = true end
    for c, set in pairs(byCls) do
        F.lookups = F.lookups + 1
        local ok, list = pcall(FindAllOf, c)
        local found = {}
        if ok and type(list) == "table" then
            for _, o in ipairs(list) do local f = F.valid(o) and F.full(o) or nil; if f and set[f] then found[f] = o end end
        end
        for cf in pairs(set) do
            local o = found[cf]
            local asc = o and F.asc(o) or nil
            if o and not asc then F.skip(cf, "stripasc", "its count GE stays: no ability system component")
            elseif asc then
                local okR, whyR = F.removeGE(asc, F.applied[cf])
                if okR then
                    local short = cf:match("([^%.:]+)$") or cf
                    F.log(("%s: no saber of ours any more - count GE v %d %s (back to its own count: %s hexes); %s"):format(short, F.applied[cf],
                        whyR and ("gone: " .. whyR) or "removed",
                        tostring(hq and F.amount(hq, o)), hq and F.refresh(hq, o, cf) or "no HQ inventory: the slot list is NOT refreshed"))
                    F.applied[cf] = nil; F.charCls[cf] = nil; F.kindShort[short] = nil
                else F.skip(cf, "strip", "its count GE could not come off: " .. tostring(whyR)) end
            else
                F.once("gone|" .. cf, cf .. " is not in this world: its count GE comes off when it is seen again without a saber")
            end
        end
    end
end
-- CP.slOnScan: SABERLOOK's scan hands its saber actors of ours ({ a, cls, owner, full }).
-- -> nil, or a number of seconds: a wielder is PENDING (its GE not resident / its apply raised) and SABERLOOK should scan
--    again that soon (errors are its caller's pcall)
function F.onScan(prim, world)
    if not F.live or F.down then return nil end
    if not (type(world) == "string" and world:find("HUB_Root", 1, true)) then return nil end   -- the count matters in the HQ only
    local now = (os.clock and os.clock()) or 0
    local wield, keys, orphan = {}, {}, {}
    for _, e in ipairs(prim) do
        local ch = nil
        pcall(function() local o = e.a:GetOwner(); if F.valid(o) then ch = o end end)
        if not ch then pcall(function() local o = e.a:GetAttachParentActor(); if F.valid(o) then ch = o end end) end
        if ch then
            local cf = F.full(ch)
            if not wield[cf] then wield[cf] = { ch = ch, kind = F.kinds[e.cls] or "single" }; keys[#keys + 1] = cf .. "=" .. e.cls end
        else
            orphan[F.kinds[e.cls] or "single"] = tostring(e.full):match("([^%.:]+)$") or tostring(e.full)
            F.once("noowner|" .. tostring(e.full), ("%s (%s): no Owner and no attach parent - no wielder to give a count to (logged once per actor)"):format(
                tostring(e.full):match("([^%.:]+)$") or tostring(e.full), tostring(e.cls)))
        end
    end
    table.sort(keys)
    local sig = table.concat(keys, "|")
    -- 2026-10-12 (retail probe 4e C3: the count came back ~36 s after the sandbox's saber re-equip, 22:46:39 -> 22:47:15: no equip
    -- hook fires for a weapon swap that is not an Armory equip, and SABERLOOK had backed off): after the wielder set CHANGES, the
    -- next WATCH_N scans come every WATCH_S s (one SABERLOOK walk each), so a swap back is seen within a few seconds.
    -- 1.8.37: a deferred strip (F.goneAt) is re-checked at every scan until it resolves
    if sig == F.sig and (now - F.lastCheck) < F.REASSERT_S and next(F.goneAt) == nil then
        if F.watchN > 0 then F.watchN = F.watchN - 1; return F.WATCH_S end
        return nil
    end
    if F.prevSig ~= nil and sig ~= F.prevSig then F.watchN = F.WATCH_N end   -- F.prevSig is never cleared (F.sig is, to force a check)
    F.prevSig = sig
    F.sig, F.lastCheck, F.checks = sig, now, F.checks + 1
    -- 1.8.37: THE TRANSIENT STRIP (retail 2026-10-18, after the 04:32:39 save load): 04:33:01 Jae had a count (3 -> 3 open); at
    -- 04:33:04 its saber BP_SWBF2_ObiWanSaber_C_1 read "no Owner and no attach parent" (re-attached after the load) and the
    -- scan stripped Jae: "no saber of ours any more - count GE v 2 removed ...; HQ slot list refreshed: 3 -> 1 open" - the
    -- shrink unequipped its StandardCell (the game's rule), and at 04:33:17 the saber was back (1 -> 3 open) with the mod gone.
    -- A former wielder is now stripped only when no saber of ours OF ITS KIND is ownerless in that scan; while one is, the strip
    -- waits (re-checked every scan, every WATCH_S) for at most STRIP_DEFER_S, then goes ahead (a real swap to a blaster while a
    -- spare saber lies ownerless). A scan with no ownerless saber strips at once, as before.
    local tNow = F.clock()
    local gone, held = {}, 0
    for cf in pairs(F.applied) do
        local short = cf:match("([^%.:]+)$") or cf
        if wield[cf] then
            if F.goneAt[cf] then
                F.log(("%s: its saber is on it again after %.0f s - nothing was stripped, its mods stay"):format(short, tNow - F.goneAt[cf]))
                F.goneAt[cf] = nil
            end
        else
            local kind = F.kindShort[short] or "single"
            local t1 = F.goneAt[cf]
            if orphan[kind] and (t1 == nil or tNow - t1 < F.STRIP_DEFER_S) then
                if t1 == nil then
                    F.goneAt[cf] = tNow; F.deferred = F.deferred + 1
                    F.log(("%s (%s): no saber of ours on it this scan, but %s (a %s saber of ours) has no Owner / attach parent right now (a load or a respawn re-attaching it) - its count GE and its HQ slot list stay (a refresh would unequip its mods); re-checked every scan for up to %d s"):format(
                        short, kind, orphan[kind], kind, F.STRIP_DEFER_S))
                end
                held = held + 1
            else
                if t1 ~= nil then F.log(("%s: still no saber of ours after %.0f s - its count GE comes off now"):format(short, tNow - t1)) end
                F.goneAt[cf] = nil
                gone[cf] = true
            end
        end
    end
    for cf in pairs(F.goneAt) do if F.applied[cf] == nil then F.goneAt[cf] = nil end end
    local pending = 0
    local hq = nil
    if next(wield) ~= nil or next(gone) ~= nil then
        hq = findHQ()
        F.lookups = F.lookups + 1
        if not hq then F.once("hq", "no BrunoHQInventory in this world: nothing checked (retried at the next scan)"); F.sig = nil; return nil end
    end
    for _, w in pairs(wield) do
        if not F.down and F.wielder(hq, w.ch, w.kind) == "pending" then pending = pending + 1 end
    end
    if next(gone) ~= nil and not F.down then F.strip(gone, hq) end
    if F.dirty then F.redraw("a count changed") end
    if pending == 0 then
        F.pendingN = 0
        if F.watchN > 0 then F.watchN = F.watchN - 1; return F.WATCH_S end
        if held > 0 then return F.WATCH_S end                -- 1.8.37: a deferred strip is looked at again soon
        return nil
    end
    F.pendingN = F.pendingN + 1
    if F.pendingN > F.PENDING_MAX then
        F.once("pendmax", ("%d wielder(s) still pending after %d quick re-checks: re-checked every %d s from now on (the lines above say why)"):format(
            pending, F.PENDING_MAX, F.REASSERT_S))
        return nil
    end
    F.sig = nil                                            -- not consumed: the next scan checks again
    return F.PENDING_S
end
-- ---- 3. the teaser. VM_ArmoryLockedSlotsList (decoded 2026-10-12, tools/recon/kismet.py on the cooked BP):
--   GetLockedSlotCount: Count = Clamp(trunc(Fact Facts.Values.MaximumModSlotCount) - Len(BrunoItemSlotListViewModel.ItemSlots),
--     0, that max) for InventoryType Modification (Utility: MaximumUtilitySlotCount); Count is written through
--     EX_LocalOutVariable, i.e. straight into the CALLER's frame - so a UE4SS hook on GetLockedSlotCount sees only its own
--     copy (retail 03:31:05: "Count 0 -> 0") and its write never reaches the list. That hook was the probe-4 teaser: dead.
--   SetupLists: NewSlots = GetLockedSlotCount x CreateSubViewModel(VM_ArmoryLockedSlot); SetPropertyValueAndBroadcast(
--     Self.LockedSlots, NewSlots) - the locked hexes ARE the LockedSlots array. So the teaser now hooks SetupLists: when the
--   view-model's loadout holds a saber of ours (any kind: single, dual, staff) and its InventoryType is Modification, the
--   LockedSlots array is emptied and broadcast (MDViewModelBase K2_BroadcastFieldValueChanged, else the FieldNotification
--   library). The same check runs again TEASER_LATER_MS later (one FindAllOf, outside the hook), in case the hook fired
--   before the function body. A blaster (or a stock saber) is never touched: its locked hexes stay stock.
--   With the count GE in place a dual (6 open) or any unit at >= the ceiling has no locked hex anyway (Clamp >= 0); a single /
--   staff (3 open) has ceiling - 3 = 1, which this removes.
function F.lockedNum(vm)
    local arr = nil; pcall(function() arr = vm.LockedSlots end)
    if arr == nil then return nil, nil end
    local n = nil
    pcall(function() n = arr:GetArrayNum() end)
    if type(n) ~= "number" then pcall(function() n = #arr end) end
    return (type(n) == "number") and n or nil, arr
end
-- one locked-slots view-model: -> nothing (logs once per gear class and outcome)
function F.clearLocked(vm, why)
    if F.down then return end
    local it = F.str(function() return vm.InventoryType.TagName:ToString() end)
    if it ~= F.MOD_TAG then return end                     -- the Utility list: never ours
    local lib, lc = F.mdLib, F.loadCls
    if not (lib and lc) then F.once("tnolib", "teaser: the MDViewModel library / loadout class was not looked up before the hook fired - the locked hexes stay"); return end
    local lo = nil; pcall(function() lo = lib:GetViewModel(vm, lc, F.fname("Default")) end)
    if not F.valid(lo) then F.once("tvm", "teaser: no loadout view-model on VM_ArmoryLockedSlotsList - the locked hexes stay (" .. why .. ")"); return end
    local gear = nil; pcall(function() gear = lo.GearActor end)
    local cn = F.valid(gear) and F.cname(gear) or nil
    if not (cn and F.ours[cn]) then return end
    local kind = F.kinds[cn] or "single"
    local n, arr = F.lockedNum(vm)
    if n == nil then F.once("tarr|" .. cn, "teaser: LockedSlots is unreadable for " .. cn .. " - the locked hexes stay"); return end
    if n == 0 then F.once("t0|" .. cn, ("teaser: %s (%s): no locked hex (the open count is at or above the ceiling) (%s)"):format(cn, kind, why)); return end
    local okE, eE = pcall(function() arr:Empty() end)
    local back = F.lockedNum(vm)
    if not okE or back ~= 0 then
        F.once("tfail|" .. cn, ("teaser: %s (%s): LockedSlots could not be emptied (%s; read back %s) - %d locked hex(es) stay"):format(
            cn, kind, okE and "no error" or tostring(eE), tostring(back), n))
        return
    end
    local fid = { FieldName = F.fname("LockedSlots") }
    local okB, eB = pcall(function() vm:K2_BroadcastFieldValueChanged(fid) end)
    local how = "K2_BroadcastFieldValueChanged"
    if not okB and F.fnLib then
        local e1 = eB
        okB, eB = pcall(function() F.fnLib:BroadcastFieldValueChanged(vm, fid) end)
        how = "FieldNotificationLibrary (K2_ raised: " .. tostring(e1) .. ")"
    end
    F.teaserZeroed = F.teaserZeroed + 1
    local redrawn = F.broadcastSlots(vm)                    -- the page copies LockedSlots only on an ItemSlots broadcast
    F.once("tz|" .. cn, ("teaser: %s (%s): %d locked hex(es) -> 0 (LockedSlots emptied, read back 0; broadcast %s; page redraw %s) (%s); logged once per saber"):format(
        cn, kind, n, okB and ("ok via " .. how) or ("FAILED: " .. tostring(eB)), redrawn, why))
    return true
end
-- the list view-model the locked list reads (the one the page draws): its ItemSlots re-broadcast, so WBP_Armory_ItemSlots
-- re-copies ItemSlots AND LockedSlots (+987). -> a short text for the log
function F.broadcastSlots(vm)
    local lib, lc = F.mdLib, F.listCls                      -- looked up by the task / F.redraw, never here (a hook path)
    if not (lib and lc) then return "skipped (no MDViewModel library / list class)" end
    local list = nil; pcall(function() list = lib:GetViewModel(vm, lc, F.fname("Default")) end)
    if not F.valid(list) then return "skipped (no item-slot list view-model on it)" end
    local fid = { FieldName = F.fname("ItemSlots") }
    local ok, e = pcall(function() list:K2_BroadcastFieldValueChanged(fid) end)
    if not ok and F.fnLib then ok, e = pcall(function() F.fnLib:BroadcastFieldValueChanged(list, fid) end) end
    if ok then return "ok (ItemSlots re-broadcast)" end
    return "FAILED: " .. tostring(e)
end
-- after a count change (apply / removal / refresh): every live Modification locked list is rebuilt from the new open count
-- (SetupLists; the teaser hook runs on it for ours), then the page redraws (ItemSlots re-broadcast). ONE FindAllOf, only when the
-- armory classes were seen this session (no page ever up = nothing drawn = nothing to redraw).
function F.redraw(why)
    F.dirty = false
    if not (F.teaserArmed or (type(CP) == "table" and CP.shPageSeen)) then return end
    if not F.mdLib then F.mdLib = F.script("mdLib", F.LIB_CDO) end
    if not F.loadCls then F.loadCls = F.script("loadCls", F.LOADOUT_CLS) end
    if not F.listCls then F.listCls = F.script("listCls", F.LIST_CLS) end
    F.lookups = F.lookups + 1
    local ok, list = pcall(FindAllOf, F.TEASER_CLASS)
    if not ok or type(list) ~= "table" then return end
    local n, txt = 0, nil
    for _, vm in ipairs(list) do
        if F.valid(vm) and not F.full(vm):find("Default__", 1, true)
           and F.str(function() return vm.InventoryType.TagName:ToString() end) == F.MOD_TAG then
            local okS, eS = pcall(function() vm:SetupLists() end)
            if not okS then F.once("setup", "redraw: SetupLists raised (the locked hexes stay as they were): " .. tostring(eS)) end
            if not F.clearLocked(vm, "redraw") then txt = F.broadcastSlots(vm) end
            n = n + 1
        end
    end
    F.redraws = F.redraws + 1
    F.once("redraw|" .. tostring(n > 0), ("redraw after %s: %d live locked list(s) rebuilt%s (logged once)"):format(why, n, txt and ("; page redraw " .. txt) or ""))
end
function F.onTeaser(ctx)
    if F.down then return end
    local vm = nil; pcall(function() vm = ctx:get() end)
    if not F.valid(vm) then return end
    F.clearLocked(vm, "SetupLists")
    if not F.teaserLaterArmed and type(F.after) == "function" then
        F.teaserLaterArmed = true
        pcall(F.after, F.TEASER_LATER_MS, function() local okL, e = pcall(F.teaserLater); if not okL then F.once("tle", "teaser re-check error: " .. tostring(e)) end end, "slotfix")
    end
end
-- the re-check (a pump timer, game thread; NOT the hook path): ONE FindAllOf of the locked-slots view-models
function F.teaserLater()
    F.teaserLaterArmed = false
    if F.down then return end
    F.lookups = F.lookups + 1
    local ok, list = pcall(FindAllOf, F.TEASER_CLASS)
    if not ok or type(list) ~= "table" then return end
    for _, o in ipairs(list) do
        if F.valid(o) and not F.full(o):find("Default__", 1, true) then F.clearLocked(o, "re-check") end
    end
end
function F.armTeaser()
    if F.teaserArmed then return end
    F.teaserArmed = true                                   -- set BEFORE the call: never retried
    F.fnLib = F.script("fnLib", F.FNLIB_CDO)               -- /Script/: the broadcast fallback (kept)
    local ok, err = pcall(RegisterHook, F.TEASER_FN, function(ctx) local okC, e = pcall(F.onTeaser, ctx); if not okC then F.once("te", "teaser hook error: " .. tostring(e)) end end)
    F.teaserOk = ok
    F.log("teaser hook " .. (ok and "ok" or ("FAILED (not retried): " .. tostring(err))) .. " on " .. F.TEASER_FN)
    -- 2026-10-12 (retail probe 4c C1, "Jae 3 open + 1 LOCKED" at the first read, 0 locked later): the hook is armed when the MODS
    -- page is first SEEN, i.e. AFTER that page's locked list already ran its SetupLists unhooked. One re-check right away (one
    -- FindAllOf, a pump timer, not the hook path) clears that first list too.
    if ok and not F.teaserLaterArmed and type(F.after) == "function" then
        F.teaserLaterArmed = true
        pcall(F.after, F.TEASER_LATER_MS, function() local okL, e = pcall(F.teaserLater); if not okL then F.once("tle", "teaser re-check error: " .. tostring(e)) end end, "slotfix")
    end
end
-- 2b. a unit back from being sent away: ABrunoHQInventory::HandleOnCharacterReturned (0x9ad2820, a UFUNCTION bound to the roster's
-- return event) re-initializes EVERY slot array of the character from the amount AT THAT MOMENT (InitializeEquipmentSlots; a
-- shrink unequips the mods past the count). If the returning actor is new, the GE is gone and the amount is 1: a NATIVE PRE-hook
-- puts a remembered wielder's count GE back first (F.wielder: key, GE, refresh).
-- Only units SLOTFIX gave a count to (their short name; F.kindShort) are touched; every other unit is the game's own.
function F.onReturned(ctx, pch)
    F.returnCalls = F.returnCalls + 1
    if F.down or not F.live then return end
    local ch = nil; pcall(function() ch = pch:get() end)
    if not F.valid(ch) then return end
    local cf = F.full(ch)
    local short = cf:match("([^%.:]+)$") or cf
    local kind = F.kindShort[short]
    if not kind then F.once("ret|" .. short, "return from away of " .. short .. ": not a wielder SLOTFIX gave a count to - the game's own count (logged once per unit)"); return end
    local hq = nil; pcall(function() hq = ctx:get() end)
    if not F.valid(hq) then hq = findHQ() end
    if not hq then F.once("rethq", "return from away: no HQ inventory - the count GE is put back at the next scan instead"); return end
    local before = F.amount(hq, ch)
    F.inHook = true                                        -- no package load inside a native hook (F.geClass)
    local okW, r = pcall(F.wielder, hq, ch, kind)
    F.inHook = false
    if not okW then r = "error: " .. tostring(r) end
    F.log(("return from away of %s (%s): count %s before the game's re-init -> %s after the count GE (%s)"):format(
        short, kind, tostring(before), tostring(F.amount(hq, ch)), r))
end
-- 2026-10-12 (retail probe 4c C3: Gia saber -> blaster -> saber drew ONE hex): an Armory equip (a weapon swap, a mod) re-checks the
-- wielders at the next SABERLOOK poll instead of the idle back-off (up to 60 s), so the count GE and the HQ slot list follow a
-- swap back to a saber within a poll. The hook only clears the check's signature and pokes SABERLOOK (no lookup, no load,
-- no write inside it). A post hook on the UFUNCTION; if the Armory calls the C++ body directly the hook never fires and the scan
-- cadence is unchanged (the first fire is logged once, so a sandbox run can tell).
function F.onEquip(ctx, pId, pChar, pSlot)
    F.equipCalls = F.equipCalls + 1
    if F.down or not F.live then return end
    F.sig = nil; F.pendingN = 0
    if type(CP) == "table" and type(CP.slPoke) == "function" then pcall(CP.slPoke) end
    F.once("equipfired", "equip hook fired (EquipItemIDToCharacter): the wielders are re-checked at the next scan poll (logged once)")
    F.noteEquip(ctx, pId, pChar, pSlot)
end
-- 1.8.37: AN EQUIP THAT DOES NOT LAND IS NEVER SILENT (retail 2026-10-18 04:32:18: Jae's HighOutputCellT1 into hex 3 came back
-- False with no line at all; after the load every further cell on Jae the same). On a unit SLOTFIX gave a count to, NOTE_MS
-- after the equip (a pump timer, outside the hook) the HQ is asked whether the id landed (IsItemIDEquippedToCharacter); if not,
-- ONE line per unit and item says it was not the loader (a refusal of ours - the zero id of DUALHEX, the Slot REFUSE_SLOT of
-- SLOTFIX - is said where it happens and skipped here) and what the game answers: the hex past the live count, or the game's
-- own CanCharacterEquipItemID (one mod per saber part slot: a single saber has ONE crystal and ONE power-cell part slot, so a
-- second cell is refused whatever the hex count; its ability already granted; the copy worn by another unit).
function F.noteEquip(ctx, pId, pChar, pSlot)
    if pChar == nil or pId == nil or type(F.after) ~= "function" then return end
    local ch = nil; pcall(function() ch = pChar:get() end)
    if not F.valid(ch) then return end
    local cf = F.full(ch)
    local short = cf:match("([^%.:]+)$") or cf
    if not F.kindShort[short] then return end                 -- not a unit SLOTFIX gave a count to: the game's own
    local id = nil
    pcall(function() local s = pId:get(); id = { A = s.A, B = s.B, C = s.C, D = s.D } end)
    if not (id and type(id.A) == "number" and type(id.B) == "number" and type(id.C) == "number" and type(id.D) == "number") then return end
    if id.A == 0 and id.B == 0 and id.C == 0 and id.D == 0 then return end   -- DUALHEX refused it (its line says why)
    local slot = nil; pcall(function() slot = pSlot:get() end)
    if slot == F.REFUSE_SLOT then return end                  -- refused by SLOTFIX / DUALHEX (said where it happened)
    local hq = nil; pcall(function() hq = ctx:get() end)
    if not F.valid(hq) then return end
    pcall(F.after, F.NOTE_MS, function()
        local okC, e = pcall(F.checkEquip, hq, ch, cf, short, id, slot)
        if not okC then F.once("ce", "equip check error: " .. tostring(e)) end
    end, "slotfix")
end
function F.itemName(hq, k)
    local name = nil
    pcall(function()
        hq.InventoryItemMap:ForEach(function(_, v)
            if name then return end
            local inst = v; pcall(function() local g = v:get(); if g ~= nil then inst = g end end)
            local s = inst.ItemId                               -- ItemId + ItemAsset (hard) only: never SoftItemAsset
            if ("%d:%d:%d:%d"):format(s.A, s.B, s.C, s.D) == k then name = inst.ItemAsset:GetFName():ToString() end
        end)
    end)
    return name
end
function F.checkEquip(hq, ch, cf, short, id, slot)
    if not (F.valid(hq) and F.valid(ch)) then return end
    local on = nil; pcall(function() on = hq:IsItemIDEquippedToCharacter(id, ch) end)
    if on ~= false then return end                            -- it landed (or the answer is unreadable: nothing to say)
    local k = ("%d:%d:%d:%d"):format(id.A, id.B, id.C, id.D)
    local key = "notlanded|" .. cf .. "|" .. k
    F.notLanded = F.notLanded + 1
    if F.noted[key] then return end
    local amt = F.amount(hq, ch)
    local can = nil; pcall(function() can = hq:CanCharacterEquipItemID(id, ch) end)
    local why
    if type(slot) == "number" and amt and slot >= amt then
        why = ("hex %d is past its live count %d (the game refuses an index >= the count)"):format(slot + 1, amt)
    elseif can == false then
        why = "the game's own CanCharacterEquipItemID says no - one mod per saber part slot (a single saber has ONE crystal and ONE power-cell slot: a mod of that slot already on it, or that slot not on its default part, refuses another), its ability already granted on the unit, or the copy worn by another unit"
    else
        why = "CanCharacterEquipItemID answers " .. tostring(can)
    end
    F.once(key, ("%s: %s into hex %s was NOT equipped - not refused by the loader (%d hex(es) open): %s (logged once per unit and item)"):format(
        short, F.itemName(hq, k) or ("item " .. k), type(slot) == "number" and slot >= 0 and tostring(slot + 1) or "(first empty)", amt or -1, why))
end
-- 2026-10-12 (probe 4e C7): the game's equip runs InitializeEquipmentSlots at the LIVE amount before it places the item, so an
-- equip on a wielder whose count went back to 1 (a load, before the next check) would shrink its HQ slot list and unequip its
-- saber mods. The PRE-hook re-asserts a REMEMBERED wielder's count first when its live amount is below its slot list (the key +
-- the GE: F.wielder with F.inHook, so no package is loaded inside the hook). If the count is STILL short (the GE class is not
-- resident and cannot be loaded inside a hook), the equip is refused before the game's re-init: its Slot is set past the live
-- amount (the body's first test, 0x9acd1bf: an index >= the amount is refused before InitializeEquipmentSlots runs), so the
-- click does nothing instead of unequipping mods; the post hook's poke re-checks within a scan poll.
function F.onEquipPre(ctx, pChar, pSlot)
    F.preCalls = F.preCalls + 1
    if F.down or not F.live then return end
    local ch = nil; pcall(function() ch = pChar:get() end)
    if not F.valid(ch) then return end
    local cf = F.full(ch)
    local short = cf:match("([^%.:]+)$") or cf
    local kind = F.kindShort[short]
    if not kind then return end                             -- not a wielder SLOTFIX gave a count to: the game's own
    local hq = nil; pcall(function() hq = ctx:get() end)
    if not F.valid(hq) then return end
    local cur, n = F.amount(hq, ch), F.slotsLen(hq, ch)
    if cur == nil or n == nil or cur >= n then return end
    F.inHook = true
    local okW, r = pcall(F.wielder, hq, ch, kind)
    F.inHook = false
    F.preFixes = F.preFixes + 1
    local now = F.amount(hq, ch)
    local held = ""
    if now == nil or now < n then
        local okS = pSlot ~= nil and pcall(function() pSlot:set(F.REFUSE_SLOT) end)
        held = okS and ("; still short: this equip is REFUSED before the game's re-init (Slot -> " .. F.REFUSE_SLOT .. "), so no mod is unequipped - equip again in a moment")
                    or "; still short and the Slot parameter could not be written: the game's re-init may unequip the mods past the live amount"
    end
    F.log(("equip on %s (%s) while its count was %d under a slot list of %d: re-asserted before the game's re-init -> %s (%s)%s"):format(
        short, kind, cur, n, tostring(now), okW and tostring(r) or ("error: " .. tostring(r)), held))
end
function F.armEquip()
    if F.equipArmed then return end
    F.equipArmed = true                                    -- set BEFORE the call: never retried
    local ok, err = pcall(RegisterHook, F.EQUIP_FN,
        function(ctx, pId, pChar, pSlot) local okP, e = pcall(F.onEquipPre, ctx, pChar, pSlot); if not okP then F.once("eqp", "equip pre-hook error: " .. tostring(e)) end end,
        function(ctx, pId, pChar, pSlot) local okC, e = pcall(F.onEquip, ctx, pId, pChar, pSlot); if not okC then F.once("eqe", "equip hook error: " .. tostring(e)) end end)
    F.equipOk = ok
    F.log("equip hook " .. (ok and "ok" or ("FAILED (not retried; a weapon swap is seen at the next scan instead): " .. tostring(err))) .. " on " .. F.EQUIP_FN)
end
-- 2026-10-12 (probe 4e C3): a weapon swap changes the character's gear kits; GearKitComponent.GearKitsChanged is a DYNAMIC
-- multicast, and the Armory's view-models bind native UFUNCTIONs to it (BrunoCharacterLoadoutViewModel:HandleOnGearKitsChanged,
-- BrunoItemSlotListViewModel:OnGearKitsChanged - jmap 197649), so a broadcast reaches them through ProcessEvent, where a UE4SS
-- post-hook sees it. Same work as the equip hook (clear the signature, poke SABERLOOK). They fire only while such a view-model
-- exists (an Armory page); otherwise the watch window after a wielder change covers the swap. Each fn's first fire is logged.
function F.onGear(fn)
    F.gearCalls = F.gearCalls + 1
    if F.down or not F.live then return end
    F.sig = nil; F.pendingN = 0; F.watchN = math.max(F.watchN, F.WATCH_N)
    if type(CP) == "table" and type(CP.slPoke) == "function" then pcall(CP.slPoke) end
    F.once("gearfired|" .. fn, "gear-kit hook fired (" .. (fn:match("([^%.]+)$") or fn) .. "): the wielders are re-checked at the next scan poll (logged once)")
end
function F.armGear()
    if F.gearArmed then return end
    F.gearArmed = true                                     -- set BEFORE the calls: never retried
    local okN, errs = 0, {}
    for _, fn in ipairs(F.GEAR_FNS) do
        local ok, err = pcall(RegisterHook, fn, function() end, function() local okC, e = pcall(F.onGear, fn); if not okC then F.once("ge|" .. fn, "gear-kit hook error: " .. tostring(e)) end end)
        if ok then okN = okN + 1 else errs[#errs + 1] = (fn:match("([^%.]+)$") or fn) .. ": " .. tostring(err) end
    end
    F.gearOk = okN
    F.log(("gear-kit hooks: %d of %d ok%s (a swap is otherwise seen by the watch window: %d scans every %d s after a wielder change)"):format(
        okN, #F.GEAR_FNS, #errs > 0 and (" (FAILED, not retried: " .. table.concat(errs, "; ") .. ")") or "", F.WATCH_N, F.WATCH_S))
end
function F.armReturn()
    if F.returnArmed then return end
    F.returnArmed = true                                   -- set BEFORE the call: never retried
    local ok, err = pcall(RegisterHook, F.RETURN_FN, function(ctx, pch) local okC, e = pcall(F.onReturned, ctx, pch); if not okC then F.once("re", "return-from-away hook error: " .. tostring(e)) end end)
    F.returnOk = ok
    F.log("return-from-away hook " .. (ok and "ok" or ("FAILED (not retried; a return from away may unequip saber mods past 1 until the next scan): " .. tostring(err))) .. " on " .. F.RETURN_FN)
end
-- the task: load the manifest once; then, in the hub, arm the teaser hook once its class is resident. The counts ride SABERLOOK.
function F.task()
    if not F.loaded then
        if not injected then return F.WAIT_S end
        F.loaded = true
        local any = false
        for _, mf in ipairs(manifests) do   -- 1.8.54 (M-3): one manifest at a time
            local ok, r = pcall(F.merge, mf.m)
            if ok and r then any = true elseif not ok then log("SLOTFIX: " .. tostring(mf.m.name) .. "'s sabers block failed: " .. tostring(r)) end
        end
        if not any then return true end                      -- no mod asks for fixed saber counts: never a lookup
        if not F.settings(UE4SS) then log("SLOTFIX OFF for the session: settings.ini [SLOTFIX] Enabled=off"); return true end
        F.live = true
        CP.slOnScan = F.onScan
        F.log(("armed: counts single %d / staff %d / dual %d, GE range %d..%d; teaser %s; rides SABERLOOK's scans (hub only)"):format(
            F.cfg.counts.single, F.cfg.counts.staff, F.cfg.counts.dual, F.cfg.min, F.cfg.max, F.teaserOn and "on" or "off"))
        F.preloadGEs()
    end
    if F.down or ((not F.teaserOn or F.teaserArmed) and F.returnArmed and F.equipArmed and F.gearArmed) then return true end
    local hub, w = strategySide()
    if not hub then F.world = nil; return F.MENU_S end
    if F.world ~= w then F.world, F.teaserProbeN = w, 0; return F.HUB_SETTLE_S end
    if not F.returnArmed then F.armReturn() end            -- past the hub's spawn wave (a native hook, armed once)
    if not F.equipArmed then F.armEquip() end              -- the same moment (a native UFUNCTION pre + post hook, armed once)
    if not F.gearArmed then F.armGear() end                -- the gear-kit change (dynamic-delegate UFUNCTIONs, armed once)
    if not F.teaserOn or F.teaserArmed then return true end
    -- the two /Script/ objects the teaser reads in its hook (looked up here, never in the hook)
    if not F.mdLib then F.mdLib = F.script("mdLib", F.LIB_CDO); if not F.mdLib then return true end; return 2 end
    if not F.loadCls then
        F.loadCls = F.script("loadCls", F.LOADOUT_CLS)
        F.listCls = F.script("listCls", F.LIST_CLS)          -- the teaser's page redraw (ItemSlots re-broadcast); optional
        if not F.loadCls then return true end; return 2
    end
    if CP.shPageSeen then F.armTeaser(); return true end   -- SABERHEADINGS found the MODS page: the class is resident
    if CP.shLive then return 2 end                          -- SABERHEADINGS watches for the page: wait for it, no walk here
    -- the armory locked-slots view-model exists (its class is resident): ONE FindAllOf, backed off while it does not
    F.lookups = F.lookups + 1
    local ok, list = pcall(FindAllOf, F.TEASER_CLASS)
    local live = false
    if ok and type(list) == "table" then for _, o in ipairs(list) do if F.valid(o) and not F.full(o):find("Default__", 1, true) then live = true end end end
    if live then F.armTeaser(); return true end
    F.teaserProbeN = F.teaserProbeN + 1
    return F.TEASER_PROBE_S[math.min(F.teaserProbeN, #F.TEASER_PROBE_S)]
end
F.taskRef = addTask("slotfix", 5.0, function()
    local ok, r = pcall(F.task)
    if not ok then log("SLOTFIX error (the loop keeps running): " .. tostring(r)); return 10 end
    return r
end)
if SLOTFIX_EXPORT then SLOTFIX_EXPORT(F) end              -- tools/replay_slotfix.py only (a nil global in the game)
end
-- ---- 2026-10-11: SLOTFIX (end) ----

-- ---- 2026-10-12: DUALHEX (begin; tools/replay_dualhex.py extracts this block verbatim) ----
-- A DUAL SABER'S 6 MOD HEXES AS 3 RIGHT + 3 LEFT (OPERATOR DECISION 2026-10-12: docs/recon/SABER_DUAL_SLOTS_UI_PLAN.md option B;
-- the def key `saberDualHex`, tools/zcmod-sabercust.js (7); NOT retail-proven: docs/recon/SABER_B0_PROBE_CHECKLIST.md §11).
-- WHAT THE PLAYER SEES. One item per kind ("Green Kyber Crystal"); hexes 1-3 = the RIGHT blade, 4-6 = the LEFT blade, a gap after
-- hex 3 and RIGHT BLADE / LEFT BLADE labels above the row. The left twins (DA_<x>_Left, their own GA: P2-1) are never listed.
-- WHY IT NEEDS LUA. The HQ hexes are untyped (FEquipmentSlots.Slots = TArray<FInventoryItemID>; EquipItemIDToCharacter takes a
-- plain index) and the BLADE is decided by the ITEM (its one CustomizationSlotTag must equal a CD slot exactly), so an item put
-- into hex 4-6 must become its left twin, and a twin into hex 1-3 its right item. Three routes, each logged ONCE when it fires:
--   1. PRE-HOOK on ABrunoHQInventory:EquipItemIDToCharacter (ItemId const ref, Character, Slot): the ItemId parameter is
--      rewritten (FGuid fields A..D of the InventoryItemID wrapper) to an owned free instance of the other hand's item, or to an
--      invalid id (the body's CanCharacterEquipItemID refuses it) when the copy rule refuses. Only for wielders of a dualHex
--      saber of ours seen at the last scan. No lookup and no load inside it: one walk of HQ.InventoryItemMap (hard ItemAsset
--      only, never SoftItemAsset) and reflected HQ calls.
--   2. POST-EQUIP FALLBACK: the post hook schedules a check FIX_MS later (a pump timer, outside the hook): if the hex holds the
--      wrong hand's item (the rewrite did not stick: a BP caller's ref parameter), it is unequipped and the other hand's free
--      copy equipped into the SAME index; if the native refused (the right item already on the right blade = P2-1) and the rule
--      allows, the twin is equipped there by us.
--   3. SCAN FALLBACK (no equip hook fired at all: the Armory calls the C++ body directly): every SABERLOOK scan reads each dualHex
--      wielder's HQ slot list (one UFUNCTION call) and fixes it up when its signature changed.
-- THE COPY RULE (`shareOneCopy`, default false = the operator's L2 "NO"): one OWNED copy fills ONE hex. Twins are granted 1:1
-- with the right copies (the generator's grants + a top-up here, outside every hook), and the loader counts, per kind,
-- in use = (right copies equipped) + (twins equipped), from GetTotalAmountOwned / GetTotalAmountOwnedExclEquipped (every unit,
-- not only this one): a new use is allowed only while in use < owned right copies. Two Green Kyber = both blades; one Ghostfire
-- = one blade (the other hex refuses it). No inventory item is ever converted (no AddItem / RemoveItem per equip: no new ids,
-- no new-item badges, no copy lost to a save between a remove and an add); unequipping a twin frees its use at once. A twin
-- whose right item is no longer owned (sold) comes off at the next fix-up. shareOneCopy = true: the rule is off (the twins are
-- free, as in the plan's default B).
-- THE PAGE (decode: ZCUIMods/notes/ARMORY_ITEMSLOTS_DECODE.md): WBP_Armory_ItemSlots_C:UpdateSlots post -> the slot widget's own
-- loadout view-model -> GearActor class -> a dualHex dual? (kept per widget PATH, a string). WBP_SimpleUtilitySlot_3_C:
-- OnListItemObjectSet post -> the entry's owning list (UserListEntryLibrary) is that widget's slotList -> index == right ? GAP : 0
-- on entry.tooltipBox.Slot (never the entry's own Padding: HandleRefreshRow rewrites it; 0 is written too: entries are pooled).
-- The labels: two TextBlocks constructed with the widget's WidgetTree as outer, named ZCSDK_DualHex_Right/_Left, added to
-- Overlay_1 (slotList:GetParent():GetParent()) with AddChildToOverlay, HitTestInvisible, the game font Secondary_Font_FSIndustrieCD
-- Medium 16.5 spacing 80, moved up into the 24 px band; found again by name on every UpdateSlots (no UObject kept), shown on a
-- dualHex dual, collapsed otherwise. Never InsertChildAt, never a reparent.
-- settings.ini [DUALHEX] Enabled = on | off, Labels = on | off, Gap = <px>.
do
local DH = {
    MOD_TAG      = "BitReactor.ItemType.Modification",
    EQUIP_FN     = "/Script/Bruno.BrunoHQInventory:EquipItemIDToCharacter",
    SLOTS_FN     = "/Game/Game/UI/Strategy/Armory/Widgets/WBP_Armory_ItemSlots.WBP_Armory_ItemSlots_C:UpdateSlots",
    ENTRY_FN     = "/Game/Game/UI/Strategy/Armory/Widgets/WBP_SimpleUtilitySlot_3.WBP_SimpleUtilitySlot_3_C:OnListItemObjectSet",
    HQ_CDO       = "/Script/Bruno.Default__BrunoHQInventory",
    ULE_CDO      = "/Script/UMG.Default__UserListEntryLibrary",
    TEXT_CLS     = "/Script/UMG.TextBlock",
    KTL_CDO      = "/Script/Engine.Default__KismetTextLibrary",
    LIB_CDO      = "/Script/MDViewModel.Default__MDViewModelFunctionLibrary",
    LOADOUT_CLS  = "/Script/Bruno.BrunoCharacterLoadoutViewModel",
    FONT         = "/Game/Game/UI/Fonts/Secondary_Font_FSIndustrieCD.Secondary_Font_FSIndustrieCD",
    LBL          = { right = "ZCSDK_DualHex_Right", left = "ZCSDK_DualHex_Left" },
    ZERO         = "0:0:0:0",
    PITCH = 132, ROW_X = 16, LABEL_Y = -24, VIS_HTI = 3, VIS_COLLAPSED = 1, HALIGN_LEFT = 1, VALIGN_TOP = 1,
    FIX_MS = 150, HUB_SETTLE_S = 10, MENU_S = 10, WAIT_S = 5, STEP_S = 2, TOPUP_S = 120, LOG_CAP = 200, REFUSE_SLOT = 99,
    INI          = "Mods/ZCSDKLoader/settings.ini",
    loaded = false, live = false, down = nil, cfg = nil, R2T = {}, T2R = {}, paths = {}, actors = {}, share = false, right = 3,
    gap = 48, labelsOn = true, labels = { right = "RIGHT BLADE", left = "LEFT BLADE" },
    world = nil, settled = false, wield = {}, sigs = {}, intent = nil, busy = false, pageDual = {},
    hqCdo = nil, ule = nil, textCls = nil, ktl = nil, mdLib = nil, loadCls = nil, tried = {},
    equipArmed = false, equipOk = false, pageArmed = false, slotsOk = false, entryOk = false, nextTopUp = 0,
    paths_ = { pre = 0, post = 0, scan = 0 }, preCalls = 0, postCalls = 0, moves = 0, refusals = 0, topUps = 0, pads = 0,
    textHow = nil, noted = {}, logged = 0, lookups = 0,
    clock = function() return (os.clock and os.clock()) or 0 end,
    after = after,
}
function DH.log(m) if DH.logged < DH.LOG_CAP then DH.logged = DH.logged + 1; log("DUALHEX " .. m) end end
function DH.once(k, m) if not DH.noted[k] then DH.noted[k] = true; DH.log(m) end end
function DH.valid(o)
    if o == nil then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return (ok and v) and true or false
end
function DH.str(f) local ok, v = pcall(f); if ok and type(v) == "string" then return v end; return nil end
function DH.full(o) return DH.str(function() return o:GetFullName() end) or "?" end
function DH.path(o) return ((DH.full(o)):gsub("^[^ ]+ ", "")) end
function DH.short(o) return (DH.full(o)):match("([^%.:]+)$") or "?" end
function DH.nameOf(o) return DH.str(function() return o:GetFName():ToString() end) end
function DH.fname(s) local ok, n = pcall(FName, s); if ok and n then return n end; return s end
function DH.tag() return { TagName = DH.fname(DH.MOD_TAG) } end
-- ---- the manifest: sabers.dualHex (a later mod's pairs add to an earlier one's; its switches win, said once)
function DH.merge(m)
    local s = m and m.sabers
    if type(s) ~= "table" or (tonumber(s.schema) or 0) < 1 or type(s.dualHex) ~= "table" then return false end
    local d = s.dualHex
    if DH.cfg then DH.once("cfg2", "two mods declare sabers.dualHex: their pairs are merged, the later one's switches win") end
    DH.cfg = true
    DH.right = tonumber(d.right) or 3
    DH.share = d.shareOneCopy == true
    DH.gap = tonumber(d.gap) or DH.gap
    if d.labels == false then DH.labelsOn = false
    elseif type(d.labels) == "table" then DH.labels = { right = tostring(d.labels.right or DH.labels.right), left = tostring(d.labels.left or DH.labels.left) } end
    for _, c in ipairs(d.actors or {}) do if type(c) == "string" then DH.actors[c] = true end end
    for r, t in pairs(d.twins or {}) do if type(r) == "string" and type(t) == "string" then DH.R2T[r] = t; DH.T2R[t] = r end end
    for n, p in pairs(d.paths or {}) do if type(n) == "string" and type(p) == "string" then DH.paths[n] = p end end
    return true
end
function DH.settings(root)
    local text = ""
    local f = io.open(root .. DH.INI, "rb")
    if f then text = f:read(262144) or ""; f:close() end
    local vals, sec = {}, ""
    for raw in (text .. "\n"):gmatch("([^\r\n]*)\r?\n") do
        local line = raw:gsub("^\239\187\191", ""):gsub("%s*[;#].*$", ""):match("^%s*(.-)%s*$") or ""
        local s = line:match("^%[%s*(.-)%s*%]$")
        if s then sec = s:lower()
        elseif sec == "dualhex" then
            local k, v = line:match("^([^=]-)%s*=%s*(.*)$")
            if k then vals[k:lower()] = v:lower() end
        end
    end
    local off = function(v) return v == "off" or v == "0" or v == "false" end
    if off(vals.enabled) then return false end
    if off(vals.labels) then DH.labelsOn = false end
    local g = tonumber(vals.gap or ""); if g then DH.gap = math.max(0, math.min(200, g)) end
    return true
end
-- a /Script/ object, looked up ONCE a session (kept: never collected)
function DH.script(key, path)
    if DH[key] then return DH[key] end
    if DH.tried[key] then return nil end
    DH.tried[key] = true; DH.lookups = DH.lookups + 1
    local ok, o = pcall(StaticFindObject, path)
    if ok and DH.valid(o) then DH[key] = o; return o end
    DH.once("miss|" .. key, "not found: " .. path)
    return nil
end
-- ---- ids: an InventoryItemID (an FGuid: A, B, C, D) <-> a plain table + a string key
function DH.idOf(s)
    local id = nil
    pcall(function() id = { A = s.A, B = s.B, C = s.C, D = s.D } end)
    if not id or type(id.A) ~= "number" or type(id.B) ~= "number" or type(id.C) ~= "number" or type(id.D) ~= "number" then return nil end
    return id
end
function DH.key(id) return id and ("%d:%d:%d:%d"):format(id.A, id.B, id.C, id.D) or DH.ZERO end
function DH.readParam(p)
    local s = nil; pcall(function() s = p:get() end)
    return s ~= nil and DH.idOf(s) or nil
end
-- the hook's ItemId parameter rewritten in place (the wrapper's fields write the parameter memory); -> true when it reads back
function DH.writeParam(p, id)
    local ok = pcall(function() local s = p:get(); s.A, s.B, s.C, s.D = id.A, id.B, id.C, id.D end)
    if not ok then ok = pcall(function() p:set({ A = id.A, B = id.B, C = id.C, D = id.D }) end) end
    local back = DH.readParam(p)
    return ok and back ~= nil and DH.key(back) == DH.key(id)
end
-- ---- the HQ reads (each a reflected call or a property walk; none loads, none looks an object up)
-- one wielder's Modification slot list: { { key, id } ... } (index i = hex i - 1) | nil
function DH.slots(hq, char)
    local arr = nil
    if not pcall(function() arr = hq:GetSpecificEquipmentSlotsForCharacter(char, DH.tag()) end) or arr == nil then return nil end
    local out = {}
    local function one(e)
        local s = e; pcall(function() local g = e:get(); if g ~= nil then s = g end end)
        local id = DH.idOf(s) or { A = 0, B = 0, C = 0, D = 0 }
        out[#out + 1] = { key = DH.key(id), id = id }
    end
    if type(arr) == "table" then for _, e in ipairs(arr) do one(e) end
    elseif not pcall(function() arr:ForEach(function(_, e) one(e) end) end) then return nil end
    return out
end
function DH.sigOf(list) local t = {}; for i, s in ipairs(list or {}) do t[i] = s.key end; return table.concat(t, "|") end
-- the inventory, ours only: one walk of HQ.InventoryItemMap (InventoryItemInstance: ItemId, ItemAsset (hard); SoftItemAsset is
-- NEVER read). -> { byId = { [key] = { name, id, asset } }, byName = { [name] = { ids = { id... }, asset } } } | nil, why
function DH.inv(hq)
    local map = nil; pcall(function() map = hq.InventoryItemMap end)
    if map == nil then return nil, "BrunoHQInventory.InventoryItemMap is unreadable" end
    local snap = { byId = {}, byName = {} }
    local ok, e = pcall(function()
        map:ForEach(function(_, v)
            local inst = v; pcall(function() local g = v:get(); if g ~= nil then inst = g end end)
            local asset = nil; pcall(function() asset = inst.ItemAsset end)
            if not DH.valid(asset) then return end
            local name = DH.nameOf(asset)
            if not (name and (DH.R2T[name] or DH.T2R[name])) then return end
            local idS = nil; pcall(function() idS = inst.ItemId end)
            local id = idS ~= nil and DH.idOf(idS) or nil
            if not id then return end
            snap.byId[DH.key(id)] = { name = name, id = id, asset = asset }
            local b = snap.byName[name] or { ids = {}, asset = asset }
            b.ids[#b.ids + 1] = id; snap.byName[name] = b
        end)
    end)
    if not ok then return nil, "InventoryItemMap:ForEach raised: " .. tostring(e) end
    return snap
end
-- owned and in use (equipped on ANY unit) of one item kind: GetTotalAmountOwned / GetTotalAmountOwnedExclEquipped
function DH.use(hq, snap, name)
    local b = snap.byName[name]
    if not b then return 0, 0 end
    local owned, free = nil, nil
    pcall(function() owned = hq:GetTotalAmountOwned(b.asset) end)
    pcall(function() free = hq:GetTotalAmountOwnedExclEquipped(b.asset) end)
    owned = type(owned) == "number" and owned or #b.ids
    free = type(free) == "number" and free or owned
    return owned, math.max(0, owned - free)
end
-- the copy rule for a kind (by either hand's name): -> owned right copies, in use (right + twins)
function DH.budget(hq, snap, name)
    local r = DH.T2R[name] or name
    local t = DH.R2T[r]
    local ownedR, usedR = DH.use(hq, snap, r)
    local _, usedT = DH.use(hq, snap, t)
    return ownedR, usedR + usedT, r
end
-- a free instance of `name` for this unit: not in its list, and the HQ says it can equip it (owned, not worn elsewhere, its
-- ability not granted yet). -> id | nil
function DH.freeId(hq, snap, name, char, inList)
    local b = snap.byName[name]
    if not b then return nil end
    for _, id in ipairs(b.ids) do
        if not inList[DH.key(id)] then
            local can = nil; pcall(function() can = hq:CanCharacterEquipItemID(id, char) end)
            if can == true then return id end
        end
    end
    return nil
end
function DH.equipNow(hq, id, char, index)
    DH.busy = true
    local ok, e = pcall(function() hq:EquipItemIDToCharacter(id, char, index) end)
    DH.busy = false
    return ok, e
end
function DH.unequipNow(hq, id, char)
    DH.busy = true
    local ok, e = pcall(function() hq:UnequipItemIDFromCharacter(id, char) end)
    DH.busy = false
    return ok, e
end
function DH.hqOf(char)
    local hq = nil
    if DH.hqCdo then pcall(function() hq = DH.hqCdo:GetInventory(char) end) end
    if DH.valid(hq) then return hq end
    return nil
end
function DH.which(i) return (i - 1) >= DH.right and "left" or "right" end
-- ---- the fix-up (pump only: a timer after an equip, or a scan): items in the wrong hex GROUP are put right, never dropped:
--   1. a right item in a left hex + a twin in a right hex (a layout from before DUALHEX, e.g. probe 4e's "equip set=" order):
--      the two swap hexes (the same items, so the same abilities and CD slots: the game allows it);
--   2. a right item in a left hex (the game took it there) -> its free twin into the SAME hex (one copy out, one in), and the
--      other way round; 3. else the item moves to an empty hex of its OWN group; 4. else it stays, said once.
-- Then the copy rule (DH.enforce). -> n changed
function DH.fixup(hq, char, how)
    local list = DH.slots(hq, char)
    if not list then DH.once("noslots", "the HQ slot list is unreadable (GetSpecificEquipmentSlotsForCharacter): nothing fixed"); return 0 end
    local snap, why = DH.inv(hq)
    if not snap then DH.once("noinv", "the inventory is unreadable (" .. tostring(why) .. "): nothing fixed"); return 0 end
    local short = DH.short(char)
    local inList, changed = {}, 0
    for _, s in ipairs(list) do inList[s.key] = true end
    local wrongL, wrongR = {}, {}                              -- right items in left hexes / twins in right hexes
    for i, s in ipairs(list) do
        local e = s.key ~= DH.ZERO and snap.byId[s.key] or nil
        if e then
            local left = (i - 1) >= DH.right
            if left and DH.R2T[e.name] then wrongL[#wrongL + 1] = { i = i, s = s, e = e }
            elseif (not left) and DH.T2R[e.name] then wrongR[#wrongR + 1] = { i = i, s = s, e = e } end
        end
    end
    local function nameAt(i) local l = DH.slots(hq, char) or {}; local x = l[i]; local e = x and snap.byId[x.key] or nil; return e and e.name or nil end
    -- 1. pair swaps
    while #wrongL > 0 and #wrongR > 0 do
        local a, b = table.remove(wrongL, 1), table.remove(wrongR, 1)
        DH.unequipNow(hq, a.s.id, char); DH.unequipNow(hq, b.s.id, char)
        DH.equipNow(hq, a.s.id, char, b.i - 1); DH.equipNow(hq, b.s.id, char, a.i - 1)
        if nameAt(b.i) == a.e.name and nameAt(a.i) == b.e.name then
            changed = changed + 2; DH.moves = DH.moves + 2
            DH.log(("%s: %s (hex %d) and %s (hex %d) swapped hexes: each in its own blade's group now (%s)"):format(short, a.e.name, a.i, b.e.name, b.i, how))
        else
            DH.once("swapfail|" .. short, ("%s: swapping %s (hex %d) and %s (hex %d) did not take (%s); left as the game has them"):format(short, a.e.name, a.i, b.e.name, b.i, how))
        end
    end
    -- 2-4. the rest, one by one
    local rest = {}
    for _, x in ipairs(wrongL) do rest[#rest + 1] = x end
    for _, x in ipairs(wrongR) do rest[#rest + 1] = x end
    for _, x in ipairs(rest) do
        local left = (x.i - 1) >= DH.right
        local target = left and DH.R2T[x.e.name] or DH.T2R[x.e.name]
        local tid = DH.freeId(hq, snap, target, char, inList)
        local done = false
        if tid then                                            -- 2. the other hand's copy into the SAME hex
            DH.unequipNow(hq, x.s.id, char)
            DH.equipNow(hq, tid, char, x.i - 1)
            if nameAt(x.i) == target then
                done = true; inList[DH.key(tid)] = true
                DH.log(("%s: %s in hex %d (%s blade) -> %s (%s)"):format(short, x.e.name, x.i, DH.which(x.i), target, how))
            else DH.equipNow(hq, x.s.id, char, x.i - 1) end     -- put it back where it was
        end
        if not done then                                       -- 3. an empty hex of its own group
            local now = DH.slots(hq, char) or {}
            local lo, hi = left and 1 or DH.right + 1, left and DH.right or #now
            for j = lo, hi do
                if now[j] and now[j].key == DH.ZERO then
                    DH.unequipNow(hq, x.s.id, char)
                    DH.equipNow(hq, x.s.id, char, j - 1)
                    if nameAt(j) == x.e.name then
                        done = true
                        DH.log(("%s: %s moved from hex %d to hex %d (its own blade's group; no %s copy this unit can take) (%s)"):format(short, x.e.name, x.i, j, target, how))
                    else DH.equipNow(hq, x.s.id, char, x.i - 1) end
                    break
                end
            end
        end
        if done then changed = changed + 1; DH.moves = DH.moves + 1
        else
            DH.once("stay|" .. short .. "|" .. x.e.name, ("%s: %s stays in hex %d (the %s group): no %s copy this unit can take and no free hex in its own group - re-arrange it in the Armory (%s)"):format(
                short, x.e.name, x.i, DH.which(x.i), target, how))
        end
    end
    return changed + DH.enforce(hq, char, how)
end
-- the copy rule on one unit: a twin whose kind is over its owned right copies comes off (the copy goes back). -> n taken off
function DH.enforce(hq, char, how)
    if DH.share then return 0 end
    local list = DH.slots(hq, char)
    local snap = list and DH.inv(hq) or nil
    if not (list and snap) then return 0 end
    local n = 0
    for i, s in ipairs(list) do
        local e = s.key ~= DH.ZERO and snap.byId[s.key] or nil
        if e and DH.T2R[e.name] then
            local owned, used, r = DH.budget(hq, snap, e.name)
            if used > owned then
                DH.unequipNow(hq, s.id, char)
                n = n + 1; DH.refusals = DH.refusals + 1
                DH.log(("%s: %s in hex %d taken off - one owned copy fills ONE hex (%s: %d owned, %d in use) (%s)"):format(
                    DH.short(char), e.name, i, r, owned, used, how))
                snap = DH.inv(hq) or snap
            end
        end
    end
    return n
end
-- 1.8.37: a refusal TOUCHES NOTHING. The ItemId becomes the zero id AND the Slot goes past every count (REFUSE_SLOT): the body's
-- first test refuses an index >= the amount (0x9acd1bf) before InitializeEquipmentSlots and before any unequip, so a copy worn
-- by another unit stays on it even when the ItemId rewrite does not reach the body (a Blueprint caller's reference). Logged ONCE
-- per unit, item and rule (the count goes on in DH.refusals), with what happens to a copy another unit wears.
function DH.refuse(intent, pId, pSlot, short, what, rule)
    DH.refusals = DH.refusals + 1
    local okW = DH.writeParam(pId, { A = 0, B = 0, C = 0, D = 0 })
    local okS = pSlot ~= nil and pcall(function() pSlot:set(DH.REFUSE_SLOT) end)
    intent.held = okW or okS
    DH.once("refused|" .. short .. "|" .. rule, ("%s: %s%s%s (logged once per unit and item)"):format(short, what,
        intent.worn and "; the copy stays on the unit that wears it" or "",
        intent.held and "" or "; neither the ItemId nor the Slot could be rewritten: the post-equip check takes a NEW copy off again (a copy moved from another unit is left where it landed)"))
end
-- ---- route 1: the PRE-hook (game thread, inside the native call: no lookup, no load, no equip of our own)
function DH.onPre(ctx, pId, pChar, pSlot)
    DH.preCalls = DH.preCalls + 1
    if DH.busy or DH.down or not DH.live then return end
    local char = nil; pcall(function() char = pChar:get() end)
    if not DH.valid(char) then return end
    local cf = DH.full(char)
    if not DH.wield[cf] then DH.intent = nil; return end
    local hq = nil; pcall(function() hq = ctx:get() end)
    if not DH.valid(hq) then return end
    local id = DH.readParam(pId)
    if not id then DH.once("idread", "pre-hook: the ItemId parameter is unreadable - the post-equip / scan fix-up handles it"); return end
    local slot = nil; pcall(function() slot = pSlot:get() end)
    if type(slot) ~= "number" then return end
    local snap = DH.inv(hq)
    local e = snap and snap.byId[DH.key(id)] or nil
    if not e then DH.intent = nil; return end                 -- not an item of a dualHex pair: the game's own
    local list = DH.slots(hq, char) or {}
    local inList = {}
    for _, s in ipairs(list) do inList[s.key] = true end
    if slot < 0 then                                            -- FindFirstEmptyEquipmentSlot's choice
        slot = #list
        for i, s in ipairs(list) do if s.key == DH.ZERO then slot = i - 1; break end end
    end
    local left = slot >= DH.right
    local target = (left and DH.R2T[e.name]) or ((not left) and DH.T2R[e.name]) or e.name
    local intent = { cf = cf, char = char, slot = slot, from = e.name, want = target }
    DH.intent = intent
    local short = DH.short(char)
    -- 1.8.37: this kind's in-use count before the call and whether the instance is worn by ANOTHER unit (not in this list, every
    -- copy of the kind in use): a refusal must leave that unit's copy where it is (DH.refuse, DH.verify)
    local ownedE, usedE = DH.use(hq, snap, e.name)
    intent.usedBefore, intent.mine = usedE, inList[DH.key(id)] == true
    intent.worn = (not intent.mine) and usedE > 0 and usedE >= ownedE
    -- the copy rule: a NEW use unless it is this very instance moving within this unit
    if not DH.share and not (target == e.name and inList[DH.key(id)]) then
        local owned, used, r = DH.budget(hq, snap, target)
        if used + 1 > owned then
            intent.refused = ("%s: %d owned, %d in use"):format(r, owned, used)
            DH.refuse(intent, pId, pSlot, short, ("%s into hex %d (%s blade) REFUSED - one owned copy fills ONE hex (%s)"):format(e.name, slot + 1,
                left and "left" or "right", intent.refused), "copy|" .. e.name)
            return
        end
    end
    if target == e.name then return end
    local tid = DH.freeId(hq, snap, target, char, inList)
    if not tid then
        intent.refused = "no " .. target .. " copy this unit can take"
        DH.refuse(intent, pId, pSlot, short, ("%s into hex %d REFUSED - no %s copy this unit can take (none free, or its blade slot / ability is already in use)"):format(
            e.name, slot + 1, target), "twin|" .. e.name)
        return
    end
    intent.rewritten = DH.writeParam(pId, tid)
    if not intent.rewritten then
        DH.once("nowrite", "pre-hook: the ItemId parameter could not be rewritten in this call (a Blueprint caller's reference?) - the post-equip fix-up moves the item instead")
    end
end
-- ---- route 2: the POST hook -> a check FIX_MS later (a pump timer: outside the native call)
function DH.onPost(ctx, pId, pChar, pSlot)
    DH.postCalls = DH.postCalls + 1
    if DH.busy or DH.down or not DH.live then return end
    local char = nil; pcall(function() char = pChar:get() end)
    if not DH.valid(char) then return end
    local cf = DH.full(char)
    if not DH.wield[cf] then return end
    local intent = DH.intent
    DH.intent = nil
    if not (intent and intent.cf == cf) then
        local slot = nil; pcall(function() slot = pSlot:get() end)
        intent = { cf = cf, char = char, slot = type(slot) == "number" and slot or -1 }
    end
    local w = DH.world
    if type(DH.after) == "function" then
        pcall(DH.after, DH.FIX_MS, function()
            if DH.world ~= w then return end
            local okV, e = pcall(DH.verify, intent)
            if not okV then DH.once("ve", "post-equip check error: " .. tostring(e)) end
        end, "dualhex")
    end
end
function DH.verify(intent)
    local char = intent.char
    if not DH.valid(char) then return end
    local hq = DH.hqOf(char) or findHQ()                     -- a pump timer: the walk is allowed here (only without the CDO)
    if not hq then DH.once("nohq", "post-equip check: no HQ inventory for the unit (GetInventory answered nothing)"); return end
    local list = DH.slots(hq, char) or {}
    local snap = DH.inv(hq) or { byId = {}, byName = {} }
    local s = intent.slot >= 0 and list[intent.slot + 1] or nil
    local e = s and s.key ~= DH.ZERO and snap.byId[s.key] or nil
    local short = DH.short(char)
    local n = 0
    if intent.refused then
        if e and (e.name == intent.from or e.name == intent.want) then
            -- 1.8.37: a copy that MOVED here from another unit (its kind's in-use count did not grow) is no new use: taking it off
            -- would leave it on nobody (retail 2026-10-18: StandardCell ended on no unit). It stays; only a NEW use comes off.
            local _, usedNow = DH.use(hq, snap, e.name)
            if not intent.mine and intent.usedBefore ~= nil and usedNow <= intent.usedBefore then
                DH.once("moved|" .. short .. "|" .. e.name, ("%s: the refusal of %s did not stick and the game MOVED a copy another unit wore into hex %d - left there (the copy count is unchanged; taking it off would leave it on no unit) (%s)"):format(
                    short, e.name, intent.slot + 1, intent.refused))
            else
                DH.unequipNow(hq, s.id, char); n = n + 1
                DH.paths_.post = DH.paths_.post + 1
                DH.once("path|post", ("path POST-EQUIP FALLBACK fired: the pre-hook's refusal did not stick - %s taken off hex %d of %s (%s)"):format(e.name, intent.slot + 1, short, intent.refused))
            end
        end
    elseif intent.want and e and e.name == intent.want then
        if intent.want ~= intent.from then
            DH.paths_.pre = DH.paths_.pre + 1
            DH.once("path|pre", ("path PRE-HOOK fired: %s into hex %d of %s became %s in the hook (the %s blade)"):format(intent.from, intent.slot + 1, short, intent.want, DH.which(intent.slot + 1)))
        end
    elseif intent.want and intent.want ~= intent.from and e == nil then
        -- the native refused the right item (P2-1: already on the right blade) and nothing was rewritten: equip the twin ourselves
        local owned, used = DH.budget(hq, snap, intent.want)
        local inList = {}
        for _, x in ipairs(list) do inList[x.key] = true end
        local tid = (DH.share or used + 1 <= owned) and DH.freeId(hq, snap, intent.want, char, inList) or nil
        if tid and DH.equipNow(hq, tid, char, intent.slot) then
            n = n + 1; DH.moves = DH.moves + 1
            DH.paths_.post = DH.paths_.post + 1
            DH.once("path|post", ("path POST-EQUIP FALLBACK fired: %s into hex %d of %s was refused by the game - its %s equipped there instead"):format(intent.from, intent.slot + 1, short, intent.want))
        else
            DH.log(("%s: %s into hex %d: nothing equipped (%s)"):format(short, intent.from, intent.slot + 1, tid and "the twin did not equip" or "no free copy under the copy rule"))
        end
    else
        local f = DH.fixup(hq, char, "post-equip")
        if f > 0 then
            n = n + f; DH.paths_.post = DH.paths_.post + 1
            DH.once("path|post", ("path POST-EQUIP FALLBACK fired: %s's hexes fixed after the equip (%d change(s))"):format(short, f))
        end
    end
    n = n + DH.enforce(hq, char, "post-equip")
    DH.sigs[intent.cf] = DH.sigOf(DH.slots(hq, char))         -- the scan must not redo it
    return n
end
-- ---- route 3: SABERLOOK's scan (CP.dhOnScan): the wielders of dualHex sabers of ours; a changed slot list is fixed up
function DH.onScan(prim, world)
    if not DH.live or DH.down then return nil end
    if not (type(world) == "string" and world:find("HUB_Root", 1, true)) then DH.wield = {}; return nil end
    local wield = {}
    for _, e in ipairs(prim) do
        if DH.actors[e.cls] then
            local ch = nil
            pcall(function() local o = e.a:GetOwner(); if DH.valid(o) then ch = o end end)
            if not ch then pcall(function() local o = e.a:GetAttachParentActor(); if DH.valid(o) then ch = o end end) end
            if ch then wield[DH.full(ch)] = { cls = e.cls, ch = ch } end
        end
    end
    local names = {}
    for cf, w in pairs(wield) do names[cf] = w.cls end
    DH.wield = names                                          -- strings only: what the pre-hook asks
    for cf, w in pairs(wield) do
        local hq = DH.hqOf(w.ch)
        local list = hq and DH.slots(hq, w.ch) or nil
        local sig = list and DH.sigOf(list) or nil
        if sig and DH.sigs[cf] ~= sig then
            local first = DH.sigs[cf] == nil
            DH.sigs[cf] = sig
            local n = DH.fixup(hq, w.ch, first and "scan" or "scan: the list changed")
            if n > 0 then
                DH.paths_.scan = DH.paths_.scan + 1
                DH.once("path|scan", ("path SCAN FALLBACK fired: %s's hexes fixed at a scan (%d change(s); no equip hook saw it)"):format(DH.short(w.ch), n))
                DH.sigs[cf] = DH.sigOf(DH.slots(hq, w.ch))
            end
        end
    end
    return nil
end
-- ---- the twin top-up (the task, outside every hook): each kind's twins >= its right copies (a purchase, an old save)
function DH.topUp()
    local hq = findHQ()
    DH.lookups = DH.lookups + 1
    if not hq then return end
    local snap = DH.inv(hq)
    if not snap then return end
    for r, t in pairs(DH.R2T) do
        local ownedR = DH.use(hq, snap, r)
        local ownedT = DH.use(hq, snap, t)
        if ownedR > ownedT then
            local asset = snap.byName[t] and snap.byName[t].asset or nil
            local p = DH.paths[t]
            if not asset and p then
                DH.lookups = DH.lookups + 1
                local okF, o = pcall(StaticFindObject, p)
                if okF and DH.valid(o) then asset = o
                else
                    local pkg = p:match("^(.-)%.[^%.]+$")
                    if pkg then pcall(bridge, "ZCSDK:loadpkg|" .. pkg) end
                    okF, o = pcall(StaticFindObject, p)
                    if okF and DH.valid(o) then asset = o end
                end
            end
            if asset then
                local okA, e = pcall(function() hq:AddItem(asset, ownedR - ownedT) end)
                DH.topUps = DH.topUps + 1
                DH.log(("twin top-up: %s x%d (%s: %d owned, %d twin(s) before) -> %s"):format(t, ownedR - ownedT, r, ownedR, ownedT,
                    okA and "added" or ("AddItem raised: " .. tostring(e))))
            else
                DH.once("tmiss|" .. t, "twin top-up: " .. t .. " is not loaded and has no path that loads (the left hexes fill only as far as its granted copies)")
            end
        end
    end
end
-- ---- the page: the gap after hex `right` and the two labels
function DH.loadoutGear(w)
    if not (DH.mdLib and DH.loadCls) then return nil end
    local vm = nil; pcall(function() vm = DH.mdLib:GetViewModel(w, DH.loadCls, DH.fname("Default")) end)
    if not DH.valid(vm) then return nil end
    local gear = nil; pcall(function() gear = vm.GearActor end)
    if not DH.valid(gear) then return nil end
    return DH.str(function() return gear:GetClass():GetFName():ToString() end)
end
function DH.mkText(s)
    if DH.textHow == nil or DH.textHow == "FText" then
        if FText ~= nil then local ok, t = pcall(FText, s); if ok and t ~= nil then DH.textHow = "FText"; return t end end
    end
    if DH.textHow == nil or DH.textHow == "ktl" then
        if DH.ktl then local ok, t = pcall(function() return DH.ktl:Conv_StringToText(s) end); if ok and t ~= nil then DH.textHow = "ktl"; return t end end
    end
    DH.textHow = "string"
    return s
end
function DH.findLabels(ov)
    local got = {}
    local n = 0; pcall(function() n = ov:GetChildrenCount() end)
    for i = 0, (tonumber(n) or 0) - 1 do
        local c = nil; pcall(function() c = ov:GetChildAt(i) end)
        local nm = DH.valid(c) and DH.nameOf(c) or nil
        if nm == DH.LBL.right then got.right = c elseif nm == DH.LBL.left then got.left = c end
    end
    return got
end
function DH.mkLabel(w, ov, hand, font)
    local lbl = nil
    local ok, e = pcall(function() lbl = StaticConstructObject(DH.textCls, w.WidgetTree, DH.fname(DH.LBL[hand])) end)
    if not ok or not DH.valid(lbl) then DH.once("lblmk", "a label could not be constructed (" .. tostring(e) .. "): the gap stays, no labels"); return nil end
    pcall(function() lbl:SetText(DH.mkText(DH.labels[hand])) end)
    if DH.valid(font) then
        pcall(function() lbl:SetFont({ FontObject = font, TypefaceFontName = DH.fname("Medium"), Size = 16.5, LetterSpacing = 80 }) end)
    else DH.once("font", "the game font " .. DH.FONT .. " is not resident: the labels use the TextBlock default") end
    local slot = nil; pcall(function() slot = ov:AddChildToOverlay(lbl) end)
    if not DH.valid(slot) then DH.once("lbladd", "AddChildToOverlay answered nothing: no labels"); return nil end
    local x = DH.ROW_X + ((hand == "left") and (DH.PITCH * DH.right + DH.gap) or 0)
    pcall(function() slot:SetHorizontalAlignment(DH.HALIGN_LEFT) end)
    pcall(function() slot:SetVerticalAlignment(DH.VALIGN_TOP) end)
    pcall(function() slot:SetPadding({ Left = x, Top = 0, Right = 0, Bottom = 0 }) end)
    pcall(function() lbl:SetRenderTranslation({ X = 0, Y = DH.LABEL_Y }) end)
    return lbl
end
function DH.onSlots(ctx)
    if DH.down or not DH.live then return end
    local w = nil; pcall(function() w = ctx:get() end)
    if not DH.valid(w) then return end
    local wp = DH.path(w)
    local inv = DH.str(function() return w.InventoryType.TagName:ToString() end)
    local cls = (inv == DH.MOD_TAG) and DH.loadoutGear(w) or nil
    local dual = cls ~= nil and DH.actors[cls] == true
    if DH.pageDual[wp] ~= dual then
        DH.pageDual[wp] = dual
        DH.once("page|" .. tostring(dual) .. "|" .. tostring(cls), ("page: %s -> %s (logged once per weapon)"):format(tostring(cls),
            dual and ("3 + 3 hexes: a gap of " .. DH.gap .. " px after hex " .. DH.right .. (DH.labelsOn and ", labels" or "")) or "stock row"))
    end
    if not DH.labelsOn or not DH.textCls then return end
    local ov = nil; pcall(function() ov = w.slotList:GetParent():GetParent() end)
    if not DH.valid(ov) then DH.once("noov", "WBP_Armory_ItemSlots.slotList has no Overlay_1 above it: no labels"); return end
    local got = DH.findLabels(ov)
    local font = nil
    if dual and not (got.right and got.left) then                      -- a new page widget: ONE font lookup for its labels, never kept
        DH.lookups = DH.lookups + 1
        local okF, f = pcall(StaticFindObject, DH.FONT)
        if okF then font = f end
    end
    for _, hand in ipairs({ "right", "left" }) do
        local l = got[hand]
        if dual and not l then l = DH.mkLabel(w, ov, hand, font) end
        if l then pcall(function() l:SetVisibility(dual and DH.VIS_HTI or DH.VIS_COLLAPSED) end) end
    end
end
function DH.onEntry(ctx, pItem)
    if DH.down or not DH.live or not DH.ule then return end
    local entry = nil; pcall(function() entry = ctx:get() end)
    if not DH.valid(entry) then return end
    local owner = nil; pcall(function() owner = DH.ule:GetOwningListView(entry) end)
    local pad = 0
    if DH.valid(owner) then
        local wp = (DH.path(owner)):match("^(.*)%.WidgetTree%.slotList$")
        if wp and DH.pageDual[wp] then
            local item = nil; pcall(function() item = pItem:get() end)
            local idx = nil; pcall(function() idx = owner:GetIndexForItem(item) end)
            if idx == DH.right then pad = DH.gap end
        end
    end
    local ok = pcall(function() entry.tooltipBox.Slot:SetPadding({ Left = pad, Top = 0, Right = 0, Bottom = 0 }) end)
    if ok and pad > 0 then DH.pads = DH.pads + 1 end
    if not ok then DH.once("pad", "entry.tooltipBox.Slot:SetPadding failed: no gap") end
end
-- ---- arming
function DH.armEquip()
    if DH.equipArmed then return end
    DH.equipArmed = true                                      -- set BEFORE the call: never retried
    local ok, err = pcall(RegisterHook, DH.EQUIP_FN,
        function(ctx, pId, pChar, pSlot) local okP, e = pcall(DH.onPre, ctx, pId, pChar, pSlot); if not okP then DH.once("pe", "pre-hook error: " .. tostring(e)) end end,
        function(ctx, pId, pChar, pSlot) local okP, e = pcall(DH.onPost, ctx, pId, pChar, pSlot); if not okP then DH.once("po", "post-hook error: " .. tostring(e)) end end)
    DH.equipOk = ok
    DH.log("equip hooks " .. (ok and "ok" or ("FAILED (not retried; the scan fix-up still works): " .. tostring(err))) .. " on " .. DH.EQUIP_FN)
end
function DH.armPage()
    if DH.pageArmed then return end
    DH.pageArmed = true                                       -- set BEFORE the calls: never retried
    local ok1, e1 = pcall(RegisterHook, DH.SLOTS_FN, function(ctx) local okC, e = pcall(DH.onSlots, ctx); if not okC then DH.once("se", "UpdateSlots hook error: " .. tostring(e)) end end)
    local ok2, e2 = pcall(RegisterHook, DH.ENTRY_FN, function(ctx, pItem) local okC, e = pcall(DH.onEntry, ctx, pItem); if not okC then DH.once("ee", "OnListItemObjectSet hook error: " .. tostring(e)) end end)
    DH.slotsOk, DH.entryOk = ok1, ok2
    DH.log(("page hooks: UpdateSlots %s, OnListItemObjectSet %s (registered once)"):format(ok1 and "ok" or ("FAILED: " .. tostring(e1)), ok2 and "ok" or ("FAILED: " .. tostring(e2))))
end
function DH.task()
    if not DH.loaded then
        if not injected then return DH.WAIT_S end
        DH.loaded = true
        local any = false
        for _, mf in ipairs(manifests) do   -- 1.8.54 (M-3): one manifest at a time
            local ok, r = pcall(DH.merge, mf.m)
            if ok and r then any = true elseif not ok then log("DUALHEX: " .. tostring(mf.m.name) .. "'s sabers block failed: " .. tostring(r)) end
        end
        if not any then return true end                         -- no dualHex saber anywhere: never a lookup, never a hook
        if not DH.settings(UE4SS) then log("DUALHEX OFF for the session: settings.ini [DUALHEX] Enabled=off"); return true end
        DH.live = true
        if type(CP) == "table" then CP.dhOnScan = DH.onScan; CP.dhLive = true end   -- SABERHEADINGS hides the twins only while this is on
        local np, na = 0, 0
        for _ in pairs(DH.R2T) do np = np + 1 end
        for _ in pairs(DH.actors) do na = na + 1 end
        DH.log(("armed: %d dual saber class(es), %d twin pair(s); hexes 1-%d right, %d+ left; copies %s; gap %d px; labels %s"):format(na, np,
            DH.right, DH.right + 1, DH.share and "SHARED (one copy may fill both blades)" or "one owned copy fills ONE hex", DH.gap, DH.labelsOn and "on" or "off"))
    end
    local hub, w = strategySide()
    if not hub then DH.world, DH.wield = nil, {}; return DH.MENU_S end
    if DH.world ~= w then DH.world, DH.sigs, DH.wield, DH.pageDual, DH.nextTopUp = w, {}, {}, {}, 0; return DH.HUB_SETTLE_S end
    -- one /Script/ lookup per pass (kept for the session)
    if not DH.hqCdo and not DH.tried.hqCdo then DH.script("hqCdo", DH.HQ_CDO); return DH.STEP_S end
    if not DH.equipArmed then DH.armEquip(); return DH.STEP_S end
    local now = DH.clock()
    if now >= DH.nextTopUp then DH.nextTopUp = now + DH.TOPUP_S; local okT, e = pcall(DH.topUp); if not okT then DH.once("tu", "twin top-up error: " .. tostring(e)) end; return DH.STEP_S end
    if not DH.pageArmed then
        if not (type(CP) == "table" and CP.shPageSeen) then return DH.STEP_S end   -- SABERHEADINGS saw the MODS page: its classes are resident
        if not DH.mdLib and not DH.tried.mdLib then DH.script("mdLib", DH.LIB_CDO); return DH.STEP_S end
        if not DH.loadCls and not DH.tried.loadCls then DH.script("loadCls", DH.LOADOUT_CLS); return DH.STEP_S end
        if not DH.ule and not DH.tried.ule then DH.script("ule", DH.ULE_CDO); return DH.STEP_S end
        if DH.labelsOn and not DH.textCls and not DH.tried.textCls then DH.script("textCls", DH.TEXT_CLS); DH.script("ktl", DH.KTL_CDO); return DH.STEP_S end
        DH.armPage()
    end
    return DH.TOPUP_S
end
DH.taskRef = addTask("dualhex", 5.0, function()
    local ok, r = pcall(DH.task)
    if not ok then log("DUALHEX error (the loop keeps running): " .. tostring(r)); return 10 end
    return r
end)
if DUALHEX_EXPORT then DUALHEX_EXPORT(DH) end                -- tools/replay_dualhex.py only (a nil global in the game)
end
-- ---- 2026-10-12: DUALHEX (end) ----

-- ---- 2026-10-11: VOLLEYLOG (begin; tools/replay_volleylog.py extracts this block verbatim) ----
-- AN OPT-IN PROBE, OFF BY DEFAULT: what a shot PLAYED and how many bolts it PLANNED and FIRED (the Z-6 volley scope §3;
-- weapons[].volley is proven with it). Turned on by ue4ss/Mods/ZCSDKLoader/settings.ini `[VOLLEYLOG] Enabled = on` or by the
-- file ue4ss/Mods/ZCSDKLoader/volleylog.txt; `[VOLLEYLOG] Bolts = on` adds one line per bolt. Off = the task reads the two
-- files ONCE and stops for good: no hook, no object lookup. tools/sandbox/zcsandbox.py `volley` summarises the lines.
-- THE HOOKS (reflected UFunctions reached through ProcessEvent / the script VM; Kismet-proven call sites):
--   BitReactorCinematicActor:PlaySequenceWithBoundActors / :PlaySequence   (native, BP-called)  -> "seq <LevelSequence>"
--   BitReactorAbilityCinematicState_PlaySequence:SelectLevelSequence (post; its out param)       -> "select <LevelSequence>"
--   BP_WeaponFireComponent_C:FireWeaponVolleyEvent  -> "#n event"  (the notify: its sequence, VolleyType, VolleyVariationIndex)
--   BP_WeaponFireComponent_C:GenerateVolleyData     -> "#n gen" (window, type, variant); post: "#n plan" (VolleyShotsData count)
--   BP_WeaponFireComponent_C:FireVolleyProjectile   -> counted per bolt ("#n bolt" lines only with Bolts = on)
--   BP_WeaponGearActor_C:PlayVolleyAk / :OnVolleyCompleted -> "#n ak", "#n done planned=P fired=F"
-- SAFETY (the loader's own lessons): armed ONCE, never retried (1.8.2), only in a MISSION world that has been up VL.SETTLE s
-- (1.8.23: the hub's spawn wave killed RegisterHook), only once both Blueprint classes are resident; every callback body
-- pcall'd; reads are PLAIN object refs, ints, floats and array counts - NEVER a TSoftObjectPtr (a Lua soft-pointer read
-- crashed retail), never a DT_AG_* row or a state's Sequences array; nothing is kept across callbacks but numbers, strings
-- and the volley counters. The log is capped at VL.LINE_CAP lines a session.
local VL = {
    INI = "Mods/ZCSDKLoader/settings.ini", FLAG = "Mods/ZCSDKLoader/volleylog.txt",
    MARK = "/Maps/Skirmish/", SETTLE = 8, LINE_CAP = 4000,
    WFC = "/Game/Game/Core/Blueprints/Components/BP_WeaponFireComponent.BP_WeaponFireComponent_C",
    GEAR = "/Game/Game/Core/Gear/BP_WeaponGearActor.BP_WeaponGearActor_C",
    CINE = "/Script/BitReactorGame.BitReactorCinematicActor",
    STATE = "/Script/BitReactorGame.BitReactorAbilityCinematicState_PlaySequence",
    on = nil, bolts = false, world = nil, seenAt = nil, lines = 0, n = 0, cur = nil, armed = 0, failed = 0,
}
function VL.read(p)
    local f = io.open(p, "rb"); if not f then return nil end
    local s = f:read(262144); f:close(); return s or ""
end
function VL.iniGet(text, section, key)              -- the value of `key` in [section]; nil when absent (';' / '#' comments)
    local sec, found = "", nil
    for raw in ((text or "") .. "\n"):gmatch("([^\r\n]*)\r?\n") do
        local line = raw:gsub("^\239\187\191", ""):gsub("%s*[;#].*$", ""):match("^%s*(.-)%s*$") or ""
        local s = line:match("^%[%s*(.-)%s*%]$")
        if s then sec = s:lower()
        elseif sec == section:lower() then
            local k, v = line:match("^([^=]-)%s*=%s*(.*)$")
            if k and k:lower() == key:lower() then found = v end
        end
    end
    return found
end
function VL.truthy(v) v = (v or ""):lower(); return v == "on" or v == "1" or v == "true" or v == "yes" end
function VL.say(m)
    VL.lines = VL.lines + 1
    if VL.lines <= VL.LINE_CAP then log("[volley] " .. m)
    elseif VL.lines == VL.LINE_CAP + 1 then log("[volley] " .. VL.LINE_CAP .. " lines this session; further volley lines are not logged") end
end
function VL.get(p)                                   -- a hook param's value (RemoteUnrealParam:get()), or nil
    local v = nil; pcall(function() v = p:get() end); return v
end
function VL.name(o)                                  -- "<package leaf>" of an object: GetFullName, the type of the result tested
    local n = nil; pcall(function() n = o:GetFullName() end)
    if type(n) ~= "string" or n == "" then return "?" end
    local pkg = n:match("(/[^%s%.:]+)")
    return pkg and (pkg:match("([^/]+)$") or pkg) or (n:match("([^%s%.:]+)$") or n)
end
function VL.num(v, fmt)
    if type(v) == "number" then return fmt and fmt:format(v) or tostring(v) end
    local s = nil; pcall(function() s = v:ToString() end)    -- an enum / FName wrapper
    return s or tostring(v)
end
function VL.count(arr)                               -- a TArray's length (0 when unreadable)
    local n = 0; pcall(function() n = arr:GetArrayNum() end); return tonumber(n) or 0
end
function VL.close(why)
    local c = VL.cur
    if not c or c.done then return end
    c.done = true
    local mism = (c.planned ~= nil and c.planned ~= c.fired) and " MISMATCH" or ""
    VL.say(("#%d done planned=%s fired=%d span=%.2fs (%s)%s"):format(c.id, c.planned == nil and "?" or tostring(c.planned), c.fired,
        os.clock() - c.t0, why, mism))
end
function VL.plan(comp, how)                         -- the planned bolts = VolleyShotsData's count (+ the keyed set it drew)
    local c = VL.cur
    if not c or c.planned ~= nil then return end
    local shots, keys, last = nil, 0, nil
    pcall(function() shots = comp.VolleyShotsData end)
    c.planned = VL.count(shots)
    pcall(function()
        local kf = comp.KeyframedVolleyData.Keyframes
        keys = VL.count(kf)
        if keys > 0 then last = kf[keys] end
    end)
    VL.say(("#%d plan planned=%d keys=%d%s (%s)"):format(c.id, c.planned, keys, last and (" last=%sms"):format(VL.num(last, "%.0f")) or "", how))
end
-- the hook bodies (each wrapped in pcall at registration)
VL.H = {
    { cls = "CINE", fn = "PlaySequenceWithBoundActors", pre = function(ctx, seq)
        VL.say("seq " .. VL.name(VL.get(seq)) .. " via PlaySequenceWithBoundActors") end },
    { cls = "CINE", fn = "PlaySequence", pre = function(ctx, seq)
        VL.say("seq " .. VL.name(VL.get(seq)) .. " via PlaySequence") end },
    { cls = "STATE", fn = "SelectLevelSequence", pre = function() end, post = function(ctx, ...)
        for _, p in ipairs({ ... }) do
            local v = VL.get(p); local full = nil
            pcall(function() full = v:GetFullName() end)
            if type(full) == "string" and full:find("^LevelSequence ") then VL.say("select " .. VL.name(v)); return end
        end
    end },
    { cls = "WFC", fn = "FireWeaponVolleyEvent", pre = function(ctx, ev)
        if VL.cur and not VL.cur.done then VL.close("next volley began; no OnVolleyCompleted") end
        VL.n = VL.n + 1
        VL.cur = { id = VL.n, t0 = os.clock(), planned = nil, fired = 0, done = false }
        local comp, e, nt, vt, vi, unit = VL.get(ctx), VL.get(ev), nil, "?", "?", "?"
        pcall(function() nt = e.OptionalObject end)
        pcall(function() vt = VL.num(nt.VolleyType) end)
        pcall(function() vi = VL.num(nt.VolleyVariationIndex) end)
        pcall(function() unit = VL.name(comp:GetOuter()) end)
        VL.say(("#%d event unit=%s notify=%s type=%s var=%s"):format(VL.n, unit, nt and VL.name(nt) or "none", vt, vi))
    end },
    { cls = "WFC", fn = "GenerateVolleyData", pre = function(ctx, held, vtype, vvar)
        local id = VL.cur and VL.cur.id or 0
        VL.say(("#%d gen window=%ss type=%s var=%s"):format(id, VL.num(VL.get(held), "%.3f"), VL.num(VL.get(vtype)), VL.num(VL.get(vvar))))
    end, post = function(ctx) VL.plan(VL.get(ctx), "post") end },
    { cls = "WFC", fn = "FireVolleyProjectile", pre = function(ctx)
        local c = VL.cur
        if not c then return end
        if c.planned == nil then VL.plan(VL.get(ctx), "at the first bolt") end
        c.fired = c.fired + 1
        if VL.bolts then
            local el = nil; pcall(function() el = VL.get(ctx).VolleyElapsedTime end)
            VL.say(("#%d bolt %d t=%ss"):format(c.id, c.fired, VL.num(el, "%.3f")))
        end
    end },
    { cls = "GEAR", fn = "PlayVolleyAk", pre = function(ctx, vtype, vvar)
        VL.say(("#%d ak type=%s variant=%s"):format(VL.cur and VL.cur.id or 0, VL.num(VL.get(vtype)), VL.num(VL.get(vvar))))
    end },
    { cls = "GEAR", fn = "OnVolleyCompleted", pre = function() VL.close("OnVolleyCompleted") end },
}
do
    local volleyHookArmed = false                   -- RegisterHook is NOT retry-safe (1.8.2): set before the first call, never cleared
    function VL.arm()
        if volleyHookArmed then return true end
        volleyHookArmed = true
        for _, h in ipairs(VL.H) do
            local path = VL[h.cls] .. ":" .. h.fn
            local pre = function(...) local ok, err = pcall(h.pre, ...); if not ok then VL.say("hook error in " .. h.fn .. ": " .. tostring(err)) end end
            local ok, err
            if h.post then
                local post = function(...) local ok2, err2 = pcall(h.post, ...); if not ok2 then VL.say("hook error in " .. h.fn .. " (post): " .. tostring(err2)) end end
                ok, err = pcall(RegisterHook, path, pre, post)
            else
                ok, err = pcall(RegisterHook, path, pre)
            end
            if ok then VL.armed = VL.armed + 1 else VL.failed = VL.failed + 1; VL.say("could NOT hook " .. path .. " (not retrying, by design): " .. tostring(err)) end
        end
        VL.say(("armed %d/%d hooks at %s"):format(VL.armed, #VL.H, os.date("%H:%M:%S")))
        return true
    end
end
-- the pump task: decide on/off ONCE, then wait for a settled mission world with both classes resident, then arm once
function VL.task()
    if VL.on == nil then
        local ini = VL.read(UE4SS .. VL.INI) or ""
        VL.on = VL.truthy(VL.iniGet(ini, "VOLLEYLOG", "Enabled")) or VL.read(UE4SS .. VL.FLAG) ~= nil
        VL.bolts = VL.truthy(VL.iniGet(ini, "VOLLEYLOG", "Bolts"))
        if not VL.on then return true end                           -- OFF (the default): stop for good, nothing was touched
        log("[volley] VOLLEYLOG on (settings.ini [VOLLEYLOG] Enabled / volleylog.txt)" .. (VL.bolts and "; one line per bolt" or "") ..
            "; arming waits for a mission world (" .. VL.MARK .. ") up " .. VL.SETTLE .. " s")
    end
    local wname = pinWorldName()
    if not wname:find(VL.MARK, 1, true) then VL.world, VL.seenAt = nil, nil; return false end
    if VL.world ~= wname then VL.world, VL.seenAt = wname, os.time(); return false end
    if os.difftime(os.time(), VL.seenAt) < VL.SETTLE then return false end
    if not (pinOk(StaticFindObject(VL.WFC)) and pinOk(StaticFindObject(VL.GEAR))) then return false end
    return VL.arm()
end
VL.taskRef = addTask("volleylog", 5.0, function()
    local ok, r = pcall(VL.task)
    if not ok then log("[volley] error (the task keeps running): " .. tostring(r)); return 10 end
    return r
end)
-- ---- 2026-10-11: VOLLEYLOG (end) ----

-- ---- 2026-10-11: CLASSFX (begin; tools/replay_classfx.py extracts this block verbatim) ----
-- THE CLASS MODS' V2 EFFECTS (docs/recon/CLASSES_V2_LUA_SCOPE.md rev 2; the mod-def keys are tools/zcmod-classlua.js):
--   effectAnims  the Force Choke target HOLD: while a unit carries the entry's `effect` (stock GE_Bind_Target) AND its own
--                `marker`, play intro -> loop on DefaultSlot (PlaySlotAnimationAsDynamicMontage; no montage asset), re-issue
--                the loop if something stops it, outro when either GE goes; a marker left alone 1 s after the effect went is
--                removed (RemoveEffectByClass on the mod's OWN class only). Other skeletons (droids, beasts) are skipped.
--   castBeams    one bolt per cone victim per hand: the cast puts the mod's own marker on each victim (the caster = its
--                instigator); the loader spawns the beam NS unattached (SpawnSystemAtLocation, never pooled), sets both
--                ends (SetVariablePosition) and keeps them on the hand and the chest, then consumes the marker.
--   fxSettings   a player setting picking an NS variant ([FX] LightningColor in the MOD's settings.ini, read at every
--                mission start, case-insensitive) for castBeams, plus `cdoWrites` into the mod's OWN FX BP's hard
--                NiagaraSystem variable on its CDO (spawns after the write copy it).
--   auras        a per-turn pulse: at a team's turn start, each source (a unit carrying the source GE / class key) gives
--                the allies (or enemies) within `radius` that meet `require` the `grant` GEs + an idempotency `marker`.
--                The ONLY GE apply from Lua: MakeEffectSpecHandle + BP_ApplyGameplayEffectSpecToTarget, falling back
--                for the session to BP_ApplyGameplayEffectToSelf when the spec route raises or does not land.
-- THE RULES (the loader's own lessons): NO RegisterHook - every feature is a pump poll of state the game keeps (GE presence
-- by CLASS, the GameState turn pair); Lua reads no gameplay tag and NO soft pointer (every asset is a manifest STRING; the
-- one soft-path call builds a path for LoadAsset_Blocking, the retail-proven route for runtime-mounted paks); nothing
-- UObject is kept across frames - units are re-listed every pass and keyed by full name, a spawned beam by its object path
-- (re-found with StaticFindObject); uvalid() before any method; every call pcall'd. Only in a MISSION world (/Maps/Skirmish/)
-- that has been up CX.SETTLE s. Dormant (the tasks stop for good) when no manifest declares a feature.
-- THE SWITCHES: ue4ss/Mods/ZCSDKLoader/settings.ini  [CLASSFX] Enabled = on|off, Holds / Beams / Auras = on|off,
-- ApplyRoute = auto|spec|self. A feature STANDS DOWN for the session (one log line) when a native class it needs is missing
-- or after CX.ERR_CAP errors; an entry whose own class / clip / NS is not loaded waits CX.LOAD_GIVEUP_S, logs once and is
-- skipped in that mission. Manifest contract: `classFx = 1` (a newer number is refused with a line, never guessed at).
-- (one `do` block: the main chunk sits near Lua's 200-local limit, so CX adds no chunk-level local)
do
local CX = {
    INI = "Mods/ZCSDKLoader/settings.ini", MARK = "/Maps/Skirmish/", SETTLE = 8, CONTRACT = 1,
    BASE_S = 0.5, HOLD_S = 0.25, BEAM_S = 0.1, TURN_S = 0.25, IDLE_S = 2.0,
    MAX_UNITS = 64, MAX_LIVE = 32, ERR_CAP = 8, LOAD_GIVEUP_S = 3, STALE_GRACE_S = 1.0, BEAM_DESTROY_S = 1.0,
    LOOP_COUNT = 100000, LINE_CAP = 600, SOCK_Z = 90,
    UNIT = "/Script/BitReactorGame.Default__BitReactorGameStatics_Unit",
    TGS = "/Script/BitReactorGame.Default__TacticalGameState",
    GSTAT = "/Script/BitReactorGame.Default__BitReactorGameStatics",   -- 1.8.40: GetTeam(Actor), the aura's team fallback (optional)
    SF = "/Script/BitReactorGame.Default__BitReactorAbilityScriptingFunctions",
    ASBL = "/Script/GameplayAbilities.Default__AbilitySystemBlueprintLibrary",
    NFL = "/Script/Niagara.Default__NiagaraFunctionLibrary",
    KSL = "/Script/Engine.Default__KismetSystemLibrary",
    NEEDS = { holds = { "UNIT", "ASBL", "SF" }, beams = { "UNIT", "ASBL", "SF", "NFL" }, auras = { "UNIT", "ASBL", "SF" } },
    clock = os.clock,
    effectAnims = {}, castBeams = {}, auras = {}, fxSettings = {}, classKeys = {},
    feat = {}, errs = {}, logged = {}, lines = 0, conf = nil, route = nil,
    wname = nil, wkey = nil, seenAt = nil, armed = false, holdFirst = true,
    holds = {}, stale = {}, live = {}, markSeen = {}, missing = {}, skelSkip = {}, coordPath = nil, lastTurn = nil, turnSig = "",
    DIAG_CAP = 400, diagN = 0, diagSeen = {},          -- 1.8.40: the aura pulse's skip lines (CX.skip), per mission
}
function CX.say(m)
    CX.lines = CX.lines + 1
    if CX.lines <= CX.LINE_CAP then log("[classfx] " .. m)
    elseif CX.lines == CX.LINE_CAP + 1 then log("[classfx] " .. CX.LINE_CAP .. " lines this session; further classfx lines are not logged") end
end
function CX.once(k, m) if CX.logged[k] then return end; CX.logged[k] = true; CX.say(m) end
function CX.read(p)
    local f = io.open(p, "rb"); if not f then return nil end
    local s = f:read(262144); f:close(); return s or ""
end
function CX.iniGet(text, section, key)              -- the value of `key` in [section] (both case-insensitive); nil when absent
    local sec, found = "", nil
    for raw in ((text or "") .. "\n"):gmatch("([^\r\n]*)\r?\n") do
        local line = raw:gsub("^\239\187\191", ""):gsub("%s*[;#].*$", ""):match("^%s*(.-)%s*$") or ""
        local s = line:match("^%[%s*(.-)%s*%]$")
        if s then sec = s:lower()
        elseif sec == section:lower() then
            local k, v = line:match("^([^=]-)%s*=%s*(.*)$")
            if k and k:lower() == key:lower() then found = v end
        end
    end
    return found
end
function CX.onoff(v, dflt)
    v = (v or ""):lower()
    if v == "off" or v == "0" or v == "false" or v == "no" then return false end
    if v == "on" or v == "1" or v == "true" or v == "yes" then return true end
    return dflt
end
function CX.name(o)
    local n = nil; pcall(function() n = o:GetFullName() end)
    return (type(n) == "string" and n ~= "") and n or nil
end
function CX.short(full) return (tostring(full):match("([^%./:%s]+)$")) or tostring(full) end
function CX.pathOf(o)                               -- "<Class> <path>" -> "<path>" (what StaticFindObject takes)
    local n = CX.name(o); return n and (n:match("^%S+%s+(.+)$") or n) or nil
end
-- an error inside a feature: logged (capped); at ERR_CAP the feature stands down for the session
function CX.fail(feat, why)
    CX.errs[feat] = (CX.errs[feat] or 0) + 1
    if CX.errs[feat] <= 3 then CX.say(feat .. " error: " .. tostring(why)) end
    if CX.errs[feat] >= CX.ERR_CAP and CX.feat[feat] == "on" then
        CX.feat[feat] = "off"
        CX.say(feat .. " STOOD DOWN for the session after " .. CX.errs[feat] .. " errors (the game is untouched from here on)")
    end
end
-- a READ the features depend on: a raise is logged ONCE per call name (the sandbox's first question: does it marshal?), and the
-- caller sees its safe default (0 / false / nil)
function CX.try(what, fn)
    local ok, err = pcall(fn)
    if not ok then CX.once("try|" .. what, what .. " raised (" .. tostring(err) .. ") - the read counts as none/false from here") end
    return ok
end
function CX.call(feat, fn)                          -- pcall(fn) -> ok, r; a raise counts against the feature
    local ok, r = pcall(fn)
    if not ok then CX.fail(feat, r) end
    return ok, r
end

-- ---- the manifests (read ONCE, after discover(): load order between mods cannot matter) ----
function CX.iniPathOf(mf)
    local base = (tostring(mf.path or ""):match("([^/\\]+)%.zcsdk%.lua$")) or tostring(mf.m.name)
    return mf.gfp and (mf.dir .. "/settings.ini") or (mf.dir .. "/" .. base .. ".settings.ini")
end
function CX.collect()
    local decl = 0
    for _, mf in ipairs(manifests) do
      local okM, errM = pcall(function()   -- 1.8.54 (M-3): one manifest at a time
        local m, mod = mf.m, tostring(mf.m.name)
        if type(m.classKeys) == "table" then
            for k, paths in pairs(m.classKeys) do
                CX.classKeys[k] = CX.classKeys[k] or {}
                for _, p in ipairs(type(paths) == "table" and paths or { paths }) do
                    local dup = false
                    for _, q in ipairs(CX.classKeys[k]) do if q == p then dup = true end end
                    if not dup and type(p) == "string" then table.insert(CX.classKeys[k], p) end
                end
            end
        end
        local any = m.effectAnims or m.castBeams or m.auras or m.fxSettings
        if any then
            local ver = tonumber(m.classFx)
            if not ver or ver > CX.CONTRACT then
                CX.say(("%s declares classFx = %s; this loader understands %d - its effect blocks are ignored (update the ZCSDK Runtime)")
                    :format(mod, tostring(m.classFx), CX.CONTRACT))
            else
                local ini, fx = CX.iniPathOf(mf), {}
                for _, s in ipairs(m.fxSettings or {}) do
                    s.mod, s.ini = mod, ini; fx[(s.key or ""):lower()] = s; table.insert(CX.fxSettings, s)
                end
                for _, e in ipairs(m.effectAnims or {}) do e.mod = mod; table.insert(CX.effectAnims, e) end
                for _, e in ipairs(m.castBeams or {}) do
                    e.mod = mod
                    if type(e.system) == "table" then e.fx = fx[(e.system.setting or ""):lower()] end
                    table.insert(CX.castBeams, e)
                end
                for _, e in ipairs(m.auras or {}) do e.mod = mod; table.insert(CX.auras, e) end
                decl = decl + 1
                CX.say(("%s declares %d hold anim(s), %d beam(s), %d aura(s), %d setting(s)"):format(mod, #(m.effectAnims or {}),
                    #(m.castBeams or {}), #(m.auras or {}), #(m.fxSettings or {})))
            end
        end
      end)
      if not okM then CX.say(tostring(mf.m.name) .. "'s class FX blocks failed: " .. tostring(errM)) end
    end
    return decl
end
-- the switches (ZCSDKLoader/settings.ini [CLASSFX]); -> true when anything is left to do
function CX.setup()
    CX.collect()
    local ini = CX.read(UE4SS .. CX.INI) or ""
    local on = CX.onoff(CX.iniGet(ini, "CLASSFX", "Enabled"), true)
    local route = (CX.iniGet(ini, "CLASSFX", "ApplyRoute") or "auto"):lower()
    CX.conf = { route = (route == "spec" or route == "self") and route or "auto" }
    CX.route = (CX.conf.route == "self") and "self" or nil
    local want = { holds = #CX.effectAnims > 0, beams = #CX.castBeams > 0, auras = #CX.auras > 0 }
    local names = { holds = "Holds", beams = "Beams", auras = "Auras" }
    local any = false
    for f, w in pairs(want) do
        if not w then CX.feat[f] = "none"
        elseif not on then CX.feat[f] = "off"
        elseif not CX.onoff(CX.iniGet(ini, "CLASSFX", names[f]), true) then CX.feat[f] = "off"; CX.say(f .. " off (settings.ini [CLASSFX] " .. names[f] .. "=off)")
        else CX.feat[f] = "on"; any = true end
    end
    local fxw = 0
    for _, s in ipairs(CX.fxSettings) do fxw = fxw + #(s.cdoWrites or {}) end
    CX.fxOn = on and fxw > 0
    if (want.holds or want.beams or want.auras or fxw > 0) and not on then
        CX.say("CLASSFX OFF for the session (settings.ini [CLASSFX] Enabled=off): no hold, beam, aura or CDO write")
        return false
    end
    if any or CX.fxOn then
        CX.say(("armed for mission worlds (%s up %d s): holds %s, beams %s, auras %s, fx CDO writes %d; apply route %s")
            :format(CX.MARK, CX.SETTLE, CX.feat.holds, CX.feat.beams, CX.feat.auras, CX.fxOn and fxw or 0, CX.conf.route))
    end
    return any or CX.fxOn
end

-- ---- the shared base ----
function CX.cdo(which) local o = StaticFindObject(CX[which]); return uvalid(o) and o or nil end
function CX.resetWorld(why)
    if CX.armed then CX.say("mission left (" .. why .. "): " .. (function() local n = 0; for _ in pairs(CX.holds) do n = n + 1 end; return n end)() .. " hold(s), " .. #CX.live .. " beam(s) dropped") end
    CX.armed, CX.holdFirst, CX.wkey = false, true, nil
    CX.holds, CX.stale, CX.live, CX.markSeen, CX.missing, CX.skelSkip = {}, {}, {}, {}, {}, {}
    CX.coordPath, CX.lastTurn, CX.turnSig = nil, nil, ""
    CX.diagN, CX.diagSeen, CX.badSince = 0, {}, nil
end
-- the world key: its name AND its address (a save load keeps the name)
function CX.worldKey(w, wname)
    local a = "?"; pcall(function() a = string.format("%x", w:GetAddress()) end)
    return wname .. "#" .. a
end
function CX.baseTask()
    local wname = pinWorldName()
    if not wname:find(CX.MARK, 1, true) then
        if CX.wname then CX.resetWorld("not a mission world"); CX.wname = nil end
        return CX.IDLE_S
    end
    local w = gameWorld()
    if not uvalid(w) then return CX.BASE_S end
    local key = CX.worldKey(w, wname)
    if CX.wname ~= key then
        if CX.wname then CX.resetWorld("a new world") end
        CX.wname, CX.seenAt = key, CX.clock()
        return CX.BASE_S
    end
    if not CX.armed then
        if CX.clock() - CX.seenAt < CX.SETTLE then return CX.BASE_S end
        CX.arm(w, key)
    end
    CX.fxPending(w)
    return CX.BASE_S
end
function CX.arm(w, key)
    CX.armed, CX.wkey = true, key
    for f, need in pairs(CX.NEEDS) do
        if CX.feat[f] == "on" then
            for _, which in ipairs(need) do
                if not CX.cdo(which) then
                    CX.feat[f] = "off"
                    CX.say(f .. " STOOD DOWN for the session: " .. CX[which] .. " is not found (a game update?)")
                    break
                end
            end
        end
    end
    CX.fxArm()
    CX.say("mission armed: " .. CX.short(key:match("^(.-)#") or key))
end
-- the armed world, re-read: nil unless it is still the world the base task armed
function CX.world()
    if not CX.armed then return nil end
    local wname = pinWorldName()
    if not wname:find(CX.MARK, 1, true) then return nil end
    local w = gameWorld()
    if not uvalid(w) or CX.worldKey(w, wname) ~= CX.wkey then return nil end
    return w
end
-- 1.8.40: `what` names the native; a returned value that is neither a table nor a TArray with ForEach (the read every aura
-- and beam rests on) is logged ONCE instead of reading silently as "no units"
function CX.list(arr, what)
    local out = {}
    if type(arr) == "table" and arr.ForEach == nil then
        for _, e in ipairs(arr) do if #out < CX.MAX_UNITS and uvalid(e) then out[#out + 1] = e end end
        return out
    end
    local ok, err = pcall(function() arr:ForEach(function(i, e)
        local v = e; pcall(function() v = e:get() end)
        if #out < CX.MAX_UNITS and uvalid(v) then out[#out + 1] = v end
    end) end)
    if not ok then
        CX.once("list|" .. tostring(what), ("%s returned a %s it could not iterate (%s) - it reads as no units")
            :format(tostring(what or "a unit list"), type(arr), tostring(err)))
    end
    return out
end
-- 1.8.41: what a native's TArray return came back as (the log names it: "table #0", "userdata Num 0", "nil", ...)
function CX.shape(r)
    local t = type(r)
    if t == "table" then local n = 0; pcall(function() n = #r end); return "table #" .. tostring(n) end
    if t == "userdata" then local n = "?"; pcall(function() n = r:GetArrayNum() end); return "userdata Num " .. tostring(n) end
    return t
end
-- -> the units, the shape of what came back
function CX.unitsRaw(w, feat)
    local u = CX.cdo("UNIT"); if not u then return {}, "no BitReactorGameStatics_Unit" end
    local ok, r = CX.call(feat, function() return u:GetAllRelevantLivingUnits(w) end)
    if not ok then return {}, "a raise" end
    return CX.list(r, "GetAllRelevantLivingUnits"), CX.shape(r)
end
function CX.units(w, feat) return (CX.unitsRaw(w, feat)) end
-- 1.8.41: THE UNIT FALLBACK. Retail 2026-10-20 10:15:03 + 10:16:00 (Sith B11, loader 1.8.40): GetAllRelevantLivingUnits AND
-- GetLivingUnitsByTeam both read 0 units while the 4-unit squad and the foes were alive (`0 unit(s) checked:
-- GetAllRelevantLivingUnits read 0, ... GetLivingUnitsByTeam 0`). No UFunction-RETURNED TArray has ever been read right
-- from this UE4SS build's Lua (the 09-06 PoolVerifier read of GetPreAuthoredRecruitablePools came back as one undecodable
-- element); FindAllOf is the loader's proven walk (grants' BrunoInventoryItem, SABERLOOK, ROWFIX RF.find). So when the
-- native gives nothing, ONE counted FindAllOf per pulse on the pawns' native base (ABitReactorGameCharacter: every
-- Char_Hero_* / Char_Enemy_* derives from it; FindAllOf matches subclasses), the CDOs out, this map's folder preferred.
-- Liveness is the pulse's own CX.ok; the team is GetTeam's. The aura pulse uses it once per team turn; the beams (1.8.46) through
-- the CX.beamUnits cache only, never a walk per 0.1 s beam pass (a FindAllOf is a whole-GUObjectArray walk).
CX.CHAR_CLASSES = { "BitReactorGameCharacter", "BitReactorCharacter" }
-- 1.8.46: THE MAP FOLDER IS REQUIRED and the dead / hidden are left out (Sith operator session 2026-10-22, loader 1.8.42: the
-- Lord's aura listed Char_Enemy_Separatist_B2_C_0 at 11003 cm, the B2 a Choke threw off the map). When the world name gives a
-- folder, only pawns under it count (none there -> none used, one line a mission; before 1.8.46 every pawn was used); a pawn
-- the statics read as not alive (IsUnitAlive false) or whose bHidden reads true is skipped. An unreadable read keeps the
-- pawn (the pulse's CX.ok still filters). -> units, class, all pawns, pawns in this map's folder, skipped (dead/hidden)
function CX.findUnits(w)
    local wn = CX.name(w) or ""
    local dir = wn:match("^%S+%s+(.*/)[^/]*$")
    local st = CX.cdo("UNIT")
    for _, cls in ipairs(CX.CHAR_CLASSES) do
        local ok, l = pcall(FindAllOf, cls)
        if ok and type(l) == "table" and #l > 0 then
            local here, all, skip = {}, {}, 0
            for _, a in ipairs(l) do
                if uvalid(a) then
                    local n = CX.name(a)
                    if n and not n:find("Default__", 1, true) then
                        all[#all + 1] = a
                        if dir == nil or n:find(dir, 1, true) then
                            local alive, hidden = nil, nil
                            if st then pcall(function() alive = st:IsUnitAlive(a) end) end
                            pcall(function() hidden = a.bHidden end)
                            if alive == false or hidden == true then skip = skip + 1 else here[#here + 1] = a end
                        end
                    end
                end
            end
            if dir and #here == 0 and skip == 0 then
                CX.monce("nofolder|" .. cls, ("units: FindAllOf(%s) found %d pawn(s), none in this map's folder %s - none used"):format(cls, #all, dir))
            end
            local out = {}
            for i = 1, math.min(#here, CX.MAX_UNITS) do out[i] = here[i] end
            return out, cls, #all, #here + skip, skip
        end
    end
    return {}, nil, 0, 0, 0
end
-- 1.8.46: THE BEAM UNITS. The 0.1 s beam pass read only GetAllRelevantLivingUnits, which comes back from this UE4SS's Lua with
-- no usable unit (retail 10-22, loader 1.8.42: "came back as table #15 with no usable unit"), so castBeams never saw a marked
-- victim and Force Lightning / Shock drew nothing. When the native gives nothing, the beam pass takes CX.findUnits' list, but
-- the walk is CACHED: one FindAllOf at most every CX.UNIT_CACHE_S (1.5 s) per world, the cached pawns re-checked with uvalid
-- on every reuse (never a whole-GUObjectArray walk every 0.1 s). A mark that lands just after a walk waits at most 1.5 s.
CX.UNIT_CACHE_S = 1.5
function CX.beamUnits(w)
    local units, shape = CX.unitsRaw(w, "beams")
    if #units > 0 then return units end
    local now, c = CX.clock(), CX.ucache
    if not (c and c.wkey == CX.wkey and now - c.t < CX.UNIT_CACHE_S) then
        local found, cls, nAll, nHere, nSkip = CX.findUnits(w)
        c = { wkey = CX.wkey, t = now, units = found }
        CX.ucache = c
        CX.monce("beamsource", ("beams: GetAllRelevantLivingUnits came back as %s with no usable unit; the units come from %s (%d pawn(s), %d in this map's folder, %d skipped dead/hidden; walked at most every %g s)")
            :format(shape, cls and ("FindAllOf(" .. cls .. ")") or "no source (FindAllOf found no pawn either)", nAll, nHere, nSkip, CX.UNIT_CACHE_S))
    end
    local out = {}
    for _, u in ipairs(c.units) do if uvalid(u) then out[#out + 1] = u end end
    return out
end
function CX.keyed(units)                            -- { {u=, k=} } in list order + k -> u
    local list, by = {}, {}
    for _, u in ipairs(units) do
        local k = CX.name(u)
        if k and not by[k] then by[k] = u; list[#list + 1] = { u = u, k = k } end
    end
    return list, by
end
function CX.asc(u)
    local l = CX.cdo("ASBL"); if not l then return nil end
    local a = nil; CX.try("GetAbilitySystemComponent", function() a = l:GetAbilitySystemComponent(u) end)
    return uvalid(a) and a or nil
end
function CX.count(u, cls)
    local a = CX.asc(u); if not a then return 0 end
    local n = 0; CX.try("GetGameplayEffectCount", function() n = a:GetGameplayEffectCount(cls, nil, true) end)
    return tonumber(n) or 0
end
function CX.fromActor(t, s, cls)
    local sf = CX.cdo("SF"); if not sf then return false end
    local r = false; CX.try("HasGameplayEffectFromActor", function() r = sf:HasGameplayEffectFromActor(t, s, cls) end)
    return r == true
end
function CX.remove(u, cls, feat)
    local sf, a = CX.cdo("SF"), CX.asc(u)
    if not (sf and a) then return false end
    return (CX.call(feat, function() sf:RemoveEffectByClass(a, cls, -1) end))
end
function CX.ok(u)                                   -- alive, not downed, not incapacitated (statics; no tag)
    local s = CX.cdo("UNIT"); if not s then return false, "no BitReactorGameStatics_Unit" end
    local r, why = false, "unread"
    CX.try("IsUnitAlive/Downed/Disabled", function()
        local al, dn, di = s:IsUnitAlive(u), s:IsUnitDowned(u), s:IsUnitDisabled(u)
        r = al == true and dn ~= true and di ~= true
        why = ("alive %s, downed %s, disabled %s"):format(tostring(al), tostring(dn), tostring(di))
    end)
    return r, why                                   -- 1.8.40: the reads, for the aura skip line
end
-- 1.8.40: the unit's team class name (UBitReactorGameStatics::GetTeam, the GetTeamTurn shape) or nil when unreadable
function CX.teamOf(u)
    local g = CX.cdo("GSTAT"); if not g then return nil end
    local t = nil; CX.try("GetTeam", function() t = g:GetTeam(u) end)
    return uvalid(t) and CX.name(t) or nil
end
function CX.hostile(a, b)
    local s = CX.cdo("UNIT"); if not s then return false end
    local r = false; CX.try("AreUnitsHostile", function() r = s:AreUnitsHostile(a, b) == true end)
    return r
end
function CX.loc(u)
    local v = nil; pcall(function() local p = u:K2_GetActorLocation(); v = { X = p.X, Y = p.Y, Z = p.Z } end)
    return v
end
function CX.dist(a, b, flat)
    local p, q = CX.loc(a), CX.loc(b)
    if not (p and q) then return math.huge end
    local dz = flat and 0 or (p.Z - q.Z)
    return math.sqrt((p.X - q.X) ^ 2 + (p.Y - q.Y) ^ 2 + dz ^ 2)
end
-- a class / object the manifest names: resident -> the object; else the bridge's synchronous loadpkg (re-sent at most every
-- PKG_RETRY_S while it stays missing), LoadAsset, then (1 s on) the blocking soft-path load (the ZC Unlocked runtime-mounted
-- pak route); after LOAD_GIVEUP_S one line, and the entry keeps retrying the loadpkg.
-- 2026-10-18 (Jedi bundle 06-51-36, 1.8.37): the hub preload loaded the 9 ZCSith marker/buff GE classes (ZCSDKBridge.log:
-- LoadPackage non-null at 06:42:27), nothing referenced them, and they were COLLECTED before the mission (the F.geClass
-- lesson of 10-12); UE4SS LoadAsset cannot find a Blueprint class (the gfp AssetRegistry.bin lists none) and the KSL route
-- failed too, so every classfx aura skipped. The loadpkg is the route SLOTFIX already relies on.
CX.PKG_RETRY_S = 10
function CX.obj(path, who)
    if type(path) ~= "string" then return nil end
    local o = StaticFindObject(path)
    if uvalid(o) then
        if CX.missing[path] then CX.missing[path] = nil end
        return o
    end
    local m = CX.missing[path]
    local now = CX.clock()
    if not m or now - (m.pkgAt or -math.huge) >= CX.PKG_RETRY_S then
        if not m then m = { t0 = now }; CX.missing[path] = m end
        m.pkgAt = now
        local pkg = path:match("^(.-)%.[^%.]+$")
        if pkg then pcall(bridge, "ZCSDK:loadpkg|" .. pkg) end
        o = StaticFindObject(path)
        if uvalid(o) then
            CX.missing[path] = nil
            if m.logged then CX.say(("%s: %s is resident again after loadpkg"):format(tostring(who), path)) end
            return o
        end
        if not m.asked then m.asked = true; pcall(LoadAsset, path) end
        -- 1.8.40: no early return here. The aura pulse asks once per team turn (turns are >= 10 s apart), so every one of its
        -- calls took this branch and the give-up line below was never reached: a class missing all mission was silent.
    end
    if not m.blocking and now - m.t0 >= 1 then
        m.blocking = true
        local okK, errK = pcall(function()
            local k = CX.cdo("KSL")
            if k then k:LoadAsset_Blocking(k:Conv_SoftObjPathToSoftObjRef(k:MakeSoftObjectPath(path))) end
        end)
        o = StaticFindObject(path)
        if uvalid(o) then CX.missing[path] = nil; return o end
        if not okK then CX.say(("%s: the blocking soft-path load of %s raised: %s"):format(tostring(who), path, tostring(errK))) end
    end
    if not m.logged and now - m.t0 >= CX.LOAD_GIVEUP_S then
        m.logged = true
        CX.say(("%s: %s is not loaded (loadpkg, LoadAsset and the blocking load found nothing: the mod is not installed, not mounted, or the class is missing from its pak) - skipped until it loads; loadpkg retried every %d s"):format(tostring(who), path, CX.PKG_RETRY_S))
    end
    return nil
end
function CX.anyOf(paths, who)                       -- the resolved classes of a class key / path list
    local out = {}
    for _, p in ipairs(paths or {}) do local o = CX.obj(p, who); if o then out[#out + 1] = o end end
    return out
end
function CX.keyPaths(key, extra)                    -- a class key: the manifest's own paths + every manifest's (fallback (b))
    local out, seen = {}, {}
    for _, src in ipairs({ extra or {}, CX.classKeys[key] or {} }) do
        for _, p in ipairs(src) do if not seen[p] then seen[p] = true; out[#out + 1] = p end end
    end
    return out
end
function CX.has(u, classes)
    for _, c in ipairs(classes) do if CX.count(u, c) > 0 then return true end end
    return false
end
function CX.readTurn(w)
    local round, team, tname = nil, nil, nil
    -- 2026-10-14 retail (Jedi sandbox, SK_Mapuzo_010): w.GameState is NOT the tactical state. ATacticalGameState derives
    -- from ABitReactorGameStateExtension, a separate AActor (TacticalGameState.h:35, BitReactorGameStateExtension.h:9), so
    -- w.GameState.CurrentRound / .CurrentTeamTurn do not exist there and UE4SS hands back an invalid userdata. The game's
    -- own static getter finds the tactical state; its UFUNCTION getters give the round and the team class.
    pcall(function()
        local s = CX.cdo("TGS")
        local tgs = s and s:GetTacticalGameState(w, true) or nil
        if not uvalid(tgs) then tgs = FindFirstOf("TacticalGameState") end
        if uvalid(tgs) then round = tgs:GetRoundNumber(); team = tgs:GetTeamTurn() end
    end)
    -- 2026-10-14 retail crash (SWZeroCompany+9377d23, GetLivingUnitsByTeam AV reading -1): the first real mission read
    -- round = a TrivialObject (not the int32) and a team whose GetFullName failed ("none"); that team went straight into
    -- the native and faulted, which pcall cannot catch. Only a numeric round and a valid, named team class pass now;
    -- anything else is "no turn" (the pulse waits) with one line naming what was read.
    if uvalid(team) then tname = CX.name(team) end
    local rn = (type(round) == "number") and round or nil
    local how = "tactical state"
    -- 1.8.41: retail 2026-10-20 10:14:38-10:15:03 (Sith B11 on 1.8.40, a sandbox SAVE LOAD into SK_Mapuzo_010): the round read
    -- as a number but the team as None for the WHOLE player turn of round 1 (the sandbox ended it ~10:14:5x); the first
    -- named team was EnemyTeam_C at 10:15:03, so round 1's player turn never pulsed. The static UBitReactorGameStatics::
    -- GetTeamTurn(WorldContext) is the second read; the same guard applies (only a valid, NAMED class passes).
    if rn ~= nil and tname == nil then
        pcall(function()
            local g = CX.cdo("GSTAT")
            local t2 = g and g:GetTeamTurn(w) or nil
            if uvalid(t2) then local n2 = CX.name(t2); if n2 then team, tname, how = t2, n2, "static GetTeamTurn" end end
        end)
    end
    if rn == nil or tname == nil then
        if round ~= nil or team ~= nil then
            -- 1.8.41: once per MISSION (was once per session), with the round value, and the clock of the first bad read
            CX.badSince = CX.badSince or CX.clock()
            CX.monce("badturn", ("auras: the tactical turn read malformed (round %s, team %s) - no pulse; GetLivingUnitsByTeam is never called with them [round value %s; the static GetTeamTurn read nothing either; a team turn that passes while this lasts is NOT pulsed]")
                :format(type(round), team == nil and "nil" or (tname and "named" or "unnamed/invalid"), tostring(round)))
        end
        return nil
    end
    return rn, team, tname, how
end

-- ---- fxSettings: the player's choice, read at every mission arm; the CDO writes ----
function CX.fxArm()
    for _, s in ipairs(CX.fxSettings) do
        local raw = CX.iniGet(CX.read(s.ini) or "", s.section or "FX", s.key)
        local pick = nil
        for _, c in ipairs(s.choices or {}) do
            if raw and c.id:lower() == raw:lower() then pick = c end
        end
        if raw and not pick then CX.once("fxbad|" .. s.mod .. "|" .. s.key .. "|" .. raw, ("%s [%s] %s=%s is not one of its choices - %s is used")
            :format(s.mod, s.section or "FX", s.key, raw, s.default)) end
        if not pick then for _, c in ipairs(s.choices or {}) do if c.id == s.default then pick = c end end end
        s.value = pick and pick.id or s.default
        s.pending = {}
        for i, wr in ipairs(s.cdoWrites or {}) do s.pending[i] = true end
        CX.say(("%s %s = %s%s"):format(s.mod, s.key, tostring(s.value), raw and "" or " (default; no settings.ini value)"))
    end
end
function CX.choicePath(s, list)
    for _, c in ipairs(list or {}) do if c.id == s.value then return c.path end end
    return nil
end
-- the FProperty class name ("ObjectProperty", "SoftObjectProperty", ...) of property `name` on obj's class chain, or nil.
-- Reflection only (ForEachProperty / GetFName on the FProperty, IsValid before GetClass); the property VALUE is never read.
CX.PROP_KINDS = { ObjectProperty = true, ObjectPtrProperty = true }   -- 1.8.54: the cdoWrites property kinds that are written
function CX.propKind(obj, name)
    local kind = nil
    pcall(function()
        local c = obj:GetClass()
        local n = 0
        while uvalid(c) and kind == nil and n < 32 do
            n = n + 1
            c:ForEachProperty(function(prop)
                if kind ~= nil or not uvalid(prop) then return end
                local pn = ""; pcall(function() pn = prop:GetFName():ToString() end)
                if pn == name then
                    local k = ""; pcall(function() local pc = prop:GetClass(); if uvalid(pc) then k = pc:GetFName():ToString() end end)
                    kind = k
                end
            end)
            if kind == nil then local ok, sup = pcall(function() return c:GetSuperStruct() end); c = ok and sup or nil end
        end
    end)
    return kind
end
function CX.fxPending(w)
    if not CX.fxOn then return end
    for _, s in ipairs(CX.fxSettings) do
        for i, wr in ipairs(s.cdoWrites or {}) do
            if s.pending and s.pending[i] then
                local cdo, ns = StaticFindObject(wr.cdo), CX.obj(CX.choicePath(s, wr.choices), s.mod .. ":" .. s.key)
                local kind = (uvalid(cdo) and ns) and CX.propKind(cdo, wr.property) or nil
                if uvalid(cdo) and ns and not CX.PROP_KINDS[kind or ""] then
                    -- 1.8.54 (security review M-2): only an object-reference property is written (a soft pointer or a
                    -- type-mismatched write is a native fault); the property's class is read before the write
                    s.pending[i] = nil
                    CX.say(("%s %s: the CDO write %s.%s REFUSED (property kind %s; only an object reference is written) - the FX keeps its cooked system")
                        :format(s.mod, s.key, CX.short(wr.class), wr.property, tostring(kind or "not found")))
                elseif uvalid(cdo) and ns then
                    s.pending[i] = nil
                    local ok, err = pcall(function() cdo[wr.property] = ns end)
                    if ok then CX.say(("%s %s=%s: wrote %s.%s on the CDO (spawns from now on use it)"):format(s.mod, s.key, s.value, CX.short(wr.class), wr.property))
                    else CX.say(("%s %s: the CDO write %s.%s FAILED (%s) - the FX keeps its cooked system"):format(s.mod, s.key, CX.short(wr.class), wr.property, tostring(err))) end
                elseif not uvalid(cdo) then
                    CX.obj(wr.class, s.mod .. ":" .. s.key)        -- loading the class brings its CDO
                end
            end
        end
    end
end

-- ---- #3 effectAnims: the hold ----
function CX.mesh(u) local m = nil; pcall(function() m = u.Mesh end); return uvalid(m) and m or nil end
function CX.anim(u)
    local m = CX.mesh(u); if not m then return nil end
    local a = nil; pcall(function() a = m:GetAnimInstance() end)
    return uvalid(a) and a or nil
end
function CX.skelOk(u, ea)
    local full = nil
    pcall(function()
        local sk = CX.mesh(u):GetSkeletalMeshAsset().Skeleton
        if uvalid(sk) then full = CX.name(sk) end
    end)
    return type(full) == "string" and full:find(ea.skeleton, 1, true) ~= nil
end
function CX.play(u, clip, ea, loops)
    local a, c = CX.anim(u), CX.obj(clip, ea.id)
    if not (a and c) then return false end
    return (CX.call("holds", function()
        a:PlaySlotAnimationAsDynamicMontage(c, FName(ea.slot or "DefaultSlot"), ea.blendIn or 0.2, ea.blendOut or 0.25, 1.0, loops, -1.0, 0.0)
    end))
end
function CX.playing(u, clip, ea)
    local a, c = CX.anim(u), CX.obj(clip, ea.id)
    if not (a and c) then return false end
    local r = false; pcall(function() r = a:IsPlayingSlotAnimation(c, FName(ea.slot or "DefaultSlot")) end)
    return r == true
end
function CX.stop(u, ea)
    local a = CX.anim(u); if not a then return end
    CX.call("holds", function() a:StopSlotAnimation(ea.blendOut or 0.25, FName(ea.slot or "DefaultSlot")) end)
end
-- a LATER ability's cinematic on the board: the Choke's own cast is already presenting when the hold starts, so only a
-- presentation that begins after an idle poll blocks the re-issues (never fight a cinematic)
function CX.presenting()
    if CX.coordPath == nil then
        CX.coordPath = false
        local all = nil; pcall(function() all = FindAllOf("TacticalTurnCoordinator") end)
        for _, o in ipairs(type(all) == "table" and all or {}) do
            local p = uvalid(o) and CX.pathOf(o) or nil
            if p and not p:find("Default__", 1, true) then CX.coordPath = p; break end
        end
        if not CX.coordPath then CX.once("nocoord", "no TacticalTurnCoordinator in this world - a hold re-issues its loop even under a later cinematic") end
    end
    if not CX.coordPath then return false end
    local o = StaticFindObject(CX.coordPath)
    if not uvalid(o) then return false end
    local n = 0; pcall(function() n = o.CurrentlyPresentingAbilities:GetArrayNum() end)
    return (tonumber(n) or 0) > 0
end
function CX.holdStep(u, k, ea, h, pres, now)
    if not h then
        if CX.skelSkip[k .. "|" .. ea.id] then return end
        if not CX.skelOk(u, ea) then
            CX.skelSkip[k .. "|" .. ea.id] = true
            CX.say(("hold %s: %s is not on %s - it keeps the stock pose"):format(ea.id, CX.short(k), CX.short(ea.skeleton)))
            return
        end
        h = { id = ea.id, phase = CX.holdFirst and "loop0" or "delay", t0 = now, tTurn = now, turnSig = CX.turnSig, sawIdle = not pres, reissues = 0 }
        CX.holds[k] = h
        CX.say(("hold %s START on %s%s"):format(ea.id, CX.short(k), h.phase == "loop0" and " (already held at the mission arm: a load - the loop, no intro)" or ""))
    end
    if not pres then h.sawIdle = true elseif h.sawIdle then return end
    if h.phase == "capped" then return end
    if CX.turnSig ~= h.turnSig then h.turnSig, h.tTurn = CX.turnSig, now end
    if now - h.tTurn > (ea.maxSeconds or 120) then
        CX.stop(u, ea); h.phase = "capped"
        CX.say(("hold %s on %s: %d s with no turn change - stopped (the GE is still on; the stock pose shows)"):format(ea.id, CX.short(k), ea.maxSeconds or 120))
        return
    end
    if not CX.ok(u) then return end
    if h.phase == "delay" then
        if now - h.t0 >= (ea.startDelay or 0) then
            if ea.intro then if CX.play(u, ea.intro, ea, 1) then h.phase = "in" end
            elseif CX.play(u, ea.loop, ea, CX.LOOP_COUNT) then h.phase = "loop" end
        end
    elseif h.phase == "loop0" then
        if CX.play(u, ea.loop, ea, CX.LOOP_COUNT) then h.phase = "loop" end
    elseif h.phase == "in" then
        if not CX.playing(u, ea.intro, ea) and CX.play(u, ea.loop, ea, CX.LOOP_COUNT) then h.phase = "loop" end
    elseif h.phase == "loop" then
        if not CX.playing(u, ea.loop, ea) and CX.play(u, ea.loop, ea, CX.LOOP_COUNT) then
            h.reissues = h.reissues + 1
            if h.reissues <= 3 then CX.say(("hold %s on %s: the loop was stopped by something - re-issued (#%d)"):format(ea.id, CX.short(k), h.reissues)) end
        end
    end
end
function CX.holdEnd(u, k, ea, h)
    CX.holds[k] = nil
    if h.phase ~= "capped" and CX.ok(u) then
        if ea.outro then CX.play(u, ea.outro, ea, 1) else CX.stop(u, ea) end
    end
    CX.say(("hold %s END on %s (%s)"):format(ea.id, CX.short(k), (ea.outro and CX.ok(u)) and "outro" or "stopped"))
end
function CX.holdPass(w)
    local now = CX.clock()
    local list, by = CX.keyed(CX.units(w, "holds"))
    local r, team, tname = CX.readTurn(w)
    if r then CX.turnSig = tostring(r) .. "|" .. tostring(tname) end
    local pres = CX.presenting()
    local claimed = {}
    for _, ea in ipairs(CX.effectAnims) do
        local ge = CX.obj(ea.effect, ea.id)
        local mk = ea.marker and CX.obj(ea.marker, ea.id) or nil
        if ge and (mk or not ea.marker) then
            for _, it in ipairs(list) do
                local u, k = it.u, it.k
                local hasGe = CX.count(u, ge) > 0
                local hasMk = (mk == nil) or CX.count(u, mk) > 0
                local sk = ea.id .. "|" .. k
                if mk and ea.clearMarker ~= false and hasMk and not hasGe then
                    if not CX.stale[sk] then CX.stale[sk] = now
                    elseif now - CX.stale[sk] >= CX.STALE_GRACE_S then
                        CX.stale[sk] = nil
                        if CX.remove(u, mk, "holds") then CX.say(("hold %s: the stale marker %s removed from %s"):format(ea.id, CX.short(ea.marker), CX.short(k))) end
                    end
                else
                    CX.stale[sk] = nil
                end
                local h, held = CX.holds[k], hasGe and hasMk
                if held and claimed[k] and claimed[k] ~= ea.id then
                    CX.once("both|" .. k .. "|" .. ea.id, ("hold: %s matches %s and %s - the first wins"):format(CX.short(k), claimed[k], ea.id))
                elseif h and h.id ~= ea.id then
                    -- another entry owns this hold
                elseif held then
                    claimed[k] = ea.id
                    CX.holdStep(u, k, ea, h, pres, now)
                elseif h then
                    CX.holdEnd(u, k, ea, h)
                end
            end
        end
    end
    for k, h in pairs(CX.holds) do if not by[k] then CX.holds[k] = nil; CX.say(("hold %s on %s dropped (the unit left the living list)"):format(h.id, CX.short(k))) end end
    CX.holdFirst = false
end

-- ---- #2 castBeams: one bolt per victim per socket ----
function CX.sockPos(u, sock)
    local m = CX.mesh(u)
    if m and sock and sock ~= "" then
        local p = nil
        pcall(function()
            if m:DoesSocketExist(FName(sock)) then local v = m:GetSocketLocation(FName(sock)); p = { X = v.X, Y = v.Y, Z = v.Z } end
        end)
        if p then return p end
    end
    local l = CX.loc(u)
    if l then l.Z = l.Z + CX.SOCK_Z end
    return l
end
function CX.bind(nc, b, caster, sock, victim)
    for _, p in ipairs(b.params or {}) do
        local v = nil
        if p.kind == "pos" then
            if p.who == "caster" then v = CX.sockPos(caster, (p.sock ~= "" and p.sock) or sock) else v = CX.sockPos(victim, p.sock) end
        elseif p.kind == "loc" then
            v = CX.loc(p.who == "caster" and caster or victim)
        end
        if p.kind == "float" then
            pcall(function() nc:SetVariableFloat(FName(p.name), p.value) end)
        elseif v then
            pcall(function() nc:SetVariablePosition(FName(p.name), v) end)
        end
    end
end
function CX.systemFor(b)
    if type(b.system) == "string" then return CX.obj(b.system, b.id) end
    local s = b.fx
    if not s then CX.once("nofx|" .. b.id, b.id .. ": its setting is not declared by " .. tostring(b.mod) .. " - no beams"); return nil end
    return CX.obj(CX.choicePath(s, s.choices), b.id)
end
function CX.spawn(w, ns, b, cv, sock, vv)
    if #CX.live >= CX.MAX_LIVE then CX.once("livecap", "beams: " .. CX.MAX_LIVE .. " live beams - further spawns skipped until some end"); return end
    local nfl = CX.cdo("NFL"); if not nfl then return end
    local start = CX.sockPos(cv.u, sock)
    if not start then return end
    local ok, nc = CX.call("beams", function()
        return nfl:SpawnSystemAtLocation(w, ns, start, { Pitch = 0, Yaw = 0, Roll = 0 }, { X = 1, Y = 1, Z = 1 }, true, true, 0, false)
    end)
    if not (ok and uvalid(nc)) then return end
    CX.bind(nc, b, cv.u, sock, vv.u)
    local path = CX.pathOf(nc)
    if path then CX.live[#CX.live + 1] = { path = path, b = b, ck = cv.k, vk = vv.k, sock = sock, t0 = CX.clock() } end
end
function CX.track(by)
    local now, keep = CX.clock(), {}
    for _, l in ipairs(CX.live) do
        local nc = StaticFindObject(l.path)
        if uvalid(nc) then
            if not l.tEnd then
                if now - l.t0 >= (l.b.seconds or 1.2) then
                    pcall(function() nc:Deactivate() end); l.tEnd = now
                elseif l.b.track ~= false and by[l.ck] and by[l.vk] then
                    CX.bind(nc, l.b, by[l.ck], l.sock, by[l.vk])
                end
                keep[#keep + 1] = l
            elseif now - l.tEnd >= CX.BEAM_DESTROY_S then
                pcall(function() nc:K2_DestroyComponent(nc) end)
            else
                keep[#keep + 1] = l
            end
        end
    end
    CX.live = keep
end
function CX.beamPass(w)
    local now = CX.clock()
    local list, by = CX.keyed(CX.beamUnits(w))         -- 1.8.46: the cached FindAllOf fallback
    CX.track(by)
    for _, b in ipairs(CX.castBeams) do
        local mark = CX.obj(b.mark, b.id)
        if mark then
            local victims = {}
            for _, it in ipairs(list) do if CX.count(it.u, mark) > 0 then victims[#victims + 1] = it end end
            if #victims > 0 then
                local ns = CX.systemFor(b)
                local groups, order, orphans = {}, {}, {}
                for _, v in ipairs(victims) do
                    local sk = b.id .. "|" .. v.k
                    CX.markSeen[sk] = CX.markSeen[sk] or now
                    local caster = nil
                    for _, c in ipairs(list) do
                        if c.k ~= v.k and CX.hostile(c.u, v.u) and CX.fromActor(v.u, c.u, mark) then caster = c; break end
                    end
                    if caster then
                        if not groups[caster.k] then groups[caster.k] = { c = caster, vs = {} }; order[#order + 1] = caster.k end
                        table.insert(groups[caster.k].vs, v)
                    else
                        orphans[#orphans + 1] = v
                    end
                end
                for _, ck in ipairs(order) do
                    local g = groups[ck]
                    local d = {}
                    for _, v in ipairs(g.vs) do d[v.k] = CX.dist(g.c.u, v.u, false) end
                    table.sort(g.vs, function(x, y) return d[x.k] < d[y.k] end)
                    local spawned = 0
                    for i, v in ipairs(g.vs) do
                        local sk = b.id .. "|" .. v.k
                        if ns and i <= (b.maxVictims or 6) then
                            for _, sock in ipairs(b.sockets or { "hand_l" }) do CX.spawn(w, ns, b, g.c, sock, v); spawned = spawned + 1 end
                        end
                        if b.consumeMark ~= false and (ns or now - CX.markSeen[sk] >= CX.LOAD_GIVEUP_S) then
                            CX.remove(v.u, mark, "beams"); CX.markSeen[sk] = nil
                        end
                    end
                    if ns then CX.say(("beam %s: %s -> %d victim(s), %d bolt(s)%s"):format(b.id, CX.short(ck), math.min(#g.vs, b.maxVictims or 6), spawned,
                        #g.vs > (b.maxVictims or 6) and (" (nearest " .. (b.maxVictims or 6) .. " of " .. #g.vs .. ")") or "")) end
                end
                for _, v in ipairs(orphans) do
                    local sk = b.id .. "|" .. v.k
                    if now - CX.markSeen[sk] >= CX.LOAD_GIVEUP_S then
                        if b.consumeMark ~= false then CX.remove(v.u, mark, "beams") end
                        CX.markSeen[sk] = nil
                        CX.once("orphan|" .. b.id, ("beam %s: a marked unit with no living hostile instigator (the caster died?) - its marker is consumed without a bolt"):format(b.id))
                    end
                end
            end
        end
    end
end

-- ---- #4 auras: the per-turn pulse ----
function CX.classesOf(ref, who)                     -- { effect = path } | { classKey =, paths = } -> resolved classes
    if ref.effect then local o = CX.obj(ref.effect, who); return o and { o } or {} end
    if ref.classKey then return CX.anyOf(CX.keyPaths(ref.classKey, ref.paths), who) end
    return {}
end
function CX.meets(q, t, src, who)
    local cl = CX.classesOf(q, who)
    if #cl == 0 then return false end
    if q.effect and q.from == "source" then return CX.fromActor(t, src, cl[1]) end
    return CX.has(t, cl)
end
function CX.hasMarker(a, mk, t, src)
    if not mk then return false end
    if a.markerFrom == "any" then return CX.count(t, mk) > 0 end
    return CX.fromActor(t, src, mk)
end
function CX.apply(cls, src, t, level)
    local tasc = CX.asc(t)
    if not tasc then return false end
    if CX.route ~= "self" then
        local ok, err = pcall(function()
            local sf, sasc = CX.cdo("SF"), CX.asc(src)
            local spec = sf:MakeEffectSpecHandle(cls, src, src, level)
            sasc:BP_ApplyGameplayEffectSpecToTarget(spec, tasc)
        end)
        if ok then return true end
        if CX.conf.route == "spec" then CX.fail("auras", "spec apply: " .. tostring(err)); return false end
        CX.route = "self"
        CX.say("aura: the spec route raised (" .. tostring(err) .. ") - BP_ApplyGameplayEffectToSelf for the rest of the session (source attribution lost)")
    end
    return (CX.call("auras", function() tasc:BP_ApplyGameplayEffectToSelf(cls, level, tasc:MakeEffectContext()) end))
end
function CX.applyAll(a, src, t, grants, mk)
    for _, g in ipairs(grants) do CX.apply(g, src, t, a.level or 1) end
    local markIsGrant = false
    for _, g in ipairs(a.grant or {}) do if g == a.marker then markIsGrant = true end end
    if mk and not markIsGrant then CX.apply(mk, src, t, a.level or 1) end
    if mk and CX.route ~= "self" and CX.count(t, mk) <= 0 and CX.conf.route ~= "spec" then
        CX.route = "self"
        CX.say("aura " .. a.id .. ": the spec route returned but nothing landed - BP_ApplyGameplayEffectToSelf for the rest of the session")
        CX.applyAll(a, src, t, grants, mk)
    end
end
-- 1.8.40: THE SILENT PULSE (Sith sandbox 2026-10-20 b-091519, loader 1.8.38, roster-9, SK_Mapuzo_010, Pass B B11). The Lord
-- held both source markers (count 1 each), the pulse RAN at every team turn (the `turn:` lines; ZCSDKBridge.log shows its
-- loadpkg of ZCSith_Presence_Buff / _Marker_Pulse_RuleOfTwo / _Communion_Buff at 09:15:29, 09:17:28, 09:18:29, 09:19:24, sent
-- from the grant/marker lookups inside this function, and LoadPackage answered non-null each time), yet no ally got the buff
-- and the log had NO aura line: 1.8.38 printed only when a source had a target (`n > 0`), and every filter before that
-- dropped it without a word. 1.8.40 made every skip say why and added the GetTeam team fallback.
-- 1.8.41 (Sith B11 on 1.8.40, 10:14-10:16): the skip lines showed the units read as 0 from BOTH natives (CX.findUnits now),
-- and the round-2 PlayerTeam_C turn logged NOTHING: 1.8.40 keyed a skip per ROUND, and the WorldTeam_PrePlayer_C turn 0.7 s
-- earlier in that round had used every key. Keys are per TEAM TURN now (round + team), and every team turn ends with ONE
-- summary line (`aura pulse (round R, TEAM): ...`) whether anything was given or not.
function CX.dlog(m)                                 -- the per-mission diagnostic budget (DIAG_CAP), apart from CX.say's
    CX.diagN = CX.diagN + 1
    if CX.diagN <= CX.DIAG_CAP then log("[classfx] " .. m)
    elseif CX.diagN == CX.DIAG_CAP + 1 then log("[classfx] " .. CX.DIAG_CAP .. " aura diagnostic lines in this mission; further ones are not logged") end
end
function CX.monce(k, m)                             -- once per MISSION (CX.resetWorld clears it)
    k = "m|" .. k
    if CX.diagSeen[k] then return end
    CX.diagSeen[k] = true
    CX.dlog(m)
end
-- one line per aura per reason per TEAM TURN (`when` = "round R, TEAM"), or per mission (`when` = "mission")
function CX.skip(a, reason, when, msg)
    local key = a.id .. "|" .. reason .. "|" .. tostring(when)
    if CX.diagSeen[key] then return end
    CX.diagSeen[key] = true
    CX.dlog(("aura %s skip (%s): %s"):format(a.id, when == "mission" and "this mission" or tostring(when), msg))
end
function CX.pulse(w, team, first, round, tname)
    round, tname = round or "?", tname or "?"
    local turnShort = CX.short(tname)
    local when = ("round %s, %s"):format(tostring(round), turnShort)
    local units, shape = CX.unitsRaw(w, "auras")
    local nAll, via = #units, "GetAllRelevantLivingUnits"
    if nAll == 0 then
        local found, cls, nFound, nHere, nSkip = CX.findUnits(w)
        for _, u in ipairs(found) do units[#units + 1] = u end
        via = cls and ("FindAllOf(" .. cls .. ")") or "no source (FindAllOf found no pawn either)"
        CX.monce("unitsource", ("auras: GetAllRelevantLivingUnits came back as %s with no usable unit; the units come from %s (%d pawn(s), %d in this map's folder, %d skipped dead/hidden; counted again at every team turn)")
            :format(shape, via, nFound, nHere, nSkip))
    end
    local onTeam, nTeam, teamShape = nil, 0, "not read"
    for _, a in ipairs(CX.auras) do
        if a.when ~= "anyTeamTurnStart" and onTeam == nil then
            onTeam = {}
            local s = CX.cdo("UNIT")
            local ok, r = CX.call("auras", function() return s:GetLivingUnitsByTeam(w, team) end)
            teamShape = ok and CX.shape(r) or "a raise"
            for _, u in ipairs(ok and CX.list(r, "GetLivingUnitsByTeam") or {}) do
                local k = CX.name(u)
                if k and not onTeam[k] then onTeam[k] = true; nTeam = nTeam + 1; units[#units + 1] = u end
            end
        end
    end
    local list = CX.keyed(units)
    local teamRead = {}
    local function teamOf(s)
        if teamRead[s.k] == nil then teamRead[s.k] = CX.teamOf(s.u) or false end
        return teamRead[s.k] or nil
    end
    local stats = {}
    for _, a in ipairs(CX.auras) do
        local st = { id = CX.short(a.id), holders = 0, mine = 0, given = 0, landed = 0, why = nil }
        stats[#stats + 1] = st
        local srcCls = CX.classesOf(a.source or {}, a.id)
        local grants, missing = {}, {}
        for _, g in ipairs(a.grant or {}) do local o = CX.obj(g, a.id); if o then grants[#grants + 1] = o else missing[#missing + 1] = CX.short(g) end end
        local mk = a.marker and CX.obj(a.marker, a.id) or nil
        if a.marker and not mk then missing[#missing + 1] = CX.short(a.marker) .. " (marker)" end
        if #srcCls == 0 then
            st.why = "source class not resident"
            CX.skip(a, "source class", "mission", "the source effect's class is not resident, so no unit holds it - nothing pulses (once a unit"
                .. " holds it, the next team turn pulses)")
        elseif #missing > 0 then
            st.why = "classes not resident"
            CX.skip(a, "classes", when, ("%s not resident (loadpkg / LoadAsset tried; the next team turn retries) - nothing given")
                :format(table.concat(missing, ", ")))
        else
            for _, s in ipairs(list) do
                if CX.has(s.u, srcCls) then
                    st.holders = st.holders + 1
                    local mine = (a.when == "anyTeamTurnStart") or onTeam[s.k] == true
                    if not mine then
                        local tm = teamOf(s)
                        if tm and tm == tname then
                            mine = true
                            CX.skip(a, "teamlist|" .. s.k, when, ("%s holds the source and GetTeam reads %s, but GetLivingUnitsByTeam listed %d unit(s) without it - counted as on the turn team")
                                :format(CX.short(s.k), turnShort, nTeam))
                        else
                            CX.skip(a, "otherteam|" .. s.k .. "|" .. tname, "mission", ("%s holds the source; not on the %s turn (GetTeam reads %s, GetLivingUnitsByTeam listed %d unit(s) without it)")
                                :format(CX.short(s.k), turnShort, tm and CX.short(tm) or "nothing", nTeam))
                        end
                    end
                    local fit, why = false, ""
                    if mine then st.mine = st.mine + 1; fit, why = CX.ok(s.u) end
                    if mine and not fit then
                        st.why = "source unfit"
                        CX.skip(a, "unfit|" .. s.k, when, ("%s holds the source but reads unfit (%s) - it gives nothing this turn"):format(CX.short(s.k), tostring(why)))
                    elseif mine then
                        local cands, side, far, unfit = {}, 0, {}, 0
                        for _, t in ipairs(list) do
                            if t.k ~= s.k then
                                local hos = CX.hostile(s.u, t.u)
                                local fits = (a.affects == "all") or (a.affects == "enemies" and hos) or ((a.affects or "allies") == "allies" and not hos)
                                if fits then
                                    side = side + 1
                                    local d = CX.dist(s.u, t.u, a.measure == "2d")
                                    if d > (a.radius or 0) then far[#far + 1] = { k = t.k, d = d }
                                    elseif not CX.ok(t.u) then unfit = unfit + 1
                                    else cands[#cands + 1] = { t = t, d = d } end
                                end
                            end
                        end
                        table.sort(cands, function(x, y) return x.d < y.d end)
                        local n, gave, landed, failedReq, excluded = 0, 0, 0, 0, 0
                        for _, c in ipairs(cands) do
                            if n >= (a.maxTargets or 12) then break end
                            local good = true
                            for _, q in ipairs(a.require or {}) do if not CX.meets(q, c.t.u, s.u, a.id) then good = false; failedReq = failedReq + 1; break end end
                            if good then for _, q in ipairs(a.exclude or {}) do if CX.meets(q, c.t.u, s.u, a.id) then good = false; excluded = excluded + 1; break end end end
                            if good then
                                n = n + 1
                                if not CX.hasMarker(a, mk, c.t.u, s.u) then
                                    CX.applyAll(a, s.u, c.t.u, grants, mk); gave = gave + 1
                                    if not mk or CX.count(c.t.u, mk) > 0 then landed = landed + 1 end
                                end
                            end
                        end
                        st.given, st.landed = st.given + gave, st.landed + landed
                        local inc = (a.includeSource == true) or (a.includeSource == "ifAnyTarget" and n > 0)
                        local selfGave = false
                        if inc and not CX.hasMarker(a, mk, s.u, s.u) then CX.applyAll(a, s.u, s.u, grants, mk); selfGave = true end
                        if n > 0 or selfGave then
                            CX.say(("aura %s: %s -> %d in range, %d given%s%s%s"):format(a.id, CX.short(s.k), n, gave, selfGave and " + the source" or "",
                                first and " (first turn seen in this world)" or "",
                                gave > 0 and (", the marker landed on " .. landed .. " of " .. gave) or ""))
                            if gave > landed then
                                CX.skip(a, "notlanded|" .. s.k, when, ("%s: the marker did not land on %d of %d target(s) after the apply (route %s) - the effect was refused or removed at once")
                                    :format(CX.short(s.k), gave - landed, gave, tostring(CX.route or "spec")))
                            end
                        else
                            st.why = st.why or "no target"
                            table.sort(far, function(x, y) return x.d < y.d end)
                            local near = {}
                            for i = 1, math.min(4, #far) do near[#near + 1] = ("%s %.0f cm"):format(CX.short(far[i].k), far[i].d) end
                            CX.skip(a, "notargets|" .. s.k, when, ("%s gives nothing: %d unit(s) on its %s side, %d beyond %s cm %s%s, %d in range but unfit, %d failed a require, %d excluded")
                                :format(CX.short(s.k), side, a.affects or "allies", #far, tostring(a.radius or 0), a.measure == "2d" and "2D" or "3D",
                                    #near > 0 and (" (nearest: " .. table.concat(near, ", ") .. ")") or "", unfit, failedReq, excluded))
                        end
                    end
                end
            end
            if st.holders == 0 then
                st.why = "no holder"
                CX.skip(a, "noholder", when, ("no unit holds the source (%d unit(s) checked: %s read %d, the %s turn's GetLivingUnitsByTeam %d)")
                    :format(#list, via, via == "GetAllRelevantLivingUnits" and nAll or (#units - nTeam), turnShort, nTeam))
            elseif st.mine == 0 then
                st.why = st.why or "no holder on this team"
            end
        end
    end
    -- 1.8.41: ONE summary per team turn, always - a turn that pulses nothing still says so
    local parts = {}
    for _, st in ipairs(stats) do
        parts[#parts + 1] = ("%s %d holder(s), %d on this team, %d given, %d landed%s"):format(st.id, st.holders, st.mine, st.given, st.landed,
            (st.given == 0 and st.why) and (" [" .. st.why .. "]") or "")
    end
    CX.dlog(("aura pulse (%s): %d unit(s) via %s (GetAllRelevantLivingUnits: %s; GetLivingUnitsByTeam: %s, %d listed); %s")
        :format(when, #list, via, shape, teamShape, nTeam, table.concat(parts, "; ")))
end
function CX.turnPass(w)
    local r, team, tname, how = CX.readTurn(w)
    if r == nil or team == nil then
        CX.badSince = CX.badSince or CX.clock()
        CX.monce("noturn", "auras: the GameState turn fields read empty in this world - no pulse until they do (re-read every 1 s)")
        return 1
    end
    local sig = tostring(r) .. "|" .. tostring(tname)
    CX.turnSig = sig
    if sig == CX.lastTurn then return end
    local first = (CX.lastTurn == nil)
    CX.lastTurn = sig
    local late = ""
    if CX.badSince then late = (" (the turn read was unreadable for %.0f s before this)"):format(CX.clock() - CX.badSince); CX.badSince = nil end
    CX.say(("turn: round %s, %s%s%s%s"):format(tostring(r), CX.short(tname), first and " (first seen in this world)" or "",
        how ~= "tactical state" and (" [team from the " .. tostring(how) .. "]") or "", late))
    CX.pulse(w, team, first, r, tname)
end

-- ---- the tasks: setup once (after discover), then the base + one per feature; all on the pump ----
function CX.featTask(feat, fn, period)
    return function()
        if CX.feat[feat] ~= "on" then return true end
        local w = CX.world()
        if not w then return CX.BASE_S end
        local ok, r = pcall(fn, w)
        if not ok then CX.fail(feat, r); return period * 4 end
        return type(r) == "number" and r or period
    end
end
CX.tasks = {
    base = addTask("classfx", CX.BASE_S, function()
        if not CX.started then
            if not injected then return CX.IDLE_S end           -- discover() has not run yet
            CX.started = true
            local go = false
            local ok, err = pcall(function() go = CX.setup() end)
            if not ok then log("[classfx] setup error (CLASSFX off for the session): " .. tostring(err)); return true end
            if not go then return true end                      -- nothing declared (silent), or switched off (one line)
            for f, t in pairs(CX.tasks) do if f ~= "base" and CX.feat[f] == "on" then wake(t, 1.0) end end
        end
        local ok, r = pcall(CX.baseTask)
        if not ok then log("[classfx] base error (the task keeps running): " .. tostring(r)); return 5 end
        return r
    end, 3.0),
    holds = addTask("cx-hold", CX.HOLD_S, CX.featTask("holds", CX.holdPass, CX.HOLD_S), math.huge),
    beams = addTask("cx-beam", CX.BEAM_S, CX.featTask("beams", CX.beamPass, CX.BEAM_S), math.huge),
    auras = addTask("cx-aura", CX.TURN_S, CX.featTask("auras", CX.turnPass, CX.TURN_S), math.huge),
}
end
-- ---- 2026-10-11: CLASSFX (end) ----

-- ---- 2026-10-28: AIMIMICS (begin; tools/replay_aimimics.py extracts this block verbatim) ----
-- THE GAME'S AI PLANS A MOD ABILITY (the mod-def key `aiMimics[]`, tools/zcmod-aimimics.js; docs/recon/AI_MIMICS_RECON.md). The
-- tactical AI (the enemy, and the squad under the sandbox's `ai on`) only plans an ability a GameplayAbilityMimic class names. A mod
-- ships its own mimic classes (cooked copies of stock GAM_* mimics re-pointed at its GAs) and lists them in its manifest:
--   aiMimicsContract = 1, aiMimics = { { mimic = "<class path>", ability = "<GA class path>", kind = "self" }, ... }
-- The build preloads every mimic package (resident from the hub on). This section, in a MISSION world (/Maps/Skirmish/, up
-- AM.SETTLE s), finds the live AIPlanner actors (ONE FindAllOf per frame, a pass every AM.PASS_S, sliced over frames since 1.8.51:
-- see AM.pass) and APPENDS each mimic class that is
-- not yet there to the planner's DefaultAbilityMimics - and to MimicTypes / MimicTypesConcat when the planner has already built
-- them (a non-empty list) - then logs the three sizes and the first stock entries: the proof-row read (which list the retail
-- planner fills is not knowable offline). Lua reads only CLASS arrays (hard references): never MimickedGameplayAbility (a soft
-- class pointer; the UE4SS soft-pointer crash rule). Nothing UObject is kept across passes.
-- THE SWITCHES: ue4ss/Mods/ZCSDKLoader/settings.ini [AIMIMICS] Enabled = on|off (off: the classes are still preloaded, nothing is
-- appended), Lists = all|default|none (all = the default: DefaultAbilityMimics + the built caches; default = DefaultAbilityMimics
-- only; none = append nothing, log the sizes only - the A/B for "does preload alone register them"), Pawns = off|on (on: also
-- append to every live unit's CustomMimics - BitReactorGameCharacter, one more FindAllOf per pass; the third route to try).
-- The section STANDS DOWN after AM.ERR_CAP errors (an append that raises or does not land), one line each.
-- (one `do` block: the main chunk sits near Lua's 200-local limit, so AM adds no chunk-level local)
do
local AM = {
    INI = "Mods/ZCSDKLoader/settings.ini", MARK = "/Maps/Skirmish/", SETTLE = 8, CONTRACT = 1,
    IDLE_S = 2.0, PASS_S = 10.0, FIRST_S = 1.0, ERR_CAP = 6, LINE_CAP = 300, LOAD_GIVEUP_S = 20, SHOW = 12,
    FRAME = 0, LOOKUPS = 2, APPEND_CAP = 12,   -- 1.8.51: a sliced pass (see AM.pass): next frame, StaticFindObject / appends per frame
    LISTS = { "DefaultAbilityMimics", "MimicTypes", "MimicTypesConcat" },
    rows = {}, conf = nil, state = "idle", errs = 0, lines = 0, logged = {}, wkey = nil, seenAt = nil,
    seen = {}, loadAt = {}, gaveUp = {}, passes = 0, res = {}, nres = 0, looks = 0, ep = nil,
}
function AM.say(m)
    AM.lines = AM.lines + 1
    if AM.lines <= AM.LINE_CAP then log("[aimimics] " .. m)
    elseif AM.lines == AM.LINE_CAP + 1 then log("[aimimics] " .. AM.LINE_CAP .. " lines this session; further aimimics lines are not logged") end
end
function AM.once(k, m) if AM.logged[k] then return end; AM.logged[k] = true; AM.say(m) end
function AM.fail(why)
    AM.errs = AM.errs + 1
    if AM.errs <= 3 then AM.say("error: " .. tostring(why)) end
    if AM.errs >= AM.ERR_CAP and AM.state ~= "off" then
        AM.state = "off"
        AM.say("STOOD DOWN for the session after " .. AM.errs .. " errors (nothing more is appended; the preloaded classes stay)")
    end
end
function AM.iniGet(text, section, key)
    local sec, found = "", nil
    for raw in ((text or "") .. "\n"):gmatch("([^\r\n]*)\r?\n") do
        local line = raw:gsub("^\239\187\191", ""):gsub("%s*[;#].*$", ""):match("^%s*(.-)%s*$") or ""
        local s = line:match("^%[%s*(.-)%s*%]$")
        if s then sec = s:lower()
        elseif sec == section:lower() then
            local k, v = line:match("^([^=]-)%s*=%s*(.*)$")
            if k and k:lower() == key:lower() then found = v end
        end
    end
    return found
end
function AM.onoff(v, dflt)
    v = (v or ""):lower()
    if v == "off" or v == "0" or v == "false" or v == "no" then return false end
    if v == "on" or v == "1" or v == "true" or v == "yes" then return true end
    return dflt
end
function AM.full(o)
    local n = nil; pcall(function() n = o:GetFullName() end)
    return (type(n) == "string" and n ~= "") and n or nil
end
function AM.pathOf(o) local n = AM.full(o); return n and (n:match("^%S+%s+(.+)$") or n) or nil end
function AM.short(p) return (tostring(p):match("([^%./:%s]+)$")) or tostring(p) end

-- ---- the manifests (read once, after discover) + the switches ----
function AM.setup()
    local seen = {}
    for _, mf in ipairs(manifests) do
        local m, mod = mf.m, tostring(mf.m.name)
        if type(m.aiMimics) == "table" and #m.aiMimics > 0 then
            local ver = tonumber(m.aiMimicsContract)
            if not ver or ver > AM.CONTRACT then
                AM.say(("%s declares aiMimicsContract = %s; this loader understands %d - its AI mimics are not registered (update the ZCSDK Runtime)")
                    :format(mod, tostring(m.aiMimicsContract), AM.CONTRACT))
            else
                local n = 0
                for _, r in ipairs(m.aiMimics) do
                    if type(r) == "table" and type(r.mimic) == "string" and not seen[r.mimic] then
                        seen[r.mimic] = true; n = n + 1
                        AM.rows[#AM.rows + 1] = { mimic = r.mimic, ability = tostring(r.ability or "?"), kind = tostring(r.kind or "?"), mod = mod }
                    end
                end
                AM.say(("%s declares %d AI mimic(s)"):format(mod, n))
            end
        end
    end
    if #AM.rows == 0 then return false end
    local ini = ""
    pcall(function() local f = io.open(UE4SS .. AM.INI, "rb"); if f then ini = f:read(262144) or ""; f:close() end end)
    local lists = (AM.iniGet(ini, "AIMIMICS", "Lists") or "all"):lower()
    if lists ~= "default" and lists ~= "none" then lists = "all" end
    AM.conf = { on = AM.onoff(AM.iniGet(ini, "AIMIMICS", "Enabled"), true), lists = lists,
                pawns = AM.onoff(AM.iniGet(ini, "AIMIMICS", "Pawns"), false) }
    if not AM.conf.on then
        AM.say("OFF for the session (settings.ini [AIMIMICS] Enabled=off): the " .. #AM.rows .. " mimic class(es) are preloaded, none is appended to a planner")
        return false
    end
    AM.say(("armed for mission worlds (%s up %d s): %d mimic(s), lists %s, pawns %s, a pass every %d s")
        :format(AM.MARK, AM.SETTLE, #AM.rows, AM.conf.lists, AM.conf.pawns and "on" or "off", AM.PASS_S))
    AM.state = "on"
    return true
end

-- ---- a mimic class: resident (preloaded) or loaded once; nil while it is not ----
function AM.class(row)
    AM.looks = AM.looks + 1                                  -- 1.8.51: each StaticFindObject is a whole-array walk; AM.resolveSlice budgets them
    local o = StaticFindObject(row.mimic)
    -- 1.8.52: a found class clears its load clock, so a class COLLECTED later (nothing referenced it yet) is re-loaded with a fresh
    -- loadpkg and a fresh 20 s window - before, a clock left from the first load made the next miss give up at once
    if uvalid(o) then AM.loadAt[row.mimic] = nil; return o end
    if AM.gaveUp[row.mimic] then return nil end
    local now = os.clock()
    local t0 = AM.loadAt[row.mimic]
    if not t0 then
        AM.loadAt[row.mimic] = now
        local pkg = row.mimic:match("^(.-)%.[^%.]+$")
        if pkg then pcall(bridge, "ZCSDK:loadpkg|" .. pkg) end
        AM.looks = AM.looks + 1
        o = StaticFindObject(row.mimic)
        if uvalid(o) then AM.loadAt[row.mimic] = nil; return o end
        pcall(LoadAsset, row.mimic)
        return nil
    end
    if now - t0 >= AM.LOAD_GIVEUP_S then
        AM.gaveUp[row.mimic] = true
        AM.say(("%s (%s): the mimic class %s is not loaded %d s after loadpkg + LoadAsset - skipped in this session (the mod's pak is not mounted, or the class is missing from it)")
            :format(row.mod, AM.short(row.ability), row.mimic, AM.LOAD_GIVEUP_S))
    end
    return nil
end

-- ---- one class array: its entries' paths (reads only; a raise -> nil) ----
function AM.paths(arr)
    local out = {}
    local ok = pcall(function() arr:ForEach(function(i, e)
        local v = e; pcall(function() v = e:get() end)
        out[#out + 1] = (uvalid(v) and AM.pathOf(v)) or "<null>"
    end) end)
    return ok and out or nil
end
function AM.has(list, path) for _, p in ipairs(list) do if p == path then return true end end; return false end
function AM.num(arr) local n = nil; pcall(function() n = arr:GetArrayNum() end); return tonumber(n) end
-- append the classes of `classes` ({ row, cls }) missing from `obj[prop]`, AT MOST `cap` of them (`tried`: the classes an earlier
-- frame of this pass already tried - a failed one is not retried, its error counts once) -> had, the paths appended (each
-- checked by its Num), more (true: classes are still missing - the next frame goes on), the entries now (nil: unreadable).
-- 2026-10-29 (Sith B2 run, loader 1.8.49: "pump: task aimimics took 677 ms in one frame" on EVERY 10 s pass of the mission): the list
-- is READ ONCE (every entry's full name) and each append is checked by its Num; the read-back of the names is AM.verify (1.8.51: a
-- frame of its own). The 1.8.49 code re-read the whole list twice per class (21 classes x ~100 entries x 2 lists). An append that
-- raises or does not land is still an error per class (AM.fail), and a class missing from the read-back counts as not landed.
function AM.appendMany(obj, prop, classes, list, cap, tried)
    local arr = nil
    if not pcall(function() arr = obj[prop] end) or arr == nil then return nil end
    list = list or AM.paths(arr)
    if not list then return nil end
    local present = {}
    for _, p in ipairs(list) do present[p] = true end
    local had, pending, n = 0, {}, 0
    tried = tried or {}
    for _, c in ipairs(classes) do
        if present[c.row.mimic] then had = had + 1
        elseif tried[c.row.mimic] then -- failed in an earlier frame of this pass
        elseif n >= (cap or math.huge) then return had, pending, true, list
        else
            n = n + 1; tried[c.row.mimic] = true
            local n0 = AM.num(arr) or #list
            local ok, err = pcall(function() arr[n0 + 1] = c.cls end)
            if not ok then
                AM.fail(("append to %s.%s raised: %s"):format(AM.short(AM.pathOf(obj) or "?"), prop, tostring(err)))
            else
                local n1 = AM.num(arr)
                if n1 ~= n0 + 1 then
                    AM.fail(("append to %s.%s did not land (%d entries before, %s after)"):format(AM.short(AM.pathOf(obj) or "?"), prop, n0, n1 and tostring(n1) or "unreadable"))
                else
                    pending[#pending + 1] = c.row.mimic; list[#list + 1] = c.row.mimic
                end
            end
            if AM.state ~= "on" then return nil end
        end
    end
    return had, pending, false, list
end
-- the read-back after the appends: ONE read of the names -> added, the entries after (nil: unreadable)
function AM.verify(obj, prop, pending)
    local arr = nil
    if not pcall(function() arr = obj[prop] end) or arr == nil then return 0, nil end
    local after = AM.paths(arr)
    local added = 0
    for _, p in ipairs(pending) do
        if after and AM.has(after, p) then added = added + 1
        else AM.fail(("append to %s.%s did not land (%s is not in the list read back)"):format(AM.short(AM.pathOf(obj) or "?"), prop, AM.short(p))) end
    end
    return added, after
end

-- ---- 1.8.52: the classes for ONE append frame of one list ----
-- 2026-11-01 (Jedi aicast L1, loader 1.8.51: "DefaultAbilityMimics 17, MimicTypes 97 ... 30 of our entries appended this pass, 0
-- already there; 41 of 41 mimic class(es) resident", and no later pass line; Force Stasis never cast): the hub preload's mimic
-- classes had been COLLECTED before the mission (nothing references a mimic class until it sits in a planner list - the 1.8.37
-- classfx lesson), so RESOLVE re-loaded every one through AM.class's loadpkg, ONE row per frame (2 lookups each): 41 frames, which
-- took 41 s at that launch's frame rate (11:12:30-11:13:11; 20 s in L2 and Sith B6). A garbage collection between the 26th and 27th
-- loadpkg (11:12:59-11:13:00) freed the 26 classes loaded before it; WORK's uvalid filter dropped them WITHOUT a line, the 15 loaded
-- after it (SaberThrow_T5 + the 14 Sith rows) were appended to both lists (15 + 15 = 30), and AM.res still counted all 41 resident -
-- so every later pass ended at SCAN (Nums unchanged, nothing "unresolved") and the 26 were never appended. 1.8.50 had no window: it
-- looked up and appended in one frame. Now a class that is no longer valid when its list's turn comes, and is missing from that
-- list, is looked up again HERE (at most AM.LOOKUPS lookups per frame) and goes FIRST in this frame's appends, so it is in the list
-- (referenced, safe from the next collection) before the frame ends. A class that cannot be found again leaves AM.res (the next
-- pass resolves it again) and its list is not marked done (AM.complete).
-- -> the classes for appendMany (present ones included, for the "already there" count), true when a stale class still waits for
-- its lookup (this frame's budget is spent: the next frame goes on)
function AM.liveClasses(ep, list, tried)
    local present = {}
    for _, p in ipairs(list or {}) do present[p] = true end
    local first, rest, looks0, waiting = {}, {}, AM.looks, false
    for _, c in ipairs(ep.classes) do
        if c.lost then -- not found again in this pass
        elseif present[c.row.mimic] or (tried and tried[c.row.mimic]) or uvalid(c.cls) then rest[#rest + 1] = c
        elseif AM.looks - looks0 >= AM.LOOKUPS then waiting = true
        else
            local fresh = AM.class(c.row)
            if fresh then
                c.cls = fresh; first[#first + 1] = c; ep.relooked = ep.relooked + 1
            else
                c.lost = true; ep.lost = ep.lost + 1
                if AM.res[c.row.mimic] then AM.res[c.row.mimic] = nil; AM.nres = math.max(0, AM.nres - 1) end
            end
        end
    end
    for _, c in ipairs(rest) do first[#first + 1] = c end
    return first, waiting
end
-- 1.8.52: a list is DONE only when it holds every mimic that is not given up (a list we do not fill is always done) -> done, missing
function AM.complete(it)
    if not it.want or not it.list then return true, 0 end
    local set, missing = {}, 0
    for _, p in ipairs(it.list) do set[p] = true end
    for _, r in ipairs(AM.rows) do if not AM.gaveUp[r.mimic] and not set[r.mimic] then missing = missing + 1 end end
    return missing == 0, missing
end

-- ---- the pass: SLICED over frames (1.8.51) ----
-- 2026-10-31 (Jedi L1 + Sith B5, loader 1.8.50: "pump: task aimimics took 1757 ms in one frame" every ~12 s for the whole mission,
-- 4092-4290 ms on the first pass): 1.8.50 stopped re-reading unchanged lists, but every pass still began with AM.class for EVERY
-- row - a StaticFindObject each, and StaticFindObject is a walk of the whole object array in this UE4SS build (the 1.8.28 finding,
-- see "THE 2.9 s FRAME"): 41 mimic rows x ~30-40 ms = the 1.2-1.8 s frame, growing with the mission's object count. Now:
--   SCAN (one frame): ONE FindAllOf(AIPlanner) and each list's Num. A list whose Num is the count verified last time (with the same
--     number of resident mimic classes) needs nothing; when no list needs work, every row is resident (or given up) and Pawns is
--     off, the pass ENDS HERE - no StaticFindObject at all (the steady state of a mission).
--   RESOLVE (frames): the rows' classes, at most AM.LOOKUPS StaticFindObject per frame (the 1.8.28 lookup budget). The class
--     objects are kept only until this pass ends (each re-checked with uvalid before use); nothing UObject crosses passes.
--     1.8.52: a class COLLECTED between RESOLVE and its list's turn is looked up again in that frame and appended in it
--     (AM.liveClasses), and a list is marked steady only when it holds every mimic not given up (AM.complete).
--   WORK (frames): one planner list per frame (the planner from that frame's own FindAllOf): its read, then its appends (at most
--     AM.APPEND_CAP per frame), then its read-back - one step per frame. Then the per-planner summary line and (Pawns=on) the units.
-- The lists are written ONLY when their Num shows the game built or rebuilt them (or a class became resident): an unchanged list is
-- never touched mid-mission (the Jedi L1 / Sith B5 logs carry no planner line after the first pass).
function AM.scan()
    local okP, planners = pcall(FindAllOf, "AIPlanner")
    if not okP or type(planners) ~= "table" or #planners == 0 then
        AM.once("noplanner|" .. tostring(AM.wkey), "no AIPlanner in this mission world yet (re-checked every " .. AM.PASS_S .. " s)")
        return nil
    end
    local items, pl = {}, {}
    for _, p in ipairs(planners) do
        if uvalid(p) then
            local key = AM.full(p) or "?"
            local rec = { key = key, sizes = {}, added = 0, had = 0 }
            pl[#pl + 1] = rec
            for li, prop in ipairs(AM.LISTS) do
                local arr = nil
                pcall(function() arr = p[prop] end)
                local nk = "n|" .. key .. "|" .. prop
                local num = arr and AM.num(arr) or nil
                rec.sizes[prop] = num or -1
                if arr ~= nil and not (num ~= nil and AM.seen[nk] == (num .. "/" .. AM.nres)) then
                    items[#items + 1] = { rec = rec, prop = prop, li = li, nk = nk, stage = "read" }
                end
            end
        end
    end
    return items, pl
end
function AM.unresolved()
    for _, r in ipairs(AM.rows) do if not AM.res[r.mimic] and not AM.gaveUp[r.mimic] then return true end end
    return false
end
-- RESOLVE: one slice -> true when every row has been looked at in this pass
function AM.resolveSlice(ep)
    local looks0 = AM.looks
    while ep.ri <= #AM.rows and AM.looks - looks0 < AM.LOOKUPS do
        local r = AM.rows[ep.ri]
        local c = AM.class(r)
        if c then ep.classes[#ep.classes + 1] = { row = r, cls = c }; AM.res[r.mimic] = true end
        ep.ri = ep.ri + 1
    end
    return ep.ri > #AM.rows
end
-- WORK: one step of the current list -> true when every list of the pass is done
function AM.workStep(ep)
    local it = ep.items[ep.ii]
    if not it then return true end
    local p = nil
    local okP, planners = pcall(FindAllOf, "AIPlanner")
    if okP and type(planners) == "table" then
        for _, q in ipairs(planners) do if uvalid(q) and AM.full(q) == it.rec.key then p = q; break end end
    end
    local rec, prop = it.rec, it.prop
    if not p then ep.ii = ep.ii + 1; return ep.ii > #ep.items end      -- the planner went away: its list is left for the next pass
    if it.stage == "read" then
        local arr = nil
        pcall(function() arr = p[prop] end)
        it.errs0 = AM.errs
        it.list = arr and AM.paths(arr) or nil
        rec.sizes[prop] = it.list and #it.list or -1
        if it.list and not AM.seen[rec.key .. "|" .. prop] then
            AM.seen[rec.key .. "|" .. prop] = true
            local list, shown = it.list, {}
            for i = 1, math.min(#list, AM.SHOW) do shown[#shown + 1] = AM.short(list[i]) end
            AM.say(("planner %s: %s had %d entr%s%s"):format(AM.short(rec.key), prop, #list, #list == 1 and "y" or "ies",
                #list > 0 and (" (" .. table.concat(shown, ", ") .. (#list > AM.SHOW and ", ..." or "") .. ")") or ""))
        end
        local want = AM.conf.lists ~= "none" and it.list ~= nil and (it.li == 1 or (AM.conf.lists == "all" and #it.list > 0))
        it.want = want
        if want then it.stage, it.pending, it.tried, it.had = "append", {}, {}, nil; return false end
        it.stage = "done"
    elseif it.stage == "append" then
        -- 1.8.52: the classes resolved this pass; one collected since is looked up again now (AM.liveClasses; was: dropped silently)
        local classes, waiting = AM.liveClasses(ep, it.list, it.tried)
        local h, pend, more, now = AM.appendMany(p, prop, classes, it.list, AM.APPEND_CAP, it.tried)
        if AM.state ~= "on" then return true end
        if h == nil then it.stage = "done"
        else
            it.had = it.had or h
            for _, x in ipairs(pend) do it.pending[#it.pending + 1] = x end
            it.list = now
            if more or waiting then return false end
            rec.had = rec.had + it.had
            rec.sizes[prop] = #now
            if #it.pending > 0 then it.stage = "verify"; return false end
            it.stage = "done"
        end
    elseif it.stage == "verify" then
        local a, after = AM.verify(p, prop, it.pending)
        rec.added = rec.added + a
        if after then rec.sizes[prop] = #after; it.list = after end
        it.stage = "done"
    end
    if it.stage == "done" then
        -- verified: read (and appended to, when wanted) with no error -> the next pass skips it while its Num and the number of
        -- resident mimic classes stay the same (a class that loads later is still appended). 1.8.52: and only when the list holds
        -- EVERY mimic not given up (AM.complete) - a list left short is read again by the next pass, never marked steady
        local whole, missing = AM.complete(it)
        if it.list and AM.errs == it.errs0 and whole then AM.seen[it.nk] = tostring(rec.sizes[prop]) .. "/" .. AM.nres end
        if not whole then
            AM.once(("short|%s|%s|%d"):format(rec.key, prop, missing), ("planner %s: %s still lacks %d of our %d entr%s after this pass (a class not loaded yet, or collected before its append) - the next pass tries again")
                :format(AM.short(rec.key), prop, missing, #AM.rows, #AM.rows == 1 and "y" or "ies"))
        end
        ep.ii = ep.ii + 1
    end
    return ep.ii > #ep.items
end
function AM.summary(pl)
    for _, rec in ipairs(pl) do
        local s = rec.sizes
        local sig = ("%d/%d/%d"):format(s.DefaultAbilityMimics, s.MimicTypes, s.MimicTypesConcat)
        if rec.added > 0 or AM.seen[rec.key] ~= sig then
            AM.seen[rec.key] = sig
            AM.say(("planner %s: DefaultAbilityMimics %d, MimicTypes %d, MimicTypesConcat %d (-1 = unreadable); %d of our entr%s appended this pass, %d already there; %d of %d mimic class(es) resident; lists=%s")
                :format(AM.short(rec.key), s.DefaultAbilityMimics, s.MimicTypes, s.MimicTypesConcat, rec.added, rec.added == 1 and "y" or "ies",
                    rec.had, AM.nres, #AM.rows, AM.conf.lists))
        end
    end
end
function AM.pawns(ep)
    local classes = {}
    for _, c in ipairs(ep.classes) do if uvalid(c.cls) then classes[#classes + 1] = c end end
    if #classes == 0 then return end
    local okU, units = pcall(FindAllOf, "BitReactorGameCharacter")
    local n, a = 0, 0
    if okU and type(units) == "table" then
        for _, u in ipairs(units) do
            if uvalid(u) then
                n = n + 1
                local h, pend = AM.appendMany(u, "CustomMimics", classes)
                if AM.state ~= "on" then return end
                if h and #pend > 0 then a = a + (AM.verify(u, "CustomMimics", pend)) end
            end
        end
    end
    if a > 0 then AM.say(("pawns: %d CustomMimics entr%s appended over %d unit(s)"):format(a, a == 1 and "y" or "ies", n)) end
end
-- one frame of the pass -> the seconds until the task runs again (AM.FRAME = the next frame, AM.PASS_S = the pass is over)
function AM.pass(w)
    local ep = AM.ep
    if not ep then
        AM.passes = AM.passes + 1
        local items = AM.scan()
        if items == nil then return AM.PASS_S end
        if #items == 0 and not AM.unresolved() and not AM.conf.pawns then return AM.PASS_S end
        AM.ep = { stage = "resolve", ri = 1, classes = {}, relooked = 0, lost = 0 }
        return AM.FRAME
    end
    if ep.stage == "resolve" then
        if not AM.resolveSlice(ep) then return AM.FRAME end
        local n = 0
        for _ in pairs(AM.res) do n = n + 1 end
        AM.nres = n
        ep.stage = "scan"
        return AM.FRAME
    end
    if ep.stage == "scan" then
        local items, pl = AM.scan()
        if items == nil then AM.ep = nil; return AM.PASS_S end
        ep.items, ep.pl, ep.ii, ep.stage = items, pl, 1, "work"
        if #items > 0 then return AM.FRAME end
    end
    if ep.stage == "work" then
        if not AM.workStep(ep) then
            if AM.state ~= "on" then AM.ep = nil end
            return AM.FRAME
        end
        if AM.state ~= "on" then AM.ep = nil; return AM.PASS_S end
        if ep.relooked > 0 or ep.lost > 0 then
            AM.say(("%d mimic class(es) were collected between their lookup and their list's turn: %d looked up again and appended in that frame, %d not found again (the next pass retries)")
                :format(ep.relooked + ep.lost, ep.relooked, ep.lost))
        end
        AM.summary(ep.pl)
        if AM.conf.pawns then ep.stage = "pawns"; return AM.FRAME end
    end
    if ep.stage == "pawns" then AM.pawns(ep) end
    AM.ep = nil
    return AM.PASS_S
end

-- ---- the task (on the pump, game thread) ----
AM.task = addTask("aimimics", AM.IDLE_S, function()
    if AM.state == "idle" then
        if not injected then return AM.IDLE_S end            -- discover() has not run yet
        local ok, go = pcall(AM.setup)
        if not ok then log("[aimimics] setup error (AIMIMICS off for the session): " .. tostring(go)); AM.state = "off"; return true end
        if not go then AM.state = "off"; return true end   -- nothing declared (silent), or switched off (one line)
    end
    if AM.state ~= "on" then AM.ep = nil; return true end
    local wname = pinWorldName()
    if not wname:find(AM.MARK, 1, true) then
        if AM.wkey then AM.wkey, AM.seenAt, AM.seen, AM.ep = nil, nil, {}, nil end
        return AM.IDLE_S
    end
    local w = gameWorld()
    if not uvalid(w) then AM.ep = nil; return AM.IDLE_S end
    local a = "?"; pcall(function() a = string.format("%x", w:GetAddress()) end)
    local key = wname .. "#" .. a
    if AM.wkey ~= key then
        AM.wkey, AM.seenAt, AM.seen, AM.ep = key, os.clock(), {}, nil
        AM.say("mission world: " .. AM.short(wname) .. " - first pass in " .. AM.SETTLE .. " s")
        return AM.FIRST_S
    end
    if os.clock() - AM.seenAt < AM.SETTLE then return AM.FIRST_S end
    local ok, r = pcall(AM.pass, w)
    if not ok then AM.ep = nil; AM.fail("pass: " .. tostring(r)); return AM.PASS_S end
    if AM.state ~= "on" then AM.ep = nil end
    return r
end, 3.0)
end
-- ---- 2026-10-28: AIMIMICS (end) ----

-- ---- 2026-10-22: WHEEL (begin; tools/replay_wheel.py extracts this block verbatim) ----
-- THE TACTICAL ABILITY WHEEL'S CLASS-SLICE CAP (1.8.44; recon: Project Handoffs/ZeroCompanyModSDK-ACTION-WHEEL-RECON-2026-10-22.md).
--   WBP_RadialPanel holds four pre-placed WBP_RadialSlice instances (StandardActionSlice 3 buttons, ClassAbilitySlice 4,
--   UtilitySlice 6, CallForBackupSlice 1). Each slice creates `Button Count` WBP_RadialAbilityWedge ONCE, at Construct
--   (ubergraph entry 1055 = "Setup Wedges": only while `Button Interfaces` is empty), and "Add Wedges" drops every ability
--   past that pool ("[UIUX] Too many abilities in slice"). A Sith Lord + Assassin has 11 class actives: 7 were dropped, and
--   the span (11 x 23 deg) ran the class arc over the Standard arc. WHEEL raises the class slice to [Wheel] classButtons
--   (default 10, 4..12) and narrows the three arcs so they fit the stock 330-degree track (CFB keeps its 35 at 328).
-- WRITE POINTS (no RegisterHook, no NotifyOnNewObject: both would put Lua on a widget-construction path, and
-- NotifyOnNewObject also fires for archetypes built on the async loading thread - the 1.8.26 one-lua_State race):
--   (1) the class TEMPLATE `.../WBP_RadialPanel.WBP_RadialPanel_C:WidgetTree.<Slice>`: UUserWidget::Initialize duplicates
--       the class WidgetTree into every new panel, so a panel created after the write is born with N wedges. Re-checked every
--       pass (one StaticFindObject) because a class that is unloaded between missions comes back with cooked values.
--   (2) the LIVE panel of the running mission (the panel is usually built with the HUD, before any Lua could know the
--       counts): the same writes, then the BP's own rebuild - `Button Interfaces`:Empty() (no element is marshalled; the
--       elements are plain FScriptInterface pairs), Slices:ClearChildren(), then the slice's own "Setup Wedges" creates N
--       wedges and fills the interface array itself. Only while the wheel is CLOSED (VM bIsRadialOpen false).
--   `Segment Width` / `Base Angle` are read by every "Populate Abilities" (each open), so they need no rebuild.
-- NAMES. BP variables keep their spaces in the FName (kis: `Self.Button Count`; CookedPropertyGuids), so the reads are
--   obj["Button Count"], obj["Segment Width"], obj["Base Angle"], obj["Button Interfaces"], obj.Slices; the spaced name is
--   tried first, the squeezed one second, and the name that answered is logged once. Functions: obj["Setup Wedges"](obj),
--   wedge["Set Hotkey Data"](wedge, -1) (what "Setup Hotkeys" itself passes for "no key"), wedge:SetWedgeWidth(deg) (the BP
--   function that sets `Wedge Width` - the ContainsAngle hit half-width - and the MID scalar `Arc Width`; 0 < deg <= 360).
--   The VM is native: B_AbilitySelectionVM.StandardAbilities / TacticalAbilities / UtilityAbilities / bIsRadialOpen.
-- LABELS. "Setup Hotkeys" (every open) labels wedge i with i + HotkeyOffset (3), so class wedges 5-7 would read 8 / 9 / 0,
--   the Utility keys (the native GetSelectableAbilityVMForHotkey maps keys 4-7 to class 1-4 only). After each open WHEEL calls
--   Set Hotkey Data(-1) on class wedges 5+. Class abilities 5+ are mouse / stick only (keyboard: a documented follow-up).
-- WHEN. Only in a mission world (/Maps/Skirmish/) up WH.SETTLE s, and only when the class bucket holds more than the stock
--   4 (or [Wheel] always=1); once needed, the session stays needed (the template must win the next mission's panel). Lookups
--   are counted: FindAllOf at most WH.WALKS times a mission, everything else re-found by path with StaticFindObject; no UObject
--   is kept across frames. No soft pointer is read; no process is spawned.
-- SWITCHES: ue4ss/Mods/ZCSDKLoader/settings.ini [Wheel] Enabled = on|off, classButtons = 10 (4..12), always = 0|1,
--   segmentWidth = 0 (auto) | degrees, gap = 2 (minimum degrees between slices), arcWidth = auto | off | degrees,
--   labels = on|off.
-- (one `do` block, state on CP.WH: the main chunk sits near Lua's 200-local limit)
do
local WH = {
    INI = "Mods/ZCSDKLoader/settings.ini", MARK = "/Maps/Skirmish/", SETTLE = 8,
    BASE_S = 0.5, FAST_S = 0.1, IDLE_S = 2.0, OPEN_PASSES = 2, WALKS = 3, WALK_GAP_S = 5, LINE_CAP = 200,
    TEMPLATE = "/Game/Game/UI/Tactical/RadialAbilityMenu/WBP_RadialPanel.WBP_RadialPanel_C:WidgetTree.",
    PANEL_CLASS = "WBP_RadialPanel_C", VM_CLASS = "B_AbilitySelectionVM",
    SLICE = { std = "StandardActionSlice", cls = "ClassAbilitySlice", util = "UtilitySlice" },
    ORDER = { "std", "cls", "util" },
    -- the stock wheel (READ, WBP_RadialPanel widget-tree instance values): buttons, width, the Standard slice's start, and
    -- the track from it (312) down to the Utility slice's stock end (120 - 6 x 23 = -18): 330 degrees
    STOCK = { std = 3, cls = 4, util = 6, W = 23, STD_BASE = 312, TRACK = 330, CLS_CENTRE = 180, UTIL_BASE = 120 },
    N_MIN = 4, N_MAX = 12, W_MIN = 6,
    P = { count = { "Button Count", "ButtonCount" }, width = { "Segment Width", "SegmentWidth" },
          base = { "Base Angle", "BaseAngle" }, iface = { "Button Interfaces", "ButtonInterfaces" }, slices = { "Slices" } },
    BUCKET = { std = "StandardAbilities", cls = "TacticalAbilities", util = "UtilityAbilities" },
    clock = os.clock,
    conf = nil, started = false, sticky = false, lines = 0, logged = {}, mlogged = {}, names = {},
    wkey = nil, seenAt = nil, m = nil,
}
CP.WH = WH
function WH.say(msg)
    WH.lines = WH.lines + 1
    if WH.lines <= WH.LINE_CAP then log("[wheel] " .. msg)
    elseif WH.lines == WH.LINE_CAP + 1 then log("[wheel] " .. WH.LINE_CAP .. " lines this session; further wheel lines are not logged") end
end
function WH.once(k, msg) if WH.logged[k] then return end; WH.logged[k] = true; WH.say(msg) end      -- once a session
function WH.monce(k, msg) if WH.mlogged[k] then return end; WH.mlogged[k] = true; WH.say(msg) end    -- once a mission
function WH.read(p)
    local f = io.open(p, "rb"); if not f then return nil end
    local s = f:read(262144); f:close(); return s or ""
end
function WH.iniGet(text, section, key)
    local sec, found = "", nil
    for raw in ((text or "") .. "\n"):gmatch("([^\r\n]*)\r?\n") do
        local line = raw:gsub("^\239\187\191", ""):gsub("%s*[;#].*$", ""):match("^%s*(.-)%s*$") or ""
        local s = line:match("^%[%s*(.-)%s*%]$")
        if s then sec = s:lower()
        elseif sec == section:lower() then
            local k, v = line:match("^([^=]-)%s*=%s*(.*)$")
            if k and k:lower() == key:lower() then found = v end
        end
    end
    return found
end
function WH.onoff(v, dflt)
    v = (v or ""):lower()
    if v == "off" or v == "0" or v == "false" or v == "no" then return false end
    if v == "on" or v == "1" or v == "true" or v == "yes" then return true end
    return dflt
end
-- PURE: the settings text -> the config + the notes (clamps, refusals) to log
function WH.parse(text)
    local c, notes = {}, {}
    local function num(key, dflt, lo, hi)
        local v = WH.iniGet(text, "Wheel", key)
        if v == nil or v == "" then return dflt end
        local n = tonumber(v)
        if not n then notes[#notes + 1] = key .. "=" .. v .. " is not a number; " .. tostring(dflt) .. " is used"; return dflt end
        if n < lo or n > hi then
            local cl = math.max(lo, math.min(hi, n))
            notes[#notes + 1] = key .. "=" .. v .. " clamped to " .. cl .. " (" .. lo .. ".." .. hi .. ")"
            return cl
        end
        return n
    end
    c.on = WH.onoff(WH.iniGet(text, "Wheel", "Enabled"), true)
    c.N = math.floor(num("classButtons", 10, WH.N_MIN, WH.N_MAX))
    c.always = WH.onoff(WH.iniGet(text, "Wheel", "always"), false)
    c.segW = num("segmentWidth", 0, 0, WH.STOCK.W)
    if c.segW > 0 and c.segW < WH.W_MIN then notes[#notes + 1] = "segmentWidth=" .. c.segW .. " raised to " .. WH.W_MIN; c.segW = WH.W_MIN end
    c.gap = num("gap", 2, 0, 20)
    local a = (WH.iniGet(text, "Wheel", "arcWidth") or "auto"):lower()
    if a == "auto" or a == "" then c.arc = "auto"
    elseif a == "off" or a == "0" then c.arc = "off"
    elseif tonumber(a) and tonumber(a) > 0 and tonumber(a) <= 360 then c.arc = tonumber(a)
    else notes[#notes + 1] = "arcWidth=" .. a .. " is not auto|off|0<deg<=360; auto is used"; c.arc = "auto" end
    c.labels = WH.onoff(WH.iniGet(text, "Wheel", "labels"), true)
    return c, notes
end
-- PURE: the layout for N class buttons. Order down the track: Standard (start 312, 3 x W), gap, Class (centred, N x W), gap,
-- Utility (6 x W), ending no lower than the stock -18. W = the largest width <= 23 (0.5 steps) that leaves 2 x gap; the slack
-- is shared by the two gaps. -> { W, gap, base = { std, cls (centre), util }, used, fits, why }
function WH.layout(N, conf)
    local S = WH.STOCK
    local slots = S.std + N + S.util
    local minGap = (conf and conf.gap) or 2
    local auto = math.floor(((S.TRACK - 2 * minGap) / slots) * 2) / 2
    if auto > S.W then auto = S.W end
    local W, why = auto, "auto"
    local want = conf and conf.segW or 0
    if want and want > 0 then
        if want * slots + 2 * minGap <= S.TRACK + 1e-9 then W, why = want, "segmentWidth" else
            why = ("segmentWidth=%g does not fit %d buttons in %d deg; auto %g is used"):format(want, slots, S.TRACK, auto)
        end
    end
    local gap = (S.TRACK - slots * W) / 2
    local stdEnd = S.STD_BASE - S.std * W
    local clsCentre = stdEnd - gap - N * W / 2
    local utilBase = stdEnd - gap - N * W - gap
    local utilEnd = utilBase - S.util * W
    local function norm(a) a = a % 360; if a < 0 then a = a + 360 end; return a end
    return { W = W, gap = gap, why = why, slots = slots, used = slots * W,
             base = { std = S.STD_BASE, cls = norm(clsCentre), util = norm(utilBase) },
             fits = (W >= WH.W_MIN) and (gap >= minGap - 1e-9) and (utilEnd >= S.STD_BASE - S.TRACK - 1e-9) }
end
-- ---- the UObject side (every call pcall'd; uvalid before any method)
function WH.full(o) local n = nil; pcall(function() n = o:GetFullName() end); return (type(n) == "string" and n ~= "") and n or nil end
function WH.pathOf(o) local n = WH.full(o); return n and (n:match("^%S+%s+(.+)$") or n) or nil end
function WH.get(o, key)
    for _, name in ipairs(WH.P[key] or { key }) do
        local ok, v = pcall(function() return o[name] end)
        if ok and v ~= nil then
            if not WH.names[key] then WH.names[key] = name end
            return v, name
        end
    end
    return nil
end
function WH.set(o, key, v)
    local _, name = WH.get(o, key)
    if not name then return false end
    return (pcall(function() o[name] = v end))
end
function WH.call(o, fname, ...)
    local args = { ... }
    return pcall(function() local f = o[fname]; return f(o, table.unpack(args)) end)
end
function WH.len(arr)
    if arr == nil then return 0 end
    local n = nil
    pcall(function() n = arr:GetArrayNum() end)
    if type(n) ~= "number" then pcall(function() n = #arr end) end
    return type(n) == "number" and n or 0
end
function WH.num(v) return type(v) == "number" and v or tonumber(tostring(v)) end
-- the VM + the live panels: a FindAllOf walk at most WH.WALKS times per class a mission (WH.WALK_GAP_S apart), then by path
function WH.walk(cls)
    local m = WH.m
    local n = m.walks[cls] or 0
    if n >= WH.WALKS or WH.clock() < (m.nextWalk[cls] or 0) then return nil end
    m.walks[cls], m.nextWalk[cls] = n + 1, WH.clock() + WH.WALK_GAP_S
    local out = {}
    local ok, all = pcall(FindAllOf, cls)
    if ok and type(all) == "table" then
        for _, o in ipairs(all) do
            local p = uvalid(o) and WH.pathOf(o)
            if p and not p:find("Default__", 1, true) and not p:find("_C:WidgetTree", 1, true) then out[#out + 1] = p end
        end
    end
    return out
end
function WH.byPath(p) if not p then return nil end; local o = StaticFindObject(p); return uvalid(o) and o or nil end
function WH.vm()
    local m = WH.m
    local o = WH.byPath(m.vmPath)
    if o then return o end
    local paths = WH.walk(WH.VM_CLASS)
    if not paths then return nil end
    local best, bestN = nil, -1
    for _, p in ipairs(paths) do
        local v = WH.byPath(p)
        local n = v and WH.len(WH.get(v, "TacticalAbilities")) or -1
        if n > bestN then best, bestN = p, n end
    end
    m.vmPath = best
    return WH.byPath(best)
end
function WH.counts(vm)
    local c = {}
    for k, prop in pairs(WH.BUCKET) do c[k] = WH.len(WH.get(vm, prop)) end
    return c
end
function WH.isOpen(vm) local v = WH.get(vm, "bIsRadialOpen"); return v == true end
function WH.livePanels()
    local m = WH.m
    local out = {}
    for _, p in ipairs(m.panelPaths) do local o = WH.byPath(p); if o then out[#out + 1] = o end end
    if #out == 0 then
        local paths = WH.walk(WH.PANEL_CLASS)
        if paths then m.panelPaths = paths; m.panelWalked = true end
        for _, p in ipairs(m.panelPaths) do local o = WH.byPath(p); if o then out[#out + 1] = o end end
    end
    return out
end
function WH.sliceOf(panel, key)
    local s = WH.get(panel, WH.SLICE[key])
    if uvalid(s) then return s end
    local p = WH.pathOf(panel)
    return p and WH.byPath(p .. ".WidgetTree." .. WH.SLICE[key]) or nil
end
function WH.wedges(slice)
    local out, box = {}, WH.get(slice, "slices")
    if not uvalid(box) then return out, nil end
    local n = 0; pcall(function() n = box:GetChildrenCount() end)
    for i = 0, (WH.num(n) or 0) - 1 do
        local w = nil; pcall(function() w = box:GetChildAt(i) end)
        if uvalid(w) then out[#out + 1] = w end
    end
    return out, box
end
-- the three slice writes on one slice object (template or live) -> list of "name a->b" changes (nil when a write failed)
function WH.writeSlice(s, key, L)
    local ch = {}
    local want = { width = L.W, base = L.base[key] }
    if key == "cls" then want.count = WH.conf.N end
    for _, f in ipairs({ "count", "width", "base" }) do
        if want[f] ~= nil then
            local cur = WH.num((WH.get(s, f)))
            if cur == nil then return nil, "no " .. WH.P[f][1] end
            if math.abs(cur - want[f]) > 1e-6 then
                if not WH.set(s, f, want[f]) then return nil, "write " .. WH.P[f][1] .. " refused" end
                ch[#ch + 1] = ("%s %g->%g"):format(WH.names[f] or WH.P[f][1], cur, want[f])
            end
        end
    end
    return ch
end
function WH.template(L)
    local wrote, missing = 0, 0
    for _, key in ipairs(WH.ORDER) do
        local s = WH.byPath(WH.TEMPLATE .. WH.SLICE[key])
        if not s then missing = missing + 1 else
            local ch, why = WH.writeSlice(s, key, L)
            if not ch then WH.monce("tpl|" .. key, "skip: template " .. WH.SLICE[key] .. ": " .. why) elseif #ch > 0 then wrote = wrote + 1 end
        end
    end
    return wrote, missing
end
-- the BP's own rebuild of a live class slice (closed wheel only) -> "rebuilt a->b" | nil, why
function WH.rebuild(s)
    local before = #(WH.wedges(s))
    local arr = WH.get(s, "iface")
    if arr == nil then return nil, "no Button Interfaces" end
    local okE = pcall(function() arr:Empty() end)
    if not okE then return nil, "Button Interfaces:Empty() is not available in this UE4SS" end
    local _, box = WH.wedges(s)
    if box then pcall(function() box:ClearChildren() end) end
    local okS, err = WH.call(s, "Setup Wedges")
    if not okS then return nil, "Setup Wedges raised: " .. tostring(err) end
    local after = #(WH.wedges(s))
    return ("rebuilt %d->%d"):format(before, after), nil, after
end
-- one live panel -> summary text
function WH.applyPanel(panel, L, open)
    local parts = {}
    for _, key in ipairs(WH.ORDER) do
        local s = WH.sliceOf(panel, key)
        if not s then parts[#parts + 1] = WH.SLICE[key] .. " not found" else
            local ch, why = WH.writeSlice(s, key, L)
            if not ch then parts[#parts + 1] = WH.SLICE[key] .. ": " .. why
            elseif key == "cls" then
                local have = #(WH.wedges(s))
                if have >= WH.conf.N then parts[#parts + 1] = ("class wedges %d (no rebuild needed)"):format(have)
                elseif open then WH.m.pending = true; parts[#parts + 1] = ("class wedges %d: rebuild deferred (the wheel is open)"):format(have)
                else
                    local r, rwhy = WH.rebuild(s)
                    parts[#parts + 1] = r and ("class wedges " .. r) or ("class rebuild skipped: " .. rwhy)
                end
            end
        end
    end
    return table.concat(parts, "; ")
end
-- after an open: no key label on class wedges 5+, and the arc / hit width on every wedge of the re-laid slices
function WH.decorate(panel, L)
    local hidden, arcs, conf = 0, 0, WH.conf
    local arc = (conf.arc == "auto") and math.max(1, L.W - 1) or conf.arc
    if L.W == WH.STOCK.W and conf.arc == "auto" then arc = "off" end
    for _, key in ipairs(WH.ORDER) do
        local s = WH.sliceOf(panel, key)
        local ws = s and WH.wedges(s) or {}
        for i, w in ipairs(ws) do
            if key == "cls" and conf.labels and i > WH.STOCK.cls then
                if WH.call(w, "Set Hotkey Data", -1) then hidden = hidden + 1 end
            end
            if arc ~= "off" and not WH.arcDead then
                local ok, err = WH.call(w, "SetWedgeWidth", arc)
                if ok then arcs = arcs + 1 else
                    WH.arcDead = true
                    WH.once("arcdead", "skip: arc width - SetWedgeWidth is not callable (" .. tostring(err) .. "); arcs stay at the material default")
                end
            end
        end
    end
    return hidden, arcs, arc
end
function WH.resetMission(why)
    if WH.m and WH.m.armed then WH.say("mission left (" .. why .. ")") end
    WH.wkey, WH.seenAt, WH.mlogged = nil, nil, {}
    WH.m = nil
end
function WH.newMission(key)
    WH.wkey, WH.seenAt, WH.mlogged = key, WH.clock(), {}
    WH.m = { armed = false, walks = {}, nextWalk = {}, vmPath = nil, panelPaths = {}, max = { std = 0, cls = 0, util = 0 },
             applied = false, pending = false, wasOpen = false, openPasses = 0, map = (key:match("([^/%.]+)#") or key) }
end
-- 1.8.47: ZCSDK_WheelActive for other mods' wheels (UE4SS shared variables are global across Lua mods)
function WH.signal(on)
    local ok, e = pcall(function() ModRef:SetSharedVariable("ZCSDK_WheelActive", on) end)
    if not ok then WH.once("signal", "ZCSDK_WheelActive not set: " .. tostring(e)) end
end
function WH.setup()
    local text = WH.read(UE4SS .. WH.INI) or ""
    local c, notes = WH.parse(text)
    WH.conf = c
    for _, n in ipairs(notes) do WH.say("settings.ini [Wheel] " .. n) end
    if not c.on then
        WH.say("OFF for the session (settings.ini [Wheel] Enabled=off): the stock wheel is untouched")
        return false
    end
    WH.say(("armed: class buttons %d (stock %d), segment %s, min gap %g, arc %s, labels %s, always %s; only in %s worlds up %d s")
        :format(c.N, WH.STOCK.cls, c.segW > 0 and tostring(c.segW) or "auto", c.gap, tostring(c.arc), c.labels and "on" or "off",
                c.always and "1" or "0", WH.MARK, WH.SETTLE))
    return true
end
-- one pass inside an armed mission -> seconds to the next
function WH.missionPass()
    local m, c = WH.m, WH.conf
    local vm = WH.vm()
    if not vm then WH.monce("novm", "skip: no ability-selection view model yet (" .. WH.VM_CLASS .. ")"); return WH.BASE_S end
    local n, open = WH.counts(vm), WH.isOpen(vm)
    for k, v in pairs(n) do if v > m.max[k] then m.max[k] = v end end
    if m.max.std + m.max.cls + m.max.util == 0 then return WH.BASE_S end          -- no unit selected yet
    local needed = c.always or m.max.cls > WH.STOCK.cls
    local head = ("mission %s: abilities std=%d class=%d util=%d (stock buttons %d/%d/%d)")
        :format(m.map, m.max.std, m.max.cls, m.max.util, WH.STOCK.std, WH.STOCK.cls, WH.STOCK.util)
    for _, k in ipairs({ "std", "util" }) do
        if m.max[k] > WH.STOCK[k] then
            WH.monce("over|" .. k, ("%s bucket holds %d > %d buttons: not handled by WHEEL (only the class slice grows)"):format(k, m.max[k], WH.STOCK[k]))
        end
    end
    if not needed and not WH.sticky then
        WH.monce("notneeded", head .. " - not needed, the stock wheel is untouched")
        return 1.0
    end
    if c.N == WH.STOCK.cls and c.segW == 0 then
        WH.monce("n4", head .. " - classButtons=4 is the stock wheel: nothing to change")
        return 1.0
    end
    WH.monce("needed", head .. (c.always and " - [Wheel] always=1" or (needed and (" - needed (class " .. m.max.cls .. " > " .. WH.STOCK.cls .. ")")
        or " - kept from earlier in the session")))
    WH.sticky = true
    if m.max.cls > c.N then
        WH.monce("over|cls|" .. m.max.cls, ("overflow: class bucket holds %d, %d button(s): %d ability(ies) still dropped (classButtons max %d)")
            :format(m.max.cls, c.N, m.max.cls - c.N, WH.N_MAX))
    end
    local L = WH.layout(c.N, c)
    if not L.fits then WH.monce("nofit", ("skip: %d class buttons do not fit the %d-degree track (W %g, gap %g)"):format(c.N, WH.STOCK.TRACK, L.W, L.gap)); return WH.IDLE_S end
    WH.monce("layout", ("layout: class buttons %d->%d, segment %g->%g (%s; std %g, class centre %g, utility %g; gap %g; %g/%d deg)")
        :format(WH.STOCK.cls, c.N, WH.STOCK.W, L.W, L.why, L.base.std, L.base.cls, L.base.util, L.gap, L.used, WH.STOCK.TRACK))
    local tw, tmiss = WH.template(L)
    if not m.applied or m.pending then
        local panels = WH.livePanels()
        if #panels == 0 then
            if m.panelWalked then WH.monce("nopanel", "live: no " .. WH.PANEL_CLASS .. " found yet (the template carries the change to the next panel)") end
        else
            local again = m.applied
            m.pending = false
            local sums = {}
            for i, p in ipairs(panels) do if i <= 4 then sums[#sums + 1] = WH.applyPanel(p, L, open) end end
            m.applied = true
            local text = table.concat(sums, " | ")
            if not (again and m.pending) then          -- a rebuild still waiting for the close is not news
                WH.monce(again and "applied|again" or "applied", ("applied: template %d slice(s) written%s; live %d panel(s): %s")
                    :format(tw, tmiss > 0 and (" (" .. tmiss .. " not loaded)") or "", #panels, text))
            end
        end
        if WH.names.count then
            WH.once("names", "property names: " .. tostring(WH.names.count) .. " / " .. tostring(WH.names.width) .. " / " ..
                tostring(WH.names.base) .. " / " .. tostring(WH.names.iface or "(no rebuild)"))
        end
    end
    -- an open edge: "Setup Hotkeys" just relabelled; decorate on the next WH.OPEN_PASSES passes
    if open and not m.wasOpen then m.openPasses = WH.OPEN_PASSES end
    m.wasOpen = open
    if m.openPasses > 0 then
        m.openPasses = m.openPasses - 1
        local hid, arcs, arc = 0, 0, "off"
        for i, p in ipairs(WH.livePanels()) do if i <= 4 then local h, a, w = WH.decorate(p, L); hid, arcs, arc = hid + h, arcs + a, w end end
        WH.monce("decor", ("labels: %d class wedge(s) past %d show no hotkey (native keys 4-7 reach class 1-4 only); arc width %s on %d wedge(s)")
            :format(hid, WH.STOCK.cls, tostring(arc), arcs))
    end
    return WH.FAST_S
end
function WH.tick()
    if not WH.started then
        WH.started = true
        local ok, go = pcall(WH.setup)
        if not ok then log("[wheel] setup error (WHEEL off for the session): " .. tostring(go)); WH.signal(false); return true end
        WH.signal(go and true or false)
        if not go then return true end
    end
    local wname = pinWorldName()
    if not wname:find(WH.MARK, 1, true) then
        if WH.wkey then WH.resetMission("not a mission world") end
        if WH.sticky then pcall(function() WH.template(WH.layout(WH.conf.N, WH.conf)) end) end
        return WH.IDLE_S
    end
    local w = gameWorld()
    if not uvalid(w) then return WH.BASE_S end
    local a = "?"; pcall(function() a = string.format("%x", w:GetAddress()) end)
    local key = wname .. "#" .. a
    if WH.wkey ~= key then
        if WH.wkey then WH.resetMission("a new world") end
        WH.newMission(key)
        return WH.BASE_S
    end
    if not WH.m.armed then
        if WH.clock() - WH.seenAt < WH.SETTLE then return WH.BASE_S end
        WH.m.armed = true
    end
    return WH.missionPass()
end
WH.task = addTask("wheel", WH.BASE_S, function()
    local ok, r = pcall(WH.tick)
    if not ok then
        WH.errs = (WH.errs or 0) + 1
        if WH.errs <= 5 then log("[wheel] error (the task keeps running): " .. tostring(r)) end
        if WH.errs >= 20 then log("[wheel] STOOD DOWN for the session after 20 errors"); WH.signal(false); return true end
        return 5
    end
    return r
end, 6.0)
end
-- ---- 2026-10-22: WHEEL (end) ----

log("ZCSDKLoader v1.8.54 loaded (win64=" .. WIN64 .. "); waiting for the main-menu world")
-- 1.8.26: the LAST statement of the main chunk. Everything above only registered tasks; nothing has run yet. From here on
-- every line of this loader runs inside `pump` on the game thread (or in a RegisterHook callback, also the game thread).
startPump()
