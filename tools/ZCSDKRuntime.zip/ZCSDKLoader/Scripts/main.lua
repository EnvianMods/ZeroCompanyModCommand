-- ZCSDKLoader v1.8.25 — runtime loader for Zero Company SDK content mods (pairs with the ZCSDKBridge C++ mod).
--   (1.8.25) HARDENING (the X1 crash review of 2026-09-24 03:14, SWBF2 Models Project notes/X1_crash_0314.md). UE4SS's
--           game-thread runner called a queued action whose Lua registry ref had been reused (a C finaliser, not the
--           closure), and this loader's recruit-pin closure had replayed stale a minute before. The ROWFIX, recruit-pin and grant
--           loops now keep AT MOST ONE closure in the game-thread queue (a 10-tick watchdog re-queues a dropped one), and
--           ROWFIX re-finds its rows every tick while rows exist, so no widget userdata crosses a tick.
--   (1.8.24) THE ARMOURY'S BLANK MODEL ROWS. A weapon list longer than the ~7 visible rows scrolls, and every row generated
--           after the page's one-time build-on cascade keeps its WBP_Customization_WeaponBox entry at BuildOn "Off" (root
--           opacity 0): blank, yet clickable. This is a latent game bug that stock lists (6 parts at most) never reach. A paced,
--           hub-only loop re-runs the stuck entry's own PlayBuildOn(0) ("entry" mode), or re-lays-out the list ("list" mode),
--           whichever the round-6 experiment proves. See the block above the final log line.
--   (1.8.23) THE HUB'S SPAWN WAVE KILLS RegisterHook, SO THE SABER HOOKS WAIT FOR A MISSION. The crash is now
--           CAPTURED TWICE, and both are the same shape: 2026-09-13 22:51:55 and 2026-09-15 08:58:38.9,
--           `EXCEPTION_ACCESS_VIOLATION` (0x70 and 0xa) with UE4SS-ONLY top frames — `+c5f4dd`, `+2a9cf9`,
--           `+2ad787`/`+2ad78a`, `+b94064`, `+b98dec`, `+c68a7e` — and no game frame anywhere near the top. Both
--           landed at the exact instant `LoopAsync(5000, …)` found `BP_FX_LightSaber_Base_C` resident and started
--           `RegisterHook`ing the 8 saber functions DURING THE HUB'S SPAWN WAVE (the pin census climbing 27 -> 73 ->
--           116 instances in the same seconds). The 09-15 UE4SS.log ends on `[RegisterHook] Registered script hook
--           (8, 8) for … Cinematic_Deactivate` — the 4th of the 8 — with no further Lua line: the fault is inside
--           UE4SS during the 4th/5th registration, or inside the game calling one of the just-hooked functions on a
--           saber actor that is still mid-spawn. 7 of 9 hub loads survived the identical code, so this is a RACE
--           with the spawn wave, not a deterministic fault. INFERRED (not proven): hooking a Blueprint UFunction
--           while that class's instances are being constructed is unsafe in UE4SS 3.0.1.
--           THE FIX IS TO STOP ARMING WHERE THE HOOKS ARE NOT NEEDED. They exist for a VAULT or a STRIKE, both of
--           which happen in a mission, so arming now needs all three of: (a) the world name contains
--           `/Maps/Skirmish/` — the same mission marker the TurnProbe uses, which `HUB_Root` and `MainMenu` can
--           never match; (b) `BP_FX_LightSaber_Base_C` resident (`StaticFindObject` valid, unchanged); and (c)
--           `SABER_HOOK_SETTLE` = 8 s elapsed since that mission world was FIRST seen, so the mission's own spawn
--           wave and its `ActivateLightsaber` burst at +2 s are over before anything is registered. Everything the
--           1.8.2 lesson bought is kept verbatim: exactly ONE registration per process (`saberHookArmed` set BEFORE
--           the call), never a retry after a failure, and the hooks persist across worlds so one mission arms them
--           for the whole session. The hub now logs `vault saber: arming deferred to a mission world (1.8.23) …`
--           once when the class is first seen there, and the first mission logs `vault saber: mission world seen at
--           <t>; arming in 8 s` and then the 8 `hook armed on` lines as before.
--           THE COST, stated because session_audit.py must not be edited to hide it: hooks armed inside a mission
--           MISS that mission's own start burst (`PATH> Activate` ×4 / `PATH> ActivateLightsaber`), which is
--           session_audit's mission-boundary marker — so for the FIRST mission of a session that marker will be
--           absent. Every later mission, and every vault or strike in the first one after the 8 s, logs as before.
--           Nothing else moved: relight still OFF (1.8.21), the stale-slot rebuild, the ghost holds and the
--           residency ladder are byte-for-byte 1.8.22.
--   (1.8.22) THE SLOT THE OPERATOR CANNOT CHANGE, AND THE SAVE THAT KEEPS IT. Retail 2026-09-14/15 (CHANGELOG
--           v1.28.53 §9(b), §11, §13): PROVEN in the data, INFERRED for the symptom. Two facts already in this header
--           — `LoadCustomization` rebuilds a slot's FragmentInstances ONLY on an id CHANGE (09-13 09:04:40), and a
--           MISSION re-creates every character FROM SAVE DATA (21:28:27 vs 21:28:30) — together explain HAWKS. He is
--           NOT a pinned character (game class `CPD_Char_Class_Hero_Humanoid`), but his `Specializations.Weapon` slot
--           holds `CPD_WeaponSpec_ZCSDK_SaberAnakin`, picked in the armoury and serialised under that mod's v1.0.0,
--           and his armoury Change Weapon is GREYED OUT — so the id never changes, the fragments stay v1.0.0, and
--           every mission rebuilds him from them: the REMOVED `GA_OverwatchMelee_Base` still draws a "Melee Overwatch"
--           card (and locks the turn) and his sprint still uses his previous BLASTER's anim proxy table while the
--           visible saber comes from the equipped part. A byte-grep of the whole deployed game finds that ability in
--           NO ZCSDK container: the card is the SAVE, not the pak. VEX is the control and he is CLEAN — because the
--           pin toggles his Weapon slot every hub load (`[TOGGLE to CPD_WeaponSpec_Blaster_Longarm]`,
--           `FragmentInstances REPLACED`) and a manual save carried the rebuilt fragments into the mission (§11,
--           retail-verified).
--           SO THE PIN NOW DOES FOR A NON-PINNED CHARACTER WHAT IT ALREADY DOES FOR A PINNED ONE: one toggle-and-back
--           on the Weapon slot, `STALE_SLOT_REBUILD` (default true), through the SAME setter and the SAME
--           BEFORE/AFTER fragment-identity check. It is the 1.8.18 toggle re-aimed, not a new mechanism, and every
--           fence narrows it: HUB ONLY; the WEAPON TAG ONLY (a Class drive re-creates the child slots, fact B); only
--           an id THIS INSTALL SHIPS — enumerated by a manifest (`pinManifestParts()`) OR RESIDENT at the SDK's own
--           `/Game/ZCSDK/<id>.<id>`, and the second test is not optional: `build/ZCSDK_SaberAnakin.zcsdk.lua`, the mod
--           whose spec is stuck on Hawks, enumerates NOTHING (one primary type over /Game/ZCSDK, empty grants), so the
--           enumerated set alone would never have fired on the one character this exists for. Either way it is never a
--           vanilla part (not under /Game/ZCSDK) and never a GHOST (not resident — that is what makes it a ghost);
--           never a character that is OURS (the pin's own toggle would
--           fight it); never a proxy and never an owner that cannot be NAMED (1.8.20); once per session per
--           (owner, id), at most PIN_MAX_RETRY writes, and a failure is FINAL. The one that matters: BOTH ids are
--           minted from live objects BEFORE the first write, because a toggle written with no way back would leave
--           the character wearing a Blaster Longarm — and if the toggle write itself does not move the fragments the
--           original id is UNWOUND back onto the slot in the same pass (one write of what it already held; the
--           verdict stays FAILED). `done` is held while a rebuild is mid-flight, bounded by those
--           same budgets. The REBUILT line ends `— make a manual save before the next mission`, because rebuilt
--           fragments live in the hub instance and the mission reads the save; the summary at `done` is
--           `stale-slot rebuild: N slot(s) REBUILT, M FAILED, K skipped (not ours, not ours-shipped)`. NOT
--           retail-verified: the check is Hawks' hub load printing REBUILT, then a manual save, then a mission with
--           no "Melee Overwatch" on him and saber locomotion on his sprint.
--   (1.8.21) THE RELIGHT IS OFF, AND THE RULE IT BROKE IS NOW WRITTEN DOWN. Retail 2026-09-14 04:53 (loader 1.8.20,
--           deployed), one second into a mission: the insertion mantle extinguished a blade (04:53:30
--           `PATH> DeactivateLightsaber` / `relighting through ActivateSaberCheck (HasMantled=true)`), and the 350 ms
--           relight threw `main.lua:2011: [Lua::Registry::get_function_ref] Ref was not function` with the traceback
--           in `[C]: in method 'ActivateSaberCheck'`. THAT FUNCTION IS ONE THIS SAME MOD HAS RegisterHook'd — the
--           log-only `[state]` probe hook of 1.8.6 — and calling it from Lua made UE4SS's hook dispatcher fail to
--           find its own callback ref. The 900 ms call then went through and even reported `RELIGHT VERIFIED (900ms)
--           - bIsActive=true | Activated Lightsaber Blade=set | Sheath=0.000`, but the operator saw EVERY CHARACTER
--           RUNNING IN PLACE at mission start: the insertion sequence never completed. INFERRED (not proven): a Lua
--           exception thrown inside UE4SS's hook dispatch while the game was mid-`ActivateSaberCheck` broke the
--           mission's start sequence. Exact or not, two rules are now proven and stand on their own:
--             (A) THIS RUNTIME MUST NEVER CALL A UFUNCTION IT HAS HOOKED. Registering and invoking the same UFunction
--                 is the `Ref was not function` fault, and it throws INSIDE the game's own call frame.
--             (B) THIS RUNTIME MUST NOT DRIVE THE SABER DURING THE INSERTION MANTLE. A scripted sequence owns the
--                 characters at mission start and a relight lands in the middle of it.
--           So `RELIGHT_ENABLED` is FALSE by default. The vault handlers still READ and still print every vdiag line
--           (the diagnostics are the point), but they schedule NOTHING and log `vault saber: relight DISABLED
--           (1.8.21) ...` once per deactivation. The blade is left to the game's own `ActivateSaberCheck`, and the
--           next retail vault decides it: PASS = the game's check reads `bIsActive=false` and `PATH>
--           ActivateLightsaber` follows and the blade comes back; FAIL = `bIsActive=false` with no
--           `ActivateLightsaber`, blade dark — then the game does not recover on its own and a relight that does NOT
--           call a hooked function is needed (drop the `[state]` hooks first). If `RELIGHT_ENABLED` is ever set true,
--           the `[state]` probe hooks on ActivateSaberCheck/DeactivateSaberCheck are NOT registered, because rule (A)
--           is not a thing to re-learn in retail. With the default false, all 8 hooks arm exactly as in 1.8.20.
--   (1.8.20) THE FLAG WAS NOT THE BLADE. Retail 2026-09-13 22:52 (loader 1.8.19, deployed) broke three things open:
--           * THE VAULT SABER RELIGHT WAS NEVER A FIX — it was the thing STOPPING the fix. 23:17:41 Hawks vaulted,
--             the relight replayed the four captured arguments into `ActivateLightsaber` and logged `re-lit (350ms)
--             - bIsActive now true`; the blade was NOT visible for the rest of the mission, and at 23:21:16 the
--             game's own `ActivateSaberCheck` logged `HasMantled=false bIsActive=true` and did nothing. Proven with
--             tools/recon/kismet.py over the cooked BP_FX_LightSaber_Base (offsets in the block comment on
--             `relight`): `+2086 EX_JumpIfNot Self.bIsActive -> +1904` is the game's OWN next-turn recovery, and
--             setting the flag turns it into a no-op; the visible blade comes only from `Timeline_Blade__UpdateFunc`
--             (`SetScalarParameterValueOnMaterials("Sheath", ...)`), which `bIsActive` does not touch; and the 4th
--             parameter `Target Saber` is DEAD — `K2Node_CustomEvent_Target_Saber_2` never appears as an operand in
--             the 1389-opcode ubergraph, so the replay of 1.8.7-1.8.19 replayed nothing that mattered.
--             THE RELIGHT NOW CALLS THE GAME'S OWN `ActivateSaberCheck(TargetSaber)` — signature READ, not guessed
--             (`kismet.py --function ActivateSaberCheck`: ONE `TargetSaber : ByteProperty`), with the saber's own
--             `Owning Saber Position` (then `GetTargetLightsaber()`, then the enum's "both" member 2). It is
--             self-idempotent at `+2086`, so the 350/900 ms pair is kept; the three captured components are gone and
--             the stale-pointer dance with them. AND `bIsActive` NO LONGER REPORTS SUCCESS: 600 ms after the call
--             one more read prints `RELIGHT VERIFIED` / `RELIGHT UNVERIFIED` from `Activated Lightsaber Blade` and,
--             where it can be read at all, the blade material's `Sheath` scalar. A relight that flips the flag and
--             leaves the blade dark now says so.
--           * THREE OF THE FOUR GHOST LINES WERE THE GAME'S OWN PARTS. `CPD_TacticalSpec_Soldier` (pass 1) and
--             `CPD_TacticalSpec_Hero_Aurelio_Assault` (pass 50) matched evidence shape 2 while the character was
--             still spawning (27 instances at pass 50 -> 109 at pass 54), and all three printed the owner as
--             `/Engine/Transient` because `shortOwner` was reading the SLOT's path. Two rules: a non-`CPD_ZCSDK_` id
--             needs PIN_GHOST_PASSES (4) CONSECUTIVE unresolved passes, and NO REPORT WITHOUT A NAMED OWNER — the
--             owner is the owning CustomizationInstance and an unnamed one DEFERS the report instead of printing it.
--             Hawks' real line is unchanged, verbatim. A candidate is counted, not blocked, unless it is a
--             `CPD_ZCSDK_` id: blocking an evidence-2 candidate would stop the drive that could disprove it.
--           * THE RESIDENCY LADDER RE-RAN ON A DELIVERED PART. 23:00:38-23:00:58, after all three slots read
--             `finished`, every pass alternated `did not resolve — step 1` / `resolved after step 1`. The drive path
--             cleared `partStep` and left the part on `partWatch`, where a step count of 0 reads as "not started".
--             Not a stale read — the tick's own precondition is a VALID StaticFindObject — so the line contradicted
--             the test that produced it, and its LoadAsset was a real request for an already-loaded asset. A part
--             that resolves once is now SETTLED: off the watch list, refused by `escalateResidency`. The 1.8.18
--             delivery path is untouched.
--   (1.8.19) THE EXPERIMENTS ARE DELETED, AND THE LOADER LEARNS TO REFUSE. 1.8.18 is RETAIL-VERIFIED (CHANGELOG
--           v1.28.46/47: all three Sith parts DELIVERED, the Focus tree DRAWS on the Sith Acolyte rails), so
--           everything it carried "in case" is now dead weight that the next reader would have to rule out again:
--           * GONE — `PIN_ROUTE` and both equip routes with all five marshalling shapes
--             (EquipCustomizationDefinition `allowed`/`tags`/`all`, EquipCustomizationParts `struct`/`table`), their
--             judge/commit helpers and the `arrival` observable that scored them. Retail 09:04:40 proved the plain
--             1.4.0 setter delivers, and an EMPTY AllowedSlots container re-created the character's own child slots
--             TWICE (07:52:26, 09:04:44). No route is going back in without a retail run that needs it.
--           * GONE — `PIN_RESOLVER_PROBE` and the whole KismetSystemLibrary resolver probe, including its
--             self-validation against the game's CPD_TacticalSpec_Assault. Its question was answered at 09:04:18:
--             the AssetManager resolves every one of our parts once they are RESIDENT. The TSoftObjectPtr accessor
--             chain it cost a crashed game to find is KEPT, as a comment beside the residency code — it is the only
--             verified way to read one in UE4SS 3.0.1 and nothing else in this project records it.
--           * NEW — THE GHOST REFUSAL (HANDOFF open items 3 and 7). Before driving anything, the pin looks at every
--             pinned slot on every real character in the world, OURS OR NOT, and if one holds a `CPD_ZCSDK_*` part id
--             that no currently enumerated manifest carries and that is resident nowhere — or a leveled tree whose
--             tier classes are null, the FocusProbe's shape on Hawks' save — it logs
--             `recruit pin: GHOST <owner> <slot tag>: holds <partId> from a mod that is not installed ...` and never
--             drives that slot. A save written while a mod was installed is not something to write over; the
--             2026-09-12 turn-end block is the INFERRED cost of one.
--           * VOCABULARY, per session_audit.py's own recommendations: one arming verb (`hook armed on <class>:<fn>`,
--             was `watching <fn>`), one firing verb (`PATH> <fn>`, was `<fn> FIRED`), `RegisterHook FAILED on <fn>`
--             names the function, and the HQ banner only says "waiting" when grants were actually declared.
--           Nothing on the proven path changed: residency before the first write, Class to completion then Weapon
--           then Tactical, the TOGGLE through a vanilla id, delivered-is-final, `done` ends the loop, proxies never
--           pinned, identity per CustomizationInstance, stale slots deduped by highest object index, xpcall around
--           the pass, IsValid before any UObject method, no UObject held across passes.
--   (1.8.18) THE ANSWER, AND IT WAS THE SETTER ALL ALONG. Retail 2026-09-13 09:02 (no crash):
--             09:04:18  GetObjectFromPrimaryAssetId returns OUR OBJECT for all three parts once resident - the
--                       AssetManager was never the problem (its path half was broken; that reading is discarded).
--             09:04:40  the plain 1.4.0 setter on Tactical.Primary: BEFORE partId=CPD_TacticalSpec_Assault |
--                       partDefinition=CPD_TacticalSpec_Assault | 3 leveled tree(s) -> AFTER partId=
--                       CPD_ZCSDK_TacticalSpec_Sith | partDefinition=CPD_ZCSDK_TacticalSpec_Sith | 2 leveled tree(s)
--                       -> DELIVERED. OUR TWO TREES, through the door eight versions tried to replace.
--             09:04:40  then a Class re-drive in the same second, and from 09:04:44 every Tactical AFTER reads
--                       partDefinition=<null> | 0 leveled tree(s), with the delivered trees stranded on stale slots.
--           TWO PROVEN FACTS: (A) LoadCustomization rebuilds fragments only on an id CHANGE, so a slot that already
--           holds our id is a no-op for ever - which is exactly why the Sith has been empty since the first session
--           that wrote our id onto him; (B) driving the CLASS part re-creates the character's child slots and
--           discards what was just delivered into them. So: Class FIRST then Weapon then Tactical (1.8.15's 'Class
--           last' was backwards); a slot that already holds our id with no fragments is TOGGLED through a different
--           id (its own remembered vanilla part, else the game default for that tag) and given ours back on the NEXT
--           pass; a delivered slot is never driven again; and `done` now means all of them delivered. The equip
--           routes and the resolver probe are both OFF by default - the setter is the route that works, and the
--           probe's question is answered.
--   (1.8.17) MY OWN PROBE CRASHED THE GAME, AND EVERY LINE IT PRINTED WAS AN ARTEFACT. Retail 2026-09-13 09:00:44,
--           91 s in: EXCEPTION_ACCESS_VIOLATION reading 0xa, frames UE4SS+2a9cf9 / +2ac8a6 (the userdata fetch and
--           UObject method binding). The 1.8.16 probe called methods on part objects it had just reported as
--           MISSING - the exact IsValid-before-method rule this file states twice elsewhere. And its output was
--           worthless in three separate ways: `id=FString: 0000...` (Conv_PrimaryAssetIdToString returns an FString
--           USERDATA, printed as its address), `path=EMPTY` for the GAME CONTROL as well as for ours (so the
--           soft-reference read was simply broken and every 'NameData is missing' line was noise), and
--           `valid=false` for our ids (because the probe ran before our parts were resident, so
--           GetPrimaryAssetIdFromObject was handed an invalid object).
--           THE ACCESSORS ARE NOW READ, NOT GUESSED. UE4SS 3.0.1's TSoftObjectPtr userdata metatable registers
--           exactly GetWeakPtr / GetTagAtLastTest / GetObjectID / type / __gc (UE4SS.dll push_softobjectproperty,
--           RVA 0x2cafe0) - no ToString, no GetAssetPathString. GetObjectID yields an FSoftObjectPath, and the
--           196985 jmap gives its shape: { AssetPath : FTopLevelAssetPath { PackageName : FName, AssetName : FName },
--           SubPathString }. The id string comes from the id's own members, the read slotState has used since 1.8.9.
--           SAFETY: a part is not asked about at all until StaticFindObject returns an object that passes IsValid -
--           before that the probe logs `not resident yet` and requests the load, and touches nothing. Every call is
--           pcall'd and every object IsValid-checked. A failed READ is reported as `<unreadable: why>` and concludes
--           NOTHING; only a successful read of an empty name means 'the manager holds no path'.
--           SELF-VALIDATION: the GAME's own CPD_TacticalSpec_Assault is probed FIRST and must answer on BOTH halves
--           (object and path). If it does not, the probe prints PROBE BROKEN, never touches our parts, and does not
--           run again this session. A probe that cannot be trusted has to say so.
--   (1.8.16) EVERY EQUIP LEAVES THE OLD SLOT OBJECTS ALIVE, AND THE CAP WAS COUNTING CORPSES. Retail 2026-09-13
--           08:38: 08:41:06 `skip Char_Hero_Humanoid_C_2: 6 slot(s) match this pin's 3 tag(s)` (the cap refused the
--           RECRUIT), 08:41:12 scoped, 08:41:17 scoped and Specializations.Weapon DELIVERED, 08:41:22
--           `12 slot(s) ...` and he was refused for the rest of the session. 3 -> 6 -> 12: each equip adds a new
--           slot object beside the previous one and the old ones stay findable. Fixes:
--           * slots are deduped BY TAG keeping the HIGHEST object index (UE numbers each new object above the last),
--             and the rest are reported as data: `<n> stale duplicate slot object(s) ignored`;
--           * an IDENTIFIED character is never refused by the cap - identity gates the drive, so the cap's only job
--             is to stop an instance nobody identified, and it can no longer fire on the recruit himself;
--           * NO VERDICT WITHOUT A DRIVE. That session ended with `STILL does not resolve` for all three parts, two
--             of which had resolved and delivered minutes earlier - the verdict was measured on a character the pin
--             had stopped driving. The ladder now holds at step 4 and says so.
--           AND THE INSTRUMENT CHANGED: a DIRECT RESOLVER PROBE replaces inference from equips. The AssetManager's
--           primary-asset API is BlueprintCallable on the KismetSystemLibrary CDO the pin already holds, takes a
--           by-value FPrimaryAssetId the pin already mints, and needs no equip, no character and no identification:
--           GetObjectFromPrimaryAssetId IS the resolver's own first step and GetSoftObjectReferenceFromPrimaryAssetId
--           is its second, so one line per part separates `no NameData` from `path present, object null` from `our
--           object reports a different id`. A game part (CPD_TacticalSpec_Assault) is probed as a control, so a
--           broken probe cannot masquerade as a broken asset.
--   (1.8.15) THE PIN LOST THE CHARACTER IT HAD JUST FOUND, AND SAID NOTHING. Retail 2026-09-13 07:47: the Sith was
--           identified at 07:52:21 and 07:52:26, the Class part DELIVERED through its own AllowedSlots container -
--           and from pass 32 onward the census read `0 ours, 14 with pinned slot(s), 0 pinned, 14 skipped` for the
--           rest of the session, with no line saying why, because the skip dedup was per OWNER and he had already
--           spent his one line on an earlier reason. THE CAUSE IS THE CALL ITSELF: the cooked
--           CPD_ZCSDK_Char_Class_Sith carries NO AllowedSlots property, so that container was EMPTY, and an empty
--           container equips every slot the definition names - the whole CD_ZCSDK_Char_Sith. That replaced the class
--           fragment, the class fragment is what builds the character's child slots, and the Info.Name slot the pin
--           identifies by was re-created underneath it. Four fixes: skip dedup is per (owner, REASON); identity is
--           STICKY for the session and has a SECOND source (a slot already holding one of this pin's own parts -
--           the Class slot re-identified him in the offline replay); a part whose AllowedSlots is EMPTY is never
--           equipped through the `allowed` shape, and the Class part goes LAST regardless so a re-creation cannot
--           orphan the specs; and the residency ladder runs on its OWN per-part clock (a step every
--           PART_STEP_PASSES ~ 15 s, ticked every pass whether or not a character was identified) instead of
--           stalling at step 2 for a whole session as it did at 07:52:26.
--           ON (e), REPORTED HONESTLY: the rescan did NOT flip the weapon at 05:48:53 - the log line ORDER shows the
--           weapon read as resolved BEFORE that pass issued the rescan command, and the bridge's before==after says
--           the rescan registered nothing. And there is NO asset-level difference to name: our weapon part's
--           registry class is BP_CPD_WeaponSpec_Base_C, identical to the game's own CPD_WeaponSpec_Blaster_Longarm,
--           and our tactical part's is BP_CPD_TacticalSpec_Base_C, identical to CPD_TacticalSpec_Assault; the
--           tactical is also the SMALLEST of the three (21 imports / 7 exports vs the class's 25/13), so 'a heavier
--           load graph' - my own earlier guess - is wrong too. Steps 3 and 4 fired in the SAME SECOND at 05:48:53,
--           so the ladder was measuring itself. The per-part clock is what makes the next run informative.
--   (1.8.14) THE PIN STOPS WHEN IT IS DONE, AND NEVER TOUCHES A PREVIEW PROXY. Retail 2026-09-13 05:43 crashed at
--           05:50:58 - EXCEPTION_ACCESS_VIOLATION reading 0xffffffffffffffff, 43 frames inside the Lua VM, no
--           GetClass frame, one pass after the loader's last line (pass 66 at 05:50:56.98; pass 67 never logged).
--           That session re-drove BP_CustomizationProxyCharacter_C_1 NINE times and C_0 three times EVERY pass,
--           forever, with zero give-up lines. Four causes, four fixes:
--           (1) A preview/portrait proxy is a transient actor the game destroys and recreates while Personnel is
--               open. It is never pinned now (`skip <owner>: preview/portrait proxy`) - pointless AND the likeliest
--               source of a userdata whose object is gone.
--           (2) PIN_MAX_RETRY was keyed by the instance PATH, which changes as proxies are recreated, so the bound
--               was unreachable. It is keyed by the character's stable identity (the pin's Name part) now.
--           (3) When every pinned slot on every identified real character is delivered or has given up, the loop
--               logs `recruit pin: done - ...` and STOPS for the session. 66 passes could not have helped.
--           (4) Nothing survives a pass but strings and numbers - the one cached UObject (the CustomizationStatics
--               CDO) is re-found every time. Cadence 3 s -> 5 s.
--           ON THE RESOLVER, CORRECTING 1.8.13's INFERENCE: the bridge's `before=3393 after=3393` with `scanned=19`
--           is GetPrimaryAssetIdList's COUNT before and after ScanPathsForPrimaryAssets (main.cpp:674-708), so the
--           manager already carried our ids and NameData was never missing. And the whole of
--           GetCustomizationPartDefinitionFromPartId (0x8c46060..0x8c46209) touches only UAssetManager::Get, two of
--           its virtuals ([+0x318] loaded-object, [+0x388] path) and a soft-path load pair - there is NO
--           UCustomizationPartsTagSubsystem call on the resolution path. What differs between the three parts is
--           asynchronous LOAD COMPLETION: Class resolved after LoadAsset alone, Weapon only two minutes after its
--           loadpkg, and the rescan that followed added nothing because there was nothing to add. The ladder keeps
--           the BuildPartTagMaps step anyway, because a step that flips a part would disprove this paragraph.
--   (1.8.13) THE MARSHALLING QUESTION IS CLOSED; THE RESOLVER ONE IS NOT. Retail 2026-09-13 05:30:21: three
--           EquipCustomizationDefinition calls, one per pinned part, each with that part's own AllowedSlots
--           container. Class -> `AFTER partDefinition=CPD_ZCSDK_Char_Class_Sith | 6 fragment instance(s)` ->
--           DELIVERED - FragmentInstances REPLACED. Weapon and Tactical.Primary -> `not delivered - nothing on the
--           slot changed`, partDefinition still <null>, fragments untouched, 0 leveled trees. One call in the same
--           pass delivering PROVES the userdata container reaches the native, so what separates the three parts is
--           GetCustomizationPartDefinitionFromPartId (RVA 0x8c46060), which asks the AssetManager for the LOADED
--           object for that FPrimaryAssetId and then for its path: an id the manager never SCANNED answers neither.
--           Cooked evidence that the three are not interchangeable: CPD_ZCSDK_Char_Class_Sith carries NO AllowedSlots
--           tagged property (an EMPTY container - so the call that delivered is the one that passed an empty one),
--           while the two spec parts carry populated ones. Both readings are now TESTED rather than argued: each
--           pinned part prints `part <name>: object=<found|missing> | valid=<y/n> | <full path>` once, and a part
--           whose slot will not resolve climbs one observable step per pass - LoadAsset, then the bridge's
--           synchronous loadpkg, then a rescan of that package's OWN directory - each step logged, and the step it
--           resolved on is logged too. Four steps in, the log says plainly that this is an asset-registration
--           question and not a loader one.
--   (1.8.12) THE UNIT OF IDENTITY IS THE CHARACTER, AND A CHARACTER IS ITS UCustomizationInstance. 1.8.10/1.8.11 made
--           it the slot's immediate parent OBJECT, and retail 2026-09-13 05:03 proved that unsatisfiable by
--           construction: `pass 39: 73 instance(s) seen, 73 candidate(s), 73 group(s), 0 pinned, 14 skipped,
--           world=HUB_Root`, every character skipped three times with `no identity: it holds 1 | 2 | 2 pinned tag(s)
--           … Info.Name reads <not present>`. One character's slots are not siblings: Class hangs off the instance,
--           the two Specializations slots off a container slot, Info.Name off a third parent - so no parent object
--           can hold both a pinned tag and the identity, and the rule could only ever fail. 1.8.7, which pinned this
--           recruit correctly, identified at INSTANCE level; that is restored. A character is ours if its instance's
--           own default CustomizationDefinition is the pin's OR if ANY slot under that instance carries the pin's
--           `match` part (in this save Vex came from the pool row, so only the Name part finds him), and the pinned
--           tags are then taken from anywhere under that same instance, at any depth. The owning instance is found by
--           walking GetOuter() with a validity check at every step (IsValid and GetFullName only - never GetClass),
--           falling back to the proven full-name prefix test.
--           WHAT STOPS THE 22:15:47 MASS-PIN IS THE CAP, NOT THE GROUPING: a character has exactly one slot per
--           pinned tag, so more matching slots than the pin declares means the instance carries more than one
--           character (a customization proxy accumulates what it has previewed) and NOTHING is written.
--   (1.8.11) 1.8.10 PINNED NOTHING, AND SAID NOTHING. Retail 2026-09-13 04:38: not one `recruit pin:` line after the
--           manifest was read, through a mission and a hub visit with the Focus tree open, while the probe showed the
--           Sith still at `partDefinition=<null> | fragment trees = 0`. Cause: 1.8.10 made the `match` Name-part
--           identity MANDATORY for every candidate - including the ones 1.8.9 found by the instance's own default
--           CustomizationDefinition, which never needed a Name slot - and every failure of that test returned in
--           silence. Same failure class as the probe that died on its first tick: a check that never PASSES reads,
--           from the log, exactly like a check that never RUNS.
--           FIXED THREE WAYS. (1) TWO identity sources, not one: a group carrying the pin's `match` part is that
--           character; failing that, an instance whose own default definition is the pin's AND which owns exactly one
--           slot group is that character (1.8.9's rule, restored). Anything else is refused - which is still the
--           22:15:47 mass-pin guard. (2) EVERY rejection logs one line naming the owner and the reason, once per owner
--           per session (`recruit pin: skip <owner>: ...`), and every accepted character logs how it was identified
--           (`recruit pin: scoped to <owner> by ...`). (3) A per-pass census - `recruit pin: pass N: X instance(s)
--           seen, Y candidate(s), Z group(s), W pinned, V skipped, world=<name>` - printed on the first pass, whenever
--           the shape changes, and every 20th pass, so a silent no-op is not expressible any more.
--   (1.8.10) A SAFETY FIX FIRST: THE PIN WAS WRITING OVER OTHER CHARACTERS. Retail 2026-09-12 22:15:47 — the pin
--           matched BP_CustomizationProxyCharacter_C_1, collected 21 slots belonging to SEVEN pool characters
--           (Astromech, Scoundrel, Sniper, Soldier, Assault, LongStrider, the Sith), asked for 18 changes, and when
--           every equip route came back empty the setter wrote Sith parts over all of them: 33 writes across the two
--           proxies. Cause: a slot belonged to a target if its full name started with the INSTANCE path. A character
--           is a slot GROUP - the immediate parent of its slots. Slots are now keyed tag -> slot PER GROUP (so a
--           group can never exceed the pin's own tags), a group is only pinned when it CARRIES THE PIN'S IDENTITY
--           (the `match` slot holding the mod's own Name part), a pin with no identity rule may only pin an instance
--           that yields exactly ONE group, and a collection larger than the pin's declared slot count is REFUSED.
--           THE SAME SESSION PROVED THE SETTER DOES DELIVER FRAGMENTS, so 1.8.9's whole premise needed narrowing:
--           at 22:15:50 `SetCustomizationPartPrimaryAssetId` left Tactical.Primary at `partDefinition=
--           CPD_ZCSDK_TacticalSpec_Sith | 5 fragment instance(s) | 2 leveled tree(s)` and DELIVERED - two trees,
--           exactly what the cooked part carries. `LoadCustomization` rebuilds the fragment instances whenever the
--           part RESOLVES, and `GetCustomizationPartDefinitionFromPartId` (RVA 0x8c46060) asks the AssetManager for
--           the LOADED object first - so ASSET RESIDENCY is the variable, not the door. The gap that kept the Sith
--           broken: the setter only ran when the id DIFFERED, so a slot carrying our id from a session where the
--           asset was not yet resident (definition NULLed, 0 trees) was never re-driven. It is now, bounded by
--           PIN_MAX_RETRY, and a retry is only spent when a route actually ran.
--           MARSHALLING: both Lua-built containers and both Lua-built maps reached the native EMPTY in that session
--           (`arrival: 0/18 ... did NOT reach the native`, `returned true; OutOriginalParts = <nil>` on all four).
--           So nothing is built in Lua any more: the first container shape is the part asset's OWN
--           `FGameplayTagContainer AllowedSlots` (CustomizationPartDefinition.h:15) passed as a real struct
--           userdata - UE4SS's userdata path is a type-checked CopyCompleteValue - one call per pinned part.
--   (1.8.9) THE RECRUIT PIN'S SUCCESS CRITERION WAS WRONG, AND IT FAILED ITS OWN NEW ROUTE. 1.8.8 judged a slot
--           equipped only when CustomizationPartDefinition came back non-null. It is not a criterion in either
--           direction: the game's own CPD_TalentSpec_TheToughGuy reads partDefinition=<null> with one leveled tree
--           and draws a full row, and the id-only setter resolves a definition by itself once the asset is resident
--           (both in the 2026-09-12 21:28 session). The criterion is now the one thing only the WithFragments door
--           can do: the slot's FragmentInstances are REPLACED (object identity) or it gains LeveledAbilities /
--           LoadedLeveledAbilities entries — and the criterion itself is printed once per session.
--           A route is also no longer demoted on a pass where every pinned slot already held the requested id
--           (1.8.8 read that no-op as a refused marshalling and locked the session to legacy before the route had
--           run once on a real change); each pass prints the ARRIVAL observable — how many of the slots that were
--           asked to change now hold the requested partId — which is what separates an empty argument from a
--           populated one when the native returns true either way.
--           NEW FIRST ROUTE: UCustomizationStatics::EquipCustomizationDefinition(CustomizationInstance,
--           CustomizationDefinition, FGameplayTagContainer SlotsToEquip, out TMap) — the same WithFragments door
--           with no TMap INPUT at all, taking the definition object the pin already holds. Order:
--           EquipCustomizationDefinition -> EquipCustomizationParts -> the 1.8.7 setter, each judged by the
--           criterion above and the winner remembered. The fragment-carrying routes are STRATEGY-SIDE ONLY: in a
--           mission the characters are rebuilt from save data and the game re-equips them during load, so an
--           in-mission pin keeps 1.8.7 behaviour exactly.
--           ALSO IN 1.8.9, from the 2026-09-12 crash analysis (the crashes were the FocusProbe, not the loader,
--           but the same shape was here): UE4SS's GetClass / GetFName bindings do NOT test validity - they read
--           [obj+0x10] off the pointer, so a null/stale UObject is a native access violation that pcall CANNOT
--           catch. IsValid() is a pure [obj+0x70] != 0 test and is the only safe first ask. dumpObject now checks
--           IsValid before every GetClass / GetFName, and the vault saber's relight re-validates the three
--           captured components (blade / light / collision) before replaying them 350 ms and 900 ms later - a
--           window long enough for the wielder to be destroyed - and NAMES the one that went stale.
--   (1.8.8) THE RECRUIT PIN NOW PINS THROUGH A PATH THAT CREATES FRAGMENT INSTANCES. Every version through 1.8.7
--           called UCustomizationFragmentInstanceSlot::SetCustomizationPartPrimaryAssetId, which (RVA 0x8c54660)
--           writes the id, NULLS CustomizationPartDefinition, and iterates the EXISTING FragmentInstances without
--           replacing them — so a pinned spec's leveled-ability fragment could never reach the instance and the
--           Focus tree drew rails with no nodes (18 hub dumps, `fragment trees = 0`; CHANGELOG v1.28.32). The pin
--           now calls UCustomizationStatics::EquipCustomizationParts(CustomizationInstance,
--           TMap<FGameplayTag,FPrimaryAssetId>, out TMap) — a BlueprintCallable UFUNCTION whose parameter list was
--           READ OUT OF THE 196985 jmap, not guessed (the v1.28.29 lesson) — which routes through the
--           ...WithFragments sibling every game equip path uses. The 1.8.7 setter stays as the fallback, the route
--           that ran is named in the log (`PATH> <fn>`), and each pinned slot prints the probe's own
--           `partId | partDefinition | fragment count` reading BEFORE and AFTER. Success = a non-null
--           partDefinition; that is the one thing the old setter can never produce.
--   (1.8.7) THE FIX, WITH THE SIGNATURE READ RATHER THAN GUESSED. bpclass.py against the cooked package gives
--           ActivateLightsaber(Lightsaber Blade: StaticMeshComponent, BladeLight: PointLightComponent,
--           WeaponInteractionCollision: BoxComponent, Target Saber: Enum_LightsaberStateTarget) - and
--           DeactivateLightsaber takes THE IDENTICAL FOUR. So the extinguish hook is handed exactly what the
--           relight needs: capture the args on the way out, replay them on the way back in. Nothing is
--           reconstructed from the actor or guessed, which is what broke 1.8.0-1.8.5.
--           THIS MATTERS BEYOND ONE SAVE: every saber mod the SDK produces inherits the bug, so the fix belongs
--           in the runtime rather than in any one mod.
--   (1.8.6) THE 1.8.5 RELIGHT CALL IS WITHDRAWN - it threw on every vault. ActivateLightsaber takes FOUR
--           parameters and was called with none ("UFunction expected 4 parameters, received 0"); the function was
--           checked for EXISTENCE and never for SIGNATURE. The turn also would not end in that session - not yet
--           attributed (bKismetScriptError appears three minutes BEFORE the relight ran), which is exactly why
--           this version calls nothing at all. NEW EVIDENCE: HasMantled was TRUE when DeactivateLightsaber fired,
--           so the v1.28.4 discriminator was right all along and was only ever read on the wrong function. The
--           live hypothesis is that HasMantled is never CLEARED after a scripted traversal, so ActivateSaberCheck
--           still believes the wielder is mid-vault and declines. This version logs the state at every check.
--   (1.8.5) THE FIX, ON THE PROVEN TRIGGER. The 1.8.4 probe named the whole sequence in retail (2026-09-12):
--           first vault = DeactivateLightsaber + DeactivateSaberCheck; later vaults = DeactivateSaberCheck alone;
--           next turn = ActivateSaberCheck fires and DECLINES. ActivateLightsaber never runs again, so the blade
--           never returns. Hook moved to DeactivateLightsaber and relight() now calls ActivateLightsaber (four
--           versions called the generic `Activate`, which is not on the blade path at all). Discriminator is
--           bSaberAutoActivateForCombat - the game's own answer - with HasMantled logged rather than trusted.
--   (1.8.4) THE PATH PROBE: 1.8.3 proved `Deactivate` is NOT on the vault path (it never fired). The cooked class
--           exports 50 UFunctions including ActivateLightsaber / DeactivateLightsaber / *SaberCheck / Cinematic_*;
--           the fix has been aimed at the generic Activate/Deactivate pair for four versions. Log-only hooks on
--           every candidate, so the next vault names the real path instead of costing another guess.
--   (1.8.3) DIAGNOSTICS ONLY, no behaviour change: the 1.8.2 hook ARMED in retail (2026-09-11) and the blade still
--           went out on a vault, with nothing else logged - because all four guards in the hook body and both in
--           relight() were bare returns. Five distinct failures shared one silence. Each now names itself.
--   (1.8.2) THE VAULT SABER FIX, REDONE — the DIAGNOSIS of 1.8.0 was right, only its ARMING was wrong. RegisterHook
--           is now called AT MOST ONCE, guarded by a flag and reached only after StaticFindObject proves the saber
--           class is loaded; the loop only LOOKS and stops for good on the first attempt, so the registry-flooding
--           abort of 1.8.0 is structurally impossible. Verified offline first (see the block at the bottom): both
--           UFunctions and all three variables are real in the cooked packages. See CHANGELOG v1.28.16.
--   (1.8.1) THE VAULT SABER FIX OF 1.8.0 IS WITHDRAWN. It hooked BP_FX_LightSaber_Base_C's Deactivate, and because that
--           Blueprint is not loaded at the main menu the arming loop RETRIED RegisterHook every 5 s. Registration never
--           succeeded, the retries piled bad entries into UE4SS's Lua function registry, and the game aborted 175 s in at
--           the main menu ('[Lua::Registry::get_function_ref] Ref was not function', retail 2026-09-10 05:46).
--           LESSON: RegisterHook is NOT retry-safe — register once, from a callback that fires when the class actually
--           exists (NotifyOnNewObject), never on a timer. The diagnosis of the vault bug itself still stands (see
--           CHANGELOG v1.28.4): the saber actor caches `Cached Humanoid ABP` / `bIsActive` /
--           `bSaberAutoActivateForCombat`, which is everything the fix needs — only the ARMING has to be redone.
--   (1.7.0) the recruit-pin loop no longer sweeps EVERY object twice, every 3 s, in every world, for as long as a pin exists.
--           It used to run unchanged inside tactical missions, where nothing can be pinned — 2 x FindAllOf on the game thread
--           forever. Two guards: the expensive CustomizationFragmentInstanceSlot sweep runs only when there is something to
--           pin, and the loop backs off 3 -> 6 -> 12 -> 24 s while nothing changes, resetting on a world change or a pin.
--           (Found chasing a GameThread HANG inside UE4SS's Lua, 2026-09-09/10: same stack in HUB_Root and in a Ryloth
--           mission, ~29 min in each time. Not proven to be the cause — but an unbounded per-frame object sweep on the game
--           thread is a defect either way, and it is the only thing this runtime does forever.)
--   (1.6.0) manifests are also discovered in SWZeroCompany/Mods/<Mod>/ (the game's own mod layout, SDK "gfp"): their registry is the
--           plugin's (not injected); refreshers, follow-ups, recruit pins, grants, rescans apply. Needs bridge 0.5.3 (depth-1 scan).
--   (1.5.0) recruitPins[].match = { slot=, part= }: pins also apply to live characters identified by a slot holding a part (a recruited
--   character carries no CustomizationDefinition, so `definition` alone never reaches it after recruitment).
--   5. (1.4.0) recruit pins: keeps the listed customization slots of every live character spawned from a manifest's
--      CustomizationDefinition set to the listed parts (the game re-rolls a pool recruit's specialization / weapon on every
--      Recruitment refresh) — see applyRecruitPins.
--   3d. runs each manifest's `refreshers` (native calls on live objects: data registries re-scan the injected registry) and the
--       game-specific follow-ups (character pools re-created; 1.3.0, bridge 0.5 `callfname`),
--
-- What it does, once the main-menu world is up:
--   1. arms the bridge (writes the PrintString trigger address to ue4ss/ZCSDKBridge.ctl),
--   2. discovers content-mod manifests  <Mod>.zcsdk.lua  in Content/Paks and Content/Paks/~mods,
--   3. ROUTE B: injects each mod's <Mod>.AssetRegistry.bin into the live asset registry (enumeration),
--   3b. preloads each manifest's `preload` packages (net-new classes resident like the game's own; 1.2.0),
--   3c. rescans each manifest's `primaryTypes` and refreshes the game's per-type caches (1.1.0),
--   4. when a campaign HQ inventory exists, grants each manifest's `grants` items ONCE per save
--      (skipped if the save has ever owned the item), so net-new items show up in the armory/inventory.
--
-- Manifest (emitted by zcmod-build.js next to the pak trio):
--   return { name = "My Mod", version = "1.0.0", registry = "MyMod.AssetRegistry.bin",
--            primaryTypes = { { type = "CustomizationPartDefinition", path = "/Game/ZCSDK", class = "...", blueprintClasses = false } },
--            preload = { "/Game/ZCSDK/GA_MyPassive" },
--            grants = { { item = "/Game/ZCSDK/DA_X.DA_X", amount = 1 } } }
-- Log: ue4ss/ZCSDKLoader.log. Bridge log: ue4ss/ZCSDKBridge.log.
local UEHelpers = require("UEHelpers")

-- SDK dev builds only: also dump item properties (the real scope mod + ours) for schema comparison.
-- Leave OFF for players: reading a TSoftObjectPtr property of a freshly loaded net-new item through
-- UE4SS's Lua binding crashed the game (null deref inside UE4SS.dll, 2026-09-04) — soft props are now
-- skipped in dumpObject, but the dump is diagnostics, not a feature.
local DIAG = false

-- ---- paths (relative to the game's Binaries/Win64; the bridge resolves $paks / $mods itself) ----
local function detectWin64()
    local ok, p = pcall(function() local h = io.popen("cd"); local d = h:read("*l"); h:close(); return d end)
    if ok and p and p ~= "" then
        p = p:gsub("\\", "/")
        local f = io.open(p .. "/ue4ss/UE4SS-settings.ini", "r"); if f then f:close(); return p end
    end
    return "G:/SteamLibrary/steamapps/common/Star Wars Zero Company/SWZeroCompany/Binaries/Win64"
end
local WIN64 = detectWin64()
local UE4SS = WIN64 .. "/ue4ss/"
local LOGFILE = UE4SS .. "ZCSDKLoader.log"

local function log(m)
    local line = "[ZCSDKLoader] " .. tostring(m); print(line .. "\n")
    local f = io.open(LOGFILE, "a"); if f then f:write(os.date("%H:%M:%S ") .. line .. "\n"); f:close() end
end
local function bridge(cmd)
    log("BRIDGE> " .. cmd)
    local ok, err = pcall(function()
        UEHelpers.GetKismetSystemLibrary():PrintString(UEHelpers.GetWorld(), cmd, false, false, {R=1,G=1,B=1,A=1}, 0.0, FName("None"))
    end)
    if not ok then log("bridge call failed: " .. tostring(err)) end
end
local function setTrigger()
    local fn = StaticFindObject("/Script/Engine.KismetSystemLibrary:PrintString")
    if not (fn and fn:IsValid()) then log("PrintString UFunction not found"); return false end
    local f = io.open(UE4SS .. "ZCSDKBridge.ctl", "w"); if not f then log("cannot write ZCSDKBridge.ctl"); return false end
    f:write(string.format("trigger=%x\n", fn:GetAddress())); f:close()
    log(string.format("trigger @ 0x%x", fn:GetAddress()))
    return true
end
local function readLines(path)
    local out = {}
    local f = io.open(path, "r"); if not f then return out end
    for line in f:lines() do line = line:gsub("^\239\187\191", ""):gsub("[\r\n]+$", ""); if line ~= "" then out[#out + 1] = line end end
    f:close(); return out
end
local function dirOf(p) return (p:match("^(.*)/[^/]*$")) or "." end

-- ---- diagnostics: dump every reflected property of an object (class chain), one level into arrays/objects ----
local function fmtValue(v, depth)
    if type(v) ~= "userdata" then return tostring(v) end
    local ok, s
    ok, s = pcall(function() return v:GetFullName() end); if ok and type(s) == "string" then return s end
    ok, s = pcall(function() return v:ToString() end); if ok and type(s) == "string" then return s end
    if depth < 1 then
        local items = {}
        local okArr = pcall(function() v:ForEach(function(i, e)
            local ev = e; pcall(function() ev = e:get() end)
            items[#items + 1] = fmtValue(ev, depth + 1)
        end) end)
        if okArr and #items > 0 then return "[" .. table.concat(items, ", ") .. "]" end
        local okTags = pcall(function() v.GameplayTags:ForEach(function(i, e)
            local t = e:get(); items[#items + 1] = t.TagName:ToString()
        end) end)
        if okTags and #items > 0 then return "{tags: " .. table.concat(items, ", ") .. "}" end
    end
    return "<" .. tostring(v) .. ">"
end
-- 1.8.9 (the 2026-09-12 crash analysis): UE4SS's `GetClass` / `GetFName` bindings do NOT test validity - they read
-- [obj+0x10] (UObjectBase::ClassPrivate) straight off the pointer, so calling either on a null/stale UObject is a
-- native access violation that `pcall` CANNOT catch (it is a hardware fault, not a Lua error). `IsValid()` is a pure
-- [obj+0x70] != 0 test and is the only safe thing to ask first; `GetFullName()` is guarded internally and returns nil.
-- Two game crashes in that session came from exactly this shape in ZCSDK_FocusProbe. RULE: IsValid, then GetClass.
local function uvalid(o)
    if o == nil then return false end
    local t = type(o)
    if t ~= "userdata" and t ~= "table" then return false end
    local ok, r = pcall(function() return o.IsValid and o:IsValid() end)
    return (ok and r) and true or false
end
local function dumpObject(obj, label, depth)
    depth = depth or 0
    if not uvalid(obj) then log(label .. ": object not valid (GetClass would fault)"); return end
    local okc, cls = pcall(function() return obj:GetClass() end)
    if not okc or not uvalid(cls) then log(label .. ": no class"); return end
    log(label .. "  class=" .. cls:GetFullName() .. "  obj=" .. obj:GetFullName())
    local c = cls
    local subobjects = {}
    while uvalid(c) do
        local okp, errp = pcall(function()
            c:ForEachProperty(function(prop)
                if not uvalid(prop) then log(string.rep("  ", depth + 1) .. "<invalid FProperty skipped>"); return end
                local name = ""; pcall(function() name = prop:GetFName():ToString() end)
                if name == "" then log(string.rep("  ", depth + 1) .. "<unnamed FProperty skipped>"); return end
                local pcls = ""
                pcall(function() local pc = prop:GetClass(); if uvalid(pc) then pcls = pc:GetFName():ToString() end end)
                if pcls:find("Soft") then log(string.rep("  ", depth + 1) .. name .. " = <" .. pcls .. " skipped>"); return end
                local ok, v = pcall(function() return obj[name] end)
                local s = ok and fmtValue(v, 0) or ("<err " .. tostring(v) .. ">")
                log(string.rep("  ", depth + 1) .. name .. " = " .. s)
                if ok and depth == 0 and type(v) == "userdata" then
                    pcall(function() v:ForEach(function(i, e)
                        local ev = e; pcall(function() ev = e:get() end)
                        if uvalid(ev) and pcall(function() return ev:GetClass() end) then subobjects[#subobjects + 1] = { ev, name .. "[" .. tostring(i) .. "]" } end
                    end) end)
                end
            end)
        end)
        if not okp then log("  (ForEachProperty failed on " .. tostring(c:GetFullName()) .. ": " .. tostring(errp) .. ")") end
        local oks, sup = pcall(function() return c:GetSuperStruct() end)
        c = oks and sup or nil
    end
    for _, so in ipairs(subobjects) do pcall(dumpObject, so[1], string.rep("  ", depth + 1) .. so[2], depth + 1) end
end

-- ---- manifests + registries ----
local manifests = {}   -- { path=, dir=, m=table }
local grants = {}      -- { item=, amount=, from=, done=bool }
local recruitPins = {} -- 1.4.0: { definition=<CustomizationDefinition object path>, slots={ {tag=, part=<part object path>} }, from= }
local injected = false
local function discover()
    -- 1.6.0: "$gamemods" = SWZeroCompany/Mods/<Mod>/ (the game's own layout, SDK v1.21.0 "gfp"; each manifest one folder down, hence the
    -- bridge's depth-1 scan, v0.5.3). A gfp mod's registry is the plugin's own (loaded by the game) — never injected here; its refreshers,
    -- follow-ups (the recruit pool re-run), recruit pins, grants and primary-type rescans apply as for any manifest.
    for _, root in ipairs({ "$paks", "$mods", "$gamemods" }) do
        local gfp = (root == "$gamemods")
        bridge("ZCSDK:scan|" .. root .. "|*.zcsdk.lua" .. (gfp and "|1" or ""))
        for _, p in ipairs(readLines(UE4SS .. "ZCSDKBridge.scan")) do
            local ok, m = pcall(dofile, p)
            if ok and type(m) == "table" then
                manifests[#manifests + 1] = { path = p, dir = dirOf(p), m = m, gfp = gfp }
                log("manifest: " .. p .. "  (" .. tostring(m.name) .. " v" .. tostring(m.version) .. (gfp and ", gfp: registry is the plugin's" or "") .. ")")
                for _, g in ipairs(m.grants or {}) do
                    if type(g.item) == "string" then grants[#grants + 1] = { item = g.item, amount = tonumber(g.amount) or 1, from = tostring(m.name), done = false } end
                end
                for _, rp in ipairs(m.recruitPins or {}) do   -- 1.4.0; 1.5.0 adds `match = { slot=, part= }`
                    local match = (type(rp.match) == "table" and type(rp.match.slot) == "string" and type(rp.match.part) == "string") and { slot = rp.match.slot, part = rp.match.part } or nil
                    if (type(rp.definition) == "string" or match) and type(rp.slots) == "table" then
                        local slots = {}
                        for _, s in ipairs(rp.slots) do if type(s.tag) == "string" and type(s.part) == "string" then slots[#slots + 1] = { tag = s.tag, part = s.part } end end
                        recruitPins[#recruitPins + 1] = { definition = rp.definition, match = match, slots = slots, from = tostring(m.name) }
                        log("recruit pins: " .. (rp.definition and rp.definition:match("([^/]+)$") or "-") .. (match and (" | " .. match.slot:match("([^.]+)$") .. "=" .. match.part:match("([^/.]+)$")) or "") .. " -> " .. #slots .. " slot(s) (" .. tostring(m.name) .. ")")
                    end
                end
            else
                log("manifest failed: " .. p .. " -> " .. tostring(m))
            end
        end
    end
    log(#manifests .. " manifest(s), " .. #grants .. " grant(s)")
end
local function injectRegistries()
    for _, mf in ipairs(manifests) do
        if type(mf.m.registry) == "string" and not mf.gfp then   -- 1.6.0: a gfp mod's registry is loaded by the game itself
            local reg = mf.m.registry:match("^%a:/") and mf.m.registry or (mf.dir .. "/" .. mf.m.registry)
            local probe = (mf.m.grants and mf.m.grants[1] and mf.m.grants[1].item) or ""
            bridge("ZCSDK:injreg|" .. reg .. "|" .. probe)
        end
    end
    injected = true
end
-- Preload (loader 1.2.0 / runtime 0.5): a manifest may list packages to LoadPackage right after the registries are injected —
--   preload = { "/Game/ZCSDK/GA_ZCSDK_LongStride", ... }
-- OPT-IN (mod-def `preload: true` or an explicit list); zcmod-build then lists the mod's blueprints[] class packages. The idea:
-- the game's own ability classes are resident at startup, so systems that resolve soft class refs and seed derived data in ONE
-- pass see every stock tier synchronously, while a net-new class arrives through an async soft-class load a moment later.
-- CORRECTED v1.28.21: this comment used to present the Focus tree's empty row as the motivating case. **It is not** — v1.11.0
-- tested preload against exactly that symptom and RULED IT OUT (the note survives in zcmod-build.js, and the two comments
-- disagreed for ten versions). The real gate was found in v1.28.21: `FocusUpgradesConfiguration`, a
-- TMap<FGameplayTag, FFocusPointLevelThresholds> keyed by br.AbilityID.*, in which a net-new ability simply had no entry, so
-- the tree drew its rails and no nodes. Fixed by OVERRIDING that asset (sith_class_mod.json). Preload remains available and
-- off by default, for content a synchronous startup pass must genuinely see.
local function preloadPackages()
    local n = 0
    for _, mf in ipairs(manifests) do
        for _, p in ipairs(mf.m.preload or {}) do
            if type(p) == "string" and p:sub(1, 1) == "/" then bridge("ZCSDK:loadpkg|" .. p); n = n + 1 end
        end
    end
    if n > 0 then log("preload requested for " .. n .. " package(s)") end
end
-- Primary-asset rescan: the asset manager built its primary-asset map at startup (ScanPathsForPrimaryAssets over the
-- registry); an injected registry does not update it. A manifest lists the primary asset types it ships —
--   primaryTypes = { { type = "CustomizationPartDefinition", path = "/Game/ZCSDK", class = "/Script/BitReactorCore.CustomizationPartDefinition" } }
-- and the bridge rescans that type over that path (the customization part picker, classes, missions... enumerate this way).
local function rescanPrimaryTypes()
    local n = 0
    for _, mf in ipairs(manifests) do
        for _, pt in ipairs(mf.m.primaryTypes or {}) do
            if type(pt.type) == "string" and type(pt.path) == "string" then
                bridge("ZCSDK:rescan|" .. pt.type .. "|" .. pt.path .. "|" .. tostring(pt.class or "") .. "|" .. tostring(pt.blueprintClasses and 1 or 0))
                n = n + 1
            end
        end
    end
    if n > 0 then log("primary-asset rescan requested for " .. n .. " type(s)") end
end
-- Per-type cache refreshers: the game keeps its own per-type caches built from the primary-asset list at startup; a
-- rescan alone does not reach them. Each entry names the subsystem object to find and the nullary native method the
-- bridge calls on it (`callthis`, bridge v0.4). Found via tools/recon/pdbsyms.py `calls`:
--   CustomizationPartDefinition -> UCustomizationPartsTagSubsystem (EngineSubsystem) caches a tag -> parts map that
--   UCustomizationStatics::GetCustomizationPartIds (the customizer's part picker) reads; BuildPartTagMaps() rebuilds it
--   (the same thing the game does on HandleAssetAdded / HandlePakFileMounted).
local REFRESHERS = {
    CustomizationPartDefinition = { { find = "CustomizationPartsTagSubsystem", sym = "?BuildPartTagMaps@UCustomizationPartsTagSubsystem@@AEAAXXZ" } },
}
local function refreshCaches()
    local done = {}
    for _, mf in ipairs(manifests) do
        for _, pt in ipairs(mf.m.primaryTypes or {}) do
            for _, r in ipairs(REFRESHERS[tostring(pt.type)] or {}) do
                local key = r.find .. r.sym
                if not done[key] then
                    done[key] = true
                    local ok, obj = pcall(FindFirstOf, r.find)
                    if ok and obj and obj:IsValid() then
                        bridge(string.format("ZCSDK:callthis|%s|%x", r.sym, obj:GetAddress()))
                        log("cache refresh: " .. r.find .. " -> " .. r.sym)
                    else
                        log("cache refresh: " .. r.find .. " not found (skipped " .. r.sym .. ")")
                    end
                end
            end
        end
    end
end

-- Manifest refreshers (loader 1.3.0 / runtime 0.6): a manifest may list native calls to make on live objects after the injection +
-- rescan, when the game built something from the asset registry ONCE at startup that no rescan reaches:
--   refreshers = { { find = "CharacterPoolDataRegistry", name = "DR_InitialCharacterPool", sym = "?RefreshRuntimeSources@UDataRegistry@@MEAAXXZ" }, ... }
--   find = the UE4SS class name to FindAllOf, name = the object's short name (optional: first live instance), sym = a nullary method
--   (bridge callthis) or, with fname = "<Name>", a void(const FName&) method (bridge callfname, v0.5).
-- zcmod-build emits one for every DataRegistry-derived asset a mod appends to (the registry's meta sources re-scan the asset registry,
-- which now holds the mod's tables). FOLLOWUPS adds what the game then has to redo: the character pools are created once in
-- UBitReactorCharacterPoolManager::OnDataRegistrySubsystemInitialized (tools/recon/pdbsyms.py callers), so after DR_InitialCharacterPool
-- is refreshed the pool creation is re-run for that registry type. NOT idempotent by itself (SDK v1.12.0 retail, PoolVerifier round 2):
-- CreateNewCharacterPool always AddDefaulted()s a fresh FCharacterPoolData onto CharacterPools, then the async acquire callback files the
-- registry's characters into the FIRST pool of that name — so a re-run fills the original pool and leaves an EMPTY duplicate at the END of
-- the array. `dedupe` (1.3.1, bridge 0.5.1 `arrpop`) pops that trailing duplicate right after the call: only when >= 2 pools carry the
-- name, the last one is one of them and it holds no characters; the element is destructed by the game's own ~FCharacterPoolData.
-- CreatePreAuthoredCharacterPool(const FName& RegistryType, const ECharacterPoolType& PoolType): the pool type rides as `arg` (an integer the
-- bridge passes by const reference; 6 = InitialCharacterPool, 7 = EnemyCharacterPool — the values the manager's pools report).
local CPACP = "?CreatePreAuthoredCharacterPool@UBitReactorCharacterPoolManager@@AEAAXAEBVFName@@AEBW4ECharacterPoolType@@@Z"
local POOLS = { prop = "CharacterPools", offset = 328, elemSize = 120, dtor = "??1FCharacterPoolData@@QEAA@XZ" }   -- jmap: UBitReactorCharacterPoolManager.CharacterPools @ 328, FCharacterPoolData 120 bytes
local FOLLOWUPS = {
    DR_InitialCharacterPool = { find = "BitReactorCharacterPoolManager", sym = CPACP, fname = "InitialCharacterPool", arg = 6, dedupe = POOLS },
    DR_EnemyCharacterPool   = { find = "BitReactorCharacterPoolManager", sym = CPACP, fname = "EnemyCharacterPool", arg = 7, dedupe = POOLS },
}
-- After a pool re-run: drop the empty duplicate pool entry named `poolName` if it sits at the END of obj.<d.prop> (see FOLLOWUPS).
local function dedupeTrailingPool(obj, d, poolName, tag)
    local ok, err = pcall(function()
        local arr = obj[d.prop]
        local n = arr:GetArrayNum()
        if n < 2 then return end
        local firstIdx, lastName, lastCount = nil, nil, 0
        arr:ForEach(function(i, e)
            local p = e:get()
            local nm = ""; pcall(function() nm = p.CharacterPoolName:ToString() end)
            if nm == poolName and not firstIdx then firstIdx = i end
            if i == n then lastName = nm; pcall(function() p.Characters:ForEach(function() lastCount = lastCount + 1 end) end) end
        end)
        if lastName ~= poolName or not firstIdx or firstIdx == n then log(tag .. ": no trailing duplicate pool (" .. n .. " pools)"); return end
        if lastCount > 0 then log(tag .. ": trailing pool '" .. poolName .. "' holds " .. lastCount .. " character(s) — kept"); return end
        local addr = nil
        pcall(function() addr = arr:GetArrayAddress() end)                     -- UE4SS TArray API, when available
        if type(addr) ~= "number" or addr == 0 then addr = obj:GetAddress() + d.offset end   -- else the owner + the property's jmap offset
        bridge(string.format("ZCSDK:arrpop|%x|%d|%s|%d", addr, d.elemSize, d.dtor, n))
        log(tag .. ": popped the empty duplicate pool '" .. poolName .. "' (entry " .. n .. " of " .. n .. "; first '" .. poolName .. "' is entry " .. firstIdx .. ")")
    end)
    if not ok then log(tag .. ": dedupe failed: " .. tostring(err)) end
end
local function findLive(className, shortName)
    local ok, list = pcall(FindAllOf, className)
    if not ok or not list then return nil end
    for _, o in ipairs(list) do
        if o and o:IsValid() then
            local full = o:GetFullName()
            if not full:find("Default__") and (not shortName or full:find("[%.:]" .. shortName .. "$") or full:find("[%.:/]" .. shortName .. "[%.:]")) then return o end
        end
    end
    return nil
end
local function runRefresher(r, tag)
    if type(r) ~= "table" or type(r.find) ~= "string" or type(r.sym) ~= "string" then return end
    local obj = findLive(r.find, r.name)
    if not obj then log(tag .. ": " .. r.find .. (r.name and (" '" .. r.name .. "'") or "") .. " not found (skipped " .. r.sym .. ")"); return end
    -- assets = registry-resolved asset paths to hand to a DataRegistry first (UDataRegistry::RegisterSpecificAsset via bridge `dtreg`):
    -- its meta sources create a child source per registered table, no path search involved
    for _, a in ipairs(r.assets or {}) do
        bridge(string.format("ZCSDK:dtreg|%x|%s", obj:GetAddress(), a))
        log(tag .. ": registered " .. a .. " with " .. (r.name or r.find))
    end
    if type(r.fname) == "string" and r.fname ~= "" then
        if r.arg ~= nil then bridge(string.format("ZCSDK:callfname|%s|%x|%s|%d", r.sym, obj:GetAddress(), r.fname, tonumber(r.arg)))
        else bridge(string.format("ZCSDK:callfname|%s|%x|%s", r.sym, obj:GetAddress(), r.fname)) end
    else
        bridge(string.format("ZCSDK:callthis|%s|%x", r.sym, obj:GetAddress()))
    end
    log(tag .. ": " .. r.find .. (r.name and (" '" .. r.name .. "'") or "") .. " -> " .. r.sym .. (r.fname and (" (" .. r.fname .. ")") or ""))
    if type(r.dedupe) == "table" and type(r.fname) == "string" then dedupeTrailingPool(obj, r.dedupe, r.fname, tag) end
end
local followups = {}
local function applyRefreshers()
    local n = 0
    for _, mf in ipairs(manifests) do
        for _, r in ipairs(mf.m.refreshers or {}) do
            runRefresher(r, "refresh"); n = n + 1
            local f = r.name and FOLLOWUPS[r.name]
            if f and not followups[r.name] then followups[r.name] = f end
        end
    end
    if n > 0 then log("refreshers: " .. n .. " requested") end
end
local function applyFollowups()
    for name, f in pairs(followups) do runRefresher(f, "follow-up for " .. name) end
end

-- ---- grants: once per save, when an HQ inventory exists ----
local statics = nil
local function findHQ()
    local ok, hq = pcall(FindFirstOf, "BrunoHQInventory")
    if ok and hq and hq:IsValid() and not hq:GetFullName():find("Default__") then return hq end
    return nil
end
local function applyGrants()
    local pending = 0
    for _, g in ipairs(grants) do if not g.done then pending = pending + 1 end end
    if pending == 0 then return true end
    local hq = findHQ(); if not hq then return false end
    if not statics then
        local s = StaticFindObject("/Script/Bruno.Default__BrunoGameStatics")
        if s and s:IsValid() then statics = s else log("BrunoGameStatics CDO not found"); return false end
    end
    for _, g in ipairs(grants) do
        if not g.done then
            local item = StaticFindObject(g.item)
            if not (item and item:IsValid()) then
                log("grant: loading " .. g.item); pcall(LoadAsset, g.item)   -- registry-resolved (works after injection); async -> retry next tick
                local pkg = g.item:match("^(.-)%.[^%.]+$"); if pkg then bridge("ZCSDK:loadpkg|" .. pkg) end
            else
                local okH, owned = pcall(function() return hq:HasEverOwnedItem(item) end)
                if okH and owned then
                    log("grant: " .. g.item .. " already owned by this save (skip)")
                else
                    local okG, err = pcall(function() statics:GrantItem(hq, item, g.amount) end)
                    log("grant: " .. g.item .. " x" .. g.amount .. " (" .. g.from .. ") -> " .. (okG and "GRANTED" or ("failed: " .. tostring(err))))
                    if DIAG and okG then pcall(dumpObject, item, "granted item") end
                end
                g.done = true
            end
        end
    end
    return false
end

-- ---- recruit pins (loader 1.4.0 / runtime 0.7; the ORDER + the TOGGLE in 1.8.18, the dead experiments cut in 1.8.19) ----
-- A pre-authored recruit's Specializations slots (tactical spec, weapon class...) are RE-ROLLED by the game on every Recruitment refresh
-- (UBitReactorGameStatics_Spawn::SpawnCharacter -> UCustomizationStatics::Randomize over the spawn params' slots; nothing data-side
-- survives it — docs/NETNEW_CLASS.md). The spawn is native (no ProcessEvent to hook), so the pin is a poll: every few seconds, every live
-- CustomizationInstance whose default CustomizationDefinition is a manifest's `recruitPins[].definition` gets the listed slots equipped
-- with the listed parts and its customization refreshed. Slot instances are matched to their instance by full-name prefix (the SlotProbe
-- technique); a fragment's TSoftObjectPtr is never read from Lua (that crashed the game in v1.3.0).
--
-- 1.8.9's SUCCESS CRITERION, which 1.8.19 keeps because it is the thing the pin still judges by: a slot counts as
-- equipped when its FragmentInstances are REPLACED (object identity) or it gains LeveledAbilities /
-- LoadedLeveledAbilities entries. `CustomizationPartDefinition` is NOT a criterion in either direction - the game's own
-- CPD_TalentSpec_TheToughGuy reads partDefinition=<null> with one leveled tree and draws a full row, and the id-only
-- setter resolves a definition by itself once the asset is resident.
--
-- 1.8.9's THIRD correction, also kept: in a MISSION the characters are rebuilt from save data and the game re-equips
-- them during load (21:28:27 vs 21:28:30), so a pin there can only write the id; PIN_STRATEGY_ONLY logs that once.
--
-- WHAT 1.8.19 DELETED, AND WHY IT IS NOT COMING BACK. Loader 1.8.8-1.8.17 tried to reach the fragment-carrying
-- `...WithFragments` sibling through UCustomizationStatics::EquipCustomizationDefinition (shapes `allowed` / `tags` /
-- `all`) and ::EquipCustomizationParts (shapes `struct` / `table`), judged by an `arrival` observable, and probed the
-- AssetManager through UKismetSystemLibrary. Retail 2026-09-13 09:04:40 settled it: the PLAIN 1.4.0 setter
-- `UCustomizationFragmentInstanceSlot::SetCustomizationPartPrimaryAssetId` (RVA 0x8c54660) delivered the Sith's two
-- leveled trees, because `LoadCustomization` rebuilds the fragment instances on an id CHANGE once the part is
-- resident. The equip routes cost two sessions: an EMPTY AllowedSlots container means "every slot this definition
-- names", so equipping the Class part through it re-created the character's own child slots twice (07:52:26,
-- 09:04:44). All of it is deleted. The sequence that WORKS is below: residency first, then Class to completion, then
-- Weapon, then Tactical, toggling through a vanilla id, delivered-is-final.
local PIN_MAX_RETRY = 4           -- re-equips of a slot that holds our id but never took a fragment instance
local PIN_RESIDENCY_PASSES = 12   -- 1.8.19: passes `done` is held while a pinned part is still loading (~60 s at the
                                  -- 5 s cadence). BOUNDED on purpose: an unbounded pin loop is the 05:43 crash.
local PIN_STRATEGY_ONLY = true    -- 1.8.19: now only an OBSERVABILITY gate — it logs, once, that this world is not the
                                  -- hub, so a pass that changes nothing in a mission is never a silent one
-- what to TOGGLE a slot through when it already holds our part but never took its fragments. The vanilla id the slot
-- itself carried is preferred and remembered per slot; these are the fallbacks, read off other characters in the same
-- hub (retail 08:41/09:04 BEFORE lines).
local PIN_TOGGLE_DEFAULT = {
    ["br.Customization.Slot.Character.Class"] = "CPD_Char_Class_Hero_Humanoid",
    ["br.Customization.Slot.Character.Specializations.Weapon"] = "CPD_WeaponSpec_Blaster_Longarm",
    ["br.Customization.Slot.Character.Specializations.Tactical.Primary"] = "CPD_TacticalSpec_Assault",
}
local PIN_TOGGLE_PATH = {
    CPD_Char_Class_Hero_Humanoid = "/Game/Game/Customizations/Characters/Common/CharacterClass/CPD_Char_Class_Hero_Humanoid.CPD_Char_Class_Hero_Humanoid",
    CPD_WeaponSpec_Blaster_Longarm = "/Game/Game/Customizations/Characters/Common/Specialization/Weapon/CPD_WeaponSpec_Blaster_Longarm.CPD_WeaponSpec_Blaster_Longarm",
    CPD_TacticalSpec_Assault = "/Game/Game/Customizations/Characters/Common/Specialization/Tactical/CPD_TacticalSpec_Assault.CPD_TacticalSpec_Assault",
}

local pinLoadRequested = false
local pinLog = {}
local pinArmed = {}          -- function name -> true, so "hook armed on <fn>" is logged once (session_audit.py vocabulary)
local pinAttempts = {}       -- owner|tag -> re-equips spent on a slot that never took a fragment
local criterionLogged = false
local pinExpected = {}       -- 1.8.18: owner|tag -> this pin wants this slot; `done` means all of them delivered
local pinDelivered = {}      -- 1.8.18: owner|tag -> this slot has delivered; never drive it again
local pinToggled = {}        -- 1.8.18: owner|tag -> the pass a toggle id was written, so ours goes back next pass
local pinVanilla = {}        -- 1.8.18: owner|tag -> the non-ours part this slot was last seen holding
local pinQuiet = {}          -- 1.8.18: one-shot log keys
local pinGaveUp = {}         -- owner|tag -> the give-up message has been logged once (1.8.10)
local pinWaited = 0          -- 1.8.19: passes spent holding `done` while a pinned part was still not resident
-- 1.8.14: a preview/portrait proxy is a TRANSIENT actor the game destroys and recreates while Personnel is open. The
-- 05:43 session re-drove BP_CustomizationProxyCharacter_C_1 nine times and C_0 three times, every pass, forever -
-- pointless (they are previews, not the saved character) and the likeliest source of a stale userdata. Never again.
local PIN_PROXY_PATTERNS = { "CustomizationProxyCharacter", "CustomizationPreviewProxyCharacter",
                             "BrunoPortraitCharacter", "PortraitCharacter", "BP_PreviewActor" }
local function isProxyOwner(p)
    for _, pat in ipairs(PIN_PROXY_PATTERNS) do if p:find(pat, 1, true) then return pat end end
    return nil
end
local pinKnown = {}          -- 1.8.15: instance path -> how it was identified; identity is sticky for the session
local pinDone = false        -- 1.8.14: every pinned slot on every real character is settled; the loop stops
local pinSkipLogged = {}     -- owner -> the skip reason has been logged once this session (1.8.11)
local pinRefused = {}        -- instance path -> already logged a refusal (1.8.10)
local scopeLogged = false

local function shortTag(t) return (tostring(t):gsub("^br%.Customization%.Slot%.Character%.", "")) end
local function shortOwner(o) return (tostring(o):gsub("^.*PersistentLevel%.", ""):gsub("%..*$", "")) end

-- session_audit.py reads "hook armed on <fn>" as an arming and "PATH> <fn>" as a firing (tools/session_audit.py:203/206).
-- Arming is therefore logged at the point the route is CHOSEN, and PATH> immediately BEFORE the call, so "armed and never
-- fired" can only ever mean "the loader decided to use it and never got as far as calling it".
local function pinArm(fn, why)
    if pinArmed[fn] then return end
    pinArmed[fn] = true
    log("recruit pin: hook armed on " .. fn .. (why and (" (" .. why .. ")") or ""))
end

-- v1.28.32's lesson, applied here too: GetFullName() on an invalid world returns nil WITHOUT raising, so the TYPE of the
-- result is what gets tested, never the pcall's ok.
local function pinWorldName()
    local n = nil
    pcall(function() n = UEHelpers.GetWorld():GetFullName() end)
    return (type(n) == "string" and n ~= "") and n or "<none>"
end
local function strategySide()
    local w = pinWorldName()
    return (w:find("HUB_Root", 1, true) ~= nil), w
end

-- The probe's reading (ZCSDK_FocusProbe/Scripts/main.lua:147 dumpOwningSlot / :161 dumpLeveledInstance), plus the two numbers
-- that actually decide it: the fragment instances' OBJECT IDENTITIES and their leveled-ability counts.
local function fragState(s)
    local names, trees, loaded = {}, 0, 0
    pcall(function()
        s.FragmentInstances:ForEach(function(_, e)
            local fi = e
            local okG, g = pcall(function() return e:get() end)
            if okG and g then fi = g end
            -- 1.8.9: IsValid before anything else. GetFullName is internally guarded (it returns nil on a dead
            -- object), but a PROPERTY read on one is not, and a native access violation is not pcall-catchable.
            if not (fi and fi.IsValid and pcall(function() return fi:IsValid() end) and fi:IsValid()) then
                names[#names + 1] = "<invalid>"; return
            end
            local n = nil
            pcall(function() n = fi:GetFullName() end)
            names[#names + 1] = (type(n) == "string") and n or "<?>"
            pcall(function() fi.LeveledAbilities:ForEach(function() trees = trees + 1 end) end)
            pcall(function() fi.LoadedLeveledAbilities:ForEach(function() loaded = loaded + 1 end) end)
        end)
    end)
    return table.concat(names, ";"), #names, trees, loaded
end

local function slotState(s)
    local st = { id = "?", defn = "<null>" }
    pcall(function()
        local p = s.CustomizationPartPrimaryAssetId
        st.id = tostring(p.PrimaryAssetType.Name:ToString()) .. ":" .. tostring(p.PrimaryAssetName:ToString())
    end)
    pcall(function()
        local d = s.CustomizationPartDefinition
        if d and d.IsValid and d:IsValid() then st.defn = (d:GetFullName():gsub("^[^ ]+ ", ""):gsub("^.*[/%.]", "")) end
    end)
    st.frags, st.nfrag, st.trees, st.loaded = fragState(s)
    return st
end

local function sigOf(st)
    return string.format("partId=%s | partDefinition=%s | %d fragment instance(s) | %d leveled tree(s) | %d loaded tree(s)",
        st.id, st.defn, st.nfrag, st.trees, st.loaded)
end

-- THE CRITERION. Not "did the definition resolve" (both doors can do that, and neither has to) — "did a fragment instance move".
local function deliveredTo(before, after)
    if after.frags ~= before.frags then return true, "FragmentInstances REPLACED" end
    if after.trees > before.trees then return true, "leveled trees " .. before.trees .. " -> " .. after.trees end
    if after.loaded > before.loaded then return true, "loaded trees " .. before.loaded .. " -> " .. after.loaded end
    if after.id ~= before.id then return false, "partId changed and the fragment instances did not — the id-only signature" end
    return false, "nothing on the slot changed"
end

local function logCriterion()
    if criterionLogged then return end
    criterionLogged = true
    log("recruit pin: success criterion = the slot's FragmentInstances are REPLACED (object identity) or it gains " ..
        "LeveledAbilities / LoadedLeveledAbilities entries. CustomizationPartDefinition is NOT a criterion: the game's own " ..
        "CPD_TalentSpec_TheToughGuy reads partDefinition=<null> with 1 leveled tree and draws a full row, and the id-only setter " ..
        "resolves a definition by itself once the asset is resident.")
end

-- ---- 1.8.19: THE GHOST REFUSAL (HANDOFF open items 3 and 7) ----
-- A save can carry a part id from a mod that is NO LONGER INSTALLED. Hawks' save does: a `ZCSDKLongStride` leveled
-- tree whose tier classes are all null, left behind by the uninstalled ZCSDK_Passive (CHANGELOG v1.28.32), and the
-- 2026-09-12 turn-end block is the INFERRED consequence — four launches with the runtime OFF (eight mods / one / none)
-- all blocked after a vault, and a fresh mission with no mods was clean. Writing over a slot in that state is the last
-- thing a loader should do: it cannot know what else in the save refers to it. So the loader REPORTS the ghost and
-- REFUSES to drive that slot, on ANY character in the hub, ours or not. Nothing is ever written by this code.
--
-- WHAT COUNTS AS A GHOST — all three, so the normal 1.8.18 toggle case can never be mistaken for one:
--   (1) the slot carries one of THIS pin's declared tags (so the sweep is bounded), and
--   (2) its part id is NOT carried by any CURRENTLY ENUMERATED manifest — the loader has just discovered every
--       `<Mod>.zcsdk.lua` on disk, so "not in that set" means "no installed mod ships this part"; a slot holding OUR
--       id is in that set BY CONSTRUCTION and is therefore never a ghost, resident or not, and
--   (3) the part is not resident anywhere the loader can see: no resolved `CustomizationPartDefinition` on the slot
--       AND no object at the SDK's own `/Game/ZCSDK/<name>.<name>`.
-- Two EVIDENCE SHAPES satisfy (2)'s "this came from a mod": a `CPD_ZCSDK_*` id (the SDK's own naming), or the
-- FocusProbe's shape — a LEVELED TREE whose tier classes are null (LeveledAbilities entries, zero
-- LoadedLeveledAbilities, and nothing resolved), which is exactly how Hawks' LongStrider tree reads.
--
-- ---- 1.8.20: AND WHAT 1.8.19 GOT WRONG — THREE FALSE POSITIVES IN ONE RETAIL SESSION ----
-- Retail 2026-09-13 (the 22:52:48 session), three of the four GHOST lines named the GAME's own parts:
--     22:54:11  GHOST /Engine/Transient Specializations.Tactical.Primary: holds CPD_TacticalSpec_Soldier ...
--     23:00:21  GHOST /Engine/Transient Specializations.Tactical.Primary: holds CPD_TacticalSpec_Hero_Aurelio_Assault ...
--     23:00:21  GHOST /Engine/Transient Class: holds CPD_ZCSDK_Char_Class_Vanguard ...
-- and only the fourth was real:
--     23:00:37  GHOST Char_Hero_HAWKS_Control_C_0 Specializations.Tactical.Primary: holds CPD_ZCSDK_TacticalSpec_LongStrider ...
-- Both defects are in the same three lines. (a) They were judged WHILE THE CHARACTER WAS STILL SPAWNING: the census
-- went 27 instance(s) at pass 50 -> 73 at pass 51 -> 109 at pass 54 -> 122 at pass 58, and at pass 50 the loader
-- itself recorded `0 with pinned slot(s)` — the slots existed, nothing owned them yet, and evidence shape 2 (a
-- leveled tree with zero LoadedLeveledAbilities on an unresolved slot) is exactly what a half-built slot looks like.
-- (b) The owner was printed from the SLOT's own name, and `shortOwner` strips up to `PersistentLevel.`, which
-- `/Engine/Transient...` does not contain — so the line named a package, not a character. `/Engine/Transient` is not
-- an owner; a report that cannot say WHOSE save is affected is not worth printing.
--
-- TWO RULES, and neither of them guesses:
--   (1) A non-`CPD_ZCSDK_` id is only called a ghost after PIN_GHOST_PASSES CONSECUTIVE passes reading unresolved
--       with trees>0 / loaded==0. Any pass that reads otherwise resets the count to zero. N is taken from the log
--       above: passes 50 -> 54 is how long the hub took to go from 27 half-built instances to the full 109 with
--       every character named (and the true Hawks ghost printed at pass 52, inside that window, so N must not be so
--       large that a real ghost is lost — it is not, because rule (1) does not apply to a `CPD_ZCSDK_` id at all).
--       STATED HONESTLY: the Aurelio slot's own resolution was never measured, because 1.8.19 marked the slot and
--       stopped looking at it; N is derived from the world-population evidence, not from that slot.
--   (1b) NOT DONE, and why: "is this id a registered GAME primary asset" would settle it in one call, but the
--       AssetManager API the loader can reach (GetObjectFromPrimaryAssetId on the KismetSystemLibrary CDO) needs a
--       real by-value FPrimaryAssetId, and the only way this runtime has ever minted one is
--       `GetPrimaryAssetIdFromObject(<a live object>)` — which needs the object a ghost by definition does not have.
--       There is no safe read, so the consecutive-pass rule stands alone. (1.8.16 guessed a UE4SS accessor and
--       printed an address for a whole session; that is not repeated here.)
--   (2) NO REPORT WITHOUT A NAMED OWNER. The owner is the OWNING CUSTOMIZATIONINSTANCE (`owningInstance`), never the
--       slot's own path, and a slot that has no owning instance yet is DEFERRED to a later pass, not printed. This
--       alone would have suppressed all three false lines, and it costs nothing on the real one: Hawks' slot was
--       owned and named at pass 52.
-- BLOCKING vs REPORTING, kept apart on purpose. A `CPD_ZCSDK_*` candidate is certain enough to refuse the moment its
-- owner can be named (that is the Hawks case, and the whole point of the mechanism). An evidence-shape-2 candidate
-- is NOT blocked while it is being counted — if it were, the pin could never drive it, it could never resolve, and
-- the count would reach N by its own doing. It is counted, and the drive is allowed to prove it wrong.
local PIN_GHOST_PASSES = 4   -- consecutive unresolved passes before a non-CPD_ZCSDK_ id is called a ghost
local pinKnownParts = nil    -- short part name -> true, for every part any enumerated manifest carries
local pinKnownPaths = {}     -- 1.8.22: ... and the object path it was named by, so a part the loader did not pin can
                             -- still be re-minted into an FPrimaryAssetId (the stale-slot rebuild needs the ORIGINAL
                             -- id back, and minting one has only ever worked from a live object)
local pinGhostLogged = {}    -- owner|tag|partId -> the GHOST line has been logged once this session
local pinGhostSlot = {}      -- slot full name -> a REPORTED ghost lives here; never collect it, never drive it
local pinGhostSeen = {}      -- slot full name|partId -> consecutive passes this slot has read as a candidate
local pinGhostHeld = {}      -- slot full name|partId|reason -> the "not reported" line has been logged once

local function pinManifestParts()
    if pinKnownParts then return pinKnownParts end
    local k = {}
    local function add(p)
        if type(p) == "string" then
            local n = p:match("([^/.]+)$")
            if n and n ~= "" then k[n] = true; pinKnownPaths[n] = pinKnownPaths[n] or p end
        end
    end
    for _, rp in ipairs(recruitPins) do
        add(rp.definition)
        if rp.match then add(rp.match.part) end
        for _, s in ipairs(rp.slots or {}) do add(s.part) end
    end
    if type(manifests) == "table" then
        for _, mf in ipairs(manifests) do
            local m = (type(mf) == "table") and mf.m or nil
            if type(m) == "table" then
                for _, g in ipairs(m.grants or {}) do add(g.item) end
                for _, p in ipairs(m.preload or {}) do add(p) end
                for _, rp in ipairs(m.recruitPins or {}) do
                    add(rp.definition)
                    if type(rp.match) == "table" then add(rp.match.part) end
                    for _, s in ipairs(rp.slots or {}) do add(s.part) end
                end
            end
        end
    end
    pinKnownParts = k
    return k
end

-- returns the ghost part id, or nil. Reads only; IsValid before every method, every read pcall'd.
local function ghostOf(s)
    local cur = ""
    pcall(function() cur = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end)
    if type(cur) ~= "string" or cur == "" or cur == "None" then return nil end
    if pinManifestParts()[cur] then return nil end                      -- an installed mod ships it: never a ghost
    -- ... and never an id THIS LOADER ITSELF WRITES. The toggle parks a vanilla id on one of our own slots for a
    -- pass; if that pass were ever read as a ghost the slot would be blocked for the session and the toggle - the
    -- whole of the 1.8.18 delivery path - would stop halfway. The toggle targets and every vanilla id a slot was
    -- remembered holding are therefore excluded by name.
    if PIN_TOGGLE_PATH[cur] then return nil end
    for _, v in pairs(pinVanilla) do if v == cur then return nil end end
    local resolved = false
    pcall(function()
        local d = s.CustomizationPartDefinition
        resolved = (d and d.IsValid and d:IsValid()) and true or false
    end)
    if resolved then return nil end                                     -- the game resolved it: the asset is there
    if cur:find("^CPD_ZCSDK_") == nil then
        local _, _, trees, loaded = fragState(s)                        -- evidence 2: a tree with null tier classes
        if not (trees > 0 and loaded == 0) then return nil end
    end
    local o = StaticFindObject("/Game/ZCSDK/" .. cur .. "." .. cur)     -- resident after all? then it is not a ghost
    if o and o.IsValid and pcall(function() return o:IsValid() end) and o:IsValid() then return nil end
    return cur
end

-- 1.8.20: is `ipath` a name a human can act on? An owning CustomizationInstance under PersistentLevel yields a
-- character name; anything else (no owner yet, /Engine/Transient, a bare package) yields nil and DEFERS the report.
local function namedOwner(ipath)
    if type(ipath) ~= "string" or not ipath:find("PersistentLevel.", 1, true) then return nil end
    local n = shortOwner(ipath)
    if type(n) ~= "string" or n == "" or n:find("/", 1, true) or n == "None" then return nil end
    return n
end

-- one-shot, so a deferral is never a SILENT pass but is never spam either
local function ghostHold(sname, partId, tag, why, reason)
    local k = sname .. "|" .. partId .. "|" .. why
    if pinGhostHeld[k] then return end
    pinGhostHeld[k] = true
    log("recruit pin: ghost candidate " .. partId .. " on " .. shortTag(tag) .. ": not reported — " .. reason)
end

-- the one line this whole mechanism exists to print, and the flag that stops the slot being driven.
-- 1.8.20: `ipath` is the OWNING INSTANCE, not the slot; `pass` is the pin pass number. Returns nothing, writes
-- nothing to the game — the only state it touches is this file's own bookkeeping.
local function ghostReport(sname, ipath, tag, partId, pass)
    local seen = pinGhostSeen[sname]
    -- the id CHANGING is also a pass that read otherwise: the count is per (slot, id), stored per slot because a
    -- slot holds exactly one id at a time
    if not (seen and seen.id == partId and seen.pass == (pass or 0) - 1) then seen = { id = partId, n = 0 } end
    seen.n = seen.n + 1
    seen.pass = pass or 0
    pinGhostSeen[sname] = seen
    local sdk = (partId:find("^CPD_ZCSDK_") ~= nil)
    if not sdk and seen.n < PIN_GHOST_PASSES then
        ghostHold(sname, partId, tag, "passes", "unresolved on " .. seen.n .. " of the " .. PIN_GHOST_PASSES ..
            " consecutive pass(es) a non-CPD_ZCSDK_ id needs before it is called a ghost (a character that is still " ..
            "spawning reads exactly like this)")
        return
    end
    local owner = namedOwner(ipath)
    if not owner then
        ghostHold(sname, partId, tag, "owner", "its owning character cannot be named yet (the slot is still under " ..
            shortOwner(sname) .. "), and a report that names no character names nothing — deferred to a later pass")
        return
    end
    pinGhostSlot[sname] = true      -- only a REPORTED ghost blocks the slot; a candidate must stay drivable
    local key = owner .. "|" .. tag .. "|" .. partId
    if pinGhostLogged[key] then return end
    pinGhostLogged[key] = true
    log("recruit pin: GHOST " .. owner .. " " .. shortTag(tag) .. ": holds " .. partId ..
        " from a mod that is not installed — a save written while it was equipped; the loader will not write over it")
end


-- ---- 1.8.22: THE STALE-SLOT REBUILD ----
-- THE EVIDENCE (retail 2026-09-14/15, CHANGELOG v1.28.53 §9(b) and §13; PROVEN in the data, INFERRED for the symptom).
-- Two facts this file already states, put together:
--   (A) `LoadCustomization` rebuilds a slot's FragmentInstances ONLY when the slot's part id CHANGES (the 1.8.19 header
--       records it from retail 2026-09-13 09:04:40 / 09:04:44), and
--   (B) a MISSION re-creates every character FROM SAVE DATA (ZCSDKLoader.log 21:28:27 vs 21:28:30, quoted by
--       `applyOwner` below).
-- HAWKS is what that costs. He is NOT a pinned character (game class `CPD_Char_Class_Hero_Humanoid`), but his
-- `Specializations.Weapon` slot holds a ZCSDK weapon spec — `CPD_WeaponSpec_ZCSDK_SaberAnakin`, picked in the armoury
-- and written into the save under that mod's v1.0.0 — and his armoury Change Weapon is GREYED OUT, so the slot's id
-- can never change again. By (A) his fragments stay the v1.0.0 ones for ever, and by (B) every mission rebuilds him
-- from them: the REMOVED `GA_OverwatchMelee_Base` still draws a "Melee Overwatch" card (and locks the turn, §1), and
-- his sprint still uses his previous BLASTER's anim proxy table while the visible saber comes from the currently
-- equipped part (§13). A byte-grep over the whole deployed game finds the ability in no ZCSDK container at all — the
-- card is the SAVE, not the pak.
-- VEX is the control, and he is fine — BECAUSE the pin toggles his Weapon slot every hub load
-- (`[TOGGLE to CPD_WeaponSpec_Blaster_Longarm]`, `FragmentInstances REPLACED`) and a manual save afterwards carried
-- the rebuilt fragments into the mission (§11: hub delivery -> manual save -> mission, and no card).
-- SO: do for a non-pinned character exactly what the pin already does for a pinned one — ONE toggle-and-back on the
-- Weapon slot, once per session, in the hub only. Nothing here is a new mechanism; it is the 1.8.18 toggle, aimed at a
-- slot this loader does not own but a mod THIS INSTALL SHIPS put a part into.
--
-- THE FENCES, every one of them narrowing, because this writes to a character that is not ours:
--   * HUB ONLY (`HUB_Root`). In a mission the game re-equips during load and a write there is thrown away anyway.
--   * THE WEAPON TAG ONLY. Class and Tactical are out of scope: driving a Class re-creates the child slots (1.8.18's
--     fact B) and no retail evidence says either of them is stale.
--   * ONLY A PART THIS INSTALL SHIPS — see `staleOursPath` below for the two tests and why one of them is not enough.
--     Either way this can never touch a vanilla part (nothing to fix — the game's own fragments are current) and can
--     never touch a GHOST (a ghost is by construction an id no installed mod ships AND is not resident; the
--     `pinGhostSlot` test is belt and braces on top of that).
--   * NOT OURS. A pinned character already gets the 1.8.18 toggle; running both on him would fight the pin mid-flight.
--   * A REAL CHARACTER: never a preview/portrait proxy (`isProxyOwner`), and never a slot whose owning
--     CustomizationInstance cannot be NAMED (1.8.20's rule — an unnamed owner is a slot mid-spawn).
--   * ONCE PER SESSION per (owner, id), at most PIN_MAX_RETRY writes, and a failure is FINAL — no retry, ever.
--   * BOTH IDS ARE MINTED BEFORE THE FIRST WRITE. This is the one that matters: if the toggle went on and the ORIGINAL
--     id could not be minted back, the character would be left wearing a Blaster Longarm. So the toggle is not written
--     until the original part and the toggle part are BOTH resident and both mint an FPrimaryAssetId.
-- AND IT IS ONLY HALF THE FIX: rebuilt fragments live in the hub instance, and a mission reads the SAVE. The REBUILT
-- line therefore tells the operator to make a manual save, exactly as §11's verified Vex sequence did.
local STALE_SLOT_REBUILD = true
local STALE_TAG = "br.Customization.Slot.Character.Specializations.Weapon"
local staleState = {}        -- owner|partId -> { phase = "toggle"|"back"|"done"|"failed", tries =, waits = }
local staleSkipped = {}      -- slot full name -> counted once as "not ours, not ours-shipped"
local staleCand = {}         -- rebuilt every pass: instance path -> the LIVE Weapon slot on a character that is not ours
local staleFlight = {}       -- owner -> the ORIGINAL part id, while the slot is parked on the toggle id. Without this
                             -- the next pass re-reads the slot, sees the (vanilla) TOGGLE id, calls it "not
                             -- ours-shipped" and walks away — leaving the character on a Blaster Longarm for ever.
local staleRebuilt, staleFailed = 0, 0

-- DOES THIS INSTALL SHIP THIS PART, and where does it live? Returns the object path, or nil.
-- TWO TESTS, because ONE IS NOT ENOUGH — and this is the correction that made the mechanism work at all. The first is
-- `pinManifestParts()`, the enumerated set. But a manifest does not have to ENUMERATE a part for the install to ship
-- it: `build/ZCSDK_SaberAnakin.zcsdk.lua` — the very mod whose spec is stuck on Hawks — declares ONE primary type
-- (`{ type = "CustomizationPartDefinition", path = "/Game/ZCSDK" }`), an empty `grants`, no `preload` and no
-- `recruitPins`, so the enumerated set does not contain `CPD_WeaponSpec_ZCSDK_SaberAnakin` and never will.
-- The second test is the one the GHOST RULE already uses in the negative: a live object at the SDK's own content root
-- `/Game/ZCSDK/<id>.<id>`, which is where every mod this SDK builds cooks its parts (it is the manifests' own
-- `primaryTypes[].path`). It is a RESIDENCY test, not a name guess, and nothing else can pass it: a VANILLA part is
-- never under /Game/ZCSDK, and a GHOST is by definition NOT resident there (that is what makes it a ghost). It also
-- hands back the path, which is what the write-back needs to re-mint the original id.
local function staleOursPath(id)
    local p = pinKnownPaths[id]
    if p then return p end
    if not pinManifestParts()[id] then
        local sdk = "/Game/ZCSDK/" .. id .. "." .. id
        local o = StaticFindObject(sdk)
        if o and o.IsValid and pcall(function() return o:IsValid() end) and o:IsValid() then return sdk end
        return nil
    end
    return nil
end

-- a live object for `path`, minted into a real FPrimaryAssetId the same way the pin's own drive does. Returns nil and
-- REQUESTS THE LOAD when the part is not resident — never a guess, never a Lua table pretending to be one.
local function staleMint(path, ksl)
    if type(path) ~= "string" or path == "" then return nil end
    local o = StaticFindObject(path)
    if not (o and o.IsValid and pcall(function() return o:IsValid() end) and o:IsValid()) then
        pcall(LoadAsset, path)
        return nil
    end
    if not (ksl and ksl.IsValid and pcall(function() return ksl:IsValid() end) and ksl:IsValid()) then return nil end
    local ok, id = pcall(function() return ksl:GetPrimaryAssetIdFromObject(o) end)
    if ok and id then return id end
    return nil
end

-- collected during the slot sweep so identity is settled before anything is judged; the LIVE slot is the highest
-- object index, the same 1.8.16 rule the pin's own collection uses (every equip leaves the old slot objects alive).
local function staleConsider(s, sname, ipath, tag)
    if not STALE_SLOT_REBUILD then return end
    if tag ~= STALE_TAG then return end
    if pinGhostSlot[sname] then return end
    if isProxyOwner(sname) or isProxyOwner(tostring(ipath or "")) then return end
    if not namedOwner(ipath) then return end
    local idx = tonumber(sname:match("_(%d+)$") or "0") or 0
    local prev = staleCand[ipath]
    if prev and prev.idx >= idx then return end
    local cur = ""
    pcall(function() cur = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end)
    if type(cur) ~= "string" or cur == "" or cur == "None" then return end
    staleCand[ipath] = { slot = s, sname = sname, tag = tag, id = cur, idx = idx }
end

-- one write, judged by the SAME criterion the pin uses: did the FragmentInstances' OBJECT IDENTITIES move.
local function staleWrite(cand, owner, id, step)
    -- session_audit.py reads `hook armed on <fn>` as an arming and `PATH> <fn>` as a firing, and a firing with no
    -- arming above it is a FINDING. The rebuild can write before `legacyOwner` ever arms the setter (it runs earlier
    -- in the pass), so it arms it itself — pinArm is one-shot, so the pin's own line is unaffected.
    pinArm("SetCustomizationPartPrimaryAssetId", "1.4.0 setter: LoadCustomization rebuilds the fragments on an id CHANGE")
    local before = slotState(cand.slot)
    log("recruit pin: PATH> SetCustomizationPartPrimaryAssetId (" .. shortTag(cand.tag) .. ") on " .. owner ..
        " [stale-slot rebuild: " .. step .. "]")
    local ok, err = pcall(function() cand.slot:SetCustomizationPartPrimaryAssetId(id) end)
    if not ok then return false, "the setter raised on the " .. step .. ": " .. tostring(err) end
    local after = slotState(cand.slot)
    log("recruit pin:   " .. shortTag(cand.tag) .. " BEFORE " .. sigOf(before))
    log("recruit pin:   " .. shortTag(cand.tag) .. " AFTER  " .. sigOf(after))
    if after.frags == before.frags then
        return false, "the " .. step .. " left FragmentInstances at the same object identities — LoadCustomization " ..
            "did not run, so nothing was rebuilt"
    end
    return true
end

-- the two-pass state machine for ONE candidate. Returns true while it is still mid-flight, so `done` can be held.
local function staleOne(cand, ipath, inst, ksl)
    local owner = namedOwner(ipath)
    if not owner then return false end
    local key = owner .. "|" .. cand.id
    local st = staleState[key]
    if st == nil then st = { phase = "toggle", tries = 0, waits = 0 }; staleState[key] = st end
    if st.phase == "done" or st.phase == "failed" then return false end
    local toggle = PIN_TOGGLE_DEFAULT[cand.tag]
    local tpath = PIN_TOGGLE_PATH[toggle or ""]
    -- remembered as a STRING the first time it resolves: mid-flight the slot holds the toggle id, and re-deriving the
    -- original's path from a slot that no longer names it is how a character gets left on a Blaster Longarm.
    st.opath = st.opath or staleOursPath(cand.id)
    local opath = st.opath
    local line = "recruit pin: stale-slot rebuild " .. owner .. " " .. shortTag(cand.tag) .. ": " .. cand.id ..
        " -> " .. tostring(toggle) .. " -> " .. cand.id .. " "
    local function fail(why)
        st.phase = "failed"
        staleFlight[owner] = nil
        staleFailed = staleFailed + 1
        log(line .. "rebuild FAILED (" .. why .. ")")
        return false
    end
    if st.tries >= PIN_MAX_RETRY then
        return fail("spent all " .. PIN_MAX_RETRY .. " attempt(s)" ..
            (st.phase == "back" and " and the slot is still on " .. tostring(toggle) .. " — re-pick the weapon in the armoury" or ""))
    end
    if st.phase == "toggle" then
        -- BOTH ids first. A toggle written without a way back would leave this character wearing the toggle part.
        local oid = staleMint(opath, ksl)
        local tid = staleMint(tpath, ksl)
        if oid == nil or tid == nil then
            st.waits = st.waits + 1
            if st.waits > PIN_RESIDENCY_PASSES then
                return fail("waited " .. PIN_RESIDENCY_PASSES .. " pass(es) and " ..
                    ((oid == nil) and (cand.id .. " (" .. tostring(opath) .. ")") or (tostring(toggle) .. " (" .. tostring(tpath) .. ")")) ..
                    " never became resident — nothing was written")
            end
            if st.waits == 1 then
                log(line .. "holding: both ids must be mintable before the first write is allowed (requested the load)")
            end
            return true
        end
        st.tries = st.tries + 1
        local ok, why = staleWrite(cand, owner, tid, "toggle out")
        if not ok then
            -- UNWIND, and it is not a retry: the verdict is already FAILED and this key never runs again. It is one
            -- write of the id the slot ALREADY HELD, because the one state this must never leave behind is a
            -- character wearing the toggle part.
            local okR = staleWrite(cand, owner, oid, "restore")
            return fail(why .. "; the original id was written back" ..
                (okR and "" or " but that write did not move the fragments either — check the slot in the armoury"))
        end
        st.phase = "back"
        staleFlight[owner] = cand.id
        log(line .. "toggled out (FragmentInstances REPLACED); ours goes back on the next pass")
        return true
    end
    -- phase "back": re-mint the ORIGINAL id from a live object (never held across passes) and put it back.
    local oid = staleMint(opath, ksl)
    if oid == nil then
        st.waits = st.waits + 1
        if st.waits > PIN_RESIDENCY_PASSES then
            return fail("the original part " .. cand.id .. " (" .. tostring(opath) .. ") could not be re-minted, and " ..
                "the slot is still on " .. tostring(toggle) .. " — re-pick the weapon in the armoury")
        end
        return true
    end
    st.tries = st.tries + 1
    local ok, why = staleWrite(cand, owner, oid, "write back")
    if not ok then return fail(why) end
    st.phase = "done"
    staleFlight[owner] = nil
    staleRebuilt = staleRebuilt + 1
    -- the hub instance now carries current fragments; the MISSION reads the save, so the save is the other half.
    if inst and inst.IsValid and pcall(function() return inst:IsValid() end) and inst:IsValid() then
        local okR, errR = pcall(function() inst:RefreshCustomization() end)
        if not okR then log("recruit pin: RefreshCustomization failed on " .. owner .. ": " .. tostring(errR)) end
    end
    log(line .. "REBUILT (FragmentInstances REPLACED twice) — make a manual save before the next mission")
    return false
end

-- every candidate this pass. Returns true while any rebuild is mid-flight, so `done` does not stop the loop halfway
-- through one (bounded: PIN_MAX_RETRY writes and PIN_RESIDENCY_PASSES waits, then it fails and stops for good).
local function staleDrive(instByPath, ksl, hub)
    if not STALE_SLOT_REBUILD or not hub then return false end
    local busy = false
    for ipath, cand in pairs(staleCand) do
        local c = instByPath[ipath]
        local ours = (c and c.ident) or pinKnown[ipath]
        if not ours then
            -- a slot PARKED ON THE TOGGLE ID reads as a vanilla part; it is this pass's job to FINISH it, not to
            -- re-judge it, so the id in flight is the one the state machine is handed.
            local fowner = namedOwner(ipath)
            local flight = fowner and staleFlight[fowner] or nil
            if flight then
                cand = { slot = cand.slot, sname = cand.sname, tag = cand.tag, id = flight, idx = cand.idx }
            end
            if not flight and not staleOursPath(cand.id) then
                staleSkipped[cand.sname] = true          -- vanilla, or a ghost: nothing this install shipped, nothing to rebuild
            elseif staleOne(cand, ipath, c and c.inst or nil, ksl) then
                busy = true
            end
        end
    end
    return busy
end

local function staleSummary()
    local k = 0
    for _ in pairs(staleSkipped) do k = k + 1 end
    log(string.format("recruit pin: stale-slot rebuild: %d slot(s) REBUILT, %d FAILED, %d skipped " ..
        "(not ours, not ours-shipped)", staleRebuilt, staleFailed, k))
end


-- THE ONE VERIFIED WAY TO READ A TSoftObjectPtr IN UE4SS 3.0.1, KEPT BECAUSE NOTHING ELSE RECORDS IT.
-- (1.8.19 deleted the resolver probe that used it - its question was answered at retail 09:04:18: the AssetManager
-- resolves every one of our parts once they are RESIDENT - but the accessor chain cost a crashed game to find and
-- must not be lost with it.) UE4SS 3.0.1's TSoftObjectPtr userdata metatable registers EXACTLY
--     GetWeakPtr | GetTagAtLastTest | GetObjectID | type | __gc
-- (read out of UE4SS.dll's push_softobjectproperty, RVA 0x2cafe0, metatable block 0x2cb2b0-0x2cb478). There is NO
-- ToString and NO GetAssetPathString - 1.8.16 guessed both and printed an address for a whole session. GetObjectID
-- yields an FSoftObjectPath, whose shape the 196985 jmap gives:
--     FSoftObjectPath { AssetPath : FTopLevelAssetPath { PackageName : FName, AssetName : FName }, SubPathString }
-- so the VERIFIED chain is
--     sp:GetObjectID().AssetPath.PackageName:ToString()   ..  "."  ..  sp:GetObjectID().AssetPath.AssetName:ToString()
-- every step pcall'd, and a SUCCESSFUL read of an EMPTY name ("the manager holds no path") must be distinguished
-- from a FAILED read (which concludes nothing) - conflating those two is what made 1.8.16's output worthless.
-- An FPrimaryAssetId is read from its own members instead (FPrimaryAssetId { PrimaryAssetType { Name : FName },
-- PrimaryAssetName : FName }) - what slotState() below does - NOT through Conv_PrimaryAssetIdToString, which hands
-- back an FString USERDATA.

-- ---- 1.8.13: PER-PART RESIDENCY, BECAUSE THE THREE PINNED PARTS BEHAVED DIFFERENTLY ON ONE CALL ----
-- Retail 2026-09-13 05:30:21. Three `EquipCustomizationDefinition` calls, one per pinned part, each with that part's own
-- AllowedSlots container, each `returned true`:
--     Class   -> AFTER partDefinition=CPD_ZCSDK_Char_Class_Sith | 6 fragment instance(s) -> DELIVERED - FragmentInstances REPLACED
--     Weapon  -> not delivered, partDefinition still <null>, 7 fragment instance(s) unchanged
--     Tactical-> not delivered, partDefinition still <null>, 5 fragment instance(s) unchanged
-- THE CONTAINER REACHED THE NATIVE - the Class slot proves it, and with it that the marshalling question is closed. What
-- separates the three is the RESOLVER: `UCustomizationStatics::GetCustomizationPartDefinitionFromPartId` (RVA 0x8c46060)
-- asks the AssetManager for the LOADED object for that FPrimaryAssetId first, and falls back to its path map. An id the
-- manager has never SCANNED resolves through neither. All three parts live in /Game/ZCSDK and the loader rescans
-- `CustomizationPartDefinition` over exactly that path at startup, so a scan-path gap is INFERRED, not proven - which is
-- why this escalates one observable step at a time and PRINTS each one instead of guessing.
--
-- Cooked-asset evidence for why the three are not interchangeable (tagged-property decode of the deployed pak):
-- CPD_ZCSDK_Char_Class_Sith carries NO `AllowedSlots` tagged property at all (it equals the class default: an EMPTY
-- FGameplayTagContainer), while CPD_WeaponSpec_ZCSDK_SithSaber (size 12) and CPD_ZCSDK_TacticalSpec_Sith (size 20) both
-- carry a non-empty one. So the one call that DELIVERED is the one that passed an EMPTY container, and the two that
-- passed a populated container delivered nothing - consistent with the resolver failing for those two ids, and also
-- with an empty container meaning "every slot this definition names". Both readings are tested by the ladder below.
local partDiag = {}          -- part path -> the diagnostic line has been logged once this session
local partStep = {}          -- part path -> how far the residency ladder has been climbed
local partWhen = {}          -- part path -> the pass number the last step was taken on (1.8.15: a per-part timer)
local partHeld = {}          -- 1.8.16: the held-verdict line has been logged once
local partDriven = {}        -- 1.8.16: part path -> the pass its slot was last actually DRIVEN
local partWatch = {}         -- part path -> { want=, ptype= } for every pinned part seen, so the ladder ticks on its own
-- ---- 1.8.20: THE LADDER RE-RAN ON A PART THAT HAD ALREADY RESOLVED ----
-- Retail 2026-09-13, 23:00:38 -> 23:00:58, after all three slots read `finished`, the log alternated every pass:
--     23:00:53  part CPD_WeaponSpec_ZCSDK_SithSaber did not resolve — step 1: LoadAsset(...)      <- pass 57 tick
--     23:00:53  part CPD_WeaponSpec_ZCSDK_SithSaber resolved after step 1 of the residency ladder <- pass 57 drive
--     23:00:58  part CPD_WeaponSpec_ZCSDK_SithSaber did not resolve — step 1: LoadAsset(...)      <- pass 58 tick
-- THE CAUSE, exactly: the drive path clears `partStep[path]` when a part resolves but leaves `partWatch[path]` set,
-- and the per-pass tick loop treats `(partStep[path] or 0) == 0` as "not started" and climbs to step 1 again. It is
-- NOT a stale read and it is NOT a re-load of something absent: the tick's own precondition is that
-- StaticFindObject(path) returns a VALID object, so the part is demonstrably resident and the line contradicts the
-- test that produced it. The LoadAsset it issues is a real (and idempotent) request for an asset already loaded.
-- THE FIX is one flag: a part that has resolved once is SETTLED — off the watch list, and refused by
-- escalateResidency if anything puts it back. Nothing on the delivery path is touched (the 1.8.18 toggle route still
-- drives Class -> Weapon -> Tactical and still delivers), and `resolved after step N` now prints once instead of
-- once per pass, because the second print was the same re-climb wearing a success verb.
local partSettled = {}       -- part path -> this part resolved on a driven slot; the ladder is finished with it
local PART_STEP_PASSES = 3   -- ~15 s at the 5 s cadence: a step is given time to take before the next one is judged
local PART_CLASS = { CustomizationPartDefinition = "/Script/BitReactorCore.CustomizationPartDefinition",
                     CustomizationDefinition     = "/Script/BitReactorCore.CustomizationDefinition",
                     CharacterClass              = "/Script/BitReactorGame.CharacterClass" }

-- what the loader can actually see about one part, printed once so the next reader does not have to infer it
local function partReport(path)
    if partDiag[path] then return end
    partDiag[path] = true
    local o = StaticFindObject(path)
    local found = (o ~= nil)
    local valid = false
    pcall(function() valid = (o and o.IsValid and o:IsValid()) and true or false end)
    local full = "<none>"
    if valid then pcall(function() local n = o:GetFullName(); if type(n) == "string" then full = n end end) end
    log(string.format("recruit pin: part %s: object=%s | valid=%s | %s",
        (path:match("([^/.]+)$") or path), found and "found" or "MISSING", valid and "y" or "n", full))
end

-- One step per pass, each one observable, for a part whose slot will not resolve. Nothing here is speculative: LoadAsset is
-- what the pin has always used, `loadpkg` is the bridge's synchronous LoadPackage, and `rescan` is the same
-- ScanPathsForPrimaryAssets the loader already runs at startup - re-aimed at this one package's own directory.
-- 1.8.15: a step is only taken when the PREVIOUS one has had time to land. In the 05:43 session steps 3 and 4 fired in
-- the same second (05:48:53), so the rescan was condemned before it could possibly have taken effect — the ladder was
-- measuring itself, not the game. `pass` is the pin pass number; PART_STEP_PASSES of them is roughly 15 s.
local function escalateResidency(path, want, ptype, pass)
    -- 1.8.20: a part that has already resolved on a driven slot never climbs again. Without this the ladder restarts
    -- at step 1 every pass for the rest of the session and prints `did not resolve` about a part it just proved
    -- resident (retail 23:00:38-23:00:58).
    if partSettled[path] then return end
    partWatch[path] = { want = want, ptype = ptype }
    local n = (partStep[path] or 0)
    if n > 0 and pass and (pass - (partWhen[path] or 0)) < PART_STEP_PASSES then return end
    n = n + 1
    partStep[path] = n
    partWhen[path] = pass or 0
    if n == 1 then
        log("recruit pin: part " .. want .. " did not resolve — step 1: LoadAsset(" .. path .. ")")
        pcall(LoadAsset, path)
    elseif n == 2 then
        local pkg = path:match("^(.-)%.[^%.]+$") or path
        log("recruit pin: part " .. want .. " did not resolve — step 2: bridge loadpkg " .. pkg)
        pcall(bridge, "ZCSDK:loadpkg|" .. pkg)
    elseif n == 3 then
        -- the coordinator's hypothesis, tested rather than argued: the part PICKER reads UCustomizationPartsTagSubsystem's
        -- maps, and BuildPartTagMaps ran at 05:44:51 — two minutes BEFORE any of our parts were resident. The resolver
        -- itself does not consult it (the whole of 0x8c46060..0x8c46209 touches only the AssetManager), so this should
        -- change nothing; if it DOES flip a part, that reading was right and this comment is wrong.
        log("recruit pin: part " .. want .. " did not resolve — step 3: bridge BuildPartTagMaps (the part tag cache was " ..
            "built before our parts were resident)")
        local sub = StaticFindObject("/Script/BitReactorCore.Default__CustomizationPartsTagSubsystem")
        local addr = nil
        pcall(function() local live = FindAllOf("CustomizationPartsTagSubsystem")
            if type(live) == "table" then for _, o in ipairs(live) do
                if o and o.IsValid and o:IsValid() then local a; pcall(function() a = o:GetAddress() end); if a then addr = a end end
            end end end)
        if addr then
            pcall(bridge, "ZCSDK:callthis|?BuildPartTagMaps@UCustomizationPartsTagSubsystem@@AEAAXXZ|" .. string.format("%x", addr))
        else
            log("recruit pin:   (no live CustomizationPartsTagSubsystem found — step skipped)")
        end
    elseif n == 4 then
        local pkg = path:match("^(.-)%.[^%.]+$") or path
        local dir = pkg:match("^(.*)/[^/]+$") or pkg
        local cls = PART_CLASS[ptype or ""] or PART_CLASS.CustomizationPartDefinition
        log("recruit pin: part " .. want .. " did not resolve — step 4: bridge rescan " ..
            tostring(ptype or "CustomizationPartDefinition") .. " over " .. dir ..
            " (the AssetManager has no NameData for this id, so GetPrimaryAssetObject cannot answer)")
        pcall(bridge, "ZCSDK:rescan|" .. tostring(ptype or "CustomizationPartDefinition") .. "|" .. dir .. "|" .. cls .. "|0")
    elseif n == 5 then
        -- 1.8.16: NO VERDICT WITHOUT A DRIVE. The 08:38 session printed `STILL does not resolve` for all three parts,
        -- two of which had already resolved and delivered minutes earlier, because the verdict was measured on a
        -- character the pin had stopped driving. A verdict now requires that this part's slot was actually driven
        -- recently; otherwise the ladder holds at step 4 and says so once.
        if not (partDriven[path] and pass and (pass - partDriven[path]) <= PART_STEP_PASSES * 2) then
            partStep[path] = 4
            if not partHeld[path] then
                partHeld[path] = true
                log("recruit pin: part " .. want .. " — holding the verdict: its slot has not been driven recently, so " ..
                    "'does not resolve' would be a statement about the pin, not the part (the 08:38 lesson)")
            end
            return
        end
        log("recruit pin: part " .. want .. " STILL does not resolve after LoadAsset, loadpkg, BuildPartTagMaps and a rescan " ..
            "of its own directory — the AssetManager will not carry this primary asset id, and no equip path can deliver its " ..
            "fragments until it does (this is now an asset-registration question, not a loader one)")
    end
end

-- 1.8.14: RE-FOUND EVERY PASS, NEVER CACHED. A UObject wrapper held across passes is a userdata whose object the
-- engine may have collected, and dereferencing one is a native access violation pcall cannot catch - which is what the
-- 05:50:58 crash was (43 frames, reading 0xffffffffffffffff, inside the Lua VM with no GetClass frame). Nothing in this
-- file survives a pass except strings and numbers.


-- THE ROUTE — the plain 1.4.0 setter, and since 1.8.19 the ONLY one in this file. Retail 2026-09-13 09:02 is the proof:
--   09:04:18  GetObjectFromPrimaryAssetId returned OUR OBJECT for all three parts once resident. The AssetManager was
--             never the problem. (That probe's path half was broken; that reading is discarded, and the probe is gone.)
--   09:04:40  PATH> SetCustomizationPartPrimaryAssetId (Specializations.Tactical.Primary)
--             BEFORE partId=CPD_TacticalSpec_Assault | partDefinition=CPD_TacticalSpec_Assault | 5 frag | 3 leveled tree(s)
--             AFTER  partId=CPD_ZCSDK_TacticalSpec_Sith | partDefinition=CPD_ZCSDK_TacticalSpec_Sith | 5 frag | 2 leveled tree(s)
--             DELIVERED — FragmentInstances REPLACED          <-- OUR TWO TREES, through the plain 1.4.0 setter
--   09:04:40  PATH> SetCustomizationPartPrimaryAssetId (Class) [re-drive: the id is already ours and its definition is null]
--   09:04:44+ every Tactical AFTER reads partDefinition=<null> | 0 leveled tree(s), and the FocusProbe finds the delivered
--             trees on STALE slot objects beside a live one at 0.
-- TWO FACTS, BOTH PROVEN BY THAT SEQUENCE:
--   (A) The setter's LoadCustomization rebuilds fragments only when the slot's id CHANGES. A slot that already holds our
--       id is a no-op for ever — which is why the Sith has been empty since the first session that wrote our id onto him,
--       and why every "re-drive" since 1.8.14 was wasted work.
--   (B) Driving the CLASS part re-creates the character's child slots, discarding whatever was just delivered into them
--       (the same mechanism that lost the identity at 07:52:26). So Class must be driven FIRST and then left alone —
--       1.8.15's "Class last" was exactly the wrong direction.
-- HENCE 1.8.18: order Class -> Weapon -> Tactical; deliver onto an "already ours, no fragments" slot by TOGGLING it to a
-- different id first and setting ours on the NEXT pass (LoadCustomization needs the change, and needs the tick); never
-- drive a slot again once it has delivered; stop when all of them have.
local function legacyOwner(owner, p)
    pinArm("SetCustomizationPartPrimaryAssetId", "1.4.0 setter: LoadCustomization rebuilds the fragments on an id CHANGE")
    -- (1) ORDER. Class first (it rebuilds the child slots), then Weapon, then Tactical.
    local ordered = {}
    for _, want in ipairs({ "%.Class$", "%.Specializations%.Weapon$", "" }) do
        for _, e in ipairs(p.list) do
            if not e.__ordered and (want == "" or e.tag:find(want)) then e.__ordered = true; ordered[#ordered + 1] = e end
        end
    end
    for _, e in ipairs(p.list) do e.__ordered = nil end

    -- 1.8.18b: "Class FIRST" means first TO COMPLETION, not merely first in the loop. Driving the Class part
    -- re-creates the character's child slots, so any spec delivered before the Class has finished is thrown away on
    -- the Class's next write — and the Class needs TWO passes when it has to be toggled. So while an undelivered
    -- Class slot is in this character's list, it is the only slot driven.
    local classPending = nil
    for _, e in ipairs(ordered) do
        if e.tag:find("%.Class$") and not pinDelivered[e.key] then classPending = e end
    end
    if classPending then
        if not pinQuiet[classPending.key .. "|first"] then
            pinQuiet[classPending.key .. "|first"] = true
            log("recruit pin: " .. shortOwner(owner) .. ": the Class slot is not delivered yet, so it is the ONLY " ..
                "slot driven — driving the Class re-creates this character's child slots and would discard anything " ..
                "already delivered into them (retail 09:04:40 -> 09:04:44)")
        end
        ordered = { classPending }
    end
    for _, e in ipairs(ordered) do
        if pinDelivered[e.key] then
            -- (3) a delivered slot is never driven again, and the Class especially never: driving it rebuilds the
            -- children and throws away the specs that were just delivered into them.
            if not pinQuiet[e.key] then
                pinQuiet[e.key] = true
                log("recruit pin: " .. shortTag(e.tag) .. " on " .. shortOwner(owner) .. " is DELIVERED — never driven again")
            end
        else
            -- remember this slot's vanilla part the first time we see one, so the toggle has something real to use
            if e.cur ~= e.want and e.cur ~= "?" and e.cur ~= "None" then pinVanilla[e.key] = e.cur end
            local write, why = nil, nil
            if e.cur ~= e.want then
                write, why = e.id, nil                                   -- a real change: the setter will rebuild
            elseif pinToggled[e.key] then
                write, why = e.id, "toggle complete: the id differs again, so LoadCustomization will rebuild"
                pinToggled[e.key] = nil
            else
                -- (2) THE TOGGLE. The id is already ours and nothing was delivered, so the setter would do nothing at
                -- all. Put a DIFFERENT id on the slot this pass; ours goes back on the NEXT one, and the change is what
                -- makes LoadCustomization run.
                local other = pinVanilla[e.key] or PIN_TOGGLE_DEFAULT[e.tag]
                if other == nil or other == e.want then
                    if not pinQuiet[e.key] then
                        pinQuiet[e.key] = true
                        log("recruit pin: " .. shortTag(e.tag) .. " on " .. shortOwner(owner) .. " holds " .. e.want ..
                            " with no fragments and there is no other id to toggle through — leaving it alone")
                    end
                else
                    local otherObj = StaticFindObject(PIN_TOGGLE_PATH[other] or "")
                    local oid = nil
                    if otherObj and otherObj.IsValid and otherObj:IsValid() then
                        local ksl2 = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
                        if ksl2 and ksl2.IsValid and ksl2:IsValid() then
                            pcall(function() oid = ksl2:GetPrimaryAssetIdFromObject(otherObj) end)
                        end
                    end
                    if oid == nil then
                        if not pinQuiet[e.key .. "|toggleload"] then
                            pinQuiet[e.key .. "|toggleload"] = true
                            log("recruit pin: " .. shortTag(e.tag) .. " toggle needs " .. tostring(other) ..
                                " resident (" .. tostring(PIN_TOGGLE_PATH[other]) .. ") — requested the load")
                        end
                        pcall(LoadAsset, PIN_TOGGLE_PATH[other] or "")
                    else
                        write, why = oid, "TOGGLE to " .. other .. " (the setter only rebuilds fragments on an id CHANGE; " ..
                            "ours goes back on the next pass)"
                        pinToggled[e.key] = pinPass
                    end
                end
            end
            if write ~= nil then
                log("recruit pin: PATH> SetCustomizationPartPrimaryAssetId (" .. shortTag(e.tag) .. ") on " ..
                    shortOwner(owner) .. (why and (" [" .. why .. "]") or ""))
                local ok, err = pcall(function() e.slot:SetCustomizationPartPrimaryAssetId(write) end)
                if not ok then
                    log("recruit pin FAILED: " .. e.tag .. " on " .. owner .. ": " .. tostring(err))
                else
                    local after = slotState(e.slot)
                    log("recruit pin:   " .. shortTag(e.tag) .. " BEFORE " .. sigOf(e.before))
                    log("recruit pin:   " .. shortTag(e.tag) .. " AFTER  " .. sigOf(after))
                    local okD, whyD = deliveredTo(e.before, after)
                    log("recruit pin:   " .. shortTag(e.tag) .. " " .. (okD and "DELIVERED" or "not delivered") .. " — " .. whyD)
                    -- a slot counts as SETTLED only when it ends up holding OUR part with a resolved definition and a
                    -- fragment set that moved. Anything else stays open for the next pass.
                    local nowOurs = ((after.id:match("([^:]+)$") or "") == e.want)
                    if okD and nowOurs and after.defn ~= "<null>" then
                        pinDelivered[e.key] = true
                        pinToggled[e.key] = nil
                        log("recruit pin: " .. shortTag(e.tag) .. " " .. e.cur .. " -> " .. e.want .. " on " ..
                            shortOwner(owner) .. " (SetCustomizationPartPrimaryAssetId; DELIVERED, " ..
                            after.trees .. " leveled tree(s)) — this slot is finished")
                    end
                end
            end
        end
    end
end

-- one character, one decision — and since 1.8.19 there is only one route to decide on: the 1.4.0 setter.
local function applyOwner(owner, p)
    logCriterion()
    local hub, wname = strategySide()
    local gated = PIN_STRATEGY_ONLY and not hub
    if gated and not scopeLogged then
        scopeLogged = true
        log("recruit pin: world=" .. wname .. " is not the hub — in a mission the characters are rebuilt from save " ..
            "data and the game re-equips them during load (ZCSDKLoader.log 21:28:27 vs 21:28:30), so a pin here " ..
            "writes the id and nothing is expected to stick")
    end
    -- 1.8.10: a retry is only spent when a route actually RAN on this slot. 1.8.9 incremented in the collection loop, so two
    -- passes that returned "needs the definition resident" burned half the budget without calling anything (22:14:29-38).
    for _, e in ipairs(p.list) do
        if e.cur == e.want then pinAttempts[e.key] = (pinAttempts[e.key] or 0) + 1 end
    end
    legacyOwner(owner, p)
end

-- returns "pinned" (a slot was changed) / "targets" (pin-able characters are here, nothing to change) / "idle" (nothing to do),
-- which is what the loop below paces itself by.
--
-- 1.8.12 — THE UNIT OF IDENTITY IS THE CHARACTER, AND A CHARACTER IS ITS `UCustomizationInstance`.
-- 1.8.10/1.8.11 made it the slot's immediate parent object, and retail 2026-09-13 05:03 proved that unsatisfiable by
-- construction: `pass 39: 73 instance(s) seen, 73 candidate(s), 73 group(s), 0 pinned, 14 skipped, world=HUB_Root`, with every
-- character skipped three times — `no identity: it holds 1 pinned tag(s) | 2 pinned tag(s) | 2 pinned tag(s) … Info.Name reads
-- <not present>`. One character's slots are NOT siblings: `Class` hangs directly off the CustomizationInstance, the two
-- `Specializations.*` slots hang off a container slot (`…CustomizationFragmentInstanceSlot_11.CustomizationFragmentInstanceSlot_2`),
-- and `Info.Name` hangs off a third parent. No parent object can ever hold both a pinned tag and the identity, so the per-group
-- identity rule could only ever fail — silently in 1.8.10, loudly in 1.8.11, but always.
-- 1.8.7 — which pinned this recruit correctly — identified at INSTANCE level, and that is what is restored here:
--   * a character is OURS if its instance's own `GetDefaultCustomizationDefinition()` is the pin's, OR if ANY slot under that
--     instance whose `SlotNameTag` is the pin's `match` slot holds the pin's `match` part (the mod's own Info.Name part).
--     In this save Vex was built from the pool row, so his instance's default definition is generic — only the Name part finds him.
--   * the pinned tags' slots are then taken from ANYWHERE under that same instance, at any depth, across parent slots.
-- WHAT STOPS THE 22:15:47 MASS-PIN IS NOT THE GROUPING — IT IS THE CAP. That incident collected 21 slots belonging to seven
-- characters under ONE proxy instance, because a customization proxy accumulates the slot trees of everything it has previewed.
-- A real character has exactly ONE slot per pinned tag, so more matching slots than the pin declares means the instance holds
-- more than one character and NOTHING is written. That test is exact, cheap, and cannot be defeated by a tree shape.
local pinPass = 0
local pinCensus = ""
-- the owning UCustomizationInstance of a slot: walk GetOuter() (validity-checked at every step, and only ever asking IsValid /
-- GetFullName — never GetClass, which faults on a stale pointer) until the outer is one of the live instances. Falls back to the
-- full-name prefix test, which is what 1.4.0-1.8.9 used and is proven, if the walk cannot answer.
local function owningInstance(s, sname, instByPath)
    local cur, n = s, 0
    while n < 12 do
        local nxt = nil
        pcall(function() nxt = cur:GetOuter() end)
        if not (nxt and nxt.IsValid and pcall(function() return nxt:IsValid() end) and nxt:IsValid()) then break end
        local p = nil
        pcall(function() p = nxt:GetFullName() end)
        if type(p) ~= "string" then break end
        p = (p:gsub("^[^ ]+ ", ""))
        if instByPath[p] then return p end
        cur = nxt; n = n + 1
    end
    for ipath in pairs(instByPath) do
        if sname:sub(1, #ipath + 1) == ipath .. "." then return ipath end
    end
    return nil
end

local function applyRecruitPins()
    if #recruitPins == 0 then return "idle" end
    if not pinLoadRequested then
        pinLoadRequested = true
        for _, rp in ipairs(recruitPins) do
            for _, s in ipairs(rp.slots) do pcall(LoadAsset, s.part) end
            if rp.match then pcall(LoadAsset, rp.match.part) end
            if rp.definition then pcall(LoadAsset, rp.definition) end
        end
    end
    pinPass = pinPass + 1
    local pinHub, wname = strategySide()
    staleCand = {}      -- 1.8.22: re-collected every pass; no slot userdata survives one (the 05:50:58 rule)
    local nInst, nOurs, nWith, nPinned, nSkip = 0, 0, 0, 0, 0
    local function census(extra)
        local line = string.format("pass %d: %d instance(s) seen, %d ours, %d with pinned slot(s), %d pinned, %d skipped, world=%s%s",
            pinPass, nInst, nOurs, nWith, nPinned, nSkip, wname, extra or "")
        local shape = line:gsub("^pass %d+: ", "")
        if shape ~= pinCensus or pinPass % 20 == 1 then
            pinCensus = shape
            log("recruit pin: " .. line)
        end
    end
    local skipped = {}
    -- 1.8.15: dedup by (owner, REASON), not owner. In the 07:47 session the Sith stopped being identified at 07:52:26
    -- and was skipped for a NEW reason for the rest of the session — invisibly, because the old dedup had already used up
    -- his one line. A changed reason is the most informative line the pin can print; it must never be swallowed.
    local function skip(owner, why)
        if skipped[owner] then return end
        skipped[owner] = true
        nSkip = nSkip + 1
        local k = owner .. "|" .. why
        if pinSkipLogged[k] then return end
        pinSkipLogged[k] = true
        log("recruit pin: skip " .. shortOwner(owner) .. ": " .. why)
    end

    local okI, insts = pcall(FindAllOf, "CustomizationInstance")
    if not okI or type(insts) ~= "table" then
        census(" (FindAllOf CustomizationInstance returned nothing usable)"); return "idle"
    end
    -- every live instance is a CHARACTER. `byDefinition` already identifies some of them; the Name part identifies the rest.
    local instByPath = {}
    for _, inst in ipairs(insts) do
        if inst and inst.IsValid and inst:IsValid() then
            local iname = nil; pcall(function() iname = inst:GetFullName() end)
            if type(iname) == "string" and iname ~= "" and not iname:find("Default__") then
                nInst = nInst + 1
                local ipath = (iname:gsub("^[^ ]+ ", ""))
                local dpath = ""
                local okD, def = pcall(function() return inst:GetDefaultCustomizationDefinition() end)
                if okD and def and def.IsValid and def:IsValid() then
                    pcall(function() dpath = def:GetFullName():gsub("^[^ ]+ ", "") end)
                end
                local proxy = isProxyOwner(ipath)
                for _, rp in ipairs(recruitPins) do
                    local byDef = (rp.definition ~= nil and dpath == rp.definition)
                    if proxy then
                        if not pinSkipLogged[ipath .. "|proxy"] then
                            pinSkipLogged[ipath .. "|proxy"] = true
                            log("recruit pin: skip " .. shortOwner(ipath) .. ": preview/portrait proxy (" .. proxy ..
                                ") — not pinned; it is a transient preview of a character, not the character")
                        end
                    elseif byDef or rp.match then
                        instByPath[ipath] = instByPath[ipath] or
                            { inst = inst, rp = rp, byDefinition = byDef, byTag = {}, dupes = 0, nameSeen = nil, ident = byDef,
                              how = byDef and "its own default CustomizationDefinition" or nil }
                    end
                end
            end
        end
    end
    if next(instByPath) == nil then census(); return "idle" end
    local ksl = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
    local okS, slots = pcall(FindAllOf, "CustomizationFragmentInstanceSlot")
    if not okS or type(slots) ~= "table" then
        census(" (FindAllOf CustomizationFragmentInstanceSlot returned nothing usable)"); return "idle"
    end

    for _, s in ipairs(slots) do
        if s and s.IsValid and s:IsValid() then
            local sname = nil; pcall(function() sname = s:GetFullName() end)
            if type(sname) == "string" and sname ~= "" then
                sname = (sname:gsub("^[^ ]+ ", ""))
                local tag = ""; pcall(function() tag = s.SlotNameTag.TagName:ToString() end)
                local ipath = owningInstance(s, sname, instByPath)
                -- 1.8.19: THE GHOST SWEEP, before anything is driven and on EVERY character in the world, ours or not.
                -- Bounded to this pin's own declared tags and to real characters (a preview proxy is a transient copy
                -- of one, and would print the same ghost again under a new name every pass). Observable-only: the
                -- only thing it changes is `pinGhostSlot`, which stops a slot being COLLECTED, and so driven.
                -- 1.8.20: it runs AFTER `owningInstance`, because the OWNER is now part of the evidence — a slot with
                -- no owning CustomizationInstance is a slot mid-spawn, and mid-spawn is what produced all three of
                -- the 2026-09-13 false positives. The loop also stops at the FIRST matching pin so a tag two pins
                -- both declare cannot double-count the consecutive-pass rule.
                if tag ~= "" and not pinGhostSlot[sname] and not isProxyOwner(sname) then
                    local matched = false
                    for _, rp in ipairs(recruitPins) do
                        for _, pin in ipairs(rp.slots) do
                            if tag == pin.tag and not matched then
                                matched = true
                                local g = ghostOf(s)
                                -- a pass that reads OTHERWISE resets the count: the rule is CONSECUTIVE passes
                                if g then ghostReport(sname, ipath, tag, g, pinPass)
                                else pinGhostSeen[sname] = nil end
                            end
                        end
                    end
                end
                -- 1.8.22: THE STALE-SLOT SWEEP, on the same footing as the ghost sweep — every character in the world,
                -- ours or not, read-only here. It runs AFTER the ghost sweep so a slot the ghost rule has just blocked
                -- can never be collected as a rebuild candidate; whether it is OURS is decided after this loop, when
                -- identity has stopped moving.
                staleConsider(s, sname, ipath, tag)
                local c = ipath and instByPath[ipath]
                if c then
                    local rp = c.rp
                    if rp.match and tag == rp.match.slot then
                        local cur = ""; pcall(function() cur = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end)
                        c.nameSeen = (cur ~= "") and cur or "<none>"
                        if cur == rp.match.part:match("([^/.]+)$") then c.ident = true; c.how = "its " .. shortTag(tag) .. " = " .. cur end
                    end
                    -- 1.8.15 SECOND IDENTITY SOURCE: a slot already holding one of THIS pin's own parts is this pin's
                    -- character. The Name slot can be re-created underneath us (equipping the definition replaces the
                    -- class fragment, and the class fragment is what makes the child slots), and when it blinked the
                    -- 07:47 session lost the Sith for the rest of the run.
                    if not c.ident then
                        local cur = ""; pcall(function() cur = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end)
                        for _, pin in ipairs(rp.slots) do
                            if tag == pin.tag and cur == pin.part:match("([^/.]+)$") then
                                c.ident = true; c.how = "its " .. shortTag(tag) .. " already holds " .. cur
                            end
                        end
                    end
                    for _, pin in ipairs(rp.slots) do
                        if tag == pin.tag and not pinGhostSlot[sname] then
                            -- 1.8.19: a GHOST slot is never collected, so it can never be driven — the refusal is
                            -- structural, not a branch inside the write path.
                            -- 1.8.16: EVERY EQUIP LEAVES THE OLD SLOT OBJECTS ALIVE BESIDE THE NEW ONES. Retail 08:38
                            -- watched one character go 3 -> 6 -> 12 matching slots across three passes, and the old cap
                            -- counted the corpses and refused him. A character has exactly one LIVE slot per tag: keep
                            -- the highest object index (UE numbers each new object above the last) and count the rest
                            -- as the stale duplicates they are.
                            local idx = tonumber(sname:match("_(%d+)$") or "0") or 0
                            local prev = c.byTag[tag]
                            if prev == nil then
                                c.byTag[tag] = { slot = s, tag = tag, pin = pin, idx = idx }
                            else
                                c.dupes = c.dupes + 1
                                if idx > prev.idx then c.byTag[tag] = { slot = s, tag = tag, pin = pin, idx = idx } end
                            end
                        end
                    end
                end
            end
        end
    end

    -- 1.8.22: the stale-slot rebuild, once identity has stopped moving for this pass and before anything of OURS is
    -- driven (different characters, different instances — the order is only so the two never interleave on one).
    local staleBusy = staleDrive(instByPath, ksl, pinHub)

    local pending, refresh = {}, {}
    local waitingOnResidency = false   -- 1.8.19: a pinned part this pass was not resident yet; see the `done` gate
    for ipath, c in pairs(instByPath) do
        local rp = c.rp
        c.hits = {}
        local distinct = 0
        for _, h in pairs(c.byTag) do c.hits[#c.hits + 1] = h; distinct = distinct + 1 end
        if #c.hits > 0 then
            nWith = nWith + 1
            if c.dupes > 0 and not pinSkipLogged[ipath .. "|dupes"] then
                pinSkipLogged[ipath .. "|dupes"] = true
                log("recruit pin: " .. shortOwner(ipath) .. ": " .. c.dupes .. " stale duplicate slot object(s) " ..
                    "ignored (" .. distinct .. " live pinned tag(s); every equip leaves the previous slot objects " ..
                    "alive beside the new ones)")
            end
            -- 1.8.15: identity is STICKY. Once this instance has been identified it stays identified for the session,
            -- because the game can re-create the slot that carried the identity while the pin is mid-flight.
            -- 1.8.16: an IDENTIFIED character is never refused by the cap. The cap exists to stop an instance
            -- nobody has identified from being pinned by accident; it must never fire on the recruit itself.
            if c.ident then pinKnown[ipath] = c.how or "identity"
            elseif pinKnown[ipath] then c.ident = true; c.how = pinKnown[ipath] .. " (remembered from an earlier pass)" end
            if not c.ident then
                skip(ipath, "not ours: " .. #c.hits .. " slot(s) carry pinned tags but its default definition is not " ..
                    tostring(rp.definition and rp.definition:match("([^/.]+)$") or "<none>") ..
                    (rp.match and (" and its " .. shortTag(rp.match.slot) .. " reads " .. tostring(c.nameSeen or "<not present>") ..
                        " (wanted " .. rp.match.part:match("([^/.]+)$") .. ")") or " and this pin declares no `match` rule"))
            elseif distinct > #rp.slots then
                -- THE MASS-PIN GUARD. A character has one slot per pinned tag; more means this instance carries more than one
                -- character's slots (a customization proxy that has previewed several). Retail 2026-09-12 22:15:47: 21 slots,
                -- seven characters, 33 wrong writes. Nothing is written here, ever.
                skip(ipath, distinct .. " LIVE distinct pinned tag(s) against this pin's " .. #rp.slots .. " under ONE CustomizationInstance — " ..
                    "it holds more than one character's slots, so nothing is written (this is the 2026-09-12 22:15:47 guard)")
            else
                nOurs = nOurs + 1
                local how = c.how or (c.byDefinition and "its own default CustomizationDefinition")
                    or (rp.match and ("its " .. shortTag(rp.match.slot) .. " = " .. rp.match.part:match("([^/.]+)$")))
                    or "identity"
                for _, hit in ipairs(c.hits) do
                    local s, tag, pin = hit.slot, hit.tag, hit.pin
                    local before = slotState(s)
                    local cur = (before.id:match("([^:]+)$") or "?")
                    local want = pin.part:match("([^/.]+)$")
                    -- 1.8.14: the retry bound is keyed by the character's STABLE identity (the pin's own Name part or
                    -- its definition), not the instance path — a proxy's path changes as the game recreates it, so the
                    -- old key made PIN_MAX_RETRY unreachable and the 05:43 session re-drove forever without one
                    -- `attempt` give-up line.
                    local ident = (rp.match and rp.match.part:match("([^/.]+)$"))
                        or (rp.definition and rp.definition:match("([^/.]+)$")) or "pin"
                    local key = ident .. "|" .. tag
                    pinExpected[key] = true
                    -- "the id already names our part" is NOT enough: that is the state the setter leaves when the part was not
                    -- resident — our id, a NULL definition, no leveled tree. Re-drive it, bounded by PIN_MAX_RETRY.
                    local need
                    if pinDelivered[key] then
                        need = false                 -- 1.8.18: finished; driving it again would undo it
                    elseif pinToggled[key] then
                        need = true                  -- 1.8.18: the toggle is mid-flight, put ours back
                    elseif cur ~= want then
                        pinAttempts[key] = 0
                        need = true
                    elseif before.defn == "<null>" or before.trees == 0 then
                        -- 1.8.14: the RE-DRIVE trigger is an UNRESOLVED definition, not a zero tree count. A part with no
                        -- leveled abilities at all (the Class and Weapon parts) legitimately has 0 trees for ever, and
                        -- keying on that re-drove them every pass — and because the setter replaces FragmentInstances on
                        -- every call, each re-drive read as DELIVERED and reset the retry counter, so the bound never bit.
                        -- That is the loop that ran 66 times and crashed. `partDefinition == <null>` is self-limiting:
                        -- it stops the moment the part resolves.
                        need = (pinAttempts[key] or 0) < PIN_MAX_RETRY
                        if not need and not pinGaveUp[key] then
                            pinGaveUp[key] = true
                            log("recruit pin: " .. shortTag(tag) .. " on " .. shortOwner(ipath) .. " already holds " .. want ..
                                " but its CustomizationPartDefinition never resolved after " .. PIN_MAX_RETRY ..
                            " attempt(s) — leaving it alone (" ..
                                sigOf(before) .. ")")
                        end
                    else
                        need = false
                    end
                    if need then
                        local partObj = StaticFindObject(pin.part)
                        if partObj and partObj.IsValid and partObj:IsValid() and ksl and ksl:IsValid() then
                            local okId, id = pcall(function() return ksl:GetPrimaryAssetIdFromObject(partObj) end)   -- a real FPrimaryAssetId, never a Lua table
                            if okId and id then
                                partReport(pin.part)
                                local p = pending[ipath]
                                if not p then p = { inst = c.inst, rp = rp, scoped = how, list = {} }; pending[ipath] = p end
                                p.list[#p.list + 1] = { slot = s, tag = tag, id = id, cur = cur, want = want, path = pin.part,
                                                        key = key, before = before }
                            else
                                log("recruit pin FAILED: " .. tag .. " on " .. ipath .. ": GetPrimaryAssetIdFromObject: " .. tostring(id))
                            end
                        else
                            -- the resolver (UCustomizationStatics::GetCustomizationPartDefinitionFromPartId, RVA 0x8c46060) asks
                            -- the AssetManager for the LOADED object first, so residency is the whole variable: without it the
                            -- id is written and the definition stays null.
                            pcall(LoadAsset, pin.part)
                            waitingOnResidency = true
                            skip(ipath .. "|" .. tag, "part " .. want .. " is not resident yet — requested the load, retrying")
                        end
                    end
                end
            end
        end
    end
    -- 1.8.15: the ladder runs on its own clock. A part that will not resolve must keep climbing whether or not the
    -- pin managed to identify a character this pass — the 07:47 session stalled both specs at step 2 for a whole
    -- session because identification blinked and the ladder was only ever driven from inside a successful pin.
    -- 1.8.20: ... but a SETTLED part is off the list entirely. `(partStep[path] or 0) < 5` used to be true again the
    -- moment the drive path cleared partStep on a resolve, which is how the ladder re-climbed a delivered part.
    for path, w in pairs(partWatch) do
        if not partSettled[path] and (partStep[path] or 0) < 5 then
            local o = StaticFindObject(path)
            local resolved = false
            pcall(function() resolved = (o and o.IsValid and o:IsValid()) and true or false end)
            if resolved then escalateResidency(path, w.want, w.ptype, pinPass) end
        end
    end
    if next(pending) == nil then
        -- 1.8.14: nothing to drive AND at least one real character was identified means every pinned slot is either
        -- delivered or has exhausted PIN_MAX_RETRY. There is nothing a 67th pass can do that the 66th did not, and the
        -- 05:43 session showed what endless passes cost: a stale userdata and a crash. Stop, and say so.
        -- 1.8.18: `done` is now a statement about DELIVERY, not about having nothing to do this pass.
        local climbing = false
        for p2 in pairs(partWatch) do if (partStep[p2] or 0) > 0 and (partStep[p2] or 0) < 5 then climbing = true end end
        -- 1.8.18: delivery beats the ladder. Once every slot this pin wants has DELIVERED there is nothing left for a
        -- residency step to discover, so `done` is not held behind it.
        local allDelivered = next(pinExpected) ~= nil
        for k in pairs(pinExpected) do if not pinDelivered[k] then allDelivered = false end end
        -- 1.8.19: `done` MUST NOT mean "the parts had not finished loading yet". Found by replay scenario P, not in
        -- retail: with our parts still absent on pass 1 the pin has nothing pending, nothing is climbing the ladder
        -- (only a DRIVEN slot registers a part with it), and 1.8.18 would log `done — 0 slot(s) DELIVERED` and stop
        -- the loop for the whole session. LoadAsset is asynchronous (the oldest gotcha in this project), so a pass
        -- that is only waiting for a load is not a pass that has finished. The wait is BOUNDED - the 05:43 lesson is
        -- that an unbounded pin loop is what crashes the game - and when the budget runs out `done` fires anyway,
        -- with the honest count and a line saying which part it gave up waiting for.
        if waitingOnResidency and not allDelivered and pinWaited < PIN_RESIDENCY_PASSES then
            pinWaited = pinWaited + 1
            if not pinQuiet["waiting"] then
                pinQuiet["waiting"] = true
                log("recruit pin: holding `done` — a pinned part is not resident yet and LoadAsset is asynchronous; " ..
                    "waiting up to " .. PIN_RESIDENCY_PASSES .. " more pass(es) before giving a verdict")
            end
            census(); return (nWith > 0) and "targets" or "idle"
        end
        if waitingOnResidency and pinWaited >= PIN_RESIDENCY_PASSES and not pinQuiet["waitedout"] then
            pinQuiet["waitedout"] = true
            log("recruit pin: waited " .. PIN_RESIDENCY_PASSES .. " pass(es) and a pinned part is STILL not resident " ..
                "— the verdict below counts it as undelivered")
        end
        -- 1.8.22: `done` stops the loop for the session, so it must not fire with a stale-slot rebuild half done —
        -- the slot would be left on the toggle id. The wait is bounded by the rebuild's own PIN_MAX_RETRY /
        -- PIN_RESIDENCY_PASSES budgets, which is what keeps the 05:43 lesson (an unbounded pin loop) intact.
        if staleBusy and not pinDone and not pinQuiet["stalehold"] then
            pinQuiet["stalehold"] = true
            log("recruit pin: holding `done` — a stale-slot rebuild is mid-flight (the slot is on its toggle id " ..
                "until the next pass writes ours back)")
        end
        if nOurs > 0 and not pinDone and not staleBusy and (allDelivered or not climbing) then
            pinDone = true
            local settled, gaveup = 0, 0
            for k in pairs(pinDelivered) do settled = settled + 1 end
            for k in pairs(pinGaveUp) do gaveup = gaveup + 1 end
            log(string.format("recruit pin: done — %d character(s) ours, %d slot(s) DELIVERED, %d gave up after %d " ..
                "attempt(s); the pin loop stops for this session (re-arm by reloading the game)",
                nOurs, settled, gaveup, PIN_MAX_RETRY))
            staleSummary()
        end
        census(); return pinDone and "done" or ((nWith > 0) and "targets" or "idle")
    end
    for ipath, p in pairs(pending) do
        log("recruit pin: scoped to " .. shortOwner(ipath) .. " by " .. p.scoped .. "; " .. #p.list .. " slot(s) to drive")
        nPinned = nPinned + 1
        applyOwner(ipath, p)
        -- 1.8.13: a slot the equip AND the setter both left with a NULL CustomizationPartDefinition is not a marshalling
        -- failure — the Class part delivered through the same call in the same pass (retail 05:30:21). It is the resolver
        -- refusing THAT id, so the part's residency is escalated one observable step per pass.
        for _, e in ipairs(p.list) do
            partDriven[e.path] = pinPass
            local st = slotState(e.slot)
            if st.defn == "<null>" then
                escalateResidency(e.path, e.want, (st.id:match("^([^:]+)") or nil), pinPass)
            elseif partStep[e.path] then
                log("recruit pin: part " .. e.want .. " resolved after step " .. tostring(partStep[e.path]) ..
                    " of the residency ladder")
                partStep[e.path] = nil
                -- 1.8.20: SETTLED. Clearing partStep alone left the part on partWatch, where a step count of 0 reads
                -- as "not started" and the tick loop climbed it again next pass — the 23:00:38-23:00:58 alternation.
                partSettled[e.path] = true
                partWatch[e.path] = nil
            end
        end
        refresh[ipath] = p.inst
    end
    for ipath, inst in pairs(refresh) do
        local ok, err = pcall(function() inst:RefreshCustomization() end)
        if not ok then log("recruit pin: RefreshCustomization failed on " .. ipath .. ": " .. tostring(err)) end
    end
    census()
    return next(refresh) ~= nil and "pinned" or "targets"
end

-- ---- sequencing ----
local steps = {}
local function addStep(d, fn) steps[#steps + 1] = { delay = d, fn = fn } end
local function runSteps(i)
    local s = steps[i]; if not s then return end
    ExecuteInGameThread(function()
        local ok, err = pcall(s.fn); if not ok then log("STEP ERROR: " .. tostring(err)) end
        ExecuteWithDelay(s.delay, function() runSteps(i + 1) end)
    end)
end
addStep(3000, function() log("=== ZCSDKLoader start ==="); setTrigger() end)
addStep(1000, function() discover() end)
addStep(1000, function() bridge("ZCSDK:byclass|/Script/Bruno|BrunoModificationInventoryItem") end)
addStep(1000, function() injectRegistries() end)
addStep(3000, function() bridge("ZCSDK:byclass|/Script/Bruno|BrunoModificationInventoryItem") end)
addStep(1000, function() preloadPackages() end)
addStep(1000, function() rescanPrimaryTypes() end)
addStep(3000, function() refreshCaches() end)
addStep(2000, function() applyRefreshers() end)     -- 1.3.0: manifest refreshers (data registries re-scan the injected registry)
addStep(6000, function() applyFollowups() end)      -- ... then what the game built from them once at startup (character pools)
if DIAG then
    local REAL = "/Game/Game/GameData/ItemData/Modifications/Modification_Scope_LongRange_T1.Modification_Scope_LongRange_T1"
    addStep(1000, function() pcall(LoadAsset, REAL) end)
    addStep(5000, function()
        local o = StaticFindObject(REAL)
        if o and o:IsValid() then dumpObject(o, "REAL scope item") else log("real scope item not loaded (yet)") end
        for _, g in ipairs(grants) do
            pcall(LoadAsset, g.item); local pkg = g.item:match("^(.-)%.[^%.]+$"); if pkg then bridge("ZCSDK:loadpkg|" .. pkg) end
        end
    end)
    addStep(5000, function()
        for _, g in ipairs(grants) do
            local o = StaticFindObject(g.item)
            if o and o:IsValid() then dumpObject(o, "MOD item") else log("mod item not loaded: " .. g.item) end
        end
    end)
end
-- 1.8.19 (session_audit.py's own recommendation, CHANGELOG v1.28.32): only say "waiting" when there is something to
-- wait FOR. With no grants declared this banner was a gate that could never pass, and the audit charged it as one —
-- seven sessions' worth of open gates that were all vacuous.
addStep(1000, function()
    if #grants > 0 then
        log("=== ZCSDKLoader ready; waiting for an HQ inventory to apply " .. #grants .. " grant(s) ===")
    else
        log("=== ZCSDKLoader ready; 0 grant(s) declared, so no HQ inventory is needed ===")
    end
end)

local ticks, armed = 0, false
LoopAsync(3000, function()
    if armed then return true end
    ticks = ticks + 1
    local ok, pc = pcall(UEHelpers.GetPlayerController)
    local wname = ""; pcall(function() wname = UEHelpers.GetWorld():GetFullName() end)
    if (ok and pc and pc:IsValid() and wname ~= "" and not wname:find("PSOLoader")) or ticks >= 40 then
        armed = true; log("armed: world=" .. wname); ExecuteWithDelay(8000, function() runSteps(1) end); return true
    end
    return false
end)
-- HARDENING (X1 crash review, 2026-09-24): AT MOST ONE grant closure in UE4SS's game-thread queue at a time - the same guard
-- as the recruit pin's pinQueued and ROWFIX's rowQueued. The 4 s tick used to enqueue a fresh closure - and take a fresh
-- Lua registry ref - every tick, forever: `done` was a per-tick local that the closure set AFTER the async body had
-- already returned it, so the loop never saw `true` and never stopped. `grantDone` is now module state, written only by a
-- closure that has RUN and read only on a later tick, so the loop stops (`return true`) once a pass has reported done and
-- never returns a stale value while a closure is pending. The flag is cleared at the END of the closure, on every path
-- (the body runs under one pcall for exactly that). A closure that never runs (a queue UE4SS dropped) must not kill the
-- grants for the session, so after 10 ticks (40 s) the loop queues again.
local grantQueued, grantQueuedFor, grantDone = false, 0, false
LoopAsync(4000, function()
    if not injected then return false end
    if grantDone then return true end                           -- a pass that RAN reported done: stop for good
    if grantQueued then
        grantQueuedFor = grantQueuedFor + 1
        if grantQueuedFor < 10 then return false end            -- the last closure has not run yet: queue nothing
    end
    grantQueued, grantQueuedFor = true, 0
    ExecuteInGameThread(function()
        local okAll, errAll = pcall(function()   -- HARDENING: nothing below may skip the grantQueued clear
            local ok, r = pcall(applyGrants)
            if not ok then log("grant loop error: " .. tostring(r)) end
            if ok and r then grantDone = true end
        end)
        if not okAll then log("grant loop error (outside the pass): " .. tostring(errAll)) end
        grantQueued = false   -- HARDENING: the LAST statement, reached on every path
    end)
    return false
end)
-- 1.4.0: recruit pins, for as long as any manifest carries them. 1.7.0: paced — 3 s while it is doing something, backing off to
-- 24 s while it is not, and back to 3 s the moment the world changes or a pin lands. Everything that touches a UObject runs on the
-- game thread (reading the world off-thread through UE4SS's Lua binding is the kind of call that has faulted inside UE4SS before).
local pinIdle, pinSkip, pinWorld = 0, 0, ""
local pinStop = false   -- 1.8.14: set when applyRecruitPins reports "done"
-- HARDENING (X1 crash review, 2026-09-24): AT MOST ONE pin closure in UE4SS's game-thread queue at a time - the same guard
-- as ROWFIX's rowQueued. pinSkip is only set when the queued closure RUNS, so while the game thread is stalled (a loading
-- screen, a hitch) the 2.5 s tick used to enqueue a fresh closure - and take a fresh Lua registry ref - every tick. This is
-- the closure that replayed stale at 03:14 (`recruit pin: pass 21` 60 s after `loop stopped`; the note is
-- SWBF2 Models Project notes/X1_crash_0314.md), so it must not add ref churn it does not need. The flag is cleared at the
-- END of the closure, on every path (the body runs under one pcall for exactly that). A closure that never runs (a queue
-- UE4SS dropped) must not kill the pin for the session, so after 10 ticks (25 s) the loop queues again.
local pinQueued, pinQueuedFor = false, 0
LoopAsync(2500, function()
    if not injected then return false end
    if #recruitPins == 0 then return true end
    if pinStop then log("recruit pin: loop stopped"); return true end   -- 1.8.14: one-shot, and it never ticks again
    if pinQueued then
        pinQueuedFor = pinQueuedFor + 1
        if pinQueuedFor < 10 then return false end            -- the last closure has not run yet: queue nothing
    end
    if pinSkip > 0 then pinSkip = pinSkip - 1; return false end
    pinQueued, pinQueuedFor = true, 0
    ExecuteInGameThread(function()
        local okAll, errAll = pcall(function()   -- HARDENING: nothing below may skip the pinQueued clear
            -- 1.8.11: the world read goes through the same nil-hardening as the pin itself (GetFullName on an invalid world
            -- returns nil WITHOUT raising), and the pass runs under xpcall so a raise lands in the LOADER'S OWN log with a
            -- traceback instead of only in UE4SS.log — which is the file nobody reads (v1.28.32).
            local w = nil; pcall(function() w = UEHelpers.GetWorld():GetFullName() end)
            w = (type(w) == "string") and w or "<none>"
            if w ~= pinWorld then pinWorld = w; pinIdle = 0 end
            local ok, r = xpcall(applyRecruitPins, function(e)
                return tostring(e) .. " | " .. tostring(debug and debug.traceback and debug.traceback("", 2) or "<no traceback>")
            end)
            if not ok then log("recruit pin error: " .. tostring(r)); r = "idle" end
            -- three tiers, by what the pass actually found:
            --   "pinned"  a slot was just changed -> stay at 3 s, more re-rolls usually follow
            --   "targets" pin-able characters are here and already correct (the squad in a mission) -> 6 s
            --   "idle"    nothing this pin could ever apply to in this world -> back off to 12 then 24 s
            if r == "done" then pinStop = true
            elseif r == "pinned" then pinIdle = 0; pinSkip = 1        -- 1.8.14: 5 s, not 3 s (two of these loops tick per pass)
            elseif r == "targets" then pinIdle = 0; pinSkip = 2
            else
                pinIdle = pinIdle + 1
                pinSkip = (pinIdle < 4) and 0 or ((pinIdle < 12) and 3 or 7)
            end
        end)
        if not okAll then log("recruit pin error (outside the pass): " .. tostring(errAll)) end
        pinQueued = false   -- HARDENING: the LAST statement, reached on every path
    end)
    return false
end)
-- ---- the VAULT saber fix (loader 1.8.2; the diagnosis is CHANGELOG v1.28.4, the arming is the v1.28.6 lesson) ----
-- THE BUG: after a scripted traversal (a mantle / vault) the blade goes out and never comes back, on every saber on
-- 196985 — the game's own and the SDK's alike, so the hilt was never the variable. ZCUnlocked 1.4.1 reads it as the
-- humanoid ABP failing to re-fire OnLightSaberActivate after the landing. This does it from the other end, needing no
-- delegate access: the saber ACTOR already caches the decision.
--
-- VERIFIED OFFLINE before shipping (the thing v1.28.4 did not do — its own note says it "had no offline verification at
-- all"). From the cooked BP_FX_LightSaber_Base.uasset (tools/recon/pkgdump.py + bpclass.py):
--   * Activate  -> exp[13], a real UFunction on BP_FX_LightSaber_Base_C   (so it is callable)
--   * Deactivate-> exp[27], a real UFunction on BP_FX_LightSaber_Base_C   (so it is hookable)
--   * bIsActive, bSaberAutoActivateForCombat -> BoolProperty variables of the class
--   * "Cached Humanoid ABP" -> ObjectProperty typed exactly ABP_BR_Humanoid_Base_C
-- and from the cooked ABP_BR_Humanoid_Base.uasset: SetHasMantled is a real UFunction and HasMantled is in the class's
-- name table. CAVEAT, stated rather than hidden: bpclass.py MISREADS an AnimBlueprintGeneratedClass (it reports
-- ABP_BR_Humanoid_Base_C as "5 functions, 0 variables" — the same silently-wrong shape v1.28.4 hardened it against for
-- the saber), so HasMantled's type and semantics are CORROBORATED, not proven. Hence every read below is pcall'd and a
-- nil/garbage answer means DO NOTHING.
--
-- THE ARMING, which is the part that crashed last time. v1.8.0 retried RegisterHook every 5 s while the class was not
-- loaded and piled bad entries into UE4SS's Lua function registry until the game aborted at the main menu. Here
-- RegisterHook is called AT MOST ONCE: a flag guards it, and it is only reached after StaticFindObject proves the class
-- object is actually loaded (if the class is loaded, so is its Deactivate UFunction export). The loop only ever LOOKS;
-- it never registers speculatively, and it stops for good on the first success. StaticFindObject + LoopAsync +
-- ExecuteInGameThread are all APIs this loader already uses, so nothing unproven is introduced into a runtime that has
-- faulted twice.
local SABER_CLASS = "/Game/Game/FX/Blueprints/Lightsaber/BP_FX_LightSaber_Base.BP_FX_LightSaber_Base_C"
local SABER_FUNC  = "/Game/Game/FX/Blueprints/Lightsaber/BP_FX_LightSaber_Base.BP_FX_LightSaber_Base_C:Deactivate"
local saberHookArmed = false        -- RegisterHook has been called; never call it again, whatever happens next

-- ---- 1.8.3 DIAGNOSTICS: why did nothing happen? ----
-- 2026-09-11 retail: the hook ARMED and the blade still went out on a vault, with no other line in the log. That is
-- five different bugs wearing the same silence, because every guard below is a bare `return`:
--   (1) Deactivate is never called on a vault at all - the blade goes out by some other path
--   (2) bSaberAutoActivateForCombat is false        (3) the Cached Humanoid ABP is not valid
--   (4) HasMantled is false at that instant         (5) relight ran but the blade was already lit
-- The handoff claimed the log distinguished the outcomes; it distinguished armed / re-lit / neither, which is one
-- level too coarse to act on. These lines name the branch. Capped, because Deactivate fires on every legitimate
-- sheath too and an uncapped log would bury the answer - this is a diagnostic, not telemetry.
local vaultDiagN, VAULT_DIAG_MAX = 0, 60
local function vdiag(msg)
    if vaultDiagN >= VAULT_DIAG_MAX then return end
    vaultDiagN = vaultDiagN + 1
    log("vault saber: " .. msg .. (vaultDiagN == VAULT_DIAG_MAX and "   [further diagnostics suppressed]" or ""))
end

-- ---- 1.8.21: THE RELIGHT SWITCH, and the evidence that closed it ----
-- RETAIL 2026-09-14 04:53, loader 1.8.20 deployed, one second into a mission:
--     04:53:30  vault saber: PATH> DeactivateLightsaber
--     04:53:30  vault saber: DeactivateLightsaber: relighting through ActivateSaberCheck (HasMantled=true)
--     04:53:30  vault saber: relight (350ms) -> ActivateSaberCheck(1) [target from Owning Saber Position]
--     04:53:30  main.lua:2011: [Lua::Registry::get_function_ref] Ref was not function
--                   traceback: [C]: in method 'ActivateSaberCheck'
--     04:53:31  vault saber: PATH> ActivateSaberCheck  ... RELIGHT VERIFIED (900ms) - bIsActive=true |
--                   Activated Lightsaber Blade=set | Sheath=0.000
--   and the operator reports EVERY CHARACTER RUNNING IN PLACE at mission start — the insertion sequence never
--   completed. `ActivateSaberCheck` is a function THIS SAME MOD has RegisterHook'd (the log-only `[state]` probe of
--   1.8.6), so calling it from Lua made UE4SS's hook dispatcher fail to find its own Lua callback ref and throw
--   INSIDE the game's call frame. INFERRED: that exception, mid-`ActivateSaberCheck` during the insertion mantle,
--   broke the mission's start sequence. The inference may be imprecise; the two rules it produced are not:
--     (A) NEVER call a UFunction this runtime has hooked.  (B) NEVER drive the saber during the insertion mantle.
-- Hence OFF by default. The handlers keep every read and every diagnostic — they are how the next vault is judged —
-- and schedule nothing. If this is ever flipped true, `armPathProbe` refuses to register the `[state]` hooks on
-- ActivateSaberCheck/DeactivateSaberCheck, so rule (A) cannot be broken by a switch.
local RELIGHT_ENABLED = false
-- the one line a disabled deactivation prints, so a retail log still says what the loader decided and what to grep
-- for next. `which` names the path that reached it (Deactivate vs DeactivateLightsaber).
local function relightDisabledNotice(which)
    log("vault saber: relight DISABLED (1.8.21) [" .. which .. "] — leaving the blade to the game's own " ..
        "ActivateSaberCheck at the next turn; watch for `ActivateSaberCheck state: ... bIsActive=false` followed " ..
        "by `PATH> ActivateLightsaber`")
end

-- one re-light attempt: only if the blade is still out and the wielder is still mid-traversal
-- 1.8.5: calls ActivateLightsaber, NOT Activate. `Activate` is the generic component method and is not on the blade
-- path at all - the 2026-09-12 probe caught `ActivateLightsaber` lighting the blade at mission start while `Activate`
-- fired separately a third of a second earlier. Four versions of this fix called the wrong one.
-- 1.8.6: THE RELIGHT CALL IS WITHDRAWN. 1.8.5 called ActivateLightsaber() with no arguments and UE4SS threw
-- "UFunction expected 4 parameters, received 0" on every vault. I checked that the function EXISTED in the export
-- table and never checked its SIGNATURE - the same mistake this project keeps writing gotchas about, made one step
-- after the probe was built specifically to stop guessing. A Blueprint UFunction's parameters are serialised inside
-- the function export's own data, not as separate exports, so the signature needs real work to read offline; until
-- it IS read, this calls nothing. A throwing hook on a gameplay function is not something to leave deployed.
-- 1.8.7: RELIGHT BY REPLAYING THE EXTINGUISH ARGUMENTS.
-- The signature was finally READ rather than guessed (v1.28.29, tools/recon/bpclass.py against the cooked package):
--     ActivateLightsaber(Lightsaber Blade : StaticMeshComponent,
--                        BladeLight       : PointLightComponent,
--                        WeaponInteractionCollision : BoxComponent,
--                        Target Saber     : Enum_LightsaberStateTarget)
-- and DeactivateLightsaber takes THE IDENTICAL FOUR. That is what makes this safe: the hook is handed exactly the
-- arguments the relight needs, so nothing has to be reconstructed from the actor's variables or guessed - which is
-- what went wrong in 1.8.0-1.8.5 (four versions called the no-arg `Activate`; 1.8.5 called this one with none and
-- UE4SS threw "expected 4 parameters, received 0").
-- The captured values are resolved with :get() INSIDE the hook, because a RemoteUnrealParam wrapper is only valid for
-- the duration of the callback - the UObjects it yields stay valid afterwards, the wrapper does not.
-- 1.8.9 (the 2026-09-12 crash analysis): the three captured COMPONENTS are held across 350 ms and 900 ms of game
-- time, which is long enough for the wielder to be destroyed, the saber to be unequipped, or a level transition to
-- collect them. `args ~= nil` only says the capture happened; it says nothing about whether the objects it points at
-- are still alive. Passing a stale UObject into a UFunction call is a native fault that pcall cannot catch, so each
-- one is re-validated here and the stale one is NAMED - the same rule as GetClass: IsValid first, then use.
--
-- ================================================================================================================
-- 1.8.20: THE REPLAY IS WITHDRAWN. THE RELIGHT GOES THROUGH THE GAME'S OWN `ActivateSaberCheck`, AND `bIsActive`
--         IS NO LONGER ALLOWED TO REPORT SUCCESS.
--
-- WHAT RETAIL 2026-09-13 22:52 SHOWED (log ZCSDKLoader.log):
--   23:17:41  Hawks vaulted, DeactivateLightsaber fired (HasMantled=true, bSaberAutoActivateForCombat=true), the
--             1.8.19 relight replayed the four captured arguments into ActivateLightsaber and logged
--             `re-lit (350ms) - bIsActive now true`.
--   the operator reports THE BLADE WAS NEVER VISIBLE AGAIN for the rest of the mission, and
--   23:21:16  the game's OWN ActivateSaberCheck logged `HasMantled=false bIsActive=true` and DID NOTHING.
-- So 1.8.19 did not fix the blade; it set the flag that stops the game fixing the blade. v1.28.30's "RETAIL
-- CONFIRMED" confirmed the FLAG, never the blade.
--
-- WHY, PROVEN from the cooked class with tools/recon/kismet.py against
-- build/_retail/SWZeroCompany/Content/Game/FX/Blueprints/LightSaber/BP_FX_LightSaber_Base.uasset (re-run it; every
-- offset below is an offset into ExecuteUbergraph_BP_FX_LightSaber_Base, 1389 opcodes, CLEAN):
--   * `ActivateLightsaber` is ubergraph entry 864 (`+864 EX_Jump -> +520`). At `+521` it sets `Self.bIsActive = true`,
--     stores the three components into `Activated Lightsaber Blade` / `Activated Blade Light` / `Activated Weapon
--     Interaction Collision`, `+621 SetCollisionEnabled(5)`, `+659 Timeline_Blade::PlayFromStart`.
--     `DeactivateLightsaber` is entry 869 (`+869 EX_Jump -> +692`), the mirror with `ReverseFromEnd`.
--   * The 4th parameter `Target Saber` lands in the ubergraph locals `K2Node_CustomEvent_Target_Saber_2` / `_3` and
--     is NEVER READ as an operand anywhere in those 1389 opcodes. It is DEAD on both paths — which is why replaying
--     it changed nothing.
--   * The VISIBLE blade is produced ONLY by `Timeline_Blade__UpdateFunc` (entry 4198):
--     `SetScalarParameterValueOnMaterials("Sheath", ...)` on the blade mesh, and the light values via `+3111`.
--     `bIsActive` is read in exactly THREE places — `+1876` (DeactivateSaberCheck), `+2091` (ActivateSaberCheck) and
--     the `IsActive` getter — and drives NO visual state at all.
--   * `ActivateSaberCheck` is entry 1890. After `Trilla Alt Saber Override` (`+1890`, CDO false) it matches
--     `TargetSaber == 2` (`+1979`) OR `TargetSaber == Self.Owning Saber Position` (`+2010..+2048`), bails at `+2076`,
--     and then **`+2086 EX_JumpIfNot Self.bIsActive -> +1904`**, where `+1904` calls
--     `ActivateLightsaber(Self.Lightsaber_Blade, Self.BladeLight, WeaponInteractionCollision, TargetSaber)` from LIVE
--     component reads. If `bIsActive` is ALREADY true it falls into `+2100 EX_PopExecutionFlow` and does nothing.
--     `DeactivateSaberCheck` (entry 1679) mirrors it at `+1875`. Both are bound to the ABP's
--     OnLightSaberActivate / OnLightSaberDeactivate delegates at entry 964.
-- INFERRED, retail-only and stated as such: the blade stayed dark because `PlayFromStart` 350 ms into the mantle
-- montage did not advance the Sheath curve. What is PROVEN is that setting `bIsActive=true` turned the game's own
-- next-turn recovery at `+2086` into a no-op.
--
-- THE SIGNATURE, READ NOT GUESSED (v1.28.29's lesson, and this is the third function in this file to need it).
-- `python tools/recon/kismet.py <the cooked asset> --function ActivateSaberCheck` prints:
--     ### ActivateSaberCheck  (36 code / 48 archive bytes, 8 opcodes) CLEAN
--     #   params/locals: TargetSaber:ByteProperty
--     +0  EX_LetValueOnPersistentFrame ...:K2Node_CustomEvent_TargetSaber ; +18 call ubergraph, +27 EX_IntConst 1890
-- ONE parameter, `TargetSaber : ByteProperty` (Enum_LightsaberStateTarget). Not four. Not zero.
--
-- THE TARGET VALUE. `GetTargetLightsaber` is `State = Self.Owning Saber Position` and nothing else (6 opcodes), and
-- the base CDO's `Owning Saber Position` is 0; the game itself passes literal 1 at mission start (`+88`) and at
-- `+502`. Enum_LightsaberStateTarget (jmap, UserDefinedEnum): NewEnumerator0=0, NewEnumerator1=1, NewEnumerator2=2
-- ("both/any"), Enum_MAX=3. So the saber's OWN position always satisfies the `+2010` equality; the property is read
-- first, `GetTargetLightsaber()` is the fallback, and 2 ("both") is the last resort because `+1979` accepts it
-- unconditionally.
--
-- AND `bIsActive` IS NO LONGER A SUCCESS REPORT. It is the flag the old fix set while the blade stayed dark, so a
-- line saying "bIsActive now true" is exactly the line that misled v1.28.30. The call logs the flag, and then ONE
-- delayed read ~600 ms later reports the actual VISUAL state: `Activated Lightsaber Blade` non-null (the ubergraph
-- writes it at `+521`, so it is the cheapest proof ActivateLightsaber really ran) and, if it can be read at all, the
-- blade material's `Sheath` scalar — which is the single value `Timeline_Blade__UpdateFunc` drives. A relight that
-- flips the flag and leaves the blade dark reads `RELIGHT UNVERIFIED`, never as a success.
-- ================================================================================================================

-- the saber's own target enum, by the three routes in descending order of directness. Reads only, every step pcall'd.
local function saberTarget(saber)
    local v = nil
    pcall(function() v = saber["Owning Saber Position"] end)
    if type(v) == "number" then return v, "Owning Saber Position" end
    pcall(function() v = saber:GetTargetLightsaber() end)
    if type(v) == "number" then return v, "GetTargetLightsaber()" end
    return 2, "the enum's 'both' member (2) — neither the property nor the getter could be read"
end

-- the VISUAL state, read ~600 ms after the call. A FAILED read is reported as `<unreadable: why>` and concludes
-- NOTHING (1.8.16's lesson); only a successful read of a null/!IsValid `Activated Lightsaber Blade` means the blade
-- is not there.
local function bladeState(saber)
    local activated = "<unreadable>"
    local okA, blade = pcall(function() return saber["Activated Lightsaber Blade"] end)
    if not okA then activated = "<unreadable: " .. tostring(blade) .. ">"
    elseif blade == nil then activated = "null"
    elseif uvalid(blade) then activated = "set"
    else activated = "stale" end
    -- the Sheath scalar is what Timeline_Blade__UpdateFunc actually writes. `Blade materials` is an
    -- ArrayProperty<MaterialInstanceDynamic> on the class (recon/bpclass.py), and K2_GetScalarParameterValue is
    -- UMaterialInstanceDynamic's own BlueprintCallable getter — but neither the array accessor nor that call has
    -- ever been exercised from Lua in this runtime, so a failure here is REPORTED, never concluded from.
    local sheath = "<unreadable: not attempted>"
    pcall(function()
        local mats = saber["Blade materials"]
        if mats == nil then sheath = "<unreadable: 'Blade materials' is null>"; return end
        local mid = nil
        pcall(function() mid = mats[1] end)
        if not uvalid(mid) then
            mid = nil
            pcall(function()
                mats:ForEach(function(_, e)
                    if mid == nil then
                        local g = nil
                        pcall(function() g = e:get() end)
                        if uvalid(g) then mid = g end
                    end
                end)
            end)
        end
        if not uvalid(mid) then sheath = "<unreadable: no live MaterialInstanceDynamic in 'Blade materials'>"; return end
        local okS, v = pcall(function() return mid:K2_GetScalarParameterValue(FName("Sheath")) end)
        sheath = (okS and type(v) == "number") and string.format("%.3f", v)
                 or ("<unreadable: K2_GetScalarParameterValue failed: " .. tostring(v) .. ">")
    end)
    return activated, sheath
end

-- one re-light attempt, through the game's own check. 1.8.20: no captured components, so nothing stale can be
-- passed into a UFunction; the only UObject held across the delay is the saber, and it is re-validated here.
local function relight(saber, tag)
    local ok, err = pcall(function()
        if not uvalid(saber) then vdiag("relight (" .. tag .. "): saber no longer valid"); return end
        local target, how = saberTarget(saber)
        -- Announced BEFORE the call, deliberately: the 1.8.4 path probe hooks ActivateSaberCheck too, so the
        -- `vault probe: PATH> ActivateSaberCheck` line that follows this one is OURS, not the game's. Without this
        -- line the log cannot tell the two apart, and telling them apart is the whole retail check.
        log(("vault saber: relight (%s) -> ActivateSaberCheck(%s) [target from %s]"):format(tag, tostring(target), how))
        -- ActivateSaberCheck is SELF-IDEMPOTENT: +2086 makes it a no-op when bIsActive is already true, so the
        -- 350/900 ms pair costs nothing and the "already lit, leaving alone" early-out of 1.8.7 is not needed.
        -- 1.8.21 RULE (A) — DO NOT CALL A UFUNCTION THIS MOD HAS HOOKED. This line is only ever reached with
        -- RELIGHT_ENABLED true, and in that case `armPathProbe` has REFUSED to register the `[state]` hooks on
        -- ActivateSaberCheck/DeactivateSaberCheck. Retail 04:53:30 is what happens when both exist: UE4SS throws
        -- `[Lua::Registry::get_function_ref] Ref was not function` inside the game's own call frame. Anyone adding
        -- a call here must check PROBE_FUNCS first — a hooked callee is a fault, not a slow path.
        saber:ActivateSaberCheck(target)
        ExecuteWithDelay(600, function() ExecuteInGameThread(function()
            local ok2, err2 = pcall(function()
                if not uvalid(saber) then
                    log("vault saber: RELIGHT UNVERIFIED (" .. tag .. ") - the saber went away before the check"); return end
                local activated, sheath = bladeState(saber)
                -- VERIFIED requires the VISUAL state, not the flag: `Activated Lightsaber Blade` is written at
                -- ubergraph +521, so it proves ActivateLightsaber really ran — but 1.8.19 got that far and the
                -- blade still stayed dark, so it is not sufficient on its own. A Sheath scalar that can actually
                -- be READ is the second half. The POLARITY of that number is not yet known (nothing offline says
                -- whether an extended blade is Sheath=0 or Sheath=1), so it is PRINTED and not judged: the first
                -- retail vault establishes it by comparing this line with a mission-start relight.
                local lit = (activated == "set") and (tonumber(sheath) ~= nil)
                log(("vault saber: %s (%s) - bIsActive=%s | Activated Lightsaber Blade=%s | Sheath=%s")
                    :format(lit and "RELIGHT VERIFIED" or "RELIGHT UNVERIFIED", tag,
                            tostring(saber.bIsActive), activated, sheath))
            end)
            if not ok2 then log("vault saber: RELIGHT UNVERIFIED (" .. tag .. ") - the check itself failed: " ..
                                tostring(err2)) end
        end) end)
    end)
    if not ok then log("vault saber: relight failed (" .. tag .. "): " .. tostring(err)) end
end

-- ---- 1.8.5: THE FIX, on the PROVEN trigger ----
-- Retail 2026-09-12 named the whole sequence. On the first vault: DeactivateLightsaber + DeactivateSaberCheck. On
-- every later vault: DeactivateSaberCheck alone (already out, nothing to do). At the next turn: ActivateSaberCheck
-- fires and DECLINES, then DeactivateSaberCheck again. ActivateLightsaber never runs after mission start, which is
-- exactly why the blade never returns on its own and why waiting for the game to recover was never going to work.
-- The gameplay side is unaffected throughout - the strike still animates, sounds and kills - so this is the blade's
-- visual/lit state alone.
--
-- THE DISCRIMINATOR, and why it is `bSaberAutoActivateForCombat` rather than `HasMantled`:
-- DeactivateLightsaber must also fire on a LEGITIMATE sheath (combat over, a cinematic), and re-lighting there would
-- be a new bug. `bSaberAutoActivateForCombat` is the game's OWN answer to "should this blade be lit for combat right
-- now", so deferring to it means a legitimate sheath is left alone without us having to model when one happens.
-- `HasMantled` was the plan for four versions and has never once been observed true at the moment of the call - so it
-- is LOGGED here, not trusted. If the log shows it reliably true on a vault, a later version can tighten on it.
local function onDeactivateLightsaber(saber)
    local ok, err = pcall(function()
        if not (saber and saber:IsValid()) then vdiag("DeactivateLightsaber: saber not valid"); return end
        -- The discriminator is the game's OWN answer to "should this blade be lit for combat right now". A legitimate
        -- sheath (combat over, a cinematic) clears it, so deferring to it means we never re-light over the game's
        -- intent. Retail 2026-09-12 measured it TRUE on a vault while bIsActive was false - exactly the stuck state.
        if not saber.bSaberAutoActivateForCombat then
            vdiag("DeactivateLightsaber: SKIP, bSaberAutoActivateForCombat=false (a legitimate sheath)"); return end
        local abp = saber["Cached Humanoid ABP"]
        local mantled = "ABP null"
        if abp and abp:IsValid() then mantled = tostring(abp.HasMantled) end
        -- 1.8.20: no `args captured=` any more — the relight replays nothing, so there is nothing to capture.
        vdiag("DeactivateLightsaber: state at the extinguish (HasMantled=" .. mantled .. ")")
        -- 1.8.21: reads and diagnostics above are UNCHANGED; only the scheduling is gated. Nothing is queued here.
        if not RELIGHT_ENABLED then relightDisabledNotice("DeactivateLightsaber"); return end
        vdiag("DeactivateLightsaber: relighting through ActivateSaberCheck (HasMantled=" .. mantled .. ")")
        ExecuteWithDelay(350, function() ExecuteInGameThread(function() relight(saber, "350ms") end) end)
        ExecuteWithDelay(900, function() ExecuteInGameThread(function() relight(saber, "900ms") end) end)
    end)
    if not ok then log("vault saber: DeactivateLightsaber handler error: " .. tostring(err)) end
end

local function onSaberDeactivate(saber)
    local ok, err = pcall(function()
        if not (saber and saber:IsValid()) then vdiag("Deactivate: saber not valid"); return end
        vdiag("PATH> Deactivate")                               -- (1) if this never appears, the blade goes out elsewhere
                                                                -- (1.8.19: was "Deactivate FIRED"; one firing verb now)
        -- should this saber be lit at all? a legitimate sheath (combat over, a cinematic) says no, and is left alone
        if not saber.bSaberAutoActivateForCombat then
            vdiag("  SKIP: bSaberAutoActivateForCombat=false (a legitimate sheath)"); return end
        local abp = saber["Cached Humanoid ABP"]
        if not (abp and abp:IsValid()) then
            vdiag("  SKIP: 'Cached Humanoid ABP' is null/invalid on this saber"); return end
        if not abp.HasMantled then                              -- not a traversal: a real deactivate, leave it alone
            vdiag("  SKIP: HasMantled=false (the discriminator says this is not a traversal)"); return end
        vdiag("  MATCH: HasMantled=true (the traversal shape)")
        -- 1.8.21: every read and every SKIP line above is unchanged; only the scheduling is gated.
        if not RELIGHT_ENABLED then relightDisabledNotice("Deactivate"); return end
        vdiag("  -> scheduling relight at 350ms and 900ms")
        ExecuteWithDelay(350, function() ExecuteInGameThread(function() relight(saber, "350ms") end) end)
        ExecuteWithDelay(900, function() ExecuteInGameThread(function() relight(saber, "900ms") end) end)
    end)
    if not ok then log("vault saber: hook body error: " .. tostring(err)) end
end

-- ---- 1.8.4: THE PATH PROBE. Which function actually extinguishes the blade? ----
-- 2026-09-12 retail, loader 1.8.3: the hook ARMED on `Deactivate` and `Deactivate FIRED` never appeared, so that
-- function is simply not on the vault path. Decoding the cooked class explains why - it exports FIFTY UFunctions
-- including BOTH a generic pair and a saber-specific pair:
--     Activate / Deactivate                 <- what 1.8.0-1.8.3 hooked, and what relight() called
--     ActivateLightsaber / DeactivateLightsaber
--     ActivateSaberCheck / DeactivateSaberCheck
--     Cinematic_Activate / Cinematic_Deactivate
-- The fix has been aimed at the generic pair for four versions. Rather than guess again, this registers a LOG-ONLY
-- hook on every candidate and prints which fires, in order, on a real vault. No relight is attempted here on purpose:
-- a probe that also acts cannot tell you whether it was right.
-- SAFETY: each RegisterHook is still called AT MOST ONCE, from the same one-shot arming path, and only after
-- StaticFindObject proves the class is loaded. The 1.8.0 abort came from RETRYING failed registrations on a timer,
-- not from registering several real ones - so N one-shot hooks carry the same risk as the one 1.8.2 already shipped.
-- NOTE: "Deactivate" is deliberately absent - SABER_FUNC already hooks it and logs "PATH> Deactivate". Registering
-- the same UFunction twice is an unknown, and this probe must not add a new failure mode to a runtime that has
-- already faulted twice.
local PROBE_FUNCS = {
    "DeactivateLightsaber", "DeactivateSaberCheck", "Cinematic_Deactivate",
    "Activate", "ActivateLightsaber", "ActivateSaberCheck", "Cinematic_Activate",
}
local probeArmed = false            -- same discipline as saberHookArmed: RegisterHook is NOT retry-safe
-- 1.8.21 RULE (A): the relight CALLS ActivateSaberCheck, and a UFunction this mod has HOOKED cannot be called from
-- Lua — retail 04:53:30 threw `[Lua::Registry::get_function_ref] Ref was not function` inside the game's own call
-- frame and the mission's insertion sequence never completed. So with the relight ON, the two `[state]` check hooks
-- are NOT registered. With the default (RELIGHT_ENABLED false) nothing is skipped and all 8 hooks arm as in 1.8.20.
local PROBE_SKIP = "vault probe: NOT hooking %s — the relight calls it and UE4SS cannot dispatch a hook from " ..
                   "inside a Lua-initiated call (1.8.21)"
local function armPathProbe(classPath)
    if probeArmed then return end   -- re-entry is impossible, whatever calls this and however often
    probeArmed = true               -- set BEFORE any RegisterHook: even if one throws, never retry
    for _, fn in ipairs(PROBE_FUNCS) do
        local target = classPath .. ":" .. fn
        local isFixTarget = (fn == "DeactivateLightsaber")     -- 1.8.5: the proven extinguish path
        -- 1.8.6: the SABER-CHECK functions are the ones worth watching now. At the start of the next turn the game
        -- runs ActivateSaberCheck and DECLINES to re-light. The hypothesis is that `HasMantled` is never CLEARED
        -- after a scripted traversal, so the check still believes the wielder is mid-vault - which would also
        -- explain why it was true when DeactivateLightsaber fired. Log the state at every check and find out.
        local isCheck = (fn == "ActivateSaberCheck" or fn == "DeactivateSaberCheck")
        if isCheck and RELIGHT_ENABLED then log(PROBE_SKIP:format(fn)); goto continue end   -- 1.8.21 rule (A), above
        local ok, err = pcall(RegisterHook, target, function(ctx)
            vdiag("PATH> " .. fn)
            if isFixTarget or isCheck then
                local ok2, s = pcall(function() return ctx:get() end)
                if ok2 and isFixTarget then
                    -- 1.8.20: the four DeactivateLightsaber parameters are NOT captured any more. The relight calls
                    -- ActivateSaberCheck(TargetSaber), which reads Self.Lightsaber_Blade / Self.BladeLight /
                    -- WeaponInteractionCollision LIVE at ubergraph +1904 — so there is nothing to hold across the
                    -- 350/900 ms wait, and with it goes the whole stale-component failure mode of 1.8.7-1.8.19.
                    onDeactivateLightsaber(s)
                end
                if ok2 and isCheck then
                    local ok3, err3 = pcall(function()
                        if not (s and s:IsValid()) then return end
                        local abp = s["Cached Humanoid ABP"]
                        local m = (abp and abp:IsValid()) and tostring(abp.HasMantled) or "ABP null"
                        vdiag(("   %s state: HasMantled=%s bIsActive=%s autoCombat=%s"):format(
                            fn, m, tostring(s.bIsActive), tostring(s.bSaberAutoActivateForCombat)))
                    end)
                    if not ok3 then vdiag("   " .. fn .. " state read failed: " .. tostring(err3)) end
                end
            end
        end)
        -- 1.8.19 VOCABULARY: one arming verb for the whole runtime — `hook armed on <class>:<fn>` — so session_audit
        -- reads the probe's hooks exactly as it reads the fix's, and the FAILURE line names the function too.
        if ok then log("vault probe: hook armed on " .. target .. (isFixTarget and "  [handler]" or (isCheck and "  [state]" or "")))
        else log("vault probe: could NOT hook " .. target .. " (" .. tostring(err) .. ")") end
        ::continue::
    end
end

-- LOOK for the class; register exactly once when it is really there. Deliberately NOT a per-frame hook:
-- ABP_BR_Humanoid_Base_C:SetHasMantled is the obvious trigger but is driven by the anim graph, and putting Lua on the
-- frame path is exactly what this runtime must not do after the 2026-09-09/10 UE4SS Lua faults. One hook covers every
-- saber: each saber Blueprint is a data-only child of BP_FX_LightSaber_Base_C, so the base's UFunction is shared.
--
-- 1.8.23: RESIDENT IS NOT ENOUGH — WAIT FOR A MISSION, AND LET IT SETTLE. Two EXCEPTION_ACCESS_VIOLATIONs inside
-- UE4SS (2026-09-13 22:51:55 and 2026-09-15 08:58:38.9) landed at exactly this point: the class went resident during
-- the HUB's spawn wave, the loop began RegisterHooking, and the process died with UE4SS-only top frames. So the gate
-- is now three-part — a MISSION world (the TurnProbe's `/Maps/Skirmish/` marker, which `HUB_Root` and `MainMenu`
-- never match), the class resident, and SABER_HOOK_SETTLE seconds since that mission world was FIRST seen. Still
-- exactly one registration per process: `saberHookArmed` is the same one-shot guard and a failed RegisterHook is
-- still never retried.
local SABER_MISSION_MARK  = "/Maps/Skirmish/"   -- the mission test the TurnProbe uses (TurnProbe main.lua MISSION_MARK)
local SABER_HOOK_SETTLE   = 8                   -- seconds a mission world must have been up before any RegisterHook
local saberMissionWorld   = nil                 -- the mission world currently being waited on
local saberMissionSeenAt  = nil                 -- os.time() it was first seen
local saberDeferNoticed   = false               -- the "deferred to a mission world" line is logged once per process
LoopAsync(5000, function()
    if saberHookArmed then return true end                      -- stop the loop for good
    local cls = StaticFindObject(SABER_CLASS)
    if not (cls and cls:IsValid()) then return false end        -- not loaded yet: LOOK again, register nothing
    local wname = pinWorldName()
    if not wname:find(SABER_MISSION_MARK, 1, true) then         -- the hub / the menu: LOOK again, register nothing
        if not saberDeferNoticed then
            saberDeferNoticed = true
            log("vault saber: arming deferred to a mission world (1.8.23) — the hub's spawn wave crashed UE4SS " ..
                "twice during RegisterHook")
        end
        saberMissionWorld, saberMissionSeenAt = nil, nil        -- the clock only ever runs in a mission world
        return false
    end
    if saberMissionWorld ~= wname then                          -- first sight of THIS mission world: start the clock
        saberMissionWorld, saberMissionSeenAt = wname, os.time()
        log(("vault saber: mission world seen at %s; arming in %d s"):format(os.date("%H:%M:%S"), SABER_HOOK_SETTLE))
        return false
    end
    if os.difftime(os.time(), saberMissionSeenAt) < SABER_HOOK_SETTLE then return false end   -- the burst is not over
    saberHookArmed = true                                       -- set BEFORE the call: even if it throws, never retry
    local ok, err = pcall(RegisterHook, SABER_FUNC, function(ctx)
        local ok2, s = pcall(function() return ctx:get() end)
        if ok2 then onSaberDeactivate(s) end
    end)
    if ok then log("vault saber: hook armed on " .. SABER_FUNC)
    else log("vault saber: RegisterHook FAILED on " .. SABER_FUNC .. " (not retrying, by design): " .. tostring(err)) end
    armPathProbe(SABER_CLASS)           -- 1.8.4: log-only, tells us which function is really on the vault path
    return true
end)

-- ---- 1.8.24: THE ARMOURY MODEL LIST'S BLANK ROWS (a latent game bug that a long weapon list exposes) ----
-- THE BUG (decoded from the retail paks, BF2BlasterPack notes/U_blank_tiles.md): the weapon MODEL list is
-- WBP_Customization_BoxList.PartList, a virtualised BitReactorListView of WBP_Customization_WeaponBox entries. The entry's
-- Construct and PreConstruct play its BuildOn animation at label "Off", which keys the entry's root panel (Overlay_0) to
-- RenderOpacity 0. Only the entry's own PlayBuildOn(Delay) plays "On" (opacity 1), and only BoxList.BuildOnTiles calls it:
-- once per page build, over PartList.GetDisplayedEntryWidgets() at that moment. A row the list generates LATER (scrolled
-- into view; the list shows about 7 rows) gets a fresh entry, or a pooled one that was itself fresh, and stays at opacity 0:
-- drawn as nothing, but still Visible, so it takes clicks. Hover and selection play "States" (colours), never BuildOn.
-- Stock weapon lists hold at most about 6 player-facing parts, so they never scroll and never hit this. A mod that adds
-- weapons makes the list scroll, and then stock rows and the mod's rows alike can go blank.
-- THE FIX: find every stuck entry (CONTENT - Overlay_0 - opacity < 0.05, the entry NOT Hidden - PlayBuildOn hides it for its delay - and
-- BuildOn not playing) and call the entry's OWN PlayBuildOn(0). If UE4SS cannot make that call, fall back to setting the
-- content's RenderOpacity to 1. A row must be seen stuck on two ticks in a row (>= 1 s), and nothing is touched while any
-- entry of the same list is mid-cascade (Hidden), so the game's own build-on is never raced. In a list the game builds
-- correctly (every stock list) no entry is ever stuck, so this never fires there.
-- COST / SAFETY (the 1.7.0 and 1.8.x lessons): no RegisterHook and no NotifyOnNewObject. Only APIs this loader already uses
-- (LoopAsync, ExecuteInGameThread, StaticFindObject, FindAllOf), plus two UFunction calls on widgets the loop just found.
-- It runs in HUB_Root only; nothing happens until the WeaponBox class is loaded (the Armoury's weapon page has been
-- opened). FindAllOf runs every tick (1 s) while entries exist (1.8.25), and backs off to 12 s while none do. All UObject access
-- happens on the game thread, and every call is pcall'd.
local ROWFIX = true                 -- kill switch
-- WHICH repair, set from the round-6 experiment (BF2BlasterPack notes/U_blank_tiles.md section 9):
--   "entry" = Ctrl+F9 filled the blank slots (entries whose CONTENT sits at BuildOn "Off"): re-show stuck entries;
--   "list"  = Ctrl+F8 closed them (the list's layout / scroll state is off): after the MODEL list settles on a new
--             selection or item count, RequestRefresh() it, then BP_ScrollItemIntoView(selected) - what the list's own
--             PartViewModels handler does at build, re-done once the entries have their real size.
local ROWFIX_MODE = "entry"
local ROWFIX_LOG_CAP = 500           -- "ROWFIX healed <name> via PlayBuildOn|opacity" lines per session
local ROWFIX_CLASS = "/Game/Game/UI/Strategy/Customization/Widgets/New/WBP_Customization_WeaponBox.WBP_Customization_WeaponBox_C"
local rowBoxes, rowStuck, rowBusy, rowTick, rowNextScan, rowIdle, rowHealed = {}, {}, {}, 0, 0, 0, 0
local function rowValid(o) return o ~= nil and o.IsValid ~= nil and o:IsValid() end
-- the CONTENT root. WeaponBox is a CommonButtonBase (via WBP_BrunoListButtonBase), whose WidgetTree.RootWidget is the
-- runtime wrapper "InternalRootButtonBase"; BuildOn fades the designer root Overlay_0 inside it (round 5b measured the
-- wrapper by mistake). Overlay_0 is a BP variable; else the wrapper's GetContent().
local function rowRoot(w)
    local c = nil; pcall(function() c = w.Overlay_0 end)
    if rowValid(c) then return c end
    local r = nil; pcall(function() r = w.WidgetTree.RootWidget end)
    if rowValid(r) then pcall(function() c = r:GetContent() end) end
    return rowValid(c) and c or nil
end
local function rowState(w)          -- -> "stuck" | "building" | "ok" | "?" (+ root)
    local r = rowRoot(w); if not r then return "?", nil end
    local vis = -1; pcall(function() vis = w:GetVisibility() end)
    if vis == 2 then return "building", r end                     -- ESlateVisibility::Hidden = inside PlayBuildOn's delay
    local playing = false; pcall(function() playing = w:IsAnimationPlaying(w.BuildOn) end)
    if playing then return "building", r end
    local op = 1; pcall(function() op = r:GetRenderOpacity() end)
    return (op < 0.05) and "stuck" or "ok", r
end
local function rowOwner(w)          -- the entry's outer is the BoxList's WidgetTree; ITS outer is the BoxList
    local o = nil; pcall(function() o = w:GetOuter():GetOuter() end)
    return rowValid(o) and o or nil
end
local function rowPass()
    rowTick = rowTick + 1
    if rowTick >= rowNextScan then                                 -- the only FindAllOf in this feature
        local ok, list = pcall(FindAllOf, "WBP_Customization_WeaponBox_C")
        rowBoxes = {}
        if ok and type(list) == "table" then
            for _, w in ipairs(list) do
                if rowValid(w) then
                    local n = ""; pcall(function() n = w:GetFullName() end)
                    if type(n) == "string" and not n:find("Default__", 1, true) then rowBoxes[#rowBoxes + 1] = w end
                end
            end
        end
        if #rowBoxes == 0 then rowIdle = rowIdle + 1 else rowIdle = 0 end
        -- HARDENING (X1 crash review, 2026-09-24): while entries exist, re-find them EVERY tick, so no widget userdata is
        -- carried from one game-thread tick to the next. UE4SS's IsValid() only tests the wrapped pointer for NULL
        -- (ZCSDK_FocusProbe v1.28.34 disassembly: UE4SS+0x2ad930), so a WeaponBox the list destroyed and GC'd between
        -- ticks would still read "valid" from a 3-tick-old rowBoxes and PlayBuildOn would run on freed memory.
        rowNextScan = rowTick + ((#rowBoxes > 0) and 1 or ((rowIdle < 4) and 4 or 12))
    end
    if #rowBoxes == 0 then rowStuck = {}; return end
    -- group by owning list; a list with any entry mid-cascade is left alone this tick
    local byOwner, busy = {}, {}
    for _, w in ipairs(rowBoxes) do
        if rowValid(w) then
            local o = rowOwner(w); local okey = o and o:GetFullName() or "?"
            local st, r = rowState(w)
            if st == "building" then busy[okey] = true end
            byOwner[okey] = byOwner[okey] or {}
            table.insert(byOwner[okey], { w = w, st = st, r = r })
        end
    end
    -- a list counts as mid-cascade for at most 5 ticks (an entry left Hidden for good must not block the fix forever)
    for okey in pairs(byOwner) do rowBusy[okey] = busy[okey] and ((rowBusy[okey] or 0) + 1) or nil end
    local seen = {}
    for okey, rows in pairs(byOwner) do
        if not (busy[okey] and rowBusy[okey] <= 5) then
            for _, e in ipairs(rows) do
                if e.st == "stuck" then
                    local key = ""; pcall(function() key = e.w:GetFullName() end)
                    seen[key] = (rowStuck[key] or 0) + 1
                    if seen[key] >= 2 then
                        seen[key] = nil
                        local how = "PlayBuildOn"
                        if not pcall(function() e.w:PlayBuildOn(0.0) end) then
                            how = pcall(function() e.r:SetRenderOpacity(1.0) end) and "opacity" or "FAILED (PlayBuildOn and opacity both raised)"
                        end
                        rowHealed = rowHealed + 1
                        -- one line per healed row (the retail proof); capped so a pathological session cannot flood the log
                        if rowHealed <= ROWFIX_LOG_CAP then
                            local nm = "?"; pcall(function() nm = e.w.ModelText:GetText():ToString() end)
                            log("ROWFIX healed " .. tostring(nm) .. " via " .. how)
                        elseif rowHealed == ROWFIX_LOG_CAP + 1 then
                            log("ROWFIX: " .. ROWFIX_LOG_CAP .. " rows healed this session; further heals are not logged")
                        end
                    end
                end
            end
        end
    end
    rowStuck = seen
end
-- "list" mode: per weapon MODEL list (a BitReactorListView under a ...ModelSlot... path) longer than the ~7 visible rows,
-- watch (item count, selected index); when it changes, wait 2 ticks for the list to generate and size its rows, then
-- RequestRefresh() and, on the next tick, BP_ScrollItemIntoView(selected). Stock lists (<= 7 items) are never touched.
local listSig, listPending, listLists, listNextScan = {}, {}, {}, 0
local function listPass()
    rowTick = rowTick + 1
    if rowTick >= listNextScan then
        listLists = {}
        local ok, views = pcall(FindAllOf, "BitReactorListView")
        if ok and type(views) == "table" then
            for _, v in ipairs(views) do
                local n = ""; pcall(function() n = v:GetFullName() end)
                if rowValid(v) and type(n) == "string" and n:find("%.ModelSlot%.") then listLists[#listLists + 1] = v end
            end
        end
        listNextScan = rowTick + ((#listLists > 0) and 3 or 12)
    end
    for _, v in ipairs(listLists) do
        if rowValid(v) then
            local key = ""; pcall(function() key = v:GetFullName() end)
            local n, sel, selIdx = 0, nil, -1
            pcall(function() n = v:GetNumItems() end)
            pcall(function() sel = v:BP_GetSelectedItem() end)
            if rowValid(sel) then pcall(function() selIdx = v:GetIndexForItem(sel) end) end
            if n > 7 then
                local sig = n .. "#" .. selIdx
                if listSig[key] ~= sig then listSig[key] = sig; listPending[key] = 2 end
                local p = listPending[key]
                if p then
                    if p > 1 then listPending[key] = p - 1
                    elseif p == 1 then
                        pcall(function() v:RequestRefresh() end); listPending[key] = 0
                    else
                        if rowValid(sel) then pcall(function() v:BP_ScrollItemIntoView(sel) end) end
                        listPending[key] = nil; rowHealed = rowHealed + 1
                        if rowHealed <= ROWFIX_LOG_CAP then log("ROWFIX re-laid-out a " .. n .. "-item MODEL list (selected index " .. selIdx .. ")") end
                    end
                end
            end
        end
    end
end
local rowSkip, rowArmedLogged = 0, false
-- HARDENING (X1 crash review, 2026-09-24): AT MOST ONE ROWFIX closure in UE4SS's game-thread queue at a time. rowSkip is
-- only set when the queued closure RUNS, so while the game thread is stalled (a loading screen, a hitch) the 1 s tick
-- used to enqueue a fresh closure - and take a fresh Lua registry ref - every second, and hand them all to the game
-- thread at once when it resumed. The 03:14 crash was a game-thread action whose registry ref had been reused
-- (UE4SS+0x2f96d9 -> ref 40 -> a C finaliser, not the queued closure), so this feature must not add ref churn it does
-- not need. The flag is cleared at the END of the closure, on every path, including a raise. A closure that never runs
-- (a queue UE4SS dropped) must not kill the feature for the session, so after 10 ticks the loop queues again.
local rowQueued, rowQueuedFor = false, 0
LoopAsync(1000, function()
    if not ROWFIX then return true end
    if rowQueued then
        rowQueuedFor = rowQueuedFor + 1
        if rowQueuedFor < 10 then return false end
    end
    if rowSkip > 0 then rowSkip = rowSkip - 1; return false end
    rowQueued, rowQueuedFor = true, 0
    ExecuteInGameThread(function()
        local ok, err = pcall(function()
            if not strategySide() then rowBoxes, rowStuck, rowNextScan = {}, {}, 0; rowSkip = 4; return end   -- not the hub
            local cls = StaticFindObject(ROWFIX_CLASS)
            if not (cls and cls:IsValid()) then rowSkip = 4; return end   -- the Armoury's weapon page was never opened
            if not rowArmedLogged then rowArmedLogged = true; log("ROWFIX armed (mode " .. ROWFIX_MODE .. "): the Armoury weapon page's row class is loaded") end
            if ROWFIX_MODE == "list" then listPass() else rowPass() end
        end)
        if not ok then log("ROWFIX error (the loop keeps running): " .. tostring(err)) end
        rowQueued = false
    end)
    return false
end)

log("ZCSDKLoader v1.8.25 loaded (win64=" .. WIN64 .. "); waiting for the main-menu world")
