-- ZCSDKLoader v1.8.29 — runtime loader for Zero Company SDK content mods (pairs with the ZCSDKBridge C++ mod).
--   (1.8.29) THE ROWFIX STUTTER (support 2026-09-30, loader 1.8.26 + ZC Ultimate Blaster pack 1.0.0 + ZCUnlocked 1.4.72,
--           game 197649): `pump: task rowfix took 60-73 ms in one frame` every 5 s in the hub, forever, with 0 heals. Every
--           ROWFIX pass began with a StaticFindObject of the row class (a whole-object-array walk in this UE4SS build), and
--           a not-resident class re-paid it every fifth second. Now: no class lookup (one row FindAllOf per pass answers
--           "page open?" and "which rows"), the idle probe backs off 5 -> 30 s, the 1 s pass backs off to 2 -> 8 s after 3
--           clean passes on the page, page close / leaving the hub disarm, and with ZCUnlocked's vm-blank / listfix on
--           ROWFIX makes no lookup at all (said once). See "1.8.29: ROWFIX" at the bottom; tools/replay_pump.py R1-R8.
--   (1.8.28) THE RETAIL PROBLEMS OF 1.8.27 (ZCClassMods\JediClass\notes\RETAIL_1_LOG_ANALYSIS.md §1, §2, §3).
--           * THE 2.9 s FRAME. StaticFindObject is NOT a hash lookup in this UE4SS build: it costs a FindAllOf (a walk
--             of the object array, 28 ms in the menu, 50-90 ms in the hub). 1.8.27 re-found every slot by path and did
--             ~40 lookups in one act frame (pass 591: max slice 2917 ms). The pass is now FRAME-BOUNDED: a drive frame
--             makes ONE FindAllOf of the slots, collects and acts on those objects in that frame (nothing is re-found,
--             so no UObject crosses a frame by construction), and at most PS.LOOKUPS (2) object lookups run per frame;
--             residency answers are cached booleans asked once per id per world. See "THE FRAME-BOUNDED PASS".
--           * SCOPE. With every pin carrying a `definition`, a pass collects only OUR characters; the world-wide ghost /
--             stale-slot / roster sweep runs on a world's first PS.SWEEP_PASSES (16) passes and once per PS.SWEEP_S
--             (120 s) after them; a world with nothing ours goes DORMANT.
--           * HOOK-DRIVEN. A RefreshCharacterVMs / RecruitCharacter event makes the pin task due on the next frame, re-arms
--             a dormant loop, bypasses the spawn-wave settle and drives the cards of ours once they are 1.5 s old;
--             `recruit pin: <event> -> done N s after the event` is T-G1's number, and ONE verify pass follows 8 s later.
--           * CLASS + CHILDREN IN ONE PASS: a delivered Class holds its character 3 idle frames, then the same pass
--             re-finds the re-created children and drives them.
--           * THE CENSUS TRIGGER only when RefreshCharacterVMs could not be hooked (or the kill switch is off); off for
--             good once the hook fires. One roll line per real refresh.
--           * `recruit pin: appearance <owner>: …Head.Face.Mesh=<id> Hair.Hair.Mesh=<id> (read-only)`, once per character.
--   (1.8.27) THE FORCE CLASS MODS' RUNTIME (ZCClassMods\_Shared\SDK_CHANGE_REQUEST.md §1b, §2d, §3, §4, §5.1, §5.6), AND
--           THE DEN PAUSE. One release, one retail pass (D4).
--           * THE PIN PASS IS SLICED. 1.8.26's recruit-pin pass ran in ONE frame: 3,208 / 2,105 / ~1,000 ms in the Den
--             (ZCSDKLoader.log 2026-09-29 03:21). It is now a resumable pass (instances -> slot scan -> walk -> act):
--             the walk over the pinned-tag slots stops at PS.SLICE_MS (4 ms) and resumes on the next frame, and NOTHING
--             but strings crosses a frame - a slot or an instance is re-found by its path (StaticFindObject) in the
--             frame that uses it, so a garbage collection between two slices can never hand the walk a freed object.
--             The first pass of a session runs whole (1.8.26 behaviour) and PROVES that route: StaticFindObject(<the
--             path>) must return the very object FindAllOf just returned; if it does not, slicing stays OFF for the
--             session and says so. Only slots carrying a tag some pin reads are named at all (the rest were walked
--             for nothing). `recruit pin: pass N timing: …` gives each pass's slices, total and max slice.
--           * THE CHEAP WORLD READ. UEHelpers.GetWorld() is FindAllOf("PlayerController") on every call - 50-170 ms per
--             frame in retail for every task that read the world (arm, saber, rowfix, the idle pin, each bridge()).
--             `gameWorld()` reads Engine.GameViewport.World (reflected: jmap Engine.GameViewport @3128,
--             GameViewportClient.World @120) and falls back to UEHelpers only when that chain is empty.
--           * G1: `done` no longer stops the pin for the session. It goes DORMANT (an O(1) tick) and RE-ARMS on a
--             Recruitment refresh (a RefreshCharacterVMs hook, or a census change in the same hub), a recruit
--             (RecruitCharacter) or a world change, at most once per 5 s and PIN_REARM_MAX (20) times a session.
--           * G2: the Talent slot toggles through CPD_TalentSpec_TheToughGuy and is driven LAST.
--           * H1 / §5.6: a pinned slot may carry an ACCEPT-SET (`accept` ids, `acceptTags` read off the equipped
--             GearKit part, `acceptOn = "roster"`) and a roster-only `escape` (fallbackSpec / fallbackWeapon): the
--             pin leaves a player's choice alone and still gives a fresh card the class default.
--           * §2d: `requires[]` - the dependency is reported once, a slot into a missing / too-old dependency is
--             delivered as its `fallback` (or dropped), and a dead id of a removed dependency is either overwritten
--             by that fallback or reported as a GHOST naming the dependency.
--           * §1b: `classPool` rows get a runtime weight (a player's settings.ini wins), rolled after the follow-up and
--             again per Recruitment refresh (roll-ahead), written to the live pool's bIsActive and read back.
--           * The Recruitment watcher's hooks arm once per process, in the hub only, after the census has settled and
--             10 s have passed (the 1.8.23 discipline); their callbacks only count events.
--   (1.8.26) NO LUA ON UE4SS's ASYNC THREAD. The Den (HUB_Root) crashes of 2026-09-13, 09-15, 09-28 21:51 and 09-29 02:46
--           share one stack: UE4SS `UObject:IsValid` faulting inside the Lua VM's protected-call path, reached from the
--           game-thread action runner. The 21:51 minidump shows WHY (scratchpad crash/R_staffprobe_hub_crash.md): at the
--           fault `L->top` sat on the IsValid function's own slot with a valid `self` above it — impossible on one
--           thread. UE4SS runs `LoopAsync`/`ExecuteWithDelay` bodies on its async thread and calls queued
--           `ExecuteInGameThread` actions with its action mutex RELEASED (UE4SS+0x2f92a0: _Mtx_lock, move the queue
--           out, _Mtx_unlock, then call), so two OS threads ran Lua in this mod's ONE lua_State. 1.8.23 blamed
--           RegisterHook and 1.8.25 thinned the async bodies; both only narrowed the window.
--           THE FIX: every LoopAsync and ExecuteWithDelay is gone. ONE function, `pump`, runs on the game thread
--           through `ExecuteInGameThread(pump)` and re-queues ITSELF (the same function value, no new closure) as its
--           first statement; the runner has already moved its queue out, so the re-queue lands on the NEXT engine
--           tick. The arm check, the startup steps, grants, the recruit pin, ROWFIX, vault-saber arming and the (OFF)
--           relight timers are tasks inside it, timed with os.clock() (wall time on the Windows CRT). At most ONE task
--           runs per frame (round-robin), so a Den load never stacks the pin, ROWFIX and grants into one frame.
--           Cadences are unchanged (arm 3 s, grants 4 s, pin 2.5 s with its skips, ROWFIX 1 s, saber 5 s, steps as
--           declared); the *Queued/*QueuedFor watchdogs are deleted because nothing crosses a thread any more.
--           ALSO: the recruit pin's `pcall(IsValid) and IsValid()` double call (the second, unguarded one is the
--           21:51 fault line) is one guarded call (`pinOk`) everywhere in the pin block; the pin defers its slot walk
--           while the CustomizationInstance census is still CLIMBING (the spawn wave; at most pinSettle.max passes);
--           and RACEPROBE (default OFF) counts any loader Lua that runs off the game thread or re-enters the pump.
--   (1.8.25) HARDENING (the X1 crash review of 2026-09-24 03:14, SWBF2 Models Project notes/X1_crash_0314.md). UE4SS's
--           game-thread runner called a queued action whose Lua registry ref had been reused (a C finaliser, not the
--           closure), and this loader's recruit-pin closure had replayed stale a minute before. The ROWFIX, recruit-pin and grant
--           loops now keep AT MOST ONE closure in the game-thread queue (a 10-tick watchdog re-queues a dropped one), and
--           ROWFIX re-finds its rows every tick while rows exist, so no widget userdata crosses a tick.
--   (1.8.24) THE ARMOURY'S BLANK MODEL ROWS. A weapon list longer than the ~7 visible rows scrolls, and every row generated
--           after the page's one-time build-on cascade keeps its WBP_Customization_WeaponBox entry at BuildOn "Off" (root
--           opacity 0): blank, yet clickable. This is a latent game bug that stock lists (6 parts at most) never reach. A paced,
--           hub-only loop re-runs the stuck entry's own PlayBuildOn(0) ("entry" mode), or re-lays-out the list ("list" mode),
--           whichever the round-6 experiment proves. See the block above the final log line.
--   (1.8.23) THE HUB'S SPAWN WAVE KILLS RegisterHook, SO THE SABER HOOKS WAIT FOR A MISSION. The crash is now
--           CAPTURED TWICE, and both are the same shape: 2026-09-13 22:51:55 and 2026-09-15 08:58:38.9,
--           `EXCEPTION_ACCESS_VIOLATION` (0x70 and 0xa) with UE4SS-ONLY top frames — `+c5f4dd`, `+2a9cf9`,
--           `+2ad787`/`+2ad78a`, `+b94064`, `+b98dec`, `+c68a7e` — and no game frame anywhere near the top. Both
--           landed at the exact instant `LoopAsync(5000, …)` found `BP_FX_LightSaber_Base_C` resident and started
--           `RegisterHook`ing the 8 saber functions DURING THE HUB'S SPAWN WAVE (the pin census climbing 27 -> 73 ->
--           116 instances in the same seconds). The 09-15 UE4SS.log ends on `[RegisterHook] Registered script hook
--           (8, 8) for … Cinematic_Deactivate` — the 4th of the 8 — with no further Lua line: the fault is inside
--           UE4SS during the 4th/5th registration, or inside the game calling one of the just-hooked functions on a
--           saber actor that is still mid-spawn. 7 of 9 hub loads survived the identical code, so this is a RACE
--           with the spawn wave, not a deterministic fault. INFERRED (not proven): hooking a Blueprint UFunction
--           while that class's instances are being constructed is unsafe in UE4SS 3.0.1.
--           THE FIX IS TO STOP ARMING WHERE THE HOOKS ARE NOT NEEDED. They exist for a VAULT or a STRIKE, both of
--           which happen in a mission, so arming now needs all three of: (a) the world name contains
--           `/Maps/Skirmish/` — the same mission marker the TurnProbe uses, which `HUB_Root` and `MainMenu` can
--           never match; (b) `BP_FX_LightSaber_Base_C` resident (`StaticFindObject` valid, unchanged); and (c)
--           `SABER_HOOK_SETTLE` = 8 s elapsed since that mission world was FIRST seen, so the mission's own spawn
--           wave and its `ActivateLightsaber` burst at +2 s are over before anything is registered. Everything the
--           1.8.2 lesson bought is kept verbatim: exactly ONE registration per process (`saberHookArmed` set BEFORE
--           the call), never a retry after a failure, and the hooks persist across worlds so one mission arms them
--           for the whole session. The hub now logs `vault saber: arming deferred to a mission world (1.8.23) …`
--           once when the class is first seen there, and the first mission logs `vault saber: mission world seen at
--           <t>; arming in 8 s` and then the 8 `hook armed on` lines as before.
--           THE COST, stated because session_audit.py must not be edited to hide it: hooks armed inside a mission
--           MISS that mission's own start burst (`PATH> Activate` ×4 / `PATH> ActivateLightsaber`), which is
--           session_audit's mission-boundary marker — so for the FIRST mission of a session that marker will be
--           absent. Every later mission, and every vault or strike in the first one after the 8 s, logs as before.
--           Nothing else moved: relight still OFF (1.8.21), the stale-slot rebuild, the ghost holds and the
--           residency ladder are byte-for-byte 1.8.22.
--   (1.8.22) THE SLOT THE OPERATOR CANNOT CHANGE, AND THE SAVE THAT KEEPS IT. Retail 2026-09-14/15 (CHANGELOG
--           v1.28.53 §9(b), §11, §13): PROVEN in the data, INFERRED for the symptom. Two facts already in this header
--           — `LoadCustomization` rebuilds a slot's FragmentInstances ONLY on an id CHANGE (09-13 09:04:40), and a
--           MISSION re-creates every character FROM SAVE DATA (21:28:27 vs 21:28:30) — together explain HAWKS. He is
--           NOT a pinned character (game class `CPD_Char_Class_Hero_Humanoid`), but his `Specializations.Weapon` slot
--           holds `CPD_WeaponSpec_ZCSDK_SaberAnakin`, picked in the armoury and serialised under that mod's v1.0.0,
--           and his armoury Change Weapon is GREYED OUT — so the id never changes, the fragments stay v1.0.0, and
--           every mission rebuilds him from them: the REMOVED `GA_OverwatchMelee_Base` still draws a "Melee Overwatch"
--           card (and locks the turn) and his sprint still uses his previous BLASTER's anim proxy table while the
--           visible saber comes from the equipped part. A byte-grep of the whole deployed game finds that ability in
--           NO ZCSDK container: the card is the SAVE, not the pak. VEX is the control and he is CLEAN — because the
--           pin toggles his Weapon slot every hub load (`[TOGGLE to CPD_WeaponSpec_Blaster_Longarm]`,
--           `FragmentInstances REPLACED`) and a manual save carried the rebuilt fragments into the mission (§11,
--           retail-verified).
--           SO THE PIN NOW DOES FOR A NON-PINNED CHARACTER WHAT IT ALREADY DOES FOR A PINNED ONE: one toggle-and-back
--           on the Weapon slot, `STALE_SLOT_REBUILD` (default true), through the SAME setter and the SAME
--           BEFORE/AFTER fragment-identity check. It is the 1.8.18 toggle re-aimed, not a new mechanism, and every
--           fence narrows it: HUB ONLY; the WEAPON TAG ONLY (a Class drive re-creates the child slots, fact B); only
--           an id THIS INSTALL SHIPS — enumerated by a manifest (`pinManifestParts()`) OR RESIDENT at the SDK's own
--           `/Game/ZCSDK/<id>.<id>`, and the second test is not optional: `build/ZCSDK_SaberAnakin.zcsdk.lua`, the mod
--           whose spec is stuck on Hawks, enumerates NOTHING (one primary type over /Game/ZCSDK, empty grants), so the
--           enumerated set alone would never have fired on the one character this exists for. Either way it is never a
--           vanilla part (not under /Game/ZCSDK) and never a GHOST (not resident — that is what makes it a ghost);
--           never a character that is OURS (the pin's own toggle would
--           fight it); never a proxy and never an owner that cannot be NAMED (1.8.20); once per session per
--           (owner, id), at most PIN_MAX_RETRY writes, and a failure is FINAL. The one that matters: BOTH ids are
--           minted from live objects BEFORE the first write, because a toggle written with no way back would leave
--           the character wearing a Blaster Longarm — and if the toggle write itself does not move the fragments the
--           original id is UNWOUND back onto the slot in the same pass (one write of what it already held; the
--           verdict stays FAILED). `done` is held while a rebuild is mid-flight, bounded by those
--           same budgets. The REBUILT line ends `— make a manual save before the next mission`, because rebuilt
--           fragments live in the hub instance and the mission reads the save; the summary at `done` is
--           `stale-slot rebuild: N slot(s) REBUILT, M FAILED, K skipped (not ours, not ours-shipped)`. NOT
--           retail-verified: the check is Hawks' hub load printing REBUILT, then a manual save, then a mission with
--           no "Melee Overwatch" on him and saber locomotion on his sprint.
--   (1.8.21) THE RELIGHT IS OFF, AND THE RULE IT BROKE IS NOW WRITTEN DOWN. Retail 2026-09-14 04:53 (loader 1.8.20,
--           deployed), one second into a mission: the insertion mantle extinguished a blade (04:53:30
--           `PATH> DeactivateLightsaber` / `relighting through ActivateSaberCheck (HasMantled=true)`), and the 350 ms
--           relight threw `main.lua:2011: [Lua::Registry::get_function_ref] Ref was not function` with the traceback
--           in `[C]: in method 'ActivateSaberCheck'`. THAT FUNCTION IS ONE THIS SAME MOD HAS RegisterHook'd — the
--           log-only `[state]` probe hook of 1.8.6 — and calling it from Lua made UE4SS's hook dispatcher fail to
--           find its own callback ref. The 900 ms call then went through and even reported `RELIGHT VERIFIED (900ms)
--           - bIsActive=true | Activated Lightsaber Blade=set | Sheath=0.000`, but the operator saw EVERY CHARACTER
--           RUNNING IN PLACE at mission start: the insertion sequence never completed. INFERRED (not proven): a Lua
--           exception thrown inside UE4SS's hook dispatch while the game was mid-`ActivateSaberCheck` broke the
--           mission's start sequence. Exact or not, two rules are now proven and stand on their own:
--             (A) THIS RUNTIME MUST NEVER CALL A UFUNCTION IT HAS HOOKED. Registering and invoking the same UFunction
--                 is the `Ref was not function` fault, and it throws INSIDE the game's own call frame.
--             (B) THIS RUNTIME MUST NOT DRIVE THE SABER DURING THE INSERTION MANTLE. A scripted sequence owns the
--                 characters at mission start and a relight lands in the middle of it.
--           So `RELIGHT_ENABLED` is FALSE by default. The vault handlers still READ and still print every vdiag line
--           (the diagnostics are the point), but they schedule NOTHING and log `vault saber: relight DISABLED
--           (1.8.21) ...` once per deactivation. The blade is left to the game's own `ActivateSaberCheck`, and the
--           next retail vault decides it: PASS = the game's check reads `bIsActive=false` and `PATH>
--           ActivateLightsaber` follows and the blade comes back; FAIL = `bIsActive=false` with no
--           `ActivateLightsaber`, blade dark — then the game does not recover on its own and a relight that does NOT
--           call a hooked function is needed (drop the `[state]` hooks first). If `RELIGHT_ENABLED` is ever set true,
--           the `[state]` probe hooks on ActivateSaberCheck/DeactivateSaberCheck are NOT registered, because rule (A)
--           is not a thing to re-learn in retail. With the default false, all 8 hooks arm exactly as in 1.8.20.
--   (1.8.20) THE FLAG WAS NOT THE BLADE. Retail 2026-09-13 22:52 (loader 1.8.19, deployed) broke three things open:
--           * THE VAULT SABER RELIGHT WAS NEVER A FIX — it was the thing STOPPING the fix. 23:17:41 Hawks vaulted,
--             the relight replayed the four captured arguments into `ActivateLightsaber` and logged `re-lit (350ms)
--             - bIsActive now true`; the blade was NOT visible for the rest of the mission, and at 23:21:16 the
--             game's own `ActivateSaberCheck` logged `HasMantled=false bIsActive=true` and did nothing. Proven with
--             tools/recon/kismet.py over the cooked BP_FX_LightSaber_Base (offsets in the block comment on
--             `relight`): `+2086 EX_JumpIfNot Self.bIsActive -> +1904` is the game's OWN next-turn recovery, and
--             setting the flag turns it into a no-op; the visible blade comes only from `Timeline_Blade__UpdateFunc`
--             (`SetScalarParameterValueOnMaterials("Sheath", ...)`), which `bIsActive` does not touch; and the 4th
--             parameter `Target Saber` is DEAD — `K2Node_CustomEvent_Target_Saber_2` never appears as an operand in
--             the 1389-opcode ubergraph, so the replay of 1.8.7-1.8.19 replayed nothing that mattered.
--             THE RELIGHT NOW CALLS THE GAME'S OWN `ActivateSaberCheck(TargetSaber)` — signature READ, not guessed
--             (`kismet.py --function ActivateSaberCheck`: ONE `TargetSaber : ByteProperty`), with the saber's own
--             `Owning Saber Position` (then `GetTargetLightsaber()`, then the enum's "both" member 2). It is
--             self-idempotent at `+2086`, so the 350/900 ms pair is kept; the three captured components are gone and
--             the stale-pointer dance with them. AND `bIsActive` NO LONGER REPORTS SUCCESS: 600 ms after the call
--             one more read prints `RELIGHT VERIFIED` / `RELIGHT UNVERIFIED` from `Activated Lightsaber Blade` and,
--             where it can be read at all, the blade material's `Sheath` scalar. A relight that flips the flag and
--             leaves the blade dark now says so.
--           * THREE OF THE FOUR GHOST LINES WERE THE GAME'S OWN PARTS. `CPD_TacticalSpec_Soldier` (pass 1) and
--             `CPD_TacticalSpec_Hero_Aurelio_Assault` (pass 50) matched evidence shape 2 while the character was
--             still spawning (27 instances at pass 50 -> 109 at pass 54), and all three printed the owner as
--             `/Engine/Transient` because `shortOwner` was reading the SLOT's path. Two rules: a non-`CPD_ZCSDK_` id
--             needs PIN_GHOST_PASSES (4) CONSECUTIVE unresolved passes, and NO REPORT WITHOUT A NAMED OWNER — the
--             owner is the owning CustomizationInstance and an unnamed one DEFERS the report instead of printing it.
--             Hawks' real line is unchanged, verbatim. A candidate is counted, not blocked, unless it is a
--             `CPD_ZCSDK_` id: blocking an evidence-2 candidate would stop the drive that could disprove it.
--           * THE RESIDENCY LADDER RE-RAN ON A DELIVERED PART. 23:00:38-23:00:58, after all three slots read
--             `finished`, every pass alternated `did not resolve — step 1` / `resolved after step 1`. The drive path
--             cleared `partStep` and left the part on `partWatch`, where a step count of 0 reads as "not started".
--             Not a stale read — the tick's own precondition is a VALID StaticFindObject — so the line contradicted
--             the test that produced it, and its LoadAsset was a real request for an already-loaded asset. A part
--             that resolves once is now SETTLED: off the watch list, refused by `escalateResidency`. The 1.8.18
--             delivery path is untouched.
--   (1.8.19) THE EXPERIMENTS ARE DELETED, AND THE LOADER LEARNS TO REFUSE. 1.8.18 is RETAIL-VERIFIED (CHANGELOG
--           v1.28.46/47: all three Sith parts DELIVERED, the Focus tree DRAWS on the Sith Acolyte rails), so
--           everything it carried "in case" is now dead weight that the next reader would have to rule out again:
--           * GONE — `PIN_ROUTE` and both equip routes with all five marshalling shapes
--             (EquipCustomizationDefinition `allowed`/`tags`/`all`, EquipCustomizationParts `struct`/`table`), their
--             judge/commit helpers and the `arrival` observable that scored them. Retail 09:04:40 proved the plain
--             1.4.0 setter delivers, and an EMPTY AllowedSlots container re-created the character's own child slots
--             TWICE (07:52:26, 09:04:44). No route is going back in without a retail run that needs it.
--           * GONE — `PIN_RESOLVER_PROBE` and the whole KismetSystemLibrary resolver probe, including its
--             self-validation against the game's CPD_TacticalSpec_Assault. Its question was answered at 09:04:18:
--             the AssetManager resolves every one of our parts once they are RESIDENT. The TSoftObjectPtr accessor
--             chain it cost a crashed game to find is KEPT, as a comment beside the residency code — it is the only
--             verified way to read one in UE4SS 3.0.1 and nothing else in this project records it.
--           * NEW — THE GHOST REFUSAL (HANDOFF open items 3 and 7). Before driving anything, the pin looks at every
--             pinned slot on every real character in the world, OURS OR NOT, and if one holds a `CPD_ZCSDK_*` part id
--             that no currently enumerated manifest carries and that is resident nowhere — or a leveled tree whose
--             tier classes are null, the FocusProbe's shape on Hawks' save — it logs
--             `recruit pin: GHOST <owner> <slot tag>: holds <partId> from a mod that is not installed ...` and never
--             drives that slot. A save written while a mod was installed is not something to write over; the
--             2026-09-12 turn-end block is the INFERRED cost of one.
--           * VOCABULARY, per session_audit.py's own recommendations: one arming verb (`hook armed on <class>:<fn>`,
--             was `watching <fn>`), one firing verb (`PATH> <fn>`, was `<fn> FIRED`), `RegisterHook FAILED on <fn>`
--             names the function, and the HQ banner only says "waiting" when grants were actually declared.
--           Nothing on the proven path changed: residency before the first write, Class to completion then Weapon
--           then Tactical, the TOGGLE through a vanilla id, delivered-is-final, `done` ends the loop, proxies never
--           pinned, identity per CustomizationInstance, stale slots deduped by highest object index, xpcall around
--           the pass, IsValid before any UObject method, no UObject held across passes.
--   (1.8.18) THE ANSWER, AND IT WAS THE SETTER ALL ALONG. Retail 2026-09-13 09:02 (no crash):
--             09:04:18  GetObjectFromPrimaryAssetId returns OUR OBJECT for all three parts once resident - the
--                       AssetManager was never the problem (its path half was broken; that reading is discarded).
--             09:04:40  the plain 1.4.0 setter on Tactical.Primary: BEFORE partId=CPD_TacticalSpec_Assault |
--                       partDefinition=CPD_TacticalSpec_Assault | 3 leveled tree(s) -> AFTER partId=
--                       CPD_ZCSDK_TacticalSpec_Sith | partDefinition=CPD_ZCSDK_TacticalSpec_Sith | 2 leveled tree(s)
--                       -> DELIVERED. OUR TWO TREES, through the door eight versions tried to replace.
--             09:04:40  then a Class re-drive in the same second, and from 09:04:44 every Tactical AFTER reads
--                       partDefinition=<null> | 0 leveled tree(s), with the delivered trees stranded on stale slots.
--           TWO PROVEN FACTS: (A) LoadCustomization rebuilds fragments only on an id CHANGE, so a slot that already
--           holds our id is a no-op for ever - which is exactly why the Sith has been empty since the first session
--           that wrote our id onto him; (B) driving the CLASS part re-creates the character's child slots and
--           discards what was just delivered into them. So: Class FIRST then Weapon then Tactical (1.8.15's 'Class
--           last' was backwards); a slot that already holds our id with no fragments is TOGGLED through a different
--           id (its own remembered vanilla part, else the game default for that tag) and given ours back on the NEXT
--           pass; a delivered slot is never driven again; and `done` now means all of them delivered. The equip
--           routes and the resolver probe are both OFF by default - the setter is the route that works, and the
--           probe's question is answered.
--   (1.8.17) MY OWN PROBE CRASHED THE GAME, AND EVERY LINE IT PRINTED WAS AN ARTEFACT. Retail 2026-09-13 09:00:44,
--           91 s in: EXCEPTION_ACCESS_VIOLATION reading 0xa, frames UE4SS+2a9cf9 / +2ac8a6 (the userdata fetch and
--           UObject method binding). The 1.8.16 probe called methods on part objects it had just reported as
--           MISSING - the exact IsValid-before-method rule this file states twice elsewhere. And its output was
--           worthless in three separate ways: `id=FString: 0000...` (Conv_PrimaryAssetIdToString returns an FString
--           USERDATA, printed as its address), `path=EMPTY` for the GAME CONTROL as well as for ours (so the
--           soft-reference read was simply broken and every 'NameData is missing' line was noise), and
--           `valid=false` for our ids (because the probe ran before our parts were resident, so
--           GetPrimaryAssetIdFromObject was handed an invalid object).
--           THE ACCESSORS ARE NOW READ, NOT GUESSED. UE4SS 3.0.1's TSoftObjectPtr userdata metatable registers
--           exactly GetWeakPtr / GetTagAtLastTest / GetObjectID / type / __gc (UE4SS.dll push_softobjectproperty,
--           RVA 0x2cafe0) - no ToString, no GetAssetPathString. GetObjectID yields an FSoftObjectPath, and the
--           196985 jmap gives its shape: { AssetPath : FTopLevelAssetPath { PackageName : FName, AssetName : FName },
--           SubPathString }. The id string comes from the id's own members, the read slotState has used since 1.8.9.
--           SAFETY: a part is not asked about at all until StaticFindObject returns an object that passes IsValid -
--           before that the probe logs `not resident yet` and requests the load, and touches nothing. Every call is
--           pcall'd and every object IsValid-checked. A failed READ is reported as `<unreadable: why>` and concludes
--           NOTHING; only a successful read of an empty name means 'the manager holds no path'.
--           SELF-VALIDATION: the GAME's own CPD_TacticalSpec_Assault is probed FIRST and must answer on BOTH halves
--           (object and path). If it does not, the probe prints PROBE BROKEN, never touches our parts, and does not
--           run again this session. A probe that cannot be trusted has to say so.
--   (1.8.16) EVERY EQUIP LEAVES THE OLD SLOT OBJECTS ALIVE, AND THE CAP WAS COUNTING CORPSES. Retail 2026-09-13
--           08:38: 08:41:06 `skip Char_Hero_Humanoid_C_2: 6 slot(s) match this pin's 3 tag(s)` (the cap refused the
--           RECRUIT), 08:41:12 scoped, 08:41:17 scoped and Specializations.Weapon DELIVERED, 08:41:22
--           `12 slot(s) ...` and he was refused for the rest of the session. 3 -> 6 -> 12: each equip adds a new
--           slot object beside the previous one and the old ones stay findable. Fixes:
--           * slots are deduped BY TAG keeping the HIGHEST object index (UE numbers each new object above the last),
--             and the rest are reported as data: `<n> stale duplicate slot object(s) ignored`;
--           * an IDENTIFIED character is never refused by the cap - identity gates the drive, so the cap's only job
--             is to stop an instance nobody identified, and it can no longer fire on the recruit himself;
--           * NO VERDICT WITHOUT A DRIVE. That session ended with `STILL does not resolve` for all three parts, two
--             of which had resolved and delivered minutes earlier - the verdict was measured on a character the pin
--             had stopped driving. The ladder now holds at step 4 and says so.
--           AND THE INSTRUMENT CHANGED: a DIRECT RESOLVER PROBE replaces inference from equips. The AssetManager's
--           primary-asset API is BlueprintCallable on the KismetSystemLibrary CDO the pin already holds, takes a
--           by-value FPrimaryAssetId the pin already mints, and needs no equip, no character and no identification:
--           GetObjectFromPrimaryAssetId IS the resolver's own first step and GetSoftObjectReferenceFromPrimaryAssetId
--           is its second, so one line per part separates `no NameData` from `path present, object null` from `our
--           object reports a different id`. A game part (CPD_TacticalSpec_Assault) is probed as a control, so a
--           broken probe cannot masquerade as a broken asset.
--   (1.8.15) THE PIN LOST THE CHARACTER IT HAD JUST FOUND, AND SAID NOTHING. Retail 2026-09-13 07:47: the Sith was
--           identified at 07:52:21 and 07:52:26, the Class part DELIVERED through its own AllowedSlots container -
--           and from pass 32 onward the census read `0 ours, 14 with pinned slot(s), 0 pinned, 14 skipped` for the
--           rest of the session, with no line saying why, because the skip dedup was per OWNER and he had already
--           spent his one line on an earlier reason. THE CAUSE IS THE CALL ITSELF: the cooked
--           CPD_ZCSDK_Char_Class_Sith carries NO AllowedSlots property, so that container was EMPTY, and an empty
--           container equips every slot the definition names - the whole CD_ZCSDK_Char_Sith. That replaced the class
--           fragment, the class fragment is what builds the character's child slots, and the Info.Name slot the pin
--           identifies by was re-created underneath it. Four fixes: skip dedup is per (owner, REASON); identity is
--           STICKY for the session and has a SECOND source (a slot already holding one of this pin's own parts -
--           the Class slot re-identified him in the offline replay); a part whose AllowedSlots is EMPTY is never
--           equipped through the `allowed` shape, and the Class part goes LAST regardless so a re-creation cannot
--           orphan the specs; and the residency ladder runs on its OWN per-part clock (a step every
--           PART_STEP_PASSES ~ 15 s, ticked every pass whether or not a character was identified) instead of
--           stalling at step 2 for a whole session as it did at 07:52:26.
--           ON (e), REPORTED HONESTLY: the rescan did NOT flip the weapon at 05:48:53 - the log line ORDER shows the
--           weapon read as resolved BEFORE that pass issued the rescan command, and the bridge's before==after says
--           the rescan registered nothing. And there is NO asset-level difference to name: our weapon part's
--           registry class is BP_CPD_WeaponSpec_Base_C, identical to the game's own CPD_WeaponSpec_Blaster_Longarm,
--           and our tactical part's is BP_CPD_TacticalSpec_Base_C, identical to CPD_TacticalSpec_Assault; the
--           tactical is also the SMALLEST of the three (21 imports / 7 exports vs the class's 25/13), so 'a heavier
--           load graph' - my own earlier guess - is wrong too. Steps 3 and 4 fired in the SAME SECOND at 05:48:53,
--           so the ladder was measuring itself. The per-part clock is what makes the next run informative.
--   (1.8.14) THE PIN STOPS WHEN IT IS DONE, AND NEVER TOUCHES A PREVIEW PROXY. Retail 2026-09-13 05:43 crashed at
--           05:50:58 - EXCEPTION_ACCESS_VIOLATION reading 0xffffffffffffffff, 43 frames inside the Lua VM, no
--           GetClass frame, one pass after the loader's last line (pass 66 at 05:50:56.98; pass 67 never logged).
--           That session re-drove BP_CustomizationProxyCharacter_C_1 NINE times and C_0 three times EVERY pass,
--           forever, with zero give-up lines. Four causes, four fixes:
--           (1) A preview/portrait proxy is a transient actor the game destroys and recreates while Personnel is
--               open. It is never pinned now (`skip <owner>: preview/portrait proxy`) - pointless AND the likeliest
--               source of a userdata whose object is gone.
--           (2) PIN_MAX_RETRY was keyed by the instance PATH, which changes as proxies are recreated, so the bound
--               was unreachable. It is keyed by the character's stable identity (the pin's Name part) now.
--           (3) When every pinned slot on every identified real character is delivered or has given up, the loop
--               logs `recruit pin: done - ...` and STOPS for the session. 66 passes could not have helped.
--           (4) Nothing survives a pass but strings and numbers - the one cached UObject (the CustomizationStatics
--               CDO) is re-found every time. Cadence 3 s -> 5 s.
--           ON THE RESOLVER, CORRECTING 1.8.13's INFERENCE: the bridge's `before=3393 after=3393` with `scanned=19`
--           is GetPrimaryAssetIdList's COUNT before and after ScanPathsForPrimaryAssets (main.cpp:674-708), so the
--           manager already carried our ids and NameData was never missing. And the whole of
--           GetCustomizationPartDefinitionFromPartId (0x8c46060..0x8c46209) touches only UAssetManager::Get, two of
--           its virtuals ([+0x318] loaded-object, [+0x388] path) and a soft-path load pair - there is NO
--           UCustomizationPartsTagSubsystem call on the resolution path. What differs between the three parts is
--           asynchronous LOAD COMPLETION: Class resolved after LoadAsset alone, Weapon only two minutes after its
--           loadpkg, and the rescan that followed added nothing because there was nothing to add. The ladder keeps
--           the BuildPartTagMaps step anyway, because a step that flips a part would disprove this paragraph.
--   (1.8.13) THE MARSHALLING QUESTION IS CLOSED; THE RESOLVER ONE IS NOT. Retail 2026-09-13 05:30:21: three
--           EquipCustomizationDefinition calls, one per pinned part, each with that part's own AllowedSlots
--           container. Class -> `AFTER partDefinition=CPD_ZCSDK_Char_Class_Sith | 6 fragment instance(s)` ->
--           DELIVERED - FragmentInstances REPLACED. Weapon and Tactical.Primary -> `not delivered - nothing on the
--           slot changed`, partDefinition still <null>, fragments untouched, 0 leveled trees. One call in the same
--           pass delivering PROVES the userdata container reaches the native, so what separates the three parts is
--           GetCustomizationPartDefinitionFromPartId (RVA 0x8c46060), which asks the AssetManager for the LOADED
--           object for that FPrimaryAssetId and then for its path: an id the manager never SCANNED answers neither.
--           Cooked evidence that the three are not interchangeable: CPD_ZCSDK_Char_Class_Sith carries NO AllowedSlots
--           tagged property (an EMPTY container - so the call that delivered is the one that passed an empty one),
--           while the two spec parts carry populated ones. Both readings are now TESTED rather than argued: each
--           pinned part prints `part <name>: object=<found|missing> | valid=<y/n> | <full path>` once, and a part
--           whose slot will not resolve climbs one observable step per pass - LoadAsset, then the bridge's
--           synchronous loadpkg, then a rescan of that package's OWN directory - each step logged, and the step it
--           resolved on is logged too. Four steps in, the log says plainly that this is an asset-registration
--           question and not a loader one.
--   (1.8.12) THE UNIT OF IDENTITY IS THE CHARACTER, AND A CHARACTER IS ITS UCustomizationInstance. 1.8.10/1.8.11 made
--           it the slot's immediate parent OBJECT, and retail 2026-09-13 05:03 proved that unsatisfiable by
--           construction: `pass 39: 73 instance(s) seen, 73 candidate(s), 73 group(s), 0 pinned, 14 skipped,
--           world=HUB_Root`, every character skipped three times with `no identity: it holds 1 | 2 | 2 pinned tag(s)
--           … Info.Name reads <not present>`. One character's slots are not siblings: Class hangs off the instance,
--           the two Specializations slots off a container slot, Info.Name off a third parent - so no parent object
--           can hold both a pinned tag and the identity, and the rule could only ever fail. 1.8.7, which pinned this
--           recruit correctly, identified at INSTANCE level; that is restored. A character is ours if its instance's
--           own default CustomizationDefinition is the pin's OR if ANY slot under that instance carries the pin's
--           `match` part (in this save Vex came from the pool row, so only the Name part finds him), and the pinned
--           tags are then taken from anywhere under that same instance, at any depth. The owning instance is found by
--           walking GetOuter() with a validity check at every step (IsValid and GetFullName only - never GetClass),
--           falling back to the proven full-name prefix test.
--           WHAT STOPS THE 22:15:47 MASS-PIN IS THE CAP, NOT THE GROUPING: a character has exactly one slot per
--           pinned tag, so more matching slots than the pin declares means the instance carries more than one
--           character (a customization proxy accumulates what it has previewed) and NOTHING is written.
--   (1.8.11) 1.8.10 PINNED NOTHING, AND SAID NOTHING. Retail 2026-09-13 04:38: not one `recruit pin:` line after the
--           manifest was read, through a mission and a hub visit with the Focus tree open, while the probe showed the
--           Sith still at `partDefinition=<null> | fragment trees = 0`. Cause: 1.8.10 made the `match` Name-part
--           identity MANDATORY for every candidate - including the ones 1.8.9 found by the instance's own default
--           CustomizationDefinition, which never needed a Name slot - and every failure of that test returned in
--           silence. Same failure class as the probe that died on its first tick: a check that never PASSES reads,
--           from the log, exactly like a check that never RUNS.
--           FIXED THREE WAYS. (1) TWO identity sources, not one: a group carrying the pin's `match` part is that
--           character; failing that, an instance whose own default definition is the pin's AND which owns exactly one
--           slot group is that character (1.8.9's rule, restored). Anything else is refused - which is still the
--           22:15:47 mass-pin guard. (2) EVERY rejection logs one line naming the owner and the reason, once per owner
--           per session (`recruit pin: skip <owner>: ...`), and every accepted character logs how it was identified
--           (`recruit pin: scoped to <owner> by ...`). (3) A per-pass census - `recruit pin: pass N: X instance(s)
--           seen, Y candidate(s), Z group(s), W pinned, V skipped, world=<name>` - printed on the first pass, whenever
--           the shape changes, and every 20th pass, so a silent no-op is not expressible any more.
--   (1.8.10) A SAFETY FIX FIRST: THE PIN WAS WRITING OVER OTHER CHARACTERS. Retail 2026-09-12 22:15:47 — the pin
--           matched BP_CustomizationProxyCharacter_C_1, collected 21 slots belonging to SEVEN pool characters
--           (Astromech, Scoundrel, Sniper, Soldier, Assault, LongStrider, the Sith), asked for 18 changes, and when
--           every equip route came back empty the setter wrote Sith parts over all of them: 33 writes across the two
--           proxies. Cause: a slot belonged to a target if its full name started with the INSTANCE path. A character
--           is a slot GROUP - the immediate parent of its slots. Slots are now keyed tag -> slot PER GROUP (so a
--           group can never exceed the pin's own tags), a group is only pinned when it CARRIES THE PIN'S IDENTITY
--           (the `match` slot holding the mod's own Name part), a pin with no identity rule may only pin an instance
--           that yields exactly ONE group, and a collection larger than the pin's declared slot count is REFUSED.
--           THE SAME SESSION PROVED THE SETTER DOES DELIVER FRAGMENTS, so 1.8.9's whole premise needed narrowing:
--           at 22:15:50 `SetCustomizationPartPrimaryAssetId` left Tactical.Primary at `partDefinition=
--           CPD_ZCSDK_TacticalSpec_Sith | 5 fragment instance(s) | 2 leveled tree(s)` and DELIVERED - two trees,
--           exactly what the cooked part carries. `LoadCustomization` rebuilds the fragment instances whenever the
--           part RESOLVES, and `GetCustomizationPartDefinitionFromPartId` (RVA 0x8c46060) asks the AssetManager for
--           the LOADED object first - so ASSET RESIDENCY is the variable, not the door. The gap that kept the Sith
--           broken: the setter only ran when the id DIFFERED, so a slot carrying our id from a session where the
--           asset was not yet resident (definition NULLed, 0 trees) was never re-driven. It is now, bounded by
--           PIN_MAX_RETRY, and a retry is only spent when a route actually ran.
--           MARSHALLING: both Lua-built containers and both Lua-built maps reached the native EMPTY in that session
--           (`arrival: 0/18 ... did NOT reach the native`, `returned true; OutOriginalParts = <nil>` on all four).
--           So nothing is built in Lua any more: the first container shape is the part asset's OWN
--           `FGameplayTagContainer AllowedSlots` (CustomizationPartDefinition.h:15) passed as a real struct
--           userdata - UE4SS's userdata path is a type-checked CopyCompleteValue - one call per pinned part.
--   (1.8.9) THE RECRUIT PIN'S SUCCESS CRITERION WAS WRONG, AND IT FAILED ITS OWN NEW ROUTE. 1.8.8 judged a slot
--           equipped only when CustomizationPartDefinition came back non-null. It is not a criterion in either
--           direction: the game's own CPD_TalentSpec_TheToughGuy reads partDefinition=<null> with one leveled tree
--           and draws a full row, and the id-only setter resolves a definition by itself once the asset is resident
--           (both in the 2026-09-12 21:28 session). The criterion is now the one thing only the WithFragments door
--           can do: the slot's FragmentInstances are REPLACED (object identity) or it gains LeveledAbilities /
--           LoadedLeveledAbilities entries — and the criterion itself is printed once per session.
--           A route is also no longer demoted on a pass where every pinned slot already held the requested id
--           (1.8.8 read that no-op as a refused marshalling and locked the session to legacy before the route had
--           run once on a real change); each pass prints the ARRIVAL observable — how many of the slots that were
--           asked to change now hold the requested partId — which is what separates an empty argument from a
--           populated one when the native returns true either way.
--           NEW FIRST ROUTE: UCustomizationStatics::EquipCustomizationDefinition(CustomizationInstance,
--           CustomizationDefinition, FGameplayTagContainer SlotsToEquip, out TMap) — the same WithFragments door
--           with no TMap INPUT at all, taking the definition object the pin already holds. Order:
--           EquipCustomizationDefinition -> EquipCustomizationParts -> the 1.8.7 setter, each judged by the
--           criterion above and the winner remembered. The fragment-carrying routes are STRATEGY-SIDE ONLY: in a
--           mission the characters are rebuilt from save data and the game re-equips them during load, so an
--           in-mission pin keeps 1.8.7 behaviour exactly.
--           ALSO IN 1.8.9, from the 2026-09-12 crash analysis (the crashes were the FocusProbe, not the loader,
--           but the same shape was here): UE4SS's GetClass / GetFName bindings do NOT test validity - they read
--           [obj+0x10] off the pointer, so a null/stale UObject is a native access violation that pcall CANNOT
--           catch. IsValid() is a pure [obj+0x70] != 0 test and is the only safe first ask. dumpObject now checks
--           IsValid before every GetClass / GetFName, and the vault saber's relight re-validates the three
--           captured components (blade / light / collision) before replaying them 350 ms and 900 ms later - a
--           window long enough for the wielder to be destroyed - and NAMES the one that went stale.
--   (1.8.8) THE RECRUIT PIN NOW PINS THROUGH A PATH THAT CREATES FRAGMENT INSTANCES. Every version through 1.8.7
--           called UCustomizationFragmentInstanceSlot::SetCustomizationPartPrimaryAssetId, which (RVA 0x8c54660)
--           writes the id, NULLS CustomizationPartDefinition, and iterates the EXISTING FragmentInstances without
--           replacing them — so a pinned spec's leveled-ability fragment could never reach the instance and the
--           Focus tree drew rails with no nodes (18 hub dumps, `fragment trees = 0`; CHANGELOG v1.28.32). The pin
--           now calls UCustomizationStatics::EquipCustomizationParts(CustomizationInstance,
--           TMap<FGameplayTag,FPrimaryAssetId>, out TMap) — a BlueprintCallable UFUNCTION whose parameter list was
--           READ OUT OF THE 196985 jmap, not guessed (the v1.28.29 lesson) — which routes through the
--           ...WithFragments sibling every game equip path uses. The 1.8.7 setter stays as the fallback, the route
--           that ran is named in the log (`PATH> <fn>`), and each pinned slot prints the probe's own
--           `partId | partDefinition | fragment count` reading BEFORE and AFTER. Success = a non-null
--           partDefinition; that is the one thing the old setter can never produce.
--   (1.8.7) THE FIX, WITH THE SIGNATURE READ RATHER THAN GUESSED. bpclass.py against the cooked package gives
--           ActivateLightsaber(Lightsaber Blade: StaticMeshComponent, BladeLight: PointLightComponent,
--           WeaponInteractionCollision: BoxComponent, Target Saber: Enum_LightsaberStateTarget) - and
--           DeactivateLightsaber takes THE IDENTICAL FOUR. So the extinguish hook is handed exactly what the
--           relight needs: capture the args on the way out, replay them on the way back in. Nothing is
--           reconstructed from the actor or guessed, which is what broke 1.8.0-1.8.5.
--           THIS MATTERS BEYOND ONE SAVE: every saber mod the SDK produces inherits the bug, so the fix belongs
--           in the runtime rather than in any one mod.
--   (1.8.6) THE 1.8.5 RELIGHT CALL IS WITHDRAWN - it threw on every vault. ActivateLightsaber takes FOUR
--           parameters and was called with none ("UFunction expected 4 parameters, received 0"); the function was
--           checked for EXISTENCE and never for SIGNATURE. The turn also would not end in that session - not yet
--           attributed (bKismetScriptError appears three minutes BEFORE the relight ran), which is exactly why
--           this version calls nothing at all. NEW EVIDENCE: HasMantled was TRUE when DeactivateLightsaber fired,
--           so the v1.28.4 discriminator was right all along and was only ever read on the wrong function. The
--           live hypothesis is that HasMantled is never CLEARED after a scripted traversal, so ActivateSaberCheck
--           still believes the wielder is mid-vault and declines. This version logs the state at every check.
--   (1.8.5) THE FIX, ON THE PROVEN TRIGGER. The 1.8.4 probe named the whole sequence in retail (2026-09-12):
--           first vault = DeactivateLightsaber + DeactivateSaberCheck; later vaults = DeactivateSaberCheck alone;
--           next turn = ActivateSaberCheck fires and DECLINES. ActivateLightsaber never runs again, so the blade
--           never returns. Hook moved to DeactivateLightsaber and relight() now calls ActivateLightsaber (four
--           versions called the generic `Activate`, which is not on the blade path at all). Discriminator is
--           bSaberAutoActivateForCombat - the game's own answer - with HasMantled logged rather than trusted.
--   (1.8.4) THE PATH PROBE: 1.8.3 proved `Deactivate` is NOT on the vault path (it never fired). The cooked class
--           exports 50 UFunctions including ActivateLightsaber / DeactivateLightsaber / *SaberCheck / Cinematic_*;
--           the fix has been aimed at the generic Activate/Deactivate pair for four versions. Log-only hooks on
--           every candidate, so the next vault names the real path instead of costing another guess.
--   (1.8.3) DIAGNOSTICS ONLY, no behaviour change: the 1.8.2 hook ARMED in retail (2026-09-11) and the blade still
--           went out on a vault, with nothing else logged - because all four guards in the hook body and both in
--           relight() were bare returns. Five distinct failures shared one silence. Each now names itself.
--   (1.8.2) THE VAULT SABER FIX, REDONE — the DIAGNOSIS of 1.8.0 was right, only its ARMING was wrong. RegisterHook
--           is now called AT MOST ONCE, guarded by a flag and reached only after StaticFindObject proves the saber
--           class is loaded; the loop only LOOKS and stops for good on the first attempt, so the registry-flooding
--           abort of 1.8.0 is structurally impossible. Verified offline first (see the block at the bottom): both
--           UFunctions and all three variables are real in the cooked packages. See CHANGELOG v1.28.16.
--   (1.8.1) THE VAULT SABER FIX OF 1.8.0 IS WITHDRAWN. It hooked BP_FX_LightSaber_Base_C's Deactivate, and because that
--           Blueprint is not loaded at the main menu the arming loop RETRIED RegisterHook every 5 s. Registration never
--           succeeded, the retries piled bad entries into UE4SS's Lua function registry, and the game aborted 175 s in at
--           the main menu ('[Lua::Registry::get_function_ref] Ref was not function', retail 2026-09-10 05:46).
--           LESSON: RegisterHook is NOT retry-safe — register once, from a callback that fires when the class actually
--           exists (NotifyOnNewObject), never on a timer. The diagnosis of the vault bug itself still stands (see
--           CHANGELOG v1.28.4): the saber actor caches `Cached Humanoid ABP` / `bIsActive` /
--           `bSaberAutoActivateForCombat`, which is everything the fix needs — only the ARMING has to be redone.
--   (1.7.0) the recruit-pin loop no longer sweeps EVERY object twice, every 3 s, in every world, for as long as a pin exists.
--           It used to run unchanged inside tactical missions, where nothing can be pinned — 2 x FindAllOf on the game thread
--           forever. Two guards: the expensive CustomizationFragmentInstanceSlot sweep runs only when there is something to
--           pin, and the loop backs off 3 -> 6 -> 12 -> 24 s while nothing changes, resetting on a world change or a pin.
--           (Found chasing a GameThread HANG inside UE4SS's Lua, 2026-09-09/10: same stack in HUB_Root and in a Ryloth
--           mission, ~29 min in each time. Not proven to be the cause — but an unbounded per-frame object sweep on the game
--           thread is a defect either way, and it is the only thing this runtime does forever.)
--   (1.6.0) manifests are also discovered in SWZeroCompany/Mods/<Mod>/ (the game's own mod layout, SDK "gfp"): their registry is the
--           plugin's (not injected); refreshers, follow-ups, recruit pins, grants, rescans apply. Needs bridge 0.5.3 (depth-1 scan).
--   (1.5.0) recruitPins[].match = { slot=, part= }: pins also apply to live characters identified by a slot holding a part (a recruited
--   character carries no CustomizationDefinition, so `definition` alone never reaches it after recruitment).
--   5. (1.4.0) recruit pins: keeps the listed customization slots of every live character spawned from a manifest's
--      CustomizationDefinition set to the listed parts (the game re-rolls a pool recruit's specialization / weapon on every
--      Recruitment refresh) — see applyRecruitPins.
--   3d. runs each manifest's `refreshers` (native calls on live objects: data registries re-scan the injected registry) and the
--       game-specific follow-ups (character pools re-created; 1.3.0, bridge 0.5 `callfname`),
--
-- What it does, once the main-menu world is up:
--   1. arms the bridge (writes the PrintString trigger address to ue4ss/ZCSDKBridge.ctl),
--   2. discovers content-mod manifests  <Mod>.zcsdk.lua  in Content/Paks and Content/Paks/~mods,
--   3. ROUTE B: injects each mod's <Mod>.AssetRegistry.bin into the live asset registry (enumeration),
--   3b. preloads each manifest's `preload` packages (net-new classes resident like the game's own; 1.2.0),
--   3c. rescans each manifest's `primaryTypes` and refreshes the game's per-type caches (1.1.0),
--   4. when a campaign HQ inventory exists, grants each manifest's `grants` items ONCE per save
--      (skipped if the save has ever owned the item), so net-new items show up in the armory/inventory.
--
-- Manifest (emitted by zcmod-build.js next to the pak trio):
--   return { name = "My Mod", version = "1.0.0", registry = "MyMod.AssetRegistry.bin",
--            primaryTypes = { { type = "CustomizationPartDefinition", path = "/Game/ZCSDK", class = "...", blueprintClasses = false } },
--            preload = { "/Game/ZCSDK/GA_MyPassive" },
--            grants = { { item = "/Game/ZCSDK/DA_X.DA_X", amount = 1 } } }
-- Log: ue4ss/ZCSDKLoader.log. Bridge log: ue4ss/ZCSDKBridge.log.
local UEHelpers = require("UEHelpers")

-- SDK dev builds only: also dump item properties (the real scope mod + ours) for schema comparison.
-- Leave OFF for players: reading a TSoftObjectPtr property of a freshly loaded net-new item through
-- UE4SS's Lua binding crashed the game (null deref inside UE4SS.dll, 2026-09-04) — soft props are now
-- skipped in dumpObject, but the dump is diagnostics, not a feature.
local DIAG = false

-- ---- paths (relative to the game's Binaries/Win64; the bridge resolves $paks / $mods itself) ----
local function detectWin64()
    local ok, p = pcall(function() local h = io.popen("cd"); local d = h:read("*l"); h:close(); return d end)
    if ok and p and p ~= "" then
        p = p:gsub("\\", "/")
        local f = io.open(p .. "/ue4ss/UE4SS-settings.ini", "r"); if f then f:close(); return p end
    end
    return "G:/SteamLibrary/steamapps/common/Star Wars Zero Company/SWZeroCompany/Binaries/Win64"
end
local WIN64 = detectWin64()
local UE4SS = WIN64 .. "/ue4ss/"
local LOGFILE = UE4SS .. "ZCSDKLoader.log"

local function log(m)
    local line = "[ZCSDKLoader] " .. tostring(m); print(line .. "\n")
    local f = io.open(LOGFILE, "a"); if f then f:write(os.date("%H:%M:%S ") .. line .. "\n"); f:close() end
end
-- ---- 1.8.27: THE CHEAP WORLD READ (begin; tools/replay_pump.py extracts this block verbatim) ----
-- WHY. UEHelpers.GetWorld() is GetPlayerController():GetWorld(), and UEHelpers.GetPlayerController() is
-- FindAllOf("PlayerController") - a walk of the whole GUObjectArray on EVERY call. Retail 1.8.26 (ZCSDKLoader.log
-- 2026-09-29/30) logged every task that reads the world at 50-170 ms per frame: arm ~60, saber ~80, rowfix ~100, the
-- idle main-menu pin ~65, and each bridge() command paid it too. The engine's viewport holds the world in a reflected
-- property (jmap: Engine.GameViewport @3128, GameViewportClient.World @120) and UEHelpers caches the Engine (one
-- FindFirstOf, and the engine is never collected), so the read is three property accesses. UEHelpers.GetWorld() is
-- the fallback for when that chain is empty (before the viewport exists). Nothing is cached here: the WORLD is re-read
-- on every call, so no UObject crosses a frame.
local WORLDREAD = { cheap = 0, fallback = 0 }
local function gameWorld()
    local w = nil
    pcall(function()
        local vp = UEHelpers.GetEngine().GameViewport
        local ww = vp and vp.World
        if ww and ww:IsValid() then w = ww end
    end)
    if w ~= nil then WORLDREAD.cheap = WORLDREAD.cheap + 1; return w end
    WORLDREAD.fallback = WORLDREAD.fallback + 1
    return UEHelpers.GetWorld()
end
-- ---- 1.8.27: THE CHEAP WORLD READ (end) ----
local function bridge(cmd)
    log("BRIDGE> " .. cmd)
    local ok, err = pcall(function()
        UEHelpers.GetKismetSystemLibrary():PrintString(gameWorld(), cmd, false, false, {R=1,G=1,B=1,A=1}, 0.0, FName("None"))
    end)
    if not ok then log("bridge call failed: " .. tostring(err)) end
end
local function setTrigger()
    local fn = StaticFindObject("/Script/Engine.KismetSystemLibrary:PrintString")
    if not (fn and fn:IsValid()) then log("PrintString UFunction not found"); return false end
    local f = io.open(UE4SS .. "ZCSDKBridge.ctl", "w"); if not f then log("cannot write ZCSDKBridge.ctl"); return false end
    f:write(string.format("trigger=%x\n", fn:GetAddress())); f:close()
    log(string.format("trigger @ 0x%x", fn:GetAddress()))
    return true
end
local function readLines(path)
    local out = {}
    local f = io.open(path, "r"); if not f then return out end
    for line in f:lines() do line = line:gsub("^\239\187\191", ""):gsub("[\r\n]+$", ""); if line ~= "" then out[#out + 1] = line end end
    f:close(); return out
end
local function dirOf(p) return (p:match("^(.*)/[^/]*$")) or "." end

-- ---- diagnostics: dump every reflected property of an object (class chain), one level into arrays/objects ----
local function fmtValue(v, depth)
    if type(v) ~= "userdata" then return tostring(v) end
    local ok, s
    ok, s = pcall(function() return v:GetFullName() end); if ok and type(s) == "string" then return s end
    ok, s = pcall(function() return v:ToString() end); if ok and type(s) == "string" then return s end
    if depth < 1 then
        local items = {}
        local okArr = pcall(function() v:ForEach(function(i, e)
            local ev = e; pcall(function() ev = e:get() end)
            items[#items + 1] = fmtValue(ev, depth + 1)
        end) end)
        if okArr and #items > 0 then return "[" .. table.concat(items, ", ") .. "]" end
        local okTags = pcall(function() v.GameplayTags:ForEach(function(i, e)
            local t = e:get(); items[#items + 1] = t.TagName:ToString()
        end) end)
        if okTags and #items > 0 then return "{tags: " .. table.concat(items, ", ") .. "}" end
    end
    return "<" .. tostring(v) .. ">"
end
-- 1.8.9 (the 2026-09-12 crash analysis): UE4SS's `GetClass` / `GetFName` bindings do NOT test validity - they read
-- [obj+0x10] (UObjectBase::ClassPrivate) straight off the pointer, so calling either on a null/stale UObject is a
-- native access violation that `pcall` CANNOT catch (it is a hardware fault, not a Lua error). `IsValid()` is a pure
-- [obj+0x70] != 0 test and is the only safe thing to ask first; `GetFullName()` is guarded internally and returns nil.
-- Two game crashes in that session came from exactly this shape in ZCSDK_FocusProbe. RULE: IsValid, then GetClass.
local function uvalid(o)
    if o == nil then return false end
    local t = type(o)
    if t ~= "userdata" and t ~= "table" then return false end
    local ok, r = pcall(function() return o.IsValid and o:IsValid() end)
    return (ok and r) and true or false
end
local function dumpObject(obj, label, depth)
    depth = depth or 0
    if not uvalid(obj) then log(label .. ": object not valid (GetClass would fault)"); return end
    local okc, cls = pcall(function() return obj:GetClass() end)
    if not okc or not uvalid(cls) then log(label .. ": no class"); return end
    log(label .. "  class=" .. cls:GetFullName() .. "  obj=" .. obj:GetFullName())
    local c = cls
    local subobjects = {}
    while uvalid(c) do
        local okp, errp = pcall(function()
            c:ForEachProperty(function(prop)
                if not uvalid(prop) then log(string.rep("  ", depth + 1) .. "<invalid FProperty skipped>"); return end
                local name = ""; pcall(function() name = prop:GetFName():ToString() end)
                if name == "" then log(string.rep("  ", depth + 1) .. "<unnamed FProperty skipped>"); return end
                local pcls = ""
                pcall(function() local pc = prop:GetClass(); if uvalid(pc) then pcls = pc:GetFName():ToString() end end)
                if pcls:find("Soft") then log(string.rep("  ", depth + 1) .. name .. " = <" .. pcls .. " skipped>"); return end
                local ok, v = pcall(function() return obj[name] end)
                local s = ok and fmtValue(v, 0) or ("<err " .. tostring(v) .. ">")
                log(string.rep("  ", depth + 1) .. name .. " = " .. s)
                if ok and depth == 0 and type(v) == "userdata" then
                    pcall(function() v:ForEach(function(i, e)
                        local ev = e; pcall(function() ev = e:get() end)
                        if uvalid(ev) and pcall(function() return ev:GetClass() end) then subobjects[#subobjects + 1] = { ev, name .. "[" .. tostring(i) .. "]" } end
                    end) end)
                end
            end)
        end)
        if not okp then log("  (ForEachProperty failed on " .. tostring(c:GetFullName()) .. ": " .. tostring(errp) .. ")") end
        local oks, sup = pcall(function() return c:GetSuperStruct() end)
        c = oks and sup or nil
    end
    for _, so in ipairs(subobjects) do pcall(dumpObject, so[1], string.rep("  ", depth + 1) .. so[2], depth + 1) end
end

-- ---- manifests + registries ----
local manifests = {}   -- { path=, dir=, m=table }
local grants = {}      -- { item=, amount=, from=, done=bool }
local recruitPins = {} -- 1.4.0: { definition=<CustomizationDefinition object path>, slots={ {tag=, part=<part object path>} }, from= }
-- 1.8.27: the class-mod runtime's state and functions (requires[], classPool, the Recruitment watcher, the pin's accept-sets
-- and dormancy). ONE table because the main chunk sits near Lua's 200-local limit. Declared here so `discover` can reach
-- it; its functions are defined inside the recruit-pin block (tools/replay_pin.py / replay_recruit.py extract them).
local CP = {}
local injected = false
local function discover()
    -- 1.6.0: "$gamemods" = SWZeroCompany/Mods/<Mod>/ (the game's own layout, SDK v1.21.0 "gfp"; each manifest one folder down, hence the
    -- bridge's depth-1 scan, v0.5.3). A gfp mod's registry is the plugin's own (loaded by the game) — never injected here; its refreshers,
    -- follow-ups (the recruit pool re-run), recruit pins, grants and primary-type rescans apply as for any manifest.
    for _, root in ipairs({ "$paks", "$mods", "$gamemods" }) do
        local gfp = (root == "$gamemods")
        bridge("ZCSDK:scan|" .. root .. "|*.zcsdk.lua" .. (gfp and "|1" or ""))
        for _, p in ipairs(readLines(UE4SS .. "ZCSDKBridge.scan")) do
            local ok, m = pcall(dofile, p)
            if ok and type(m) == "table" then
                manifests[#manifests + 1] = { path = p, dir = dirOf(p), m = m, gfp = gfp }
                log("manifest: " .. p .. "  (" .. tostring(m.name) .. " v" .. tostring(m.version) .. (gfp and ", gfp: registry is the plugin's" or "") .. ")")
                for _, g in ipairs(m.grants or {}) do
                    if type(g.item) == "string" then grants[#grants + 1] = { item = g.item, amount = tonumber(g.amount) or 1, from = tostring(m.name), done = false } end
                end
                -- 1.4.0 recruitPins (1.5.0 `match`) are built by CP.afterDiscover below, once EVERY manifest is known:
                -- 1.8.27 a slot may name a dependency (`requires`) whose presence decides which part it pins.
            else
                log("manifest failed: " .. p .. " -> " .. tostring(m))
            end
        end
    end
    log(#manifests .. " manifest(s), " .. #grants .. " grant(s)")
    CP.afterDiscover()   -- 1.8.27: requires[] -> the recruit pins -> classPool + settings.ini (one reader, in the pin block)
end
local function injectRegistries()
    for _, mf in ipairs(manifests) do
        if type(mf.m.registry) == "string" and not mf.gfp then   -- 1.6.0: a gfp mod's registry is loaded by the game itself
            local reg = mf.m.registry:match("^%a:/") and mf.m.registry or (mf.dir .. "/" .. mf.m.registry)
            local probe = (mf.m.grants and mf.m.grants[1] and mf.m.grants[1].item) or ""
            bridge("ZCSDK:injreg|" .. reg .. "|" .. probe)
        end
    end
    injected = true
end
-- Preload (loader 1.2.0 / runtime 0.5): a manifest may list packages to LoadPackage right after the registries are injected —
--   preload = { "/Game/ZCSDK/GA_ZCSDK_LongStride", ... }
-- OPT-IN (mod-def `preload: true` or an explicit list); zcmod-build then lists the mod's blueprints[] class packages. The idea:
-- the game's own ability classes are resident at startup, so systems that resolve soft class refs and seed derived data in ONE
-- pass see every stock tier synchronously, while a net-new class arrives through an async soft-class load a moment later.
-- CORRECTED v1.28.21: this comment used to present the Focus tree's empty row as the motivating case. **It is not** — v1.11.0
-- tested preload against exactly that symptom and RULED IT OUT (the note survives in zcmod-build.js, and the two comments
-- disagreed for ten versions). The real gate was found in v1.28.21: `FocusUpgradesConfiguration`, a
-- TMap<FGameplayTag, FFocusPointLevelThresholds> keyed by br.AbilityID.*, in which a net-new ability simply had no entry, so
-- the tree drew its rails and no nodes. Fixed then by OVERRIDING that asset (in the sith_class_mod.json sample, since retired:
-- ZCSithClass replaces it; docs/NETNEW_ABILITY.md has the focus-curve rule). Preload remains available and
-- off by default, for content a synchronous startup pass must genuinely see.
local function preloadPackages()
    local n = 0
    for _, mf in ipairs(manifests) do
        for _, p in ipairs(mf.m.preload or {}) do
            if type(p) == "string" and p:sub(1, 1) == "/" then bridge("ZCSDK:loadpkg|" .. p); n = n + 1 end
        end
    end
    if n > 0 then log("preload requested for " .. n .. " package(s)") end
end
-- Primary-asset rescan: the asset manager built its primary-asset map at startup (ScanPathsForPrimaryAssets over the
-- registry); an injected registry does not update it. A manifest lists the primary asset types it ships —
--   primaryTypes = { { type = "CustomizationPartDefinition", path = "/Game/ZCSDK", class = "/Script/BitReactorCore.CustomizationPartDefinition" } }
-- and the bridge rescans that type over that path (the customization part picker, classes, missions... enumerate this way).
local function rescanPrimaryTypes()
    local n = 0
    for _, mf in ipairs(manifests) do
        for _, pt in ipairs(mf.m.primaryTypes or {}) do
            if type(pt.type) == "string" and type(pt.path) == "string" then
                bridge("ZCSDK:rescan|" .. pt.type .. "|" .. pt.path .. "|" .. tostring(pt.class or "") .. "|" .. tostring(pt.blueprintClasses and 1 or 0))
                n = n + 1
            end
        end
    end
    if n > 0 then log("primary-asset rescan requested for " .. n .. " type(s)") end
end
-- Per-type cache refreshers: the game keeps its own per-type caches built from the primary-asset list at startup; a
-- rescan alone does not reach them. Each entry names the subsystem object to find and the nullary native method the
-- bridge calls on it (`callthis`, bridge v0.4). Found via tools/recon/pdbsyms.py `calls`:
--   CustomizationPartDefinition -> UCustomizationPartsTagSubsystem (EngineSubsystem) caches a tag -> parts map that
--   UCustomizationStatics::GetCustomizationPartIds (the customizer's part picker) reads; BuildPartTagMaps() rebuilds it
--   (the same thing the game does on HandleAssetAdded / HandlePakFileMounted).
local REFRESHERS = {
    CustomizationPartDefinition = { { find = "CustomizationPartsTagSubsystem", sym = "?BuildPartTagMaps@UCustomizationPartsTagSubsystem@@AEAAXXZ" } },
}
local function refreshCaches()
    local done = {}
    for _, mf in ipairs(manifests) do
        for _, pt in ipairs(mf.m.primaryTypes or {}) do
            for _, r in ipairs(REFRESHERS[tostring(pt.type)] or {}) do
                local key = r.find .. r.sym
                if not done[key] then
                    done[key] = true
                    local ok, obj = pcall(FindFirstOf, r.find)
                    if ok and obj and obj:IsValid() then
                        bridge(string.format("ZCSDK:callthis|%s|%x", r.sym, obj:GetAddress()))
                        log("cache refresh: " .. r.find .. " -> " .. r.sym)
                    else
                        log("cache refresh: " .. r.find .. " not found (skipped " .. r.sym .. ")")
                    end
                end
            end
        end
    end
end

-- Manifest refreshers (loader 1.3.0 / runtime 0.6): a manifest may list native calls to make on live objects after the injection +
-- rescan, when the game built something from the asset registry ONCE at startup that no rescan reaches:
--   refreshers = { { find = "CharacterPoolDataRegistry", name = "DR_InitialCharacterPool", sym = "?RefreshRuntimeSources@UDataRegistry@@MEAAXXZ" }, ... }
--   find = the UE4SS class name to FindAllOf, name = the object's short name (optional: first live instance), sym = a nullary method
--   (bridge callthis) or, with fname = "<Name>", a void(const FName&) method (bridge callfname, v0.5).
-- zcmod-build emits one for every DataRegistry-derived asset a mod appends to (the registry's meta sources re-scan the asset registry,
-- which now holds the mod's tables). FOLLOWUPS adds what the game then has to redo: the character pools are created once in
-- UBitReactorCharacterPoolManager::OnDataRegistrySubsystemInitialized (tools/recon/pdbsyms.py callers), so after DR_InitialCharacterPool
-- is refreshed the pool creation is re-run for that registry type. NOT idempotent by itself (SDK v1.12.0 retail, PoolVerifier round 2):
-- CreateNewCharacterPool always AddDefaulted()s a fresh FCharacterPoolData onto CharacterPools, then the async acquire callback files the
-- registry's characters into the FIRST pool of that name — so a re-run fills the original pool and leaves an EMPTY duplicate at the END of
-- the array. `dedupe` (1.3.1, bridge 0.5.1 `arrpop`) pops that trailing duplicate right after the call: only when >= 2 pools carry the
-- name, the last one is one of them and it holds no characters; the element is destructed by the game's own ~FCharacterPoolData.
-- CreatePreAuthoredCharacterPool(const FName& RegistryType, const ECharacterPoolType& PoolType): the pool type rides as `arg` (an integer the
-- bridge passes by const reference; 6 = InitialCharacterPool, 7 = EnemyCharacterPool — the values the manager's pools report).
local CPACP = "?CreatePreAuthoredCharacterPool@UBitReactorCharacterPoolManager@@AEAAXAEBVFName@@AEBW4ECharacterPoolType@@@Z"
local POOLS = { prop = "CharacterPools", offset = 328, elemSize = 120, dtor = "??1FCharacterPoolData@@QEAA@XZ" }   -- jmap: UBitReactorCharacterPoolManager.CharacterPools @ 328, FCharacterPoolData 120 bytes
local FOLLOWUPS = {
    DR_InitialCharacterPool = { find = "BitReactorCharacterPoolManager", sym = CPACP, fname = "InitialCharacterPool", arg = 6, dedupe = POOLS },
    DR_EnemyCharacterPool   = { find = "BitReactorCharacterPoolManager", sym = CPACP, fname = "EnemyCharacterPool", arg = 7, dedupe = POOLS },
}
-- After a pool re-run: drop the empty duplicate pool entry named `poolName` if it sits at the END of obj.<d.prop> (see FOLLOWUPS).
local function dedupeTrailingPool(obj, d, poolName, tag)
    local ok, err = pcall(function()
        local arr = obj[d.prop]
        local n = arr:GetArrayNum()
        if n < 2 then return end
        local firstIdx, lastName, lastCount = nil, nil, 0
        arr:ForEach(function(i, e)
            local p = e:get()
            local nm = ""; pcall(function() nm = p.CharacterPoolName:ToString() end)
            if nm == poolName and not firstIdx then firstIdx = i end
            if i == n then lastName = nm; pcall(function() p.Characters:ForEach(function() lastCount = lastCount + 1 end) end) end
        end)
        if lastName ~= poolName or not firstIdx or firstIdx == n then log(tag .. ": no trailing duplicate pool (" .. n .. " pools)"); return end
        if lastCount > 0 then log(tag .. ": trailing pool '" .. poolName .. "' holds " .. lastCount .. " character(s) — kept"); return end
        local addr = nil
        pcall(function() addr = arr:GetArrayAddress() end)                     -- UE4SS TArray API, when available
        if type(addr) ~= "number" or addr == 0 then addr = obj:GetAddress() + d.offset end   -- else the owner + the property's jmap offset
        bridge(string.format("ZCSDK:arrpop|%x|%d|%s|%d", addr, d.elemSize, d.dtor, n))
        log(tag .. ": popped the empty duplicate pool '" .. poolName .. "' (entry " .. n .. " of " .. n .. "; first '" .. poolName .. "' is entry " .. firstIdx .. ")")
    end)
    if not ok then log(tag .. ": dedupe failed: " .. tostring(err)) end
end
local function findLive(className, shortName)
    local ok, list = pcall(FindAllOf, className)
    if not ok or not list then return nil end
    for _, o in ipairs(list) do
        if o and o:IsValid() then
            local full = o:GetFullName()
            if not full:find("Default__") and (not shortName or full:find("[%.:]" .. shortName .. "$") or full:find("[%.:/]" .. shortName .. "[%.:]")) then return o end
        end
    end
    return nil
end
local function runRefresher(r, tag)
    if type(r) ~= "table" or type(r.find) ~= "string" or type(r.sym) ~= "string" then return end
    local obj = findLive(r.find, r.name)
    if not obj then log(tag .. ": " .. r.find .. (r.name and (" '" .. r.name .. "'") or "") .. " not found (skipped " .. r.sym .. ")"); return end
    -- assets = registry-resolved asset paths to hand to a DataRegistry first (UDataRegistry::RegisterSpecificAsset via bridge `dtreg`):
    -- its meta sources create a child source per registered table, no path search involved
    for _, a in ipairs(r.assets or {}) do
        bridge(string.format("ZCSDK:dtreg|%x|%s", obj:GetAddress(), a))
        log(tag .. ": registered " .. a .. " with " .. (r.name or r.find))
    end
    if type(r.fname) == "string" and r.fname ~= "" then
        if r.arg ~= nil then bridge(string.format("ZCSDK:callfname|%s|%x|%s|%d", r.sym, obj:GetAddress(), r.fname, tonumber(r.arg)))
        else bridge(string.format("ZCSDK:callfname|%s|%x|%s", r.sym, obj:GetAddress(), r.fname)) end
    else
        bridge(string.format("ZCSDK:callthis|%s|%x", r.sym, obj:GetAddress()))
    end
    log(tag .. ": " .. r.find .. (r.name and (" '" .. r.name .. "'") or "") .. " -> " .. r.sym .. (r.fname and (" (" .. r.fname .. ")") or ""))
    if type(r.dedupe) == "table" and type(r.fname) == "string" then dedupeTrailingPool(obj, r.dedupe, r.fname, tag) end
end
local followups = {}
local function applyRefreshers()
    local n = 0
    for _, mf in ipairs(manifests) do
        for _, r in ipairs(mf.m.refreshers or {}) do
            runRefresher(r, "refresh"); n = n + 1
            local f = r.name and FOLLOWUPS[r.name]
            if f and not followups[r.name] then followups[r.name] = f end
        end
    end
    if n > 0 then log("refreshers: " .. n .. " requested") end
end
local function applyFollowups()
    for name, f in pairs(followups) do runRefresher(f, "follow-up for " .. name) end
end

-- ---- grants: once per save, when an HQ inventory exists ----
local statics = nil
local function findHQ()
    local ok, hq = pcall(FindFirstOf, "BrunoHQInventory")
    if ok and hq and hq:IsValid() and not hq:GetFullName():find("Default__") then return hq end
    return nil
end
local function applyGrants()
    local pending = 0
    for _, g in ipairs(grants) do if not g.done then pending = pending + 1 end end
    if pending == 0 then return true end
    local hq = findHQ(); if not hq then return false end
    if not statics then
        local s = StaticFindObject("/Script/Bruno.Default__BrunoGameStatics")
        if s and s:IsValid() then statics = s else log("BrunoGameStatics CDO not found"); return false end
    end
    for _, g in ipairs(grants) do
        if not g.done then
            local item = StaticFindObject(g.item)
            if not (item and item:IsValid()) then
                log("grant: loading " .. g.item); pcall(LoadAsset, g.item)   -- registry-resolved (works after injection); async -> retry next tick
                local pkg = g.item:match("^(.-)%.[^%.]+$"); if pkg then bridge("ZCSDK:loadpkg|" .. pkg) end
            else
                local okH, owned = pcall(function() return hq:HasEverOwnedItem(item) end)
                if okH and owned then
                    log("grant: " .. g.item .. " already owned by this save (skip)")
                else
                    local okG, err = pcall(function() statics:GrantItem(hq, item, g.amount) end)
                    log("grant: " .. g.item .. " x" .. g.amount .. " (" .. g.from .. ") -> " .. (okG and "GRANTED" or ("failed: " .. tostring(err))))
                    if DIAG and okG then pcall(dumpObject, item, "granted item") end
                end
                g.done = true
            end
        end
    end
    return false
end

-- ---- recruit pins (loader 1.4.0 / runtime 0.7; the ORDER + the TOGGLE in 1.8.18, the dead experiments cut in 1.8.19) ----
-- A pre-authored recruit's Specializations slots (tactical spec, weapon class...) are RE-ROLLED by the game on every Recruitment refresh
-- (UBitReactorGameStatics_Spawn::SpawnCharacter -> UCustomizationStatics::Randomize over the spawn params' slots; nothing data-side
-- survives it — docs/NETNEW_CLASS.md). The spawn is native (no ProcessEvent to hook), so the pin is a poll: every few seconds, every live
-- CustomizationInstance whose default CustomizationDefinition is a manifest's `recruitPins[].definition` gets the listed slots equipped
-- with the listed parts and its customization refreshed. Slot instances are matched to their instance by full-name prefix (the SlotProbe
-- technique); a fragment's TSoftObjectPtr is never read from Lua (that crashed the game in v1.3.0).
--
-- 1.8.9's SUCCESS CRITERION, which 1.8.19 keeps because it is the thing the pin still judges by: a slot counts as
-- equipped when its FragmentInstances are REPLACED (object identity) or it gains LeveledAbilities /
-- LoadedLeveledAbilities entries. `CustomizationPartDefinition` is NOT a criterion in either direction - the game's own
-- CPD_TalentSpec_TheToughGuy reads partDefinition=<null> with one leveled tree and draws a full row, and the id-only
-- setter resolves a definition by itself once the asset is resident.
--
-- 1.8.9's THIRD correction, also kept: in a MISSION the characters are rebuilt from save data and the game re-equips
-- them during load (21:28:27 vs 21:28:30), so a pin there can only write the id; PIN_STRATEGY_ONLY logs that once.
--
-- WHAT 1.8.19 DELETED, AND WHY IT IS NOT COMING BACK. Loader 1.8.8-1.8.17 tried to reach the fragment-carrying
-- `...WithFragments` sibling through UCustomizationStatics::EquipCustomizationDefinition (shapes `allowed` / `tags` /
-- `all`) and ::EquipCustomizationParts (shapes `struct` / `table`), judged by an `arrival` observable, and probed the
-- AssetManager through UKismetSystemLibrary. Retail 2026-09-13 09:04:40 settled it: the PLAIN 1.4.0 setter
-- `UCustomizationFragmentInstanceSlot::SetCustomizationPartPrimaryAssetId` (RVA 0x8c54660) delivered the Sith's two
-- leveled trees, because `LoadCustomization` rebuilds the fragment instances on an id CHANGE once the part is
-- resident. The equip routes cost two sessions: an EMPTY AllowedSlots container means "every slot this definition
-- names", so equipping the Class part through it re-created the character's own child slots twice (07:52:26,
-- 09:04:44). All of it is deleted. The sequence that WORKS is below: residency first, then Class to completion, then
-- Weapon, then Tactical, toggling through a vanilla id, delivered-is-final.
local PIN_MAX_RETRY = 4           -- re-equips of a slot that holds our id but never took a fragment instance
local PIN_RESIDENCY_PASSES = 12   -- 1.8.19: passes `done` is held while a pinned part is still loading (~60 s at the
                                  -- 5 s cadence). BOUNDED on purpose: an unbounded pin loop is the 05:43 crash.
local PIN_STRATEGY_ONLY = true    -- 1.8.19: now only an OBSERVABILITY gate — it logs, once, that this world is not the
                                  -- hub, so a pass that changes nothing in a mission is never a silent one
-- what to TOGGLE a slot through when it already holds our part but never took its fragments. The vanilla id the slot
-- itself carried is preferred and remembered per slot; these are the fallbacks, read off other characters in the same
-- hub (retail 08:41/09:04 BEFORE lines).
-- 1.8.27 (G2, SDK_CHANGE_REQUEST §4): the Talent slot too. A Talent that holds our id with no fragments and no remembered
-- vanilla id had nothing to toggle through. CPD_TalentSpec_TheToughGuy's path is VERIFIED in build/_gameregistry.json
-- (2026-09-29), and the ghost refusal's toggle-id exemption (PIN_TOGGLE_PATH[cur]) covers it by construction.
local PIN_TOGGLE_DEFAULT = {
    ["br.Customization.Slot.Character.Class"] = "CPD_Char_Class_Hero_Humanoid",
    ["br.Customization.Slot.Character.Specializations.Weapon"] = "CPD_WeaponSpec_Blaster_Longarm",
    ["br.Customization.Slot.Character.Specializations.Tactical.Primary"] = "CPD_TacticalSpec_Assault",
    ["br.Customization.Slot.Character.Specializations.Talent"] = "CPD_TalentSpec_TheToughGuy",
}
local PIN_TOGGLE_PATH = {
    CPD_Char_Class_Hero_Humanoid = "/Game/Game/Customizations/Characters/Common/CharacterClass/CPD_Char_Class_Hero_Humanoid.CPD_Char_Class_Hero_Humanoid",
    CPD_WeaponSpec_Blaster_Longarm = "/Game/Game/Customizations/Characters/Common/Specialization/Weapon/CPD_WeaponSpec_Blaster_Longarm.CPD_WeaponSpec_Blaster_Longarm",
    CPD_TacticalSpec_Assault = "/Game/Game/Customizations/Characters/Common/Specialization/Tactical/CPD_TacticalSpec_Assault.CPD_TacticalSpec_Assault",
    CPD_TalentSpec_TheToughGuy = "/Game/Game/Customizations/Characters/Common/Specialization/Talent/CPD_TalentSpec_TheToughGuy.CPD_TalentSpec_TheToughGuy",
}
-- 1.8.27: THE PASS STATE. One table, for the 200-local limit. `P` is the pass in flight (nil between passes).
-- 1.8.28: THE LOOKUP BUDGET (see "THE FRAME-BOUNDED PASS" above PS.get). A pass holds strings, numbers and booleans across
-- frames; the objects a frame uses come from THAT frame's own FindAllOf / StaticFindObject, and at most PS.LOOKUPS of those
-- run per frame. The one exception is PS.ksl(): a class default object (KismetSystemLibrary's CDO), which is never
-- collected, exactly as UEHelpers caches it.
local PS = { OVER_MS = 16, OVER_CAP = 30, P = nil, clock = os.clock, overLogged = 0, walked = 0, knownRp = {},
             LOOKUPS = 2,          -- object lookups (FindAllOf / StaticFindObject) per frame: the slot FindAllOf + ONE more
             DRIVE_MAX = 16,       -- drive frames per pass (the Class, then the children, one part lookup per frame)
             LOOK_MAX = 24,        -- lookup-only frames per pass (the ghost / stale residency checks)
             SWEEP_PASSES = 16,    -- the first N passes of every world sweep the WHOLE world (ghosts, stale slots, roster)
             SWEEP_S = 120,        -- ... and after that one pass in SWEEP_S does, while the loop is awake
             CLASS_HOLD = 3,       -- idle frames after a Class delivery before its children are re-found
             CLASS_TRIES = 4,      -- drive frames that may find the children NOT yet re-created before they are driven anyway
             URGENT_WAIT_S = 12,   -- a Recruitment event: how long an urgent pass waits for a card of ours to exist
             URGENT_STEP_S = 0.5,  -- ... looking again every URGENT_STEP_S
             SPAWN_SETTLE_S = 1.5, -- a card must have existed this long (its async spawn sets the Talent at its end)
             VERIFY_S = 8,         -- after an urgent episode's `done`: ONE verify pass this much later
             res = {}, partRes = {}, cdos = {}, firstSeen = {}, lookEchoed = {}, accKey = {}, reverted = {},
             worldPasses = 0, lastWorld = nil, sweepAt = nil, forceFull = false, urgent = nil, sfo = 0, fao = 0 }

local pinLoadRequested = false
local pinLog = {}
local pinArmed = {}          -- function name -> true, so "hook armed on <fn>" is logged once (session_audit.py vocabulary)
local pinAttempts = {}       -- owner|tag -> re-equips spent on a slot that never took a fragment
local criterionLogged = false
local pinExpected = {}       -- 1.8.18: owner|tag -> this pin wants this slot; `done` means all of them delivered
local pinDelivered = {}      -- 1.8.18: owner|tag -> this slot has delivered; never drive it again
local pinToggled = {}        -- 1.8.18: owner|tag -> the pass a toggle id was written, so ours goes back next pass
local pinVanilla = {}        -- 1.8.18: owner|tag -> the non-ours part this slot was last seen holding
local pinQuiet = {}          -- 1.8.18: one-shot log keys
local pinGaveUp = {}         -- owner|tag -> the give-up message has been logged once (1.8.10)
local pinWaited = 0          -- 1.8.19: passes spent holding `done` while a pinned part was still not resident
-- 1.8.14: a preview/portrait proxy is a TRANSIENT actor the game destroys and recreates while Personnel is open. The
-- 05:43 session re-drove BP_CustomizationProxyCharacter_C_1 nine times and C_0 three times, every pass, forever -
-- pointless (they are previews, not the saved character) and the likeliest source of a stale userdata. Never again.
local PIN_PROXY_PATTERNS = { "CustomizationProxyCharacter", "CustomizationPreviewProxyCharacter",
                             "BrunoPortraitCharacter", "PortraitCharacter", "BP_PreviewActor" }
local function isProxyOwner(p)
    for _, pat in ipairs(PIN_PROXY_PATTERNS) do if p:find(pat, 1, true) then return pat end end
    return nil
end
local pinKnown = {}          -- 1.8.15: instance path -> how it was identified; identity is sticky for the session
local pinDone = false        -- 1.8.14: every pinned slot on every real character is settled; the loop stops
local pinSkipLogged = {}     -- owner -> the skip reason has been logged once this session (1.8.11)
local pinRefused = {}        -- instance path -> already logged a refusal (1.8.10)
local scopeLogged = false

local function shortTag(t) return (tostring(t):gsub("^br%.Customization%.Slot%.Character%.", "")) end
local function shortOwner(o) return (tostring(o):gsub("^.*PersistentLevel%.", ""):gsub("%..*$", "")) end
-- 1.8.26: ONE guarded IsValid. The pin block used to write `o.IsValid and pcall(function() return o:IsValid() end) and
-- o:IsValid()` — the pcall's first result is its STATUS, so that only proved IsValid did not raise and then called it
-- a second time UNGUARDED. The 2026-09-28 21:51 fault is that second call (owningInstance, the old main.lua:1705).
-- A pcall cannot catch a hardware fault, so this is hygiene, not the crash fix (that is the pump, below); it halves
-- the IsValid calls on the hottest path in the loader and leaves no unguarded one. Defined INSIDE the pin block so
-- tools/replay_pin.py, which extracts this block verbatim, carries it.
local function pinOk(o)
    if o == nil then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return (ok and v) and true or false
end

-- session_audit.py reads "hook armed on <fn>" as an arming and "PATH> <fn>" as a firing (tools/session_audit.py:203/206).
-- Arming is therefore logged at the point the route is CHOSEN, and PATH> immediately BEFORE the call, so "armed and never
-- fired" can only ever mean "the loader decided to use it and never got as far as calling it".
local function pinArm(fn, why)
    if pinArmed[fn] then return end
    pinArmed[fn] = true
    log("recruit pin: hook armed on " .. fn .. (why and (" (" .. why .. ")") or ""))
end

-- v1.28.32's lesson, applied here too: GetFullName() on an invalid world returns nil WITHOUT raising, so the TYPE of the
-- result is what gets tested, never the pcall's ok.
-- 1.8.27: through gameWorld() (the viewport's world: three property reads), not UEHelpers.GetWorld() (a FindAllOf).
local function pinWorldName()
    local n = nil
    pcall(function() n = gameWorld():GetFullName() end)
    return (type(n) == "string" and n ~= "") and n or "<none>"
end
local function strategySide()
    local w = pinWorldName()
    return (w:find("HUB_Root", 1, true) ~= nil), w
end

-- The probe's reading (ZCSDK_FocusProbe/Scripts/main.lua:147 dumpOwningSlot / :161 dumpLeveledInstance), plus the two numbers
-- that actually decide it: the fragment instances' OBJECT IDENTITIES and their leveled-ability counts.
local function fragState(s)
    local names, trees, loaded = {}, 0, 0
    pcall(function()
        s.FragmentInstances:ForEach(function(_, e)
            local fi = e
            local okG, g = pcall(function() return e:get() end)
            if okG and g then fi = g end
            -- 1.8.9: IsValid before anything else. GetFullName is internally guarded (it returns nil on a dead
            -- object), but a PROPERTY read on one is not, and a native access violation is not pcall-catchable.
            if not (pinOk(fi)) then
                names[#names + 1] = "<invalid>"; return
            end
            local n = nil
            pcall(function() n = fi:GetFullName() end)
            names[#names + 1] = (type(n) == "string") and n or "<?>"
            pcall(function() fi.LeveledAbilities:ForEach(function() trees = trees + 1 end) end)
            pcall(function() fi.LoadedLeveledAbilities:ForEach(function() loaded = loaded + 1 end) end)
        end)
    end)
    return table.concat(names, ";"), #names, trees, loaded
end

local function slotState(s)
    local st = { id = "?", defn = "<null>" }
    pcall(function()
        local p = s.CustomizationPartPrimaryAssetId
        st.id = tostring(p.PrimaryAssetType.Name:ToString()) .. ":" .. tostring(p.PrimaryAssetName:ToString())
    end)
    pcall(function()
        local d = s.CustomizationPartDefinition
        if d and d.IsValid and d:IsValid() then st.defn = (d:GetFullName():gsub("^[^ ]+ ", ""):gsub("^.*[/%.]", "")) end
    end)
    st.frags, st.nfrag, st.trees, st.loaded = fragState(s)
    return st
end

local function sigOf(st)
    return string.format("partId=%s | partDefinition=%s | %d fragment instance(s) | %d leveled tree(s) | %d loaded tree(s)",
        st.id, st.defn, st.nfrag, st.trees, st.loaded)
end

-- THE CRITERION. Not "did the definition resolve" (both doors can do that, and neither has to) — "did a fragment instance move".
local function deliveredTo(before, after)
    if after.frags ~= before.frags then return true, "FragmentInstances REPLACED" end
    if after.trees > before.trees then return true, "leveled trees " .. before.trees .. " -> " .. after.trees end
    if after.loaded > before.loaded then return true, "loaded trees " .. before.loaded .. " -> " .. after.loaded end
    if after.id ~= before.id then return false, "partId changed and the fragment instances did not — the id-only signature" end
    return false, "nothing on the slot changed"
end

local function logCriterion()
    if criterionLogged then return end
    criterionLogged = true
    log("recruit pin: success criterion = the slot's FragmentInstances are REPLACED (object identity) or it gains " ..
        "LeveledAbilities / LoadedLeveledAbilities entries. CustomizationPartDefinition is NOT a criterion: the game's own " ..
        "CPD_TalentSpec_TheToughGuy reads partDefinition=<null> with 1 leveled tree and draws a full row, and the id-only setter " ..
        "resolves a definition by itself once the asset is resident.")
end

-- ---- 1.8.19: THE GHOST REFUSAL (HANDOFF open items 3 and 7) ----
-- A save can carry a part id from a mod that is NO LONGER INSTALLED. Hawks' save does: a `ZCSDKLongStride` leveled
-- tree whose tier classes are all null, left behind by the uninstalled ZCSDK_Passive (CHANGELOG v1.28.32), and the
-- 2026-09-12 turn-end block is the INFERRED consequence — four launches with the runtime OFF (eight mods / one / none)
-- all blocked after a vault, and a fresh mission with no mods was clean. Writing over a slot in that state is the last
-- thing a loader should do: it cannot know what else in the save refers to it. So the loader REPORTS the ghost and
-- REFUSES to drive that slot, on ANY character in the hub, ours or not. Nothing is ever written by this code.
--
-- WHAT COUNTS AS A GHOST — all three, so the normal 1.8.18 toggle case can never be mistaken for one:
--   (1) the slot carries one of THIS pin's declared tags (so the sweep is bounded), and
--   (2) its part id is NOT carried by any CURRENTLY ENUMERATED manifest — the loader has just discovered every
--       `<Mod>.zcsdk.lua` on disk, so "not in that set" means "no installed mod ships this part"; a slot holding OUR
--       id is in that set BY CONSTRUCTION and is therefore never a ghost, resident or not, and
--   (3) the part is not resident anywhere the loader can see: no resolved `CustomizationPartDefinition` on the slot
--       AND no object at the SDK's own `/Game/ZCSDK/<name>.<name>`.
-- Two EVIDENCE SHAPES satisfy (2)'s "this came from a mod": a `CPD_ZCSDK_*` id (the SDK's own naming), or the
-- FocusProbe's shape — a LEVELED TREE whose tier classes are null (LeveledAbilities entries, zero
-- LoadedLeveledAbilities, and nothing resolved), which is exactly how Hawks' LongStrider tree reads.
--
-- ---- 1.8.20: AND WHAT 1.8.19 GOT WRONG — THREE FALSE POSITIVES IN ONE RETAIL SESSION ----
-- Retail 2026-09-13 (the 22:52:48 session), three of the four GHOST lines named the GAME's own parts:
--     22:54:11  GHOST /Engine/Transient Specializations.Tactical.Primary: holds CPD_TacticalSpec_Soldier ...
--     23:00:21  GHOST /Engine/Transient Specializations.Tactical.Primary: holds CPD_TacticalSpec_Hero_Aurelio_Assault ...
--     23:00:21  GHOST /Engine/Transient Class: holds CPD_ZCSDK_Char_Class_Vanguard ...
-- and only the fourth was real:
--     23:00:37  GHOST Char_Hero_HAWKS_Control_C_0 Specializations.Tactical.Primary: holds CPD_ZCSDK_TacticalSpec_LongStrider ...
-- Both defects are in the same three lines. (a) They were judged WHILE THE CHARACTER WAS STILL SPAWNING: the census
-- went 27 instance(s) at pass 50 -> 73 at pass 51 -> 109 at pass 54 -> 122 at pass 58, and at pass 50 the loader
-- itself recorded `0 with pinned slot(s)` — the slots existed, nothing owned them yet, and evidence shape 2 (a
-- leveled tree with zero LoadedLeveledAbilities on an unresolved slot) is exactly what a half-built slot looks like.
-- (b) The owner was printed from the SLOT's own name, and `shortOwner` strips up to `PersistentLevel.`, which
-- `/Engine/Transient...` does not contain — so the line named a package, not a character. `/Engine/Transient` is not
-- an owner; a report that cannot say WHOSE save is affected is not worth printing.
--
-- TWO RULES, and neither of them guesses:
--   (1) A non-`CPD_ZCSDK_` id is only called a ghost after PIN_GHOST_PASSES CONSECUTIVE passes reading unresolved
--       with trees>0 / loaded==0. Any pass that reads otherwise resets the count to zero. N is taken from the log
--       above: passes 50 -> 54 is how long the hub took to go from 27 half-built instances to the full 109 with
--       every character named (and the true Hawks ghost printed at pass 52, inside that window, so N must not be so
--       large that a real ghost is lost — it is not, because rule (1) does not apply to a `CPD_ZCSDK_` id at all).
--       STATED HONESTLY: the Aurelio slot's own resolution was never measured, because 1.8.19 marked the slot and
--       stopped looking at it; N is derived from the world-population evidence, not from that slot.
--   (1b) NOT DONE, and why: "is this id a registered GAME primary asset" would settle it in one call, but the
--       AssetManager API the loader can reach (GetObjectFromPrimaryAssetId on the KismetSystemLibrary CDO) needs a
--       real by-value FPrimaryAssetId, and the only way this runtime has ever minted one is
--       `GetPrimaryAssetIdFromObject(<a live object>)` — which needs the object a ghost by definition does not have.
--       There is no safe read, so the consecutive-pass rule stands alone. (1.8.16 guessed a UE4SS accessor and
--       printed an address for a whole session; that is not repeated here.)
--   (2) NO REPORT WITHOUT A NAMED OWNER. The owner is the OWNING CUSTOMIZATIONINSTANCE (`owningInstance`), never the
--       slot's own path, and a slot that has no owning instance yet is DEFERRED to a later pass, not printed. This
--       alone would have suppressed all three false lines, and it costs nothing on the real one: Hawks' slot was
--       owned and named at pass 52.
-- BLOCKING vs REPORTING, kept apart on purpose. A `CPD_ZCSDK_*` candidate is certain enough to refuse the moment its
-- owner can be named (that is the Hawks case, and the whole point of the mechanism). An evidence-shape-2 candidate
-- is NOT blocked while it is being counted — if it were, the pin could never drive it, it could never resolve, and
-- the count would reach N by its own doing. It is counted, and the drive is allowed to prove it wrong.
local PIN_GHOST_PASSES = 4   -- consecutive unresolved passes before a non-CPD_ZCSDK_ id is called a ghost
local pinKnownParts = nil    -- short part name -> true, for every part any enumerated manifest carries
local pinKnownPaths = {}     -- 1.8.22: ... and the object path it was named by, so a part the loader did not pin can
                             -- still be re-minted into an FPrimaryAssetId (the stale-slot rebuild needs the ORIGINAL
                             -- id back, and minting one has only ever worked from a live object)
local pinGhostLogged = {}    -- owner|tag|partId -> the GHOST line has been logged once this session
local pinGhostSlot = {}      -- slot full name -> a REPORTED ghost lives here; never collect it, never drive it
local pinGhostSeen = {}      -- slot full name|partId -> consecutive passes this slot has read as a candidate
local pinGhostHeld = {}      -- slot full name|partId|reason -> the "not reported" line has been logged once

local function pinManifestParts()
    if pinKnownParts then return pinKnownParts end
    local k = {}
    local function add(p)
        if type(p) == "string" then
            local n = p:match("([^/.]+)$")
            if n and n ~= "" then k[n] = true; pinKnownPaths[n] = pinKnownPaths[n] or p end
        end
    end
    -- 1.8.27: an id a pin ACCEPTS (H1 / §5.6) or leaves alone on a roster character (its `escape`) is
    -- a part the install ships or a stock part: never a ghost. Only the NAME is recorded - a stock id given a path here
    -- would make the 1.8.22 stale-slot rebuild treat every Blaster Pistol in the hub as ours-shipped.
    local function addName(p)
        local n = (type(p) == "string") and p:match("([^/.]+)$") or nil
        if n and n ~= "" then k[n] = true end
    end
    local function addAny(p)
        if type(p) ~= "string" then return end
        if p:find("/", 1, true) and not p:find("^/Game/Game/") then add(p) else addName(p) end
    end
    for _, rp in ipairs(recruitPins) do
        add(rp.definition)
        if rp.match then add(rp.match.part) end
        for _, s in ipairs(rp.slots or {}) do
            add(s.part)
            for n in pairs(s.accept or {}) do k[n] = true end
            for n in pairs(s.rosterIds or {}) do k[n] = true end
        end
    end
    if type(manifests) == "table" then
        for _, mf in ipairs(manifests) do
            local m = (type(mf) == "table") and mf.m or nil
            if type(m) == "table" then
                for _, g in ipairs(m.grants or {}) do add(g.item) end
                for _, p in ipairs(m.preload or {}) do add(p) end
                for _, rp in ipairs(m.recruitPins or {}) do
                    add(rp.definition)
                    if type(rp.match) == "table" then add(rp.match.part) end
                    for _, s in ipairs(rp.slots or {}) do
                        add(s.part)
                        addAny(s.fallback); addAny(s.escape)
                        if type(s.accept) == "table" then for _, a in ipairs(s.accept) do addAny(a) end end
                    end
                end
            end
        end
    end
    -- 1.8.27 (§2d.3, the :1094 rule narrowed): a part of a dependency that is MISSING is not shipped by anything installed,
    -- whatever a manifest names. Its ids leave the set, so the ghost refusal can see them.
    for n in pairs(CP.deadName or {}) do k[n] = nil; pinKnownPaths[n] = nil end
    pinKnownParts = k
    return k
end

-- returns the ghost part id, or nil. Reads only; IsValid before every method, every read pcall'd.
-- 1.8.27 (§2d.3): a THIRD evidence shape. An id in the name snapshot of a dependency that is MISSING (`requires[].names`,
-- plus the dependency's packages and the pinned parts into it) is certain enough to report - it has no tags, no residency
-- and no installed mod behind it - UNLESS a pin on this tag declares a `fallback`: then it is not a ghost at all, because
-- the normal delivery writes the fallback over it (the removed-pack case with an escape hatch). Second return: the dep.
local function ghostOf(s, tag)
    local cur = ""
    pcall(function() cur = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end)
    if type(cur) ~= "string" or cur == "" or cur == "None" then return nil end
    local dead = CP.deadName and CP.deadName[cur]
    if dead then
        if dead.fb[tag or ""] then return nil end                       -- the fallback will be delivered over it
        local res = false
        pcall(function() local d = s.CustomizationPartDefinition; res = (d and d.IsValid and d:IsValid()) and true or false end)
        if res then return nil end                                      -- resolved after all: the asset is there
        return cur, dead
    end
    if pinManifestParts()[cur] then return nil end                      -- an installed mod ships it: never a ghost
    -- ... and never an id THIS LOADER ITSELF WRITES. The toggle parks a vanilla id on one of our own slots for a
    -- pass; if that pass were ever read as a ghost the slot would be blocked for the session and the toggle - the
    -- whole of the 1.8.18 delivery path - would stop halfway. The toggle targets and every vanilla id a slot was
    -- remembered holding are therefore excluded by name.
    if PIN_TOGGLE_PATH[cur] then return nil end
    for _, v in pairs(pinVanilla) do if v == cur then return nil end end
    local resolved = false
    pcall(function()
        local d = s.CustomizationPartDefinition
        resolved = (d and d.IsValid and d:IsValid()) and true or false
    end)
    if resolved then return nil end                                     -- the game resolved it: the asset is there
    if cur:find("^CPD_ZCSDK_") == nil then
        local _, _, trees, loaded = fragState(s)                        -- evidence 2: a tree with null tier classes
        if not (trees > 0 and loaded == 0) then return nil end
    end
    -- resident after all? then it is not a ghost. 1.8.28: a CACHED answer (PS.resident): one StaticFindObject costs a
    -- whole object-array walk in this UE4SS build, so it is asked once per id per world, in a lookup frame of its own.
    -- Unknown yet -> "pending": the slot is neither reported nor driven this pass.
    local res = PS.resident("/Game/ZCSDK/" .. cur .. "." .. cur)
    if res == nil then return nil, nil, true end
    if res then return nil end
    return cur
end

-- 1.8.20: is `ipath` a name a human can act on? An owning CustomizationInstance under PersistentLevel yields a
-- character name; anything else (no owner yet, /Engine/Transient, a bare package) yields nil and DEFERS the report.
local function namedOwner(ipath)
    if type(ipath) ~= "string" or not ipath:find("PersistentLevel.", 1, true) then return nil end
    local n = shortOwner(ipath)
    if type(n) ~= "string" or n == "" or n:find("/", 1, true) or n == "None" then return nil end
    return n
end

-- one-shot, so a deferral is never a SILENT pass but is never spam either
local function ghostHold(sname, partId, tag, why, reason)
    local k = sname .. "|" .. partId .. "|" .. why
    if pinGhostHeld[k] then return end
    pinGhostHeld[k] = true
    log("recruit pin: ghost candidate " .. partId .. " on " .. shortTag(tag) .. ": not reported — " .. reason)
end

-- the one line this whole mechanism exists to print, and the flag that stops the slot being driven.
-- 1.8.20: `ipath` is the OWNING INSTANCE, not the slot; `pass` is the pin pass number. Returns nothing, writes
-- nothing to the game — the only state it touches is this file's own bookkeeping.
local function ghostReport(sname, ipath, tag, partId, pass, dead)
    local seen = pinGhostSeen[sname]
    -- the id CHANGING is also a pass that read otherwise: the count is per (slot, id), stored per slot because a
    -- slot holds exactly one id at a time
    -- 1.8.28: consecutive CHECKS of this slot, not consecutive pass numbers. A character that is not ours is only
    -- read on a sweep pass (PS.SWEEP_PASSES / PS.SWEEP_S), so its passes are not adjacent any more; a check that reads
    -- otherwise still resets the count (walkOne), and a pass that reads the slot twice (two drive frames) counts once.
    if not (seen and seen.id == partId) then seen = { id = partId, n = 0 } end
    if seen.pass ~= (pass or 0) then seen.n = seen.n + 1; seen.pass = pass or 0 end
    pinGhostSeen[sname] = seen
    local sdk = (partId:find("^CPD_ZCSDK_") ~= nil) or (dead ~= nil)   -- 1.8.27: a missing dependency's id is certain too
    if not sdk and seen.n < PIN_GHOST_PASSES then
        ghostHold(sname, partId, tag, "passes", "unresolved on " .. seen.n .. " of the " .. PIN_GHOST_PASSES ..
            " consecutive pass(es) a non-CPD_ZCSDK_ id needs before it is called a ghost (a character that is still " ..
            "spawning reads exactly like this)")
        return
    end
    local owner = namedOwner(ipath)
    if not owner then
        ghostHold(sname, partId, tag, "owner", "its owning character cannot be named yet (the slot is still under " ..
            shortOwner(sname) .. "), and a report that names no character names nothing — deferred to a later pass")
        return
    end
    pinGhostSlot[sname] = true      -- only a REPORTED ghost blocks the slot; a candidate must stay drivable
    local key = owner .. "|" .. tag .. "|" .. partId
    if pinGhostLogged[key] then return end
    pinGhostLogged[key] = true
    if dead then
        log("recruit pin: GHOST " .. owner .. " " .. shortTag(tag) .. ": holds " .. partId .. " from " .. dead.dep ..
            ", which " .. dead.mod .. " requires and is not installed — reinstall it; the loader will not write over it")
        return
    end
    log("recruit pin: GHOST " .. owner .. " " .. shortTag(tag) .. ": holds " .. partId ..
        " from a mod that is not installed — a save written while it was equipped; the loader will not write over it")
end


-- ---- 1.8.22: THE STALE-SLOT REBUILD ----
-- THE EVIDENCE (retail 2026-09-14/15, CHANGELOG v1.28.53 §9(b) and §13; PROVEN in the data, INFERRED for the symptom).
-- Two facts this file already states, put together:
--   (A) `LoadCustomization` rebuilds a slot's FragmentInstances ONLY when the slot's part id CHANGES (the 1.8.19 header
--       records it from retail 2026-09-13 09:04:40 / 09:04:44), and
--   (B) a MISSION re-creates every character FROM SAVE DATA (ZCSDKLoader.log 21:28:27 vs 21:28:30, quoted by
--       `applyOwner` below).
-- HAWKS is what that costs. He is NOT a pinned character (game class `CPD_Char_Class_Hero_Humanoid`), but his
-- `Specializations.Weapon` slot holds a ZCSDK weapon spec — `CPD_WeaponSpec_ZCSDK_SaberAnakin`, picked in the armoury
-- and written into the save under that mod's v1.0.0 — and his armoury Change Weapon is GREYED OUT, so the slot's id
-- can never change again. By (A) his fragments stay the v1.0.0 ones for ever, and by (B) every mission rebuilds him
-- from them: the REMOVED `GA_OverwatchMelee_Base` still draws a "Melee Overwatch" card (and locks the turn, §1), and
-- his sprint still uses his previous BLASTER's anim proxy table while the visible saber comes from the currently
-- equipped part (§13). A byte-grep over the whole deployed game finds the ability in no ZCSDK container at all — the
-- card is the SAVE, not the pak.
-- VEX is the control, and he is fine — BECAUSE the pin toggles his Weapon slot every hub load
-- (`[TOGGLE to CPD_WeaponSpec_Blaster_Longarm]`, `FragmentInstances REPLACED`) and a manual save afterwards carried
-- the rebuilt fragments into the mission (§11: hub delivery -> manual save -> mission, and no card).
-- SO: do for a non-pinned character exactly what the pin already does for a pinned one — ONE toggle-and-back on the
-- Weapon slot, once per session, in the hub only. Nothing here is a new mechanism; it is the 1.8.18 toggle, aimed at a
-- slot this loader does not own but a mod THIS INSTALL SHIPS put a part into.
--
-- THE FENCES, every one of them narrowing, because this writes to a character that is not ours:
--   * HUB ONLY (`HUB_Root`). In a mission the game re-equips during load and a write there is thrown away anyway.
--   * THE WEAPON TAG ONLY. Class and Tactical are out of scope: driving a Class re-creates the child slots (1.8.18's
--     fact B) and no retail evidence says either of them is stale.
--   * ONLY A PART THIS INSTALL SHIPS — see `staleOursPath` below for the two tests and why one of them is not enough.
--     Either way this can never touch a vanilla part (nothing to fix — the game's own fragments are current) and can
--     never touch a GHOST (a ghost is by construction an id no installed mod ships AND is not resident; the
--     `pinGhostSlot` test is belt and braces on top of that).
--   * NOT OURS. A pinned character already gets the 1.8.18 toggle; running both on him would fight the pin mid-flight.
--   * A REAL CHARACTER: never a preview/portrait proxy (`isProxyOwner`), and never a slot whose owning
--     CustomizationInstance cannot be NAMED (1.8.20's rule — an unnamed owner is a slot mid-spawn).
--   * ONCE PER SESSION per (owner, id), at most PIN_MAX_RETRY writes, and a failure is FINAL — no retry, ever.
--   * BOTH IDS ARE MINTED BEFORE THE FIRST WRITE. This is the one that matters: if the toggle went on and the ORIGINAL
--     id could not be minted back, the character would be left wearing a Blaster Longarm. So the toggle is not written
--     until the original part and the toggle part are BOTH resident and both mint an FPrimaryAssetId.
-- AND IT IS ONLY HALF THE FIX: rebuilt fragments live in the hub instance, and a mission reads the SAVE. The REBUILT
-- line therefore tells the operator to make a manual save, exactly as §11's verified Vex sequence did.
local STALE_SLOT_REBUILD = true
local STALE_TAG = "br.Customization.Slot.Character.Specializations.Weapon"
local staleState = {}        -- owner|partId -> { phase = "toggle"|"back"|"done"|"failed", tries =, waits = }
local staleSkipped = {}      -- slot full name -> counted once as "not ours, not ours-shipped"
local staleCand = {}         -- rebuilt every pass: instance path -> the LIVE Weapon slot on a character that is not ours
local staleFlight = {}       -- owner -> the ORIGINAL part id, while the slot is parked on the toggle id. Without this
                             -- the next pass re-reads the slot, sees the (vanilla) TOGGLE id, calls it "not
                             -- ours-shipped" and walks away — leaving the character on a Blaster Longarm for ever.
local staleRebuilt, staleFailed = 0, 0

-- DOES THIS INSTALL SHIP THIS PART, and where does it live? Returns the object path, or nil.
-- TWO TESTS, because ONE IS NOT ENOUGH — and this is the correction that made the mechanism work at all. The first is
-- `pinManifestParts()`, the enumerated set. But a manifest does not have to ENUMERATE a part for the install to ship
-- it: `build/ZCSDK_SaberAnakin.zcsdk.lua` — the very mod whose spec is stuck on Hawks — declares ONE primary type
-- (`{ type = "CustomizationPartDefinition", path = "/Game/ZCSDK" }`), an empty `grants`, no `preload` and no
-- `recruitPins`, so the enumerated set does not contain `CPD_WeaponSpec_ZCSDK_SaberAnakin` and never will.
-- The second test is the one the GHOST RULE already uses in the negative: a live object at the SDK's own content root
-- `/Game/ZCSDK/<id>.<id>`, which is where every mod this SDK builds cooks its parts (it is the manifests' own
-- `primaryTypes[].path`). It is a RESIDENCY test, not a name guess, and nothing else can pass it: a VANILLA part is
-- never under /Game/ZCSDK, and a GHOST is by definition NOT resident there (that is what makes it a ghost). It also
-- hands back the path, which is what the write-back needs to re-mint the original id.
-- 1.8.28: the residency answer is CACHED per world (PS.resident); nil = not asked yet (queued for a lookup frame), and the
-- caller treats that as "not judged this pass" - never as "vanilla".
local function staleOursPath(id)
    local p = pinKnownPaths[id]
    if p then return p end
    if not pinManifestParts()[id] then
        local sdk = "/Game/ZCSDK/" .. id .. "." .. id
        local res = PS.resident(sdk)
        if res == nil then return nil, true end
        if res then return sdk end
        return nil
    end
    return nil
end

-- a live object for `path`, minted into a real FPrimaryAssetId the same way the pin's own drive does. Returns nil and
-- REQUESTS THE LOAD when the part is not resident — never a guess, never a Lua table pretending to be one.
-- 1.8.28: counted (PS.get) but NOT budgeted: a rebuild writes at most twice per character per session, and its
-- both-ids-before-the-first-write rule (and the unwind) must never be split across frames by a budget.
local function staleMint(path, ksl)
    if type(path) ~= "string" or path == "" then return nil end
    local o = PS.get(path, true)
    if not (pinOk(o)) then
        pcall(LoadAsset, path)
        return nil
    end
    if not (pinOk(ksl)) then return nil end
    local ok, id = pcall(function() return ksl:GetPrimaryAssetIdFromObject(o) end)
    if ok and id then return id end
    return nil
end

-- collected during the slot sweep so identity is settled before anything is judged; the LIVE slot is the highest
-- object index, the same 1.8.16 rule the pin's own collection uses (every equip leaves the old slot objects alive).
local function staleConsider(s, sname, ipath, tag)
    if not STALE_SLOT_REBUILD then return end
    if tag ~= STALE_TAG then return end
    if pinGhostSlot[sname] then return end
    if isProxyOwner(sname) or isProxyOwner(tostring(ipath or "")) then return end
    if not namedOwner(ipath) then return end
    local idx = tonumber(sname:match("_(%d+)$") or "0") or 0
    local prev = staleCand[ipath]
    if prev and prev.idx >= idx then return end
    local cur = ""
    pcall(function() cur = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end)
    if type(cur) ~= "string" or cur == "" or cur == "None" then return end
    -- 1.8.28: the slot is THIS frame's (the drive frame collects and acts in one frame); staleCand is rebuilt per frame.
    staleCand[ipath] = { slot = s, sname = sname, tag = tag, id = cur, idx = idx }
end

-- one write, judged by the SAME criterion the pin uses: did the FragmentInstances' OBJECT IDENTITIES move.
local function staleWrite(cand, owner, id, step)
    -- session_audit.py reads `hook armed on <fn>` as an arming and `PATH> <fn>` as a firing, and a firing with no
    -- arming above it is a FINDING. The rebuild can write before `legacyOwner` ever arms the setter (it runs earlier
    -- in the pass), so it arms it itself — pinArm is one-shot, so the pin's own line is unaffected.
    pinArm("SetCustomizationPartPrimaryAssetId", "1.4.0 setter: LoadCustomization rebuilds the fragments on an id CHANGE")
    local before = slotState(cand.slot)
    log("recruit pin: PATH> SetCustomizationPartPrimaryAssetId (" .. shortTag(cand.tag) .. ") on " .. owner ..
        " [stale-slot rebuild: " .. step .. "]")
    local ok, err = pcall(function() cand.slot:SetCustomizationPartPrimaryAssetId(id) end)
    if not ok then return false, "the setter raised on the " .. step .. ": " .. tostring(err) end
    local after = slotState(cand.slot)
    log("recruit pin:   " .. shortTag(cand.tag) .. " BEFORE " .. sigOf(before))
    log("recruit pin:   " .. shortTag(cand.tag) .. " AFTER  " .. sigOf(after))
    if after.frags == before.frags then
        return false, "the " .. step .. " left FragmentInstances at the same object identities — LoadCustomization " ..
            "did not run, so nothing was rebuilt"
    end
    return true
end

-- the two-pass state machine for ONE candidate. Returns true while it is still mid-flight, so `done` can be held.
local function staleOne(cand, ipath, inst, ksl)
    local owner = namedOwner(ipath)
    if not owner then return false end
    local key = owner .. "|" .. cand.id
    local st = staleState[key]
    if st == nil then st = { phase = "toggle", tries = 0, waits = 0 }; staleState[key] = st end
    if st.phase == "done" or st.phase == "failed" then return false end
    local toggle = PIN_TOGGLE_DEFAULT[cand.tag]
    local tpath = PIN_TOGGLE_PATH[toggle or ""]
    -- remembered as a STRING the first time it resolves: mid-flight the slot holds the toggle id, and re-deriving the
    -- original's path from a slot that no longer names it is how a character gets left on a Blaster Longarm.
    st.opath = st.opath or staleOursPath(cand.id)
    local opath = st.opath
    local line = "recruit pin: stale-slot rebuild " .. owner .. " " .. shortTag(cand.tag) .. ": " .. cand.id ..
        " -> " .. tostring(toggle) .. " -> " .. cand.id .. " "
    local function fail(why)
        st.phase = "failed"
        staleFlight[owner] = nil
        staleFailed = staleFailed + 1
        log(line .. "rebuild FAILED (" .. why .. ")")
        return false
    end
    if st.tries >= PIN_MAX_RETRY then
        return fail("spent all " .. PIN_MAX_RETRY .. " attempt(s)" ..
            (st.phase == "back" and " and the slot is still on " .. tostring(toggle) .. " — re-pick the weapon in the armoury" or ""))
    end
    if st.phase == "toggle" then
        -- BOTH ids first. A toggle written without a way back would leave this character wearing the toggle part.
        local oid = staleMint(opath, ksl)
        local tid = staleMint(tpath, ksl)
        if oid == nil or tid == nil then
            st.waits = st.waits + 1
            if st.waits > PIN_RESIDENCY_PASSES then
                return fail("waited " .. PIN_RESIDENCY_PASSES .. " pass(es) and " ..
                    ((oid == nil) and (cand.id .. " (" .. tostring(opath) .. ")") or (tostring(toggle) .. " (" .. tostring(tpath) .. ")")) ..
                    " never became resident — nothing was written")
            end
            if st.waits == 1 then
                log(line .. "holding: both ids must be mintable before the first write is allowed (requested the load)")
            end
            return true
        end
        st.tries = st.tries + 1
        local ok, why = staleWrite(cand, owner, tid, "toggle out")
        if not ok then
            -- UNWIND, and it is not a retry: the verdict is already FAILED and this key never runs again. It is one
            -- write of the id the slot ALREADY HELD, because the one state this must never leave behind is a
            -- character wearing the toggle part.
            local okR = staleWrite(cand, owner, oid, "restore")
            return fail(why .. "; the original id was written back" ..
                (okR and "" or " but that write did not move the fragments either — check the slot in the armoury"))
        end
        st.phase = "back"
        staleFlight[owner] = cand.id
        log(line .. "toggled out (FragmentInstances REPLACED); ours goes back on the next pass")
        return true
    end
    -- phase "back": re-mint the ORIGINAL id from a live object (never held across passes) and put it back.
    local oid = staleMint(opath, ksl)
    if oid == nil then
        st.waits = st.waits + 1
        if st.waits > PIN_RESIDENCY_PASSES then
            return fail("the original part " .. cand.id .. " (" .. tostring(opath) .. ") could not be re-minted, and " ..
                "the slot is still on " .. tostring(toggle) .. " — re-pick the weapon in the armoury")
        end
        return true
    end
    st.tries = st.tries + 1
    local ok, why = staleWrite(cand, owner, oid, "write back")
    if not ok then return fail(why) end
    st.phase = "done"
    staleFlight[owner] = nil
    staleRebuilt = staleRebuilt + 1
    -- the hub instance now carries current fragments; the MISSION reads the save, so the save is the other half.
    if pinOk(inst) then
        local okR, errR = pcall(function() inst:RefreshCustomization() end)
        if not okR then log("recruit pin: RefreshCustomization failed on " .. owner .. ": " .. tostring(errR)) end
    end
    log(line .. "REBUILT (FragmentInstances REPLACED twice) — make a manual save before the next mission")
    return false
end

-- every candidate this pass. Returns true while any rebuild is mid-flight, so `done` does not stop the loop halfway
-- through one (bounded: PIN_MAX_RETRY writes and PIN_RESIDENCY_PASSES waits, then it fails and stops for good).
local function staleDrive(instByPath, ksl, hub)
    if not STALE_SLOT_REBUILD or not hub then return false end
    local busy = false
    for ipath, cand in pairs(staleCand) do
        local c = instByPath[ipath]
        local ours = (c and c.ident) or pinKnown[ipath]
        if not ours then
            -- a slot PARKED ON THE TOGGLE ID reads as a vanilla part; it is this pass's job to FINISH it, not to
            -- re-judge it, so the id in flight is the one the state machine is handed.
            local fowner = namedOwner(ipath)
            local flight = fowner and staleFlight[fowner] or nil
            if flight then
                cand = { slot = cand.slot, sname = cand.sname, tag = cand.tag, id = flight, idx = cand.idx }
            end
            local shipped, pending = nil, false
            if not flight then shipped, pending = staleOursPath(cand.id) end
            if pending then
                -- 1.8.28: its residency is being looked up (a lookup frame of its own): judged on a later pass
            elseif not flight and not shipped then
                staleSkipped[cand.sname] = true          -- vanilla, or a ghost: nothing this install shipped, nothing to rebuild
            else
                -- 1.8.28: the slot is this frame's own (collected by this frame's FindAllOf); the owning instance is
                -- reached from it by GetOuter (PS.instOf), never by a StaticFindObject
                local live = cand.slot
                if pinOk(live) then
                    if staleOne(cand, ipath, PS.instOf(live, ipath), ksl) then busy = true end
                elseif flight then
                    busy = true                          -- mid-flight and gone this frame: hold `done`, finish next pass
                end
            end
        end
    end
    return busy
end

local function staleSummary()
    local k = 0
    for _ in pairs(staleSkipped) do k = k + 1 end
    log(string.format("recruit pin: stale-slot rebuild: %d slot(s) REBUILT, %d FAILED, %d skipped " ..
        "(not ours, not ours-shipped)", staleRebuilt, staleFailed, k))
end


-- THE ONE VERIFIED WAY TO READ A TSoftObjectPtr IN UE4SS 3.0.1, KEPT BECAUSE NOTHING ELSE RECORDS IT.
-- (1.8.19 deleted the resolver probe that used it - its question was answered at retail 09:04:18: the AssetManager
-- resolves every one of our parts once they are RESIDENT - but the accessor chain cost a crashed game to find and
-- must not be lost with it.) UE4SS 3.0.1's TSoftObjectPtr userdata metatable registers EXACTLY
--     GetWeakPtr | GetTagAtLastTest | GetObjectID | type | __gc
-- (read out of UE4SS.dll's push_softobjectproperty, RVA 0x2cafe0, metatable block 0x2cb2b0-0x2cb478). There is NO
-- ToString and NO GetAssetPathString - 1.8.16 guessed both and printed an address for a whole session. GetObjectID
-- yields an FSoftObjectPath, whose shape the 196985 jmap gives:
--     FSoftObjectPath { AssetPath : FTopLevelAssetPath { PackageName : FName, AssetName : FName }, SubPathString }
-- so the VERIFIED chain is
--     sp:GetObjectID().AssetPath.PackageName:ToString()   ..  "."  ..  sp:GetObjectID().AssetPath.AssetName:ToString()
-- every step pcall'd, and a SUCCESSFUL read of an EMPTY name ("the manager holds no path") must be distinguished
-- from a FAILED read (which concludes nothing) - conflating those two is what made 1.8.16's output worthless.
-- An FPrimaryAssetId is read from its own members instead (FPrimaryAssetId { PrimaryAssetType { Name : FName },
-- PrimaryAssetName : FName }) - what slotState() below does - NOT through Conv_PrimaryAssetIdToString, which hands
-- back an FString USERDATA.

-- ---- 1.8.13: PER-PART RESIDENCY, BECAUSE THE THREE PINNED PARTS BEHAVED DIFFERENTLY ON ONE CALL ----
-- Retail 2026-09-13 05:30:21. Three `EquipCustomizationDefinition` calls, one per pinned part, each with that part's own
-- AllowedSlots container, each `returned true`:
--     Class   -> AFTER partDefinition=CPD_ZCSDK_Char_Class_Sith | 6 fragment instance(s) -> DELIVERED - FragmentInstances REPLACED
--     Weapon  -> not delivered, partDefinition still <null>, 7 fragment instance(s) unchanged
--     Tactical-> not delivered, partDefinition still <null>, 5 fragment instance(s) unchanged
-- THE CONTAINER REACHED THE NATIVE - the Class slot proves it, and with it that the marshalling question is closed. What
-- separates the three is the RESOLVER: `UCustomizationStatics::GetCustomizationPartDefinitionFromPartId` (RVA 0x8c46060)
-- asks the AssetManager for the LOADED object for that FPrimaryAssetId first, and falls back to its path map. An id the
-- manager has never SCANNED resolves through neither. All three parts live in /Game/ZCSDK and the loader rescans
-- `CustomizationPartDefinition` over exactly that path at startup, so a scan-path gap is INFERRED, not proven - which is
-- why this escalates one observable step at a time and PRINTS each one instead of guessing.
--
-- Cooked-asset evidence for why the three are not interchangeable (tagged-property decode of the deployed pak):
-- CPD_ZCSDK_Char_Class_Sith carries NO `AllowedSlots` tagged property at all (it equals the class default: an EMPTY
-- FGameplayTagContainer), while CPD_WeaponSpec_ZCSDK_SithSaber (size 12) and CPD_ZCSDK_TacticalSpec_Sith (size 20) both
-- carry a non-empty one. So the one call that DELIVERED is the one that passed an EMPTY container, and the two that
-- passed a populated container delivered nothing - consistent with the resolver failing for those two ids, and also
-- with an empty container meaning "every slot this definition names". Both readings are tested by the ladder below.
local partDiag = {}          -- part path -> the diagnostic line has been logged once this session
local partStep = {}          -- part path -> how far the residency ladder has been climbed
local partWhen = {}          -- part path -> the pass number the last step was taken on (1.8.15: a per-part timer)
local partHeld = {}          -- 1.8.16: the held-verdict line has been logged once
local partDriven = {}        -- 1.8.16: part path -> the pass its slot was last actually DRIVEN
local partWatch = {}         -- part path -> { want=, ptype= } for every pinned part seen, so the ladder ticks on its own
-- ---- 1.8.20: THE LADDER RE-RAN ON A PART THAT HAD ALREADY RESOLVED ----
-- Retail 2026-09-13, 23:00:38 -> 23:00:58, after all three slots read `finished`, the log alternated every pass:
--     23:00:53  part CPD_WeaponSpec_ZCSDK_SithSaber did not resolve — step 1: LoadAsset(...)      <- pass 57 tick
--     23:00:53  part CPD_WeaponSpec_ZCSDK_SithSaber resolved after step 1 of the residency ladder <- pass 57 drive
--     23:00:58  part CPD_WeaponSpec_ZCSDK_SithSaber did not resolve — step 1: LoadAsset(...)      <- pass 58 tick
-- THE CAUSE, exactly: the drive path clears `partStep[path]` when a part resolves but leaves `partWatch[path]` set,
-- and the per-pass tick loop treats `(partStep[path] or 0) == 0` as "not started" and climbs to step 1 again. It is
-- NOT a stale read and it is NOT a re-load of something absent: the tick's own precondition is that
-- StaticFindObject(path) returns a VALID object, so the part is demonstrably resident and the line contradicts the
-- test that produced it. The LoadAsset it issues is a real (and idempotent) request for an asset already loaded.
-- THE FIX is one flag: a part that has resolved once is SETTLED — off the watch list, and refused by
-- escalateResidency if anything puts it back. Nothing on the delivery path is touched (the 1.8.18 toggle route still
-- drives Class -> Weapon -> Tactical and still delivers), and `resolved after step N` now prints once instead of
-- once per pass, because the second print was the same re-climb wearing a success verb.
local partSettled = {}       -- part path -> this part resolved on a driven slot; the ladder is finished with it
local PART_STEP_PASSES = 3   -- ~15 s at the 5 s cadence: a step is given time to take before the next one is judged
local PART_CLASS = { CustomizationPartDefinition = "/Script/BitReactorCore.CustomizationPartDefinition",
                     CustomizationDefinition     = "/Script/BitReactorCore.CustomizationDefinition",
                     CharacterClass              = "/Script/BitReactorGame.CharacterClass" }

-- what the loader can actually see about one part, printed once so the next reader does not have to infer it
-- 1.8.28: handed the object the drive just found (the same frame), never a second StaticFindObject of its own
local function partReport(path, o)
    if partDiag[path] then return end
    partDiag[path] = true
    local found = (o ~= nil)
    local valid = false
    pcall(function() valid = (o and o.IsValid and o:IsValid()) and true or false end)
    local full = "<none>"
    if valid then pcall(function() local n = o:GetFullName(); if type(n) == "string" then full = n end end) end
    log(string.format("recruit pin: part %s: object=%s | valid=%s | %s",
        (path:match("([^/.]+)$") or path), found and "found" or "MISSING", valid and "y" or "n", full))
end

-- One step per pass, each one observable, for a part whose slot will not resolve. Nothing here is speculative: LoadAsset is
-- what the pin has always used, `loadpkg` is the bridge's synchronous LoadPackage, and `rescan` is the same
-- ScanPathsForPrimaryAssets the loader already runs at startup - re-aimed at this one package's own directory.
-- 1.8.15: a step is only taken when the PREVIOUS one has had time to land. In the 05:43 session steps 3 and 4 fired in
-- the same second (05:48:53), so the rescan was condemned before it could possibly have taken effect — the ladder was
-- measuring itself, not the game. `pass` is the pin pass number; PART_STEP_PASSES of them is roughly 15 s.
local function escalateResidency(path, want, ptype, pass)
    -- 1.8.20: a part that has already resolved on a driven slot never climbs again. Without this the ladder restarts
    -- at step 1 every pass for the rest of the session and prints `did not resolve` about a part it just proved
    -- resident (retail 23:00:38-23:00:58).
    if partSettled[path] then return end
    partWatch[path] = { want = want, ptype = ptype }
    local n = (partStep[path] or 0)
    if n > 0 and pass and (pass - (partWhen[path] or 0)) < PART_STEP_PASSES then return end
    n = n + 1
    partStep[path] = n
    partWhen[path] = pass or 0
    if n == 1 then
        log("recruit pin: part " .. want .. " did not resolve — step 1: LoadAsset(" .. path .. ")")
        pcall(LoadAsset, path)
    elseif n == 2 then
        local pkg = path:match("^(.-)%.[^%.]+$") or path
        log("recruit pin: part " .. want .. " did not resolve — step 2: bridge loadpkg " .. pkg)
        pcall(bridge, "ZCSDK:loadpkg|" .. pkg)
    elseif n == 3 then
        -- the coordinator's hypothesis, tested rather than argued: the part PICKER reads UCustomizationPartsTagSubsystem's
        -- maps, and BuildPartTagMaps ran at 05:44:51 — two minutes BEFORE any of our parts were resident. The resolver
        -- itself does not consult it (the whole of 0x8c46060..0x8c46209 touches only the AssetManager), so this should
        -- change nothing; if it DOES flip a part, that reading was right and this comment is wrong.
        log("recruit pin: part " .. want .. " did not resolve — step 3: bridge BuildPartTagMaps (the part tag cache was " ..
            "built before our parts were resident)")
        local sub = StaticFindObject("/Script/BitReactorCore.Default__CustomizationPartsTagSubsystem")
        local addr = nil
        pcall(function() local live = FindAllOf("CustomizationPartsTagSubsystem")
            if type(live) == "table" then for _, o in ipairs(live) do
                if o and o.IsValid and o:IsValid() then local a; pcall(function() a = o:GetAddress() end); if a then addr = a end end
            end end end)
        if addr then
            pcall(bridge, "ZCSDK:callthis|?BuildPartTagMaps@UCustomizationPartsTagSubsystem@@AEAAXXZ|" .. string.format("%x", addr))
        else
            log("recruit pin:   (no live CustomizationPartsTagSubsystem found — step skipped)")
        end
    elseif n == 4 then
        local pkg = path:match("^(.-)%.[^%.]+$") or path
        local dir = pkg:match("^(.*)/[^/]+$") or pkg
        local cls = PART_CLASS[ptype or ""] or PART_CLASS.CustomizationPartDefinition
        log("recruit pin: part " .. want .. " did not resolve — step 4: bridge rescan " ..
            tostring(ptype or "CustomizationPartDefinition") .. " over " .. dir ..
            " (the AssetManager has no NameData for this id, so GetPrimaryAssetObject cannot answer)")
        pcall(bridge, "ZCSDK:rescan|" .. tostring(ptype or "CustomizationPartDefinition") .. "|" .. dir .. "|" .. cls .. "|0")
    elseif n == 5 then
        -- 1.8.16: NO VERDICT WITHOUT A DRIVE. The 08:38 session printed `STILL does not resolve` for all three parts,
        -- two of which had already resolved and delivered minutes earlier, because the verdict was measured on a
        -- character the pin had stopped driving. A verdict now requires that this part's slot was actually driven
        -- recently; otherwise the ladder holds at step 4 and says so once.
        if not (partDriven[path] and pass and (pass - partDriven[path]) <= PART_STEP_PASSES * 2) then
            partStep[path] = 4
            if not partHeld[path] then
                partHeld[path] = true
                log("recruit pin: part " .. want .. " — holding the verdict: its slot has not been driven recently, so " ..
                    "'does not resolve' would be a statement about the pin, not the part (the 08:38 lesson)")
            end
            return
        end
        log("recruit pin: part " .. want .. " STILL does not resolve after LoadAsset, loadpkg, BuildPartTagMaps and a rescan " ..
            "of its own directory — the AssetManager will not carry this primary asset id, and no equip path can deliver its " ..
            "fragments until it does (this is now an asset-registration question, not a loader one)")
    end
end

-- 1.8.14: RE-FOUND EVERY PASS, NEVER CACHED. A UObject wrapper held across passes is a userdata whose object the
-- engine may have collected, and dereferencing one is a native access violation pcall cannot catch - which is what the
-- 05:50:58 crash was (43 frames, reading 0xffffffffffffffff, inside the Lua VM with no GetClass frame). Nothing in this
-- file survives a pass except strings and numbers.


-- THE ROUTE — the plain 1.4.0 setter, and since 1.8.19 the ONLY one in this file. Retail 2026-09-13 09:02 is the proof:
--   09:04:18  GetObjectFromPrimaryAssetId returned OUR OBJECT for all three parts once resident. The AssetManager was
--             never the problem. (That probe's path half was broken; that reading is discarded, and the probe is gone.)
--   09:04:40  PATH> SetCustomizationPartPrimaryAssetId (Specializations.Tactical.Primary)
--             BEFORE partId=CPD_TacticalSpec_Assault | partDefinition=CPD_TacticalSpec_Assault | 5 frag | 3 leveled tree(s)
--             AFTER  partId=CPD_ZCSDK_TacticalSpec_Sith | partDefinition=CPD_ZCSDK_TacticalSpec_Sith | 5 frag | 2 leveled tree(s)
--             DELIVERED — FragmentInstances REPLACED          <-- OUR TWO TREES, through the plain 1.4.0 setter
--   09:04:40  PATH> SetCustomizationPartPrimaryAssetId (Class) [re-drive: the id is already ours and its definition is null]
--   09:04:44+ every Tactical AFTER reads partDefinition=<null> | 0 leveled tree(s), and the FocusProbe finds the delivered
--             trees on STALE slot objects beside a live one at 0.
-- TWO FACTS, BOTH PROVEN BY THAT SEQUENCE:
--   (A) The setter's LoadCustomization rebuilds fragments only when the slot's id CHANGES. A slot that already holds our
--       id is a no-op for ever — which is why the Sith has been empty since the first session that wrote our id onto him,
--       and why every "re-drive" since 1.8.14 was wasted work.
--   (B) Driving the CLASS part re-creates the character's child slots, discarding whatever was just delivered into them
--       (the same mechanism that lost the identity at 07:52:26). So Class must be driven FIRST and then left alone —
--       1.8.15's "Class last" was exactly the wrong direction.
-- HENCE 1.8.18: order Class -> Weapon -> Tactical; deliver onto an "already ours, no fragments" slot by TOGGLING it to a
-- different id first and setting ours on the NEXT pass (LoadCustomization needs the change, and needs the tick); never
-- drive a slot again once it has delivered; stop when all of them have.
local function legacyOwner(owner, p)
    pinArm("SetCustomizationPartPrimaryAssetId", "1.4.0 setter: LoadCustomization rebuilds the fragments on an id CHANGE")
    -- (1) ORDER. Class first (it rebuilds the child slots), then Weapon, then Tactical and the rest, then the TALENT
    -- (1.8.27, G2): last, so the native voice writer (OnSpawnCharacterAsyncComplete sets the talent from the voice map)
    -- has already run and the Class's re-creation of the child slots, driven first and to completion, cannot erase it.
    -- The catch-all "" pass therefore skips the Talent.
    local ordered = {}
    local TALENT = "%.Specializations%.Talent$"
    for _, want in ipairs({ "%.Class$", "%.Specializations%.Weapon$", "", TALENT }) do
        for _, e in ipairs(p.list) do
            if not e.__ordered and ((want == "" and not e.tag:find(TALENT)) or (want ~= "" and e.tag:find(want))) then
                e.__ordered = true; ordered[#ordered + 1] = e
            end
        end
    end
    for _, e in ipairs(p.list) do e.__ordered = nil end

    -- 1.8.18b: "Class FIRST" means first TO COMPLETION, not merely first in the loop. Driving the Class part
    -- re-creates the character's child slots, so any spec delivered before the Class has finished is thrown away on
    -- the Class's next write — and the Class needs TWO passes when it has to be toggled. So while an undelivered
    -- Class slot is in this character's list, it is the only slot driven.
    local classPending = nil
    for _, e in ipairs(ordered) do
        if e.tag:find("%.Class$") and not pinDelivered[e.key] then classPending = e end
    end
    if classPending then
        if not pinQuiet[classPending.key .. "|first"] then
            pinQuiet[classPending.key .. "|first"] = true
            log("recruit pin: " .. shortOwner(owner) .. ": the Class slot is not delivered yet, so it is the ONLY " ..
                "slot driven — driving the Class re-creates this character's child slots and would discard anything " ..
                "already delivered into them (retail 09:04:40 -> 09:04:44)")
        end
        ordered = { classPending }
    end
    for _, e in ipairs(ordered) do
        if pinDelivered[e.key] then
            -- (3) a delivered slot is never driven again, and the Class especially never: driving it rebuilds the
            -- children and throws away the specs that were just delivered into them.
            if not pinQuiet[e.key] then
                pinQuiet[e.key] = true
                log("recruit pin: " .. shortTag(e.tag) .. " on " .. shortOwner(owner) .. " is DELIVERED — never driven again")
            end
        else
            -- remember this slot's vanilla part the first time we see one, so the toggle has something real to use
            if e.cur ~= e.want and e.cur ~= "?" and e.cur ~= "None" then pinVanilla[e.key] = e.cur end
            local write, why, busy, merr = nil, nil, false, nil
            -- 1.8.28: the id is minted HERE, at the write, from an object THIS frame found (PS.mint: the frame's own
            -- lookup, within its budget). A spent budget is not a verdict: the write waits for the next drive frame.
            local ours = (e.cur ~= e.want) or (pinToggled[e.key] ~= nil)
            if ours then
                write, busy, merr = PS.mint(e.path)
                if pinToggled[e.key] and e.cur == e.want then
                    why = "toggle complete: the id differs again, so LoadCustomization will rebuild"
                    if write ~= nil then pinToggled[e.key] = nil end
                end
                if write == nil and not busy then
                    if merr then
                        log("recruit pin FAILED: " .. e.tag .. " on " .. owner .. ": GetPrimaryAssetIdFromObject: " .. merr)
                    else
                        -- resident when this pass judged it, gone at the write: ask again, and let the next pass decide
                        pcall(LoadAsset, e.path)
                        CP.once("gone|" .. e.path, "recruit pin: part " .. e.want .. " was resident when the pass " ..
                            "judged it and is not at the write — requested the load; the next pass decides")
                    end
                end
            else
                -- (2) THE TOGGLE. The id is already ours and nothing was delivered, so the setter would do nothing at
                -- all. Put a DIFFERENT id on the slot this pass; ours goes back on the NEXT one, and the change is what
                -- makes LoadCustomization run.
                local other = pinVanilla[e.key] or PIN_TOGGLE_DEFAULT[e.tag]
                if other == nil or other == e.want then
                    if not pinQuiet[e.key] then
                        pinQuiet[e.key] = true
                        log("recruit pin: " .. shortTag(e.tag) .. " on " .. shortOwner(owner) .. " holds " .. e.want ..
                            " with no fragments and there is no other id to toggle through — leaving it alone")
                    end
                else
                    local oid, b2 = PS.mint(PIN_TOGGLE_PATH[other] or "")
                    busy = b2
                    if oid == nil and not busy then
                        if not pinQuiet[e.key .. "|toggleload"] then
                            pinQuiet[e.key .. "|toggleload"] = true
                            log("recruit pin: " .. shortTag(e.tag) .. " toggle needs " .. tostring(other) ..
                                " resident (" .. tostring(PIN_TOGGLE_PATH[other]) .. ") — requested the load")
                        end
                        pcall(LoadAsset, PIN_TOGGLE_PATH[other] or "")
                    elseif oid ~= nil then
                        write, why = oid, "TOGGLE to " .. other .. " (the setter only rebuilds fragments on an id CHANGE; " ..
                            "ours goes back on the next pass)"
                        pinToggled[e.key] = pinPass
                    end
                end
            end
            if busy then
                -- the ORDER holds under the budget: nothing after this slot is written this frame either
                if PS.P then PS.P.again, PS.P.deferred = true, PS.P.deferred + 1 end
                break
            end
            if write ~= nil then
                -- 1.8.10: a retry is only spent when a route actually RAN on this slot (1.8.28: counted at the write
                -- itself, so a write the lookup budget deferred to the next frame costs nothing)
                if e.cur == e.want then pinAttempts[e.key] = (pinAttempts[e.key] or 0) + 1 end
                log("recruit pin: PATH> SetCustomizationPartPrimaryAssetId (" .. shortTag(e.tag) .. ") on " ..
                    shortOwner(owner) .. (why and (" [" .. why .. "]") or ""))
                local ok, err = pcall(function() e.slot:SetCustomizationPartPrimaryAssetId(write) end)
                if not ok then
                    log("recruit pin FAILED: " .. e.tag .. " on " .. owner .. ": " .. tostring(err))
                else
                    local after = slotState(e.slot)
                    log("recruit pin:   " .. shortTag(e.tag) .. " BEFORE " .. sigOf(e.before))
                    log("recruit pin:   " .. shortTag(e.tag) .. " AFTER  " .. sigOf(after))
                    local okD, whyD = deliveredTo(e.before, after)
                    log("recruit pin:   " .. shortTag(e.tag) .. " " .. (okD and "DELIVERED" or "not delivered") .. " — " .. whyD)
                    -- a slot counts as SETTLED only when it ends up holding OUR part with a resolved definition and a
                    -- fragment set that moved. Anything else stays open for the next pass.
                    local nowOurs = ((after.id:match("([^:]+)$") or "") == e.want)
                    if okD and nowOurs and after.defn ~= "<null>" then
                        pinDelivered[e.key] = true
                        pinToggled[e.key] = nil
                        log("recruit pin: " .. shortTag(e.tag) .. " " .. e.cur .. " -> " .. e.want .. " on " ..
                            shortOwner(owner) .. " (SetCustomizationPartPrimaryAssetId; DELIVERED, " ..
                            after.trees .. " leveled tree(s)) — this slot is finished")
                        -- 1.8.28 (fix 4): a delivered Class re-created this character's child slots; the SAME pass
                        -- re-finds and drives them a few frames from now (PS.drive), not 2.5 s+ later
                        if e.tag:find("%.Class$") and PS.P then PS.P.classDone[owner] = true end
                    end
                end
            end
        end
    end
end

-- one character, one decision — and since 1.8.19 there is only one route to decide on: the 1.4.0 setter.
local function applyOwner(owner, p)
    logCriterion()
    local hub, wname = strategySide()
    local gated = PIN_STRATEGY_ONLY and not hub
    if gated and not scopeLogged then
        scopeLogged = true
        log("recruit pin: world=" .. wname .. " is not the hub — in a mission the characters are rebuilt from save " ..
            "data and the game re-equips them during load (ZCSDKLoader.log 21:28:27 vs 21:28:30), so a pin here " ..
            "writes the id and nothing is expected to stick")
    end
    -- 1.8.10: a retry is only spent when a route actually RAN on this slot. 1.8.9 incremented in the collection loop, so two
    -- passes that returned "needs the definition resident" burned half the budget without calling anything (22:14:29-38).
    -- 1.8.28: counted at the write itself (legacyOwner), so an entry the Class-first rule or the lookup budget held back
    -- this frame spends nothing.
    legacyOwner(owner, p)
end

-- returns "pinned" (a slot was changed) / "targets" (pin-able characters are here, nothing to change) / "idle" (nothing to do),
-- which is what the loop below paces itself by.
--
-- 1.8.12 — THE UNIT OF IDENTITY IS THE CHARACTER, AND A CHARACTER IS ITS `UCustomizationInstance`.
-- 1.8.10/1.8.11 made it the slot's immediate parent object, and retail 2026-09-13 05:03 proved that unsatisfiable by
-- construction: `pass 39: 73 instance(s) seen, 73 candidate(s), 73 group(s), 0 pinned, 14 skipped, world=HUB_Root`, with every
-- character skipped three times — `no identity: it holds 1 pinned tag(s) | 2 pinned tag(s) | 2 pinned tag(s) … Info.Name reads
-- <not present>`. One character's slots are NOT siblings: `Class` hangs directly off the CustomizationInstance, the two
-- `Specializations.*` slots hang off a container slot (`…CustomizationFragmentInstanceSlot_11.CustomizationFragmentInstanceSlot_2`),
-- and `Info.Name` hangs off a third parent. No parent object can ever hold both a pinned tag and the identity, so the per-group
-- identity rule could only ever fail — silently in 1.8.10, loudly in 1.8.11, but always.
-- 1.8.7 — which pinned this recruit correctly — identified at INSTANCE level, and that is what is restored here:
--   * a character is OURS if its instance's own `GetDefaultCustomizationDefinition()` is the pin's, OR if ANY slot under that
--     instance whose `SlotNameTag` is the pin's `match` slot holds the pin's `match` part (the mod's own Info.Name part).
--     In this save Vex was built from the pool row, so his instance's default definition is generic — only the Name part finds him.
--   * the pinned tags' slots are then taken from ANYWHERE under that same instance, at any depth, across parent slots.
-- WHAT STOPS THE 22:15:47 MASS-PIN IS NOT THE GROUPING — IT IS THE CAP. That incident collected 21 slots belonging to seven
-- characters under ONE proxy instance, because a customization proxy accumulates the slot trees of everything it has previewed.
-- A real character has exactly ONE slot per pinned tag, so more matching slots than the pin declares means the instance holds
-- more than one character and NOTHING is written. That test is exact, cheap, and cannot be defeated by a tree shape.
local pinPass = 0
local pinCensus = ""
-- 1.8.26: `max` = passes the slot walk may be deferred while the instance census climbs (0 = off)
local pinSettle = { max = 6, last = 0, waits = 0 }
-- 1.8.28: the owning UCustomizationInstance OBJECT of a slot, for the one call that needs the object (RefreshCustomization):
-- walk GetOuter() (validity-checked at every step, and only ever asking IsValid / GetFullName — never GetClass, which faults
-- on a stale pointer) until the outer's full name IS `ipath`. Which instance owns a slot is decided by NAME (PS.ownerOf);
-- this walk only fetches the object, in the frame that uses it.
function PS.instOf(s, ipath)
    local cur, n = s, 0
    while n < 12 do
        local nxt = nil
        pcall(function() nxt = cur:GetOuter() end)
        if not (pinOk(nxt)) then break end
        local p = nil
        pcall(function() p = nxt:GetFullName() end)
        if type(p) ~= "string" then break end
        if (p:gsub("^[^ ]+ ", "")) == ipath then return nxt end
        cur = nxt; n = n + 1
    end
    return nil
end

-- ---- 1.8.28: THE FRAME-BOUNDED PASS (the 2.9 s frame) ----
-- THE EVIDENCE. Retail 2026-09-30 (ZCJediClass + ZCSithClass on 1.8.27, the hub): `pass 591 timing: 523 slice(s), 35647.0
-- ms total, max slice 2917.0 ms (act)`, `pass 592 … 2212.0 ms (act)`, `pass 599 … 1384.0 ms (act)`, and EVERY hub pass with
-- nothing of ours on it `~250 slice(s), 12-21 s total, max slice ~430 ms (act)` for 35 minutes. The Den (the saber
-- session): pass 610 `459 slice(s), 31728.0 ms total`, walk slices of ~69 ms against a 4 ms budget.
-- THE CAUSE: StaticFindObject IS NOT A HASH LOOKUP IN THIS UE4SS BUILD. It costs what a FindAllOf costs - a walk of the
-- whole object array: 28 ms in the main menu (`pump: task saber took 28 ms` - that task is ONE StaticFindObject of a class
-- that is not loaded, and nothing else), 50-90 ms in the hub (`pump: task rowfix took 80-90 ms` - one StaticFindObject
-- plus the cheap world read), ~69 ms per walk slice in the Den. 1.8.27's slicing rested on the opposite assumption: it
-- RE-FOUND EVERY SLOT BY PATH (one StaticFindObject per slot), so its 4 ms budget could never bind - every slice held
-- exactly one slot at 50-70 ms (254 slices = ~254 slots = 13 s per hub pass). And the act phase, which runs in ONE frame,
-- did ~9 of them with nothing of ours in the world (the KismetSystemLibrary CDO, plus one `/Game/ZCSDK/<id>` residency
-- probe per stale-slot candidate: `8 skipped` -> ~450 ms, the `max slice ~430 ms (act)` of every idle hub pass) and ~40
-- with three recruits to drive (per pinned slot: its re-find, its part, partReport's own lookup; per character its
-- instance; the ladder's watch list): 40 x ~70 ms = the 2.9 s frame. It matches pass for pass - 591: 11 slots, 2917 ms;
-- 592: 8, 2212 ms; 599: 11 delivered, 1384 ms. (The per-slot GetOuter walk itself is microseconds; it was the lookup.)
-- THE FIX, four rules:
--   (1) NO RE-FIND. A frame that needs slots makes its own FindAllOf and uses those objects in THAT frame only - the X1 rule
--       (no UObject crosses a frame) now holds by construction. The drive frame collects AND acts; there is no per-slot
--       StaticFindObject and no sliced walk left. (The instance comes from its slot by GetOuter: PS.instOf.)
--   (2) A LOOKUP BUDGET. At most PS.LOOKUPS object lookups (FindAllOf / StaticFindObject) per frame: the slot FindAllOf and
--       ONE part. A write whose part would be one more waits for the next drive frame (`again`), and the frame's cache
--       (P.fcache) serves every character that needs the same part. The KismetSystemLibrary CDO is looked up once a session.
--   (3) RESIDENCY IS A CACHED FACT. The ghost refusal's and the stale-slot rebuild's `/Game/ZCSDK/<id>` checks are asked ONCE
--       per id per world, one per frame, in lookup frames of their own (PS.look); until answered the slot is not judged this
--       pass, and a candidate on a slot of OURS is not driven either.
--   (4) OWNERS BY NAME. A slot's owner is found from its full name (a full name IS its outer chain: PS.ownerOf), with no UE
--       call per slot.
-- AND THE SCOPE (fix 2). When every pin has a `definition`, a pass after a world's first PS.SWEEP_PASSES collects only the
-- instances that are OURS (the default definition matched in `insts`, or identified before - pinKnown). The world-wide
-- sweep - the ghost refusal and the stale-slot rebuild on every character, and roster characters found by their Name part -
-- runs on those first passes and then once per PS.SWEEP_S. A world with nothing ours goes DORMANT once its sweeps are done
-- (`recruit pin: dormant — nothing ours …`); a Recruitment event, a recruit or a return to the hub re-arms it.
-- THE PASS: insts (FindAllOf CustomizationInstance) -> drive (FindAllOf the slots; collect; act) [-> look (one
-- StaticFindObject per frame) -> drive] [-> idle frames after a Class -> drive (its children)] -> the verdict.
-- WHAT DID NOT CHANGE: identity, the mass-pin cap, the ghost refusal's evidence rules, the stale-slot rebuild's fences, the
-- ORDER (Class to completion first, the Talent last), the toggle, the retry and residency bounds, `done`.

-- one COUNTED object lookup. Answers from this frame's cache first; `force` = not budgeted (the stale-slot rebuild, see
-- staleMint). Returns obj|nil, busy. Also records the residency as a BOOLEAN (PS.partRes) for later frames.
function PS.get(path, force)
    local P = PS.P
    local fc = P and P.fcache
    if fc and fc[path] ~= nil then return fc[path] or nil, false end
    if P and not force and P.lookups >= PS.LOOKUPS then return nil, true end
    if P then P.lookups, P.nLook = P.lookups + 1, P.nLook + 1 end
    PS.sfo = PS.sfo + 1
    local o = nil
    pcall(function() o = StaticFindObject(path) end)
    local ok = pinOk(o)
    if fc then fc[path] = ok and o or false end
    PS.partRes[path] = ok
    return ok and o or nil, false
end

-- the KismetSystemLibrary CDO. A class default object is never collected, so it is looked up ONCE a session (as UEHelpers
-- does) and re-validated on every use.
function PS.ksl()
    local k = PS.cdos.ksl
    if k ~= nil and pinOk(k) then return k end
    k = nil
    PS.sfo = PS.sfo + 1
    if PS.P then PS.P.nLook, PS.P.lookups = PS.P.nLook + 1, PS.P.lookups + 1 end   -- (once a session, budgeted too)
    pcall(function() k = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary") end)
    if pinOk(k) then PS.cdos.ksl = k; return k end
    return nil
end

-- a real FPrimaryAssetId for `path`, minted from an object THIS frame found. -> id | nil, busy, err
function PS.mint(path)
    if type(path) ~= "string" or path == "" then return nil, false end
    local o, busy = PS.get(path)
    if busy then return nil, true end
    if not pinOk(o) then return nil, false end
    local ksl = PS.ksl()
    if not pinOk(ksl) then return nil, false, "no KismetSystemLibrary CDO" end
    local ok, id = pcall(function() return ksl:GetPrimaryAssetIdFromObject(o) end)
    if ok and id then return id, false end
    return nil, false, tostring(id)
end

-- is `path` resident? A per-world cache of booleans; nil = not asked yet, and then it is QUEUED for a lookup frame.
function PS.resident(path)
    local v = PS.res[path]
    if v ~= nil then return v end
    local P = PS.P
    if P and not P.lookSet[path] then P.lookSet[path] = true; P.lookq[#P.lookq + 1] = path end
    return nil
end

-- which instance of this pass owns the slot `sname`? Its full name is its outer chain, so strip one `.`/`:` segment at a
-- time and look the prefix up (the 1.8.26 GetOuter walk, without a UE call per level).
function PS.ownerOf(P, sname)
    local p = sname
    for _ = 1, 14 do
        p = p:match("^(.*)[%.:][^%.:]*$")
        if not p then return nil end
        if P.inst[p] then return p end
    end
    return nil
end

function PS.census(P, extra)
    local line = string.format("pass %d: %d instance(s) seen, %d ours, %d with pinned slot(s), %d pinned, %d skipped, world=%s%s",
        P.pass, P.nInst, P.nOurs, P.nWith, P.nPinned, P.nSkip, P.wname, extra or "")
    local shape = line:gsub("^pass %d+: ", "")
    if shape ~= pinCensus or P.pass % 20 == 1 then
        pinCensus = shape
        P.printed = true
        log("recruit pin: " .. line)
    end
end

-- 1.8.15: dedup by (owner, REASON), not owner. In the 07:47 session the Sith stopped being identified at 07:52:26
-- and was skipped for a NEW reason for the rest of the session — invisibly, because the old dedup had already used up
-- his one line. A changed reason is the most informative line the pin can print; it must never be swallowed.
function PS.skip(P, owner, why)
    if P.skipped[owner] then return end
    P.skipped[owner] = true
    P.nSkip = P.nSkip + 1
    local k = owner .. "|" .. why
    if pinSkipLogged[k] then return end
    pinSkipLogged[k] = true
    log("recruit pin: skip " .. shortOwner(owner) .. ": " .. why)
end

-- 1.8.18 / 1.8.27 G2: the drive ORDER, as a rank (legacyOwner orders by it too): Class, Weapon, the rest, Talent
function PS.orderOf(tag)
    if tag:find("%.Class$") then return 1 end
    if tag:find("%.Specializations%.Weapon$") then return 2 end
    if tag:find("%.Specializations%.Talent$") then return 4 end
    return 3
end

-- 1.8.28 (fix 6): the two appearance slots whose part ids are echoed, read-only, once per character of ours
PS.FACE = "br.Customization.Slot.Character.Appearance.Humanoid.Head.Face.Mesh"
PS.HAIR = "br.Customization.Slot.Character.Hair.Hair.Mesh"

-- the slot tags a pass reads at all: every pinned tag, every `match` tag, the tags of slots a missing dependency
-- dropped (the ghost sweep still looks at them), the stale-slot rebuild's Weapon tag and - when a pin matches weapon
-- CLASSES by tag - the GearKit sub-slot; 1.8.28: and the two appearance slots of the echo. A slot with any other tag is
-- never named.
function PS.tags()
    local t = { [STALE_TAG] = true, [PS.FACE] = true, [PS.HAIR] = true }
    for _, rp in ipairs(recruitPins) do
        if rp.match then t[rp.match.slot] = true end
        for _, pin in ipairs(rp.slots) do
            t[pin.tag] = true
            if pin.acceptTags and #pin.acceptTags > 0 then t[CP.GEARKIT] = true end
        end
        for tg in pairs(rp.ghostTags or {}) do t[tg] = true end
    end
    return t
end

-- PHASE insts (one frame). Returns a verdict when the pass ends here, nil to go on.
function PS.begin(P)
    if not pinLoadRequested then
        pinLoadRequested = true
        for _, rp in ipairs(recruitPins) do
            for _, s in ipairs(rp.slots) do pcall(LoadAsset, s.part) end
            if rp.match then pcall(LoadAsset, rp.match.part) end
            if rp.definition then pcall(LoadAsset, rp.definition) end
        end
    end
    local now = PS.clock()
    CP.foldEvents()     -- 1.8.27: a Recruitment event that arrived before this pass began is this pass's to see
    -- 1.8.28: a NEW WORLD starts its sweeps and its residency answers afresh (a mission and the hub load different things)
    if P.wname ~= PS.lastWorld then
        PS.lastWorld, PS.worldPasses, PS.sweepAt = P.wname, 0, nil
        PS.res, PS.partRes = {}, {}
    end
    -- 1.8.28 (fix 3): an URGENT pass (a Recruitment event) bypasses the spawn-wave settle; it waits instead for the cards of
    -- OURS to exist and be PS.SPAWN_SETTLE_S old (below). Bounded: after PS.URGENT_WAIT_S it is an ordinary pass again.
    local urgent = PS.urgent
    if urgent and (now - urgent.t) > PS.URGENT_WAIT_S then
        log(("recruit pin: %s: no card of ours appeared within %d s — back to the normal cadence"):format(urgent.why,
            PS.URGENT_WAIT_S))
        PS.urgent, urgent = nil, nil
    end
    PS.fao = PS.fao + 1
    P.nLook = P.nLook + 1
    local okI, insts = pcall(FindAllOf, "CustomizationInstance")
    if not okI or type(insts) ~= "table" then
        PS.census(P, " (FindAllOf CustomizationInstance returned nothing usable)"); return "idle"
    end
    -- 1.8.26: THE SPAWN-WAVE SETTLE. Every Den crash landed while the census was CLIMBING (27 -> 73 -> 116 instances in
    -- a few seconds), which is when a pass is heaviest (a GetOuter walk of up to 12 levels per slot) and the game is
    -- busiest. While the raw instance count is still rising, this pass only counts and returns "settling" (the loop
    -- keeps its 2.5 s cadence). BOUNDED: at most pinSettle.max deferrals in a row, then the pass runs whatever the
    -- count does; a pass that sees the count NOT rising re-arms the budget for the next world. Nothing is read from a
    -- slot and nothing is written while settling, so no userdata is held across the deferral.
    -- 1.8.28: NOT for an urgent pass - a Recruitment refresh IS a spawn wave (118 -> 149 -> 153 at retail 05:12), and the
    -- three deferrals it cost were the first 15 s of T-G1's 70.
    if pinSettle.max > 0 then
        local nAll = #insts
        if not urgent and nAll > pinSettle.last and pinSettle.waits < pinSettle.max then
            local prev = pinSettle.last
            pinSettle.last, pinSettle.waits = nAll, pinSettle.waits + 1
            CP.noteCensus(P.wname, nil)
            PS.census(P, string.format(" (census climbing %d -> %d; slot walk deferred, %d of at most %d)",
                prev, nAll, pinSettle.waits, pinSettle.max))
            return "settling"
        end
        if nAll <= pinSettle.last then pinSettle.waits = 0 end
        pinSettle.last = nAll
    end
    -- every live instance is a CHARACTER. `byDefinition` already identifies some of them; the Name part identifies the rest.
    local cn, csum = 0, 0
    for _, inst in ipairs(insts) do
        if pinOk(inst) then
            local iname = nil; pcall(function() iname = inst:GetFullName() end)
            if type(iname) == "string" and iname ~= "" and not iname:find("Default__") then
                P.nInst = P.nInst + 1
                local ipath = (iname:gsub("^[^ ]+ ", ""))
                local dpath = ""
                local okD, def = pcall(function() return inst:GetDefaultCustomizationDefinition() end)
                if okD and pinOk(def) then
                    pcall(function() dpath = def:GetFullName():gsub("^[^ ]+ ", "") end)
                end
                local proxy = isProxyOwner(ipath)
                if not proxy then
                    cn = cn + 1
                    csum = csum + (tonumber(shortOwner(ipath):match("_(%d+)$") or "0") or 0)
                end
                -- 1.8.27: WHICH PIN an instance belongs to is decided by IDENTITY (rank 3 its own default definition, 2 a
                -- pin's `match` Name part, 1 a slot already holding a pin's own part - PS.walkOne), never by the order
                -- of the pins. 1.4.0-1.8.26 attached every instance to the FIRST pin with a `match` rule, so with more
                -- than one pin (three recruits per class mod, two class mods) only the first pin's character could ever
                -- be identified (replay W-g). The instance starts on its definition's pin, else on the first `match` pin
                -- as a placeholder that identity replaces.
                local defRp, matchRp = nil, nil
                for _, rp in ipairs(recruitPins) do
                    if not defRp and rp.definition ~= nil and dpath == rp.definition then defRp = rp end
                    if not matchRp and rp.match then matchRp = rp end
                end
                if proxy then
                    if not pinSkipLogged[ipath .. "|proxy"] then
                        pinSkipLogged[ipath .. "|proxy"] = true
                        log("recruit pin: skip " .. shortOwner(ipath) .. ": preview/portrait proxy (" .. proxy ..
                            ") — not pinned; it is a transient preview of a character, not the character")
                    end
                elseif defRp or matchRp then
                    if defRp and not PS.firstSeen[ipath] then PS.firstSeen[ipath] = now end
                    P.inst[ipath] = { rp = defRp or matchRp, rp0 = defRp or matchRp, rank = defRp and 3 or 0,
                                      byDefinition = (defRp ~= nil), slotsAll = {}, dupesBy = {}, nameSeen = nil,
                                      ident = (defRp ~= nil), how = defRp and "its own default CustomizationDefinition" or nil }
                end
            end
        end
    end
    CP.noteCensus(P.wname, cn, csum)   -- 1.8.27: the census the Recruitment watcher's fallback trigger reads
    -- 1.8.28 (fix 2): THE SCOPE. A world's first PS.SWEEP_PASSES passes, and one pass per PS.SWEEP_S after them, sweep the
    -- whole world; every other pass collects only what is OURS. A pin without a `definition` can only be found by its
    -- Name part, so then every pass sweeps (the 1.8.27 shape, without its lookups).
    PS.worldPasses = PS.worldPasses + 1
    local scopable = true
    for _, rp in ipairs(recruitPins) do if not rp.definition then scopable = false end end
    P.full = (not scopable) or PS.forceFull or PS.worldPasses <= PS.SWEEP_PASSES
             or (PS.sweepAt ~= nil and (now - PS.sweepAt) >= PS.SWEEP_S)
    if P.full then
        PS.sweepAt, PS.forceFull = now, false
    else
        local keep = {}
        for ipath, c in pairs(P.inst) do
            if c.byDefinition or pinKnown[ipath] then keep[ipath] = c end
        end
        P.inst = keep
    end
    if next(P.inst) == nil then
        if urgent then
            PS.census(P, string.format(" (%s: no card of ours yet; looking again in %.1f s)", urgent.why, PS.URGENT_STEP_S))
            return "urgent"
        end
        if not P.full then
            PS.census(P, " (nothing ours; this world's sweeps are done)")
            return "none"
        end
        PS.census(P); return "idle"
    end
    -- 1.8.28 (fix 3): the urgent pass drives once every card of OURS exists and is PS.SPAWN_SETTLE_S old
    if urgent then
        local ready, young = 0, 0
        for ipath, c in pairs(P.inst) do
            if c.byDefinition then
                if (now - (PS.firstSeen[ipath] or now)) >= PS.SPAWN_SETTLE_S then ready = ready + 1 else young = young + 1 end
            end
        end
        if ready == 0 or young > 0 then
            PS.census(P, string.format(" (%s: %d card(s) of ours ready, %d still spawning; looking again in %.1f s)",
                urgent.why, ready, young, PS.URGENT_STEP_S))
            return "urgent"
        end
        P.urgent = urgent
    end
    P.phase = "drive"
    return nil
end

-- one slot of the collection: the 1.8.26 loop body. 1.8.28: `ipath` comes from the slot's NAME (PS.ownerOf), and the
-- two world-wide sweeps run only on a sweep pass (P.sweep).
function PS.walkOne(P, s, sname, tag, ipath)
    local instByPath = P.inst
    -- 1.8.19: THE GHOST SWEEP, before anything is driven and on EVERY character in the world, ours or not.
    -- Bounded to this pin's own declared tags and to real characters (a preview proxy is a transient copy
    -- of one, and would print the same ghost again under a new name every pass). Observable-only: the
    -- only thing it changes is `pinGhostSlot`, which stops a slot being COLLECTED, and so driven.
    -- 1.8.20: it runs AFTER the owner is known, because the OWNER is now part of the evidence — a slot with
    -- no owning CustomizationInstance is a slot mid-spawn, and mid-spawn is what produced all three of
    -- the 2026-09-13 false positives. The loop also stops at the FIRST matching pin so a tag two pins
    -- both declare cannot double-count the consecutive-pass rule.
    -- 1.8.27: a slot a missing dependency DROPPED from its pin (no fallback) is still swept (rp.ghostTags).
    -- 1.8.28: on a scoped pass only OUR characters' slots reach this line (PS.drive), so the refusal still guards
    -- every slot the pin could write.
    if tag ~= "" and not pinGhostSlot[sname] and not isProxyOwner(sname) then
        local matched = false
        for _, rp in ipairs(recruitPins) do
            local hit = false
            for _, pin in ipairs(rp.slots) do if tag == pin.tag then hit = true end end
            if not hit and rp.ghostTags and rp.ghostTags[tag] then hit = true end
            if hit and not matched then
                matched = true
                local g, dead, pend = ghostOf(s, tag)
                -- a pass that reads OTHERWISE resets the count: the rule is CONSECUTIVE checks
                if pend then P.ghostWait[sname] = true            -- 1.8.28: residency not known yet: not judged, not driven
                elseif g then ghostReport(sname, ipath, tag, g, pinPass, dead)
                else pinGhostSeen[sname] = nil end
            end
        end
    end
    -- 1.8.22: THE STALE-SLOT SWEEP, on the same footing as the ghost sweep — every character in the world,
    -- ours or not, read-only here. It runs AFTER the ghost sweep so a slot the ghost rule has just blocked
    -- can never be collected as a rebuild candidate; whether it is OURS is decided after this loop, when
    -- identity has stopped moving. 1.8.28: on a sweep pass only.
    if P.sweep then staleConsider(s, sname, ipath, tag) end
    local c = ipath and instByPath[ipath]
    if c then
        -- 1.8.28 (fix 6): the appearance echo's two slots, read-only; the live one is the highest object index
        if tag == PS.FACE or tag == PS.HAIR then
            local idx = tonumber(sname:match("_(%d+)$") or "0") or 0
            local prev = c.look[tag]
            if not prev or idx > prev.idx then
                local id = "?"
                pcall(function() id = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end)
                c.look[tag] = { idx = idx, id = tostring(id) }
            end
        end
        -- 1.8.27: identity over EVERY pin (see PS.begin), a higher rank never replaced by a lower one
        local cur = nil
        for _, rp in ipairs(recruitPins) do
            if rp.match and tag == rp.match.slot then
                if cur == nil then cur = ""; pcall(function() cur = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end) end
                c.nameSeen = (cur ~= "") and cur or "<none>"
                if c.rank < 2 and cur == rp.match.part:match("([^/.]+)$") then
                    c.rp, c.rank, c.ident = rp, 2, true
                    c.how = "its " .. shortTag(tag) .. " = " .. cur
                end
            end
        end
        -- 1.8.15 SECOND IDENTITY SOURCE: a slot already holding one of THIS pin's own parts is this pin's
        -- character. The Name slot can be re-created underneath us (equipping the definition replaces the
        -- class fragment, and the class fragment is what makes the child slots), and when it blinked the
        -- 07:47 session lost the Sith for the rest of the run.
        if c.rank < 1 then
            if cur == nil then cur = ""; pcall(function() cur = s.CustomizationPartPrimaryAssetId.PrimaryAssetName:ToString() end) end
            for _, rp in ipairs(recruitPins) do
                for _, pin in ipairs(rp.slots) do
                    if c.rank < 1 and tag == pin.tag and cur == pin.part:match("([^/.]+)$") then
                        c.rp, c.rank, c.ident = rp, 1, true
                        c.how = "its " .. shortTag(tag) .. " already holds " .. cur
                    end
                end
            end
        end
        -- 1.8.27 (§5.6): the GearKit sub-slot, whose MODEL part carries the weapon class's identity tag. The live one
        -- is the highest object index, as for every other slot (1.8.16).
        if tag == CP.GEARKIT then
            local idx = tonumber(sname:match("_(%d+)$") or "0") or 0
            if not c.gear or idx > c.gear.idx then c.gear = { sname = sname, obj = s, idx = idx } end
        end
        -- 1.8.27: collected for EVERY pinned tag, keyed by tag; PS.act keeps the tags of the pin identity chose
        if P.pinTags[tag] and not pinGhostSlot[sname] and not P.ghostWait[sname] then
            -- 1.8.19: a GHOST slot is never collected, so it can never be driven — the refusal is
            -- structural, not a branch inside the write path.
            -- 1.8.16: EVERY EQUIP LEAVES THE OLD SLOT OBJECTS ALIVE BESIDE THE NEW ONES. Retail 08:38
            -- watched one character go 3 -> 6 -> 12 matching slots across three passes, and the old cap
            -- counted the corpses and refused him. A character has exactly one LIVE slot per tag: keep
            -- the highest object index (UE numbers each new object above the last) and count the rest
            -- as the stale duplicates they are.
            local idx = tonumber(sname:match("_(%d+)$") or "0") or 0
            local prev = c.slotsAll[tag]
            local entry = { sname = sname, obj = s, tag = tag, idx = idx }
            if prev == nil then
                c.slotsAll[tag] = entry
            else
                c.dupesBy[tag] = (c.dupesBy[tag] or 0) + 1
                if idx > prev.idx then c.slotsAll[tag] = entry end
            end
        end
    end
end

-- PHASE drive (one frame): ONE FindAllOf of the slots, the collection, and the act - on the objects of THIS frame only.
function PS.drive(P)
    P.drives = P.drives + 1
    P.sweep = P.full and not P.swept
    P.lookups, P.nLook = P.lookups + 1, P.nLook + 1
    PS.fao = PS.fao + 1
    local okS, slots = pcall(FindAllOf, "CustomizationFragmentInstanceSlot")
    if not okS or type(slots) ~= "table" then
        PS.census(P, " (FindAllOf CustomizationFragmentInstanceSlot returned nothing usable)"); return "idle"
    end
    staleCand = {}      -- 1.8.22: re-collected every frame; no slot userdata survives one (the 05:50:58 rule)
    P.ghostWait = {}
    for _, c in pairs(P.inst) do
        c.slotsAll, c.dupesBy, c.gear, c.nameSeen, c.look = {}, {}, nil, nil, {}
        c.rp, c.rank, c.ident = c.rp0, c.byDefinition and 3 or 0, c.byDefinition
        c.how = c.byDefinition and "its own default CustomizationDefinition" or nil
    end
    local want = PS.tags()
    P.pinTags = {}
    for _, rp in ipairs(recruitPins) do for _, pin in ipairs(rp.slots) do P.pinTags[pin.tag] = true end end
    for _, s in ipairs(slots) do
        if pinOk(s) then
            local tag = ""; pcall(function() tag = s.SlotNameTag.TagName:ToString() end)
            if type(tag) == "string" and want[tag] then
                local sname = nil; pcall(function() sname = s:GetFullName() end)
                if type(sname) == "string" and sname ~= "" then
                    sname = (sname:gsub("^[^ ]+ ", ""))
                    local ipath = PS.ownerOf(P, sname)
                    -- a scoped pass reads only OUR characters' slots; a sweep reads every one (the ghost refusal and
                    -- the stale-slot rebuild look at characters that are not ours, and at slots with no owner yet)
                    if ipath or P.sweep then
                        PS.walked = PS.walked + 1
                        PS.walkOne(P, s, sname, tag, ipath)
                    end
                end
            end
        end
    end
    -- residency answers this collection needs and does not have: one lookup frame each, then a fresh drive frame
    if P.lookAt < #P.lookq and P.looks < PS.LOOK_MAX then
        P.phase = "look"
        return "more"
    end
    local r = PS.act(P)
    if P.sweep then P.swept = true end
    return r
end

-- PHASE look: ONE StaticFindObject per frame, answering the residency questions the collection queued.
function PS.look(P)
    P.looks = P.looks + 1
    local path = P.lookq[P.lookAt + 1]
    if path then
        P.lookAt = P.lookAt + 1
        if PS.res[path] == nil then
            P.lookups, P.nLook = P.lookups + 1, P.nLook + 1
            PS.sfo = PS.sfo + 1
            local o = nil
            pcall(function() o = StaticFindObject(path) end)
            PS.res[path] = pinOk(o)
        end
    end
    if P.lookAt >= #P.lookq or P.looks >= PS.LOOK_MAX then P.phase = "drive" end
    return "more"
end

-- 1.8.28 (fix 4): a character whose Class was delivered earlier in THIS pass: are its child slots the re-created ones yet?
-- true = hold it this frame. The children are the new objects when their live slot names differ from the ones read before
-- the Class write; after PS.CLASS_TRIES frames that still read the old ones they are driven as they are (and said so).
function PS.kidsHold(P, ipath, c)
    local ca = P.classAt[ipath]
    if not ca or ca.go then return false end
    ca.tries = ca.tries + 1
    local same = 0
    for tag, sn in pairs(ca.kids) do
        local h = c.slotsAll[tag]
        if h and h.sname == sn then same = same + 1 end
    end
    if same > 0 and ca.tries < PS.CLASS_TRIES then return true end
    ca.go = true
    if same > 0 then
        CP.once("kids|" .. ipath, "recruit pin: " .. shortOwner(ipath) .. ": " .. same .. " child slot(s) are still the " ..
            "same objects " .. ca.tries .. " drive frame(s) after its Class was delivered — driving them as they are")
    end
    return false
end

-- 1.8.28 (fix 6): ONE read-only line per character of ours: which head and hair its slots hold (analysis §3's question)
-- 1.8.28b: AND ONCE MORE AT THE VERIFY PASS (~VERIFY_S after `done`). Retail 1.8.28 read Face=CPD_H_Head_HM02 /
-- Hair=CPD_H_Human_Hair_None on all three cards of the FIRST set after load (none of the mod's CDs), and the right heads on
-- the second set. The verify read tells "read before the appearance settled" (CHANGED) from "spawned with the default
-- head" (unchanged). Same reads, same frame as the verify pass's own collection: no lookup of its own.
function PS.echoLook(P, ipath, c)
    local f, h = c.look[PS.FACE], c.look[PS.HAIR]
    local fid, hid = f and f.id or "<no slot>", h and h.id or "<no slot>"
    local body = shortTag(PS.FACE) .. "=" .. fid .. " " .. shortTag(PS.HAIR) .. "=" .. hid
    local first = PS.lookEchoed[ipath]
    if not first then
        PS.lookEchoed[ipath] = { face = fid, hair = hid }
        log("recruit pin: appearance " .. shortOwner(ipath) .. ": " .. body .. " (read-only)")
        return
    end
    if not P.verify or P.lookVerified[ipath] then return end
    P.lookVerified[ipath] = true
    local same = (first.face == fid and first.hair == hid)
    log("recruit pin: appearance (verify) " .. shortOwner(ipath) .. ": " .. body .. " (read-only) — " ..
        (same and "unchanged since the first read" or ("CHANGED since the first read (was " .. shortTag(PS.FACE) .. "=" ..
        first.face .. " " .. shortTag(PS.HAIR) .. "=" .. first.hair .. ")")))
end

-- PHASE act (inside the drive frame): the 1.8.26 judgement and drive, on objects this frame's FindAllOf returned.
-- returns "pinned" (a slot was changed) / "targets" (pin-able characters are here, nothing to change) / "idle" (nothing to do),
-- which is what the loop below paces itself by; "more" when the same pass drives again next frame (1.8.28).
--
-- 1.8.12 — THE UNIT OF IDENTITY IS THE CHARACTER, AND A CHARACTER IS ITS `UCustomizationInstance`.
-- 1.8.10/1.8.11 made it the slot's immediate parent object, and retail 2026-09-13 05:03 proved that unsatisfiable by
-- construction: `pass 39: 73 instance(s) seen, 73 candidate(s), 73 group(s), 0 pinned, 14 skipped, world=HUB_Root`, with every
-- character skipped three times — `no identity: it holds 1 pinned tag(s) | 2 pinned tag(s) | 2 pinned tag(s) … Info.Name reads
-- <not present>`. One character's slots are NOT siblings: `Class` hangs directly off the CustomizationInstance, the two
-- `Specializations.*` slots hang off a container slot (`…CustomizationFragmentInstanceSlot_11.CustomizationFragmentInstanceSlot_2`),
-- and `Info.Name` hangs off a third parent. No parent object can ever hold both a pinned tag and the identity, so the per-group
-- identity rule could only ever fail — silently in 1.8.10, loudly in 1.8.11, but always.
-- 1.8.7 — which pinned this recruit correctly — identified at INSTANCE level, and that is what is restored here:
--   * a character is OURS if its instance's own `GetDefaultCustomizationDefinition()` is the pin's, OR if ANY slot under that
--     instance whose `SlotNameTag` is the pin's `match` slot holds the pin's `match` part (the mod's own Info.Name part).
--     In this save Vex was built from the pool row, so his instance's default definition is generic — only the Name part finds him.
--   * the pinned tags' slots are then taken from ANYWHERE under that same instance, at any depth, across parent slots.
-- WHAT STOPS THE 22:15:47 MASS-PIN IS NOT THE GROUPING — IT IS THE CAP. That incident collected 21 slots belonging to seven
-- characters under ONE proxy instance, because a customization proxy accumulates the slot trees of everything it has previewed.
-- A real character has exactly ONE slot per pinned tag, so more matching slots than the pin declares means the instance holds
-- more than one character and NOTHING is written. That test is exact, cheap, and cannot be defeated by a tree shape.
function PS.act(P)
    local instByPath = P.inst
    -- 1.8.28: the CDO once a session (PS.ksl), not a StaticFindObject per act
    local ksl = PS.ksl()
    -- 1.8.22: the stale-slot rebuild, once identity has stopped moving for this pass and before anything of OURS is
    -- driven (different characters, different instances — the order is only so the two never interleave on one).
    -- 1.8.28: on a sweep pass (the candidates are collected only then), and on every pass while one is mid-flight.
    local staleBusy = P.sweep and staleDrive(instByPath, ksl, P.hub) or false
    if staleBusy then PS.forceFull = true end   -- the rebuild's second write needs the next pass to be a sweep too
    P.nOurs, P.nWith, P.nSkip, P.skipped = 0, 0, 0, {}

    local pending, refresh = {}, {}
    local waitingOnResidency = false   -- 1.8.19: a pinned part this pass was not resident yet; see the `done` gate
    for ipath, c in pairs(instByPath) do
        -- 1.8.27: identity is sticky PER PIN too - an instance identified in an earlier pass keeps that pin, over a
        -- part match (rank 1): the rows of one class share their class/spec/weapon parts, so a part match alone
        -- cannot tell row A from row B when the Name slot blinks
        if c.rank < 2 and pinKnown[ipath] and PS.knownRp[ipath] then c.rp = PS.knownRp[ipath] end
        local rp = c.rp
        c.byTag, c.dupes = {}, 0
        for _, pin in ipairs(rp.slots) do
            local h = c.slotsAll[pin.tag]
            if h then
                c.byTag[pin.tag] = { sname = h.sname, obj = h.obj, tag = pin.tag, pin = pin, idx = h.idx }
                c.dupes = c.dupes + (c.dupesBy[pin.tag] or 0)
            end
        end
        c.hits = {}
        local distinct = 0
        for _, h in pairs(c.byTag) do c.hits[#c.hits + 1] = h; distinct = distinct + 1 end
        -- 1.8.28: in legacyOwner's ORDER (Class, Weapon, the rest, Talent). The Class-first rule is now enforced HERE too:
        -- a hit is only looked up / made pending after the Class is settled, because the lookup budget would otherwise
        -- let a child's part in first and leave the Class for a later frame - and the Class write would then discard it.
        table.sort(c.hits, function(a, b)
            local ra, rb = PS.orderOf(a.tag), PS.orderOf(b.tag)
            if ra ~= rb then return ra < rb end
            return a.tag < b.tag
        end)
        if #c.hits > 0 then
            P.nWith = P.nWith + 1
            if c.dupes > 0 and not pinSkipLogged[ipath .. "|dupes"] then
                pinSkipLogged[ipath .. "|dupes"] = true
                log("recruit pin: " .. shortOwner(ipath) .. ": " .. c.dupes .. " stale duplicate slot object(s) " ..
                    "ignored (" .. distinct .. " live pinned tag(s); every equip leaves the previous slot objects " ..
                    "alive beside the new ones)")
            end
            -- 1.8.15: identity is STICKY. Once this instance has been identified it stays identified for the session,
            -- because the game can re-create the slot that carried the identity while the pin is mid-flight.
            -- 1.8.16: an IDENTIFIED character is never refused by the cap. The cap exists to stop an instance
            -- nobody has identified from being pinned by accident; it must never fire on the recruit itself.
            if c.ident then pinKnown[ipath] = c.how or "identity"; PS.knownRp[ipath] = rp
            elseif pinKnown[ipath] then c.ident = true; c.how = pinKnown[ipath] .. " (remembered from an earlier pass)" end
            if not c.ident then
                PS.skip(P, ipath, "not ours: " .. #c.hits .. " slot(s) carry pinned tags but its default definition is not " ..
                    tostring(rp.definition and rp.definition:match("([^/.]+)$") or "<none>") ..
                    (rp.match and (" and its " .. shortTag(rp.match.slot) .. " reads " .. tostring(c.nameSeen or "<not present>") ..
                        " (wanted " .. rp.match.part:match("([^/.]+)$") .. ")") or " and this pin declares no `match` rule"))
            elseif distinct > #rp.slots then
                -- THE MASS-PIN GUARD. A character has one slot per pinned tag; more means this instance carries more than one
                -- character's slots (a customization proxy that has previewed several). Retail 2026-09-12 22:15:47: 21 slots,
                -- seven characters, 33 wrong writes. Nothing is written here, ever.
                PS.skip(P, ipath, distinct .. " LIVE distinct pinned tag(s) against this pin's " .. #rp.slots .. " under ONE CustomizationInstance — " ..
                    "it holds more than one character's slots, so nothing is written (this is the 2026-09-12 22:15:47 guard)")
            else
                P.nOurs = P.nOurs + 1
                PS.echoLook(P, ipath, c)
                local how = c.how or (c.byDefinition and "its own default CustomizationDefinition")
                    or (rp.match and ("its " .. shortTag(rp.match.slot) .. " = " .. rp.match.part:match("([^/.]+)$")))
                    or "identity"
                if PS.kidsHold(P, ipath, c) then
                    P.again, P.hold = true, PS.CLASS_HOLD          -- 1.8.28: its children are not re-created yet
                else
                local classBlock = nil       -- 1.8.28: "pending" / "held" while this character's Class needs a drive
                local blocked = false        -- 1.8.28: a slot of this character waits for the next frame's budget
                for _, hit in ipairs(c.hits) do
                    local s, tag, pin = hit.obj, hit.tag, hit.pin
                    if pinOk(s) then
                    local before = slotState(s)
                    local cur = (before.id:match("([^:]+)$") or "?")
                    local want = pin.part:match("([^/.]+)$")
                    -- 1.8.14: the retry bound is keyed by the character's STABLE identity (the pin's own Name part or
                    -- its definition), not the instance path — a proxy's path changes as the game recreates it, so the
                    -- old key made PIN_MAX_RETRY unreachable and the 05:43 session re-drove forever without one
                    -- `attempt` give-up line.
                    -- 1.8.27 (G1): ... EXCEPT a recruit CARD (identified by the pool definition). A card is a transient
                    -- instance and a Recruitment refresh spawns new ones, so a card's slot state is keyed by its instance
                    -- (`|card:<path>`): a card delivered before a refresh can never mark the NEXT card of the same row
                    -- delivered. Proxies are never pinned (1.8.14), so the 05:43 churn cannot come back through a card.
                    local ident = (rp.match and rp.match.part:match("([^/.]+)$"))
                        or (rp.definition and rp.definition:match("([^/.]+)$")) or "pin"
                    local key = ident .. "|" .. tag .. (c.byDefinition and ("|card:" .. ipath) or "")
                    pinExpected[key] = true
                    -- "the id already names our part" is NOT enough: that is the state the setter leaves when the part was not
                    -- resident — our id, a NULL definition, no leveled tree. Re-drive it, bounded by PIN_MAX_RETRY.
                    local need
                    if pinDelivered[key] then
                        need = false                 -- 1.8.18: finished; driving it again would undo it
                        -- 1.8.28 (fix 3): THE VERIFY PASS, once, VERIFY_S after an urgent episode's `done`: a slot that
                        -- DELIVERED and no longer holds ours (the spawn's voice writer, say) is driven again - once.
                        if P.verify and cur ~= want and not PS.accKey[key] and not PS.reverted[key] then
                            PS.reverted[key] = true
                            pinDelivered[key], pinAttempts[key] = nil, 0
                            P.reverts = P.reverts + 1
                            log("recruit pin: " .. shortTag(tag) .. " on " .. shortOwner(ipath) .. " reverted to " .. cur ..
                                " after it was DELIVERED — driving it again (verify pass)")
                            need = true
                        end
                    elseif pinToggled[key] then
                        -- 1.8.18: the toggle is mid-flight, put ours back - on a LATER pass (1.8.28: a pass now spans
                        -- several frames; LoadCustomization's tick between the two writes is kept as retail proved it)
                        need = (pinToggled[key] ~= pinPass)
                    elseif cur ~= want then
                        -- 1.8.27 (H1 / §5.6): a part the pin ACCEPTS is a player's choice (or the uninstall escape
                        -- hatch on a roster character): settled, never driven.
                        local acc = CP.accepted(pin, cur, c.byDefinition,
                            function(id) return CP.weaponTags(c, id, pin) end)
                        if acc then
                            need = false
                            pinDelivered[key] = true
                            PS.accKey[key] = true
                            CP.acceptLog(acc, pin, tag, ipath, cur)
                        else
                            pinAttempts[key] = 0
                            need = true
                            if pin.dead and pin.dead[cur] then   -- §2d.3: the removed-pack case WITH a fallback
                                CP.once("deadfb|" .. ipath .. "|" .. tag .. "|" .. cur, "recruit pin: " .. shortOwner(ipath) ..
                                    " " .. shortTag(tag) .. " held " .. cur .. " from missing " .. tostring(pin.dep) ..
                                    " — delivering fallback " .. want)
                            end
                        end
                    elseif (pin.accept or pin.acceptTags) and not c.byDefinition and before.defn ~= "<null>"
                           and before.trees == 0 then
                        -- 1.8.27 (§5.6.1 a2): an ACCEPT-SET slot on a ROSTER character that already holds `want`,
                        -- resolved, is settled. The 1.8.18 re-drive below would toggle it (a Weapon part always reads 0
                        -- trees), and toggling the spec re-creates its GearKit sub-slot: a hilt the player re-picked
                        -- inside the class would be reset every session. (The cost, stated: such a slot no longer gets
                        -- the once-a-session toggle that also refreshes stale fragments - 1.8.22's Hawks case.)
                        need = false
                        pinDelivered[key] = true
                        PS.accKey[key] = true
                        CP.acceptLog("kept", pin, tag, ipath, cur)
                    elseif before.defn == "<null>" or before.trees == 0 then
                        -- 1.8.14: the RE-DRIVE trigger is an UNRESOLVED definition, not a zero tree count. A part with no
                        -- leveled abilities at all (the Class and Weapon parts) legitimately has 0 trees for ever, and
                        -- keying on that re-drove them every pass — and because the setter replaces FragmentInstances on
                        -- every call, each re-drive read as DELIVERED and reset the retry counter, so the bound never bit.
                        -- That is the loop that ran 66 times and crashed. `partDefinition == <null>` is self-limiting:
                        -- it stops the moment the part resolves.
                        need = (pinAttempts[key] or 0) < PIN_MAX_RETRY
                        if not need and not pinGaveUp[key] then
                            pinGaveUp[key] = true
                            log("recruit pin: " .. shortTag(tag) .. " on " .. shortOwner(ipath) .. " already holds " .. want ..
                                " but its CustomizationPartDefinition never resolved after " .. PIN_MAX_RETRY ..
                            " attempt(s) — leaving it alone (" ..
                                sigOf(before) .. ")")
                        end
                    else
                        need = false
                    end
                    local isClass = (tag:find("%.Class$") ~= nil)
                    if need and not isClass and classBlock == "held" then
                        need = false                 -- 1.8.28: the Class is not settled and could not be driven this frame
                    elseif need and not isClass and classBlock == "pending" then
                        -- listed (legacyOwner drives the Class ALONE while it is undelivered - the 1.8.18b rule), and not
                        -- looked up: it is not written this frame
                        need = false
                        pending[ipath].list[#pending[ipath].list + 1] = { slot = s, tag = tag, cur = cur, want = want,
                            path = pin.part, key = key, before = before }
                    end
                    if need and blocked then
                        need = false                 -- 1.8.28: an earlier slot of this character waits for the budget
                    end
                    if need then
                        -- 1.8.28: RESIDENCY FIRST, from THIS frame's lookup, in the ORDER (so the lookup budget can never
                        -- let a later slot overtake an earlier one); the id is minted at the write (legacyOwner -> PS.mint)
                        -- from that same frame's object. A slot about to be TOGGLED writes the other id, not ours, so for
                        -- it a residency FACT from an earlier frame (a boolean, never an object) is enough - otherwise a
                        -- toggle, which needs ours resident AND the other part, could never fit one frame's budget.
                        local toggle = (cur == want) and not pinToggled[key]
                        local resident, busy = (toggle and PS.partRes[pin.part] == true), false
                        if isClass then classBlock = "held" end
                        if not resident and not P.absent[pin.part] then   -- (absent once this pass = absent this pass)
                            local partObj
                            partObj, busy = PS.get(pin.part)
                            resident = (partObj ~= nil)
                            if resident then partReport(pin.part, partObj)
                            elseif not busy then P.absent[pin.part] = true end
                        end
                        if busy then
                            P.again, P.deferred = true, P.deferred + 1   -- the frame's lookup budget: next drive frame
                            blocked = true
                        elseif resident and pinOk(ksl) then
                            local p = pending[ipath]
                            if not p then
                                p = { slot0 = s, rp = rp, scoped = how, list = {} }
                                pending[ipath] = p
                            end
                            p.list[#p.list + 1] = { slot = s, tag = tag, cur = cur, want = want, path = pin.part,
                                                    key = key, before = before }
                            if isClass then classBlock = "pending" end
                            -- a TOGGLE looks its other part up at the write: nothing after it may take that lookup first
                            -- (a toggle with no other part to look up - legacyOwner says so - blocks nothing)
                            if toggle then
                                local other = pinVanilla[key] or PIN_TOGGLE_DEFAULT[tag]
                                if other and other ~= want and PIN_TOGGLE_PATH[other] then blocked = true end
                            end
                        else
                            -- the resolver (UCustomizationStatics::GetCustomizationPartDefinitionFromPartId, RVA 0x8c46060) asks
                            -- the AssetManager for the LOADED object first, so residency is the whole variable: without it the
                            -- id is written and the definition stays null.
                            pcall(LoadAsset, pin.part)
                            waitingOnResidency = true
                            PS.skip(P, ipath .. "|" .. tag, "part " .. want .. " is not resident yet — requested the load, retrying")
                        end
                    end
                    end
                end
                end
            end
        end
    end
    -- 1.8.15: the ladder runs on its own clock. A part that will not resolve must keep climbing whether or not the
    -- pin managed to identify a character this pass — the 07:47 session stalled both specs at step 2 for a whole
    -- session because identification blinked and the ladder was only ever driven from inside a successful pin.
    -- 1.8.20: ... but a SETTLED part is off the list entirely. `(partStep[path] or 0) < 5` used to be true again the
    -- moment the drive path cleared partStep on a resolve, which is how the ladder re-climbed a delivered part.
    -- 1.8.28: PS.watchTick, AFTER this frame's writes (it must never spend the lookup a write needs); through the frame's
    -- lookup budget, so a part it cannot look at this frame is looked at on another.
    if next(pending) == nil then
        PS.watchTick(P)
        if P.again and P.drives < PS.DRIVE_MAX then return PS.again(P) end
        -- 1.8.14: nothing to drive AND at least one real character was identified means every pinned slot is either
        -- delivered or has exhausted PIN_MAX_RETRY. There is nothing a 67th pass can do that the 66th did not, and the
        -- 05:43 session showed what endless passes cost: a stale userdata and a crash. Stop, and say so.
        -- 1.8.18: `done` is now a statement about DELIVERY, not about having nothing to do this pass.
        -- 1.8.27 (G1): `done` ends the EPISODE, not the session: the loop goes dormant and re-arms (CP.pinTick).
        local climbing = false
        for p2 in pairs(partWatch) do if (partStep[p2] or 0) > 0 and (partStep[p2] or 0) < 5 then climbing = true end end
        -- 1.8.18: delivery beats the ladder. Once every slot this pin wants has DELIVERED there is nothing left for a
        -- residency step to discover, so `done` is not held behind it.
        local allDelivered = next(pinExpected) ~= nil
        for k in pairs(pinExpected) do if not pinDelivered[k] then allDelivered = false end end
        -- 1.8.19: `done` MUST NOT mean "the parts had not finished loading yet". Found by replay scenario P, not in
        -- retail: with our parts still absent on pass 1 the pin has nothing pending, nothing is climbing the ladder
        -- (only a DRIVEN slot registers a part with it), and 1.8.18 would log `done — 0 slot(s) DELIVERED` and stop
        -- the loop for the whole session. LoadAsset is asynchronous (the oldest gotcha in this project), so a pass
        -- that is only waiting for a load is not a pass that has finished. The wait is BOUNDED - the 05:43 lesson is
        -- that an unbounded pin loop is what crashes the game - and when the budget runs out `done` fires anyway,
        -- with the honest count and a line saying which part it gave up waiting for.
        if waitingOnResidency and not allDelivered and pinWaited < PIN_RESIDENCY_PASSES then
            pinWaited = pinWaited + 1
            if not pinQuiet["waiting"] then
                pinQuiet["waiting"] = true
                log("recruit pin: holding `done` — a pinned part is not resident yet and LoadAsset is asynchronous; " ..
                    "waiting up to " .. PIN_RESIDENCY_PASSES .. " more pass(es) before giving a verdict")
            end
            PS.census(P); return (P.nWith > 0) and "targets" or "idle"
        end
        if waitingOnResidency and pinWaited >= PIN_RESIDENCY_PASSES and not pinQuiet["waitedout"] then
            pinQuiet["waitedout"] = true
            log("recruit pin: waited " .. PIN_RESIDENCY_PASSES .. " pass(es) and a pinned part is STILL not resident " ..
                "— the verdict below counts it as undelivered")
        end
        -- 1.8.22: `done` stops the loop for the session, so it must not fire with a stale-slot rebuild half done —
        -- the slot would be left on the toggle id. The wait is bounded by the rebuild's own PIN_MAX_RETRY /
        -- PIN_RESIDENCY_PASSES budgets, which is what keeps the 05:43 lesson (an unbounded pin loop) intact.
        if staleBusy and not pinDone and not pinQuiet["stalehold"] then
            pinQuiet["stalehold"] = true
            log("recruit pin: holding `done` — a stale-slot rebuild is mid-flight (the slot is on its toggle id " ..
                "until the next pass writes ours back)")
        end
        if P.nOurs > 0 and not pinDone and not staleBusy and (allDelivered or not climbing) then
            pinDone = true
            local settled, gaveup = 0, 0
            for k in pairs(pinDelivered) do settled = settled + 1 end
            for k in pairs(pinGaveUp) do gaveup = gaveup + 1 end
            log(string.format("recruit pin: done — %d character(s) ours, %d slot(s) DELIVERED, %d gave up after %d " ..
                "attempt(s); the pin loop is dormant (re-arms on a Recruitment refresh / recruit / world change, up to %d " ..
                "more time(s))", P.nOurs, settled, gaveup, PIN_MAX_RETRY, math.max(0, CP.PIN_REARM_MAX - CP.rearms)))
            staleSummary()
            CP.episodeDone(settled)
        end
        PS.census(P); return pinDone and "done" or ((P.nWith > 0) and "targets" or "idle")
    end
    for ipath, p in pairs(pending) do
        log("recruit pin: scoped to " .. shortOwner(ipath) .. " by " .. p.scoped .. "; " .. #p.list .. " slot(s) to drive")
        if not P.pinnedSet[ipath] then P.pinnedSet[ipath] = true; P.nPinned = P.nPinned + 1 end   -- characters, not frames
        -- 1.8.28 (fix 4): the child slots as they are BEFORE a Class write, so the next drive frame can tell the
        -- re-created ones from these
        local kids = {}
        for _, e in ipairs(p.list) do if not e.tag:find("%.Class$") then kids[e.tag] = true end end
        local c = instByPath[ipath]
        local before = {}
        for tag, h in pairs(c and c.byTag or {}) do if not tag:find("%.Class$") then before[tag] = h.sname end end
        applyOwner(ipath, p)
        if P.classDone[ipath] then
            P.classDone[ipath] = nil
            P.classAt[ipath] = { kids = before, tries = 0 }
            P.again, P.hold = true, PS.CLASS_HOLD
        end
        -- 1.8.13: a slot the equip AND the setter both left with a NULL CustomizationPartDefinition is not a marshalling
        -- failure — the Class part delivered through the same call in the same pass (retail 05:30:21). It is the resolver
        -- refusing THAT id, so the part's residency is escalated one observable step per pass.
        for _, e in ipairs(p.list) do
            partDriven[e.path] = pinPass
            local st = slotState(e.slot)
            if st.defn == "<null>" then
                escalateResidency(e.path, e.want, (st.id:match("^([^:]+)") or nil), pinPass)
            elseif partStep[e.path] then
                log("recruit pin: part " .. e.want .. " resolved after step " .. tostring(partStep[e.path]) ..
                    " of the residency ladder")
                partStep[e.path] = nil
                -- 1.8.20: SETTLED. Clearing partStep alone left the part on partWatch, where a step count of 0 reads
                -- as "not started" and the tick loop climbed it again next pass — the 23:00:38-23:00:58 alternation.
                partSettled[e.path] = true
                partWatch[e.path] = nil
            end
        end
        refresh[ipath] = p.slot0
    end
    for ipath, s0 in pairs(refresh) do
        -- 1.8.28: the instance object is reached from its own slot, in this frame (no StaticFindObject)
        local inst = PS.instOf(s0, ipath)
        local ok, err = pcall(function() inst:RefreshCustomization() end)
        if not ok then log("recruit pin: RefreshCustomization failed on " .. ipath .. ": " .. tostring(err)) end
    end
    PS.watchTick(P)
    if P.again and P.drives < PS.DRIVE_MAX then return PS.again(P) end
    PS.census(P)
    return "pinned"
end

-- 1.8.15: the ladder runs on its own clock (see PS.act). 1.8.28: once per PASS (escalateResidency paces itself per pass
-- anyway), after the frame's writes, and only with lookup budget left - it never takes the lookup a write needs.
function PS.watchTick(P)
    if P.watched then return end
    for path, w in pairs(partWatch) do
        if not partSettled[path] and (partStep[path] or 0) < 5 then
            local o, busy = PS.get(path)
            if busy then return end
            if pinOk(o) then escalateResidency(path, w.want, w.ptype, pinPass) end
        end
    end
    P.watched = true
end

-- 1.8.28: the SAME pass drives again on a later frame (the children after a Class; a write the lookup budget deferred).
-- Only the characters identified as ours this frame are carried (by path); everything else is re-read by that frame.
function PS.again(P)
    local keep = {}
    for ipath, c in pairs(P.inst) do if c.ident or pinKnown[ipath] then keep[ipath] = c end end
    P.inst = keep
    P.phase = "drive"
    P.againN = P.againN + 1
    return "more"
end

-- a pass's timing, printed with its census line (which prints on a change of shape and every 20th pass) and on any pass
-- whose largest slice passed PS.OVER_MS (capped). 1.8.28: and its object lookups (FindAllOf + StaticFindObject), which
-- are what a frame costs in this UE4SS build.
function PS.report(P, r)
    local over = P.max > PS.OVER_MS
    if over then PS.overLogged = PS.overLogged + 1 end
    if P.printed or (over and PS.overLogged <= PS.OVER_CAP) then
        log(string.format("recruit pin: pass %d timing: %d slice(s), %.1f ms total, max slice %.1f ms (%s), %d object " ..
            "lookup(s)%s -> %s", P.pass, P.slices, P.ms, P.max, P.maxAt, P.nLook,
            (P.drives > 1) and (", " .. P.drives .. " drive frame(s)") or "", tostring(r)))
    end
end

-- ONE CALL = ONE FRAME. Returns "more" while the pass is unfinished (the pin task then returns 0: again next frame), or
-- the pass's verdict. 1.8.28: every pass is frame-bounded (there is no "whole" first pass and no proof any more: nothing is
-- re-found by path), and an idle frame after a Class delivery (P.hold) touches nothing at all.
local function applyRecruitPins()
    if #recruitPins == 0 then return "idle" end
    local P = PS.P
    if P == nil then
        pinPass = pinPass + 1
        local hub, wname = strategySide()
        P = { pass = pinPass, nInst = 0, nOurs = 0, nWith = 0, nPinned = 0, pinnedSet = {}, nSkip = 0, skipped = {}, inst = {},
              hub = hub, wname = wname, world = wname, phase = "insts", slices = 0, ms = 0, max = 0, maxAt = "",
              nLook = 0, lookups = 0, drives = 0, looks = 0, lookq = {}, lookSet = {}, lookAt = 0, hold = 0,
              deferred = 0, againN = 0, reverts = 0, classDone = {}, classAt = {}, ghostWait = {}, fcache = {}, absent = {}, lookVerified = {},
              verify = PS.verifyNext }
        PS.verifyNext = false
        PS.P = P
    end
    if P.hold > 0 then P.hold = P.hold - 1; return "more" end
    local t0 = PS.clock()
    P.lookups, P.fcache, P.again = 0, {}, false
    local at = P.phase
    local r
    if at == "insts" then
        r = PS.begin(P)
        if r == nil then r = "more" end           -- the instance FindAllOf: its own frame
    elseif at == "drive" then
        r = PS.drive(P)
    elseif at == "look" then
        r = PS.look(P)
    else
        r = "idle"
    end
    local ms = (PS.clock() - t0) * 1000
    P.slices, P.ms = P.slices + 1, P.ms + ms
    if ms > P.max or P.maxAt == "" then P.max, P.maxAt = ms, at end
    P.fcache = {}                                 -- nothing of this frame's survives it
    if r ~= "more" then
        PS.P = nil
        PS.report(P, r)
        -- 1.8.28 (fix 3): T-G1's number, once per event: the first pass that DROVE a card after it
        local u = P.urgent or CP.epUrgent
        if u and P.nPinned > 0 and not u.logged then
            u.logged = true
            log(("recruit pin: %s -> %d character(s) driven %.1f s after the event (pass %d)"):format(u.why, P.nPinned,
                PS.clock() - u.t, P.pass))
        end
        if P.urgent and r ~= "urgent" then PS.urgent = nil; CP.epUrgent = CP.epUrgent or P.urgent end
        if P.reverts > 0 then pinDone = false; CP.pinDormant = false end   -- the verify pass re-opened the episode
    end
    return r
end

-- ---- 1.8.27: THE CLASS-MOD RUNTIME (ZCClassMods\_Shared\SDK_CHANGE_REQUEST.md §1b, §2d, §3 G1, §5.1 H1, §5.6) ----
-- THE DATA CONTRACT - ALIGNED WITH THE BUILD LANE (zcmod-build.js; docs/NETNEW_CLASS.md "The loader contract"). This block
-- is the ONLY reader of the 1.8.27 manifest keys in <Mod>.zcsdk.lua; if a spelling changes there, it changes HERE only:
--   recruitPins[].slots[] = { tag =, part = }                                 -- the short form, unchanged since 1.4.0
--                         | { tag =, part =, requires = "<id>"?, fallback = "<obj path>"?,
--                             accept = { "<obj path>", … }?, acceptTags = { "<tag>", … }?, acceptOn = "roster" | "any"?,
--                             escape = "<obj path>"? }
--     part / fallback / accept[] / escape are OBJECT paths, compared by their leaf (the short id) as `part` always was.
--     `part` is implicitly accepted and never repeated in `accept`; `acceptOn` is written whenever an accept-set exists.
--     `fallback` appears only with `requires`: delivered INSTEAD of `part` when the dependency is missing or too old; with no
--     `fallback` such a slot is dropped. On a missing dependency its `tags` are dropped from `acceptTags` too.
--     `escape` = the D6 fallbackSpec (Tactical.Primary) / §5.6.4 fallbackWeapon (Weapon): ACCEPTED on a roster character
--     only - never on a card, whatever `acceptOn` says - and NEVER delivered.
--   requires = { { id =, minVersion = ?, optional = <bool>, packages = { "<package path>" }, tags = { … },
--                  names = { <sorted leaf names> } } }                        -- names = the dead-id snapshot (name-based)
--   classPool = { schema = "zcsdk-classpool/1", table = "<obj path>", weighted = <bool>, exclusive = <bool>,
--                 settingsIni = <bool>, rows = { { row =, guid = "<32 upper hex>", cd = "<obj path>", recruitable = <bool>,
--                 weight = <0..1> } } }                                       -- recruitable = false always carries weight = 0
--     weighted = false = no weight anywhere: nothing is written - unless the PLAYER's settings.ini sets one (D2: it wins).
--   settings.ini (the player's copy; only settings.default.ini ships): gfp Mods/<Mod>/settings.ini, paks
--   Content/Paks/<Mod>.settings.ini; CRLF; ';' comments; [ClassPool] Weight= and <row>= lines; precedence row > Weight >
--   the manifest.
CP.GEARKIT = "br.Customization.Slot.Character.Specializations.Weapon.GearKit"
CP.PIN_REARM_MAX = 20        -- §3.1.4: re-arms per session, then the loop stops as 1.8.26 did
CP.REARM_GAP = 5             -- §3.1.2: at most one re-arm per 5 s
CP.MAX_ROLLS = 200           -- §1b.3: class-pool rolls per session
CP.RECRUIT_HOOK = true       -- §1b.2 kill switch: false = the census trigger only
CP.HUB_SETTLE_S = 10         -- §1b.2 (c): seconds the hub must have been up before a RegisterHook
CP.NAME_TAG_FALLBACK = true  -- §5.6: when no route can read a GearKit part's tags, match the pack's spec NAME instead
CP.rearms, CP.rolls, CP.pinDormant = 0, 0, false
CP.evt = { refresh = 0, recruit = 0, census = 0, fired = false, why = "" }
CP.pinSeen = { refresh = 0, recruit = 0, census = 0 }
CP.poolSeen, CP.poolSeenR, CP.seenLog = 0, 0, { refresh = 0, recruit = 0, lines = 0 }
CP.deps, CP.tagDep, CP.deadName = {}, {}, {}
CP.pool, CP.byGuid, CP.poolLive = {}, {}, false
CP.tagsOf, CP.tagCalls, CP.tagRoute = {}, 0, nil
CP.reqFinal, CP.reqDeadline = true, nil
CP.logged = {}
local recruitHookArmed = false   -- §1b.2: RegisterHook is NOT retry-safe (1.8.2): set BEFORE the first call, never cleared
-- the pin task's state (1.8.26 kept these beside the task; 1.8.27 moves them here, above every function that reads them)
local pinIdle, pinSkip, pinWorld = 0, 0, ""
local pinStop = false   -- 1.8.27: set only by the re-arm cap (1.8.14-1.8.26: by `done`)
-- 1.8.11: the pass runs under xpcall so a raise lands in the LOADER'S OWN log with a traceback instead of only in
-- UE4SS.log — which is the file nobody reads (v1.28.32). 1.8.26: the handler is hoisted (no closure per pass).
local function pinTraceback(e)
    return tostring(e) .. " | " .. tostring(debug and debug.traceback and debug.traceback("", 2) or "<no traceback>")
end


function CP.once(k, line) if CP.logged[k] then return end; CP.logged[k] = true; log(line) end
function CP.leaf(p) return (type(p) == "string") and p:match("([^/.]+)$") or nil end

-- semver-ish: every run of digits, compared left to right; a missing part is 0. nil minimum = anything passes.
function CP.verGE(a, b)
    if b == nil then return true end
    local function parts(v) local t = {}; for n in tostring(v or ""):gmatch("%d+") do t[#t + 1] = tonumber(n) end; return t end
    local x, y = parts(a), parts(b)
    for i = 1, math.max(#x, #y) do
        local p, q = x[i] or 0, y[i] or 0
        if p ~= q then return p > q end
    end
    return true
end

-- ---- §2d.1: requires[] ----
function CP.readRequires()
    CP.deps, CP.tagDep = {}, {}
    for _, mf in ipairs(manifests) do
        local m = mf.m
        for _, r in ipairs(type(m.requires) == "table" and m.requires or {}) do
            if type(r) == "table" and type(r.id) == "string" and r.id ~= "" then
                local d = CP.deps[r.id]
                if not d then
                    d = { id = r.id, packages = {}, tags = {}, names = {}, ns = {}, needers = {}, needSet = {}, optional = true }
                    CP.deps[r.id] = d
                end
                if type(r.minVersion) == "string" and (d.minVersion == nil or CP.verGE(r.minVersion, d.minVersion)) then
                    d.minVersion = r.minVersion
                end
                if r.optional == false then d.optional = false end
                local who = tostring(m.name)
                if not d.needSet[who] then d.needSet[who] = true; d.needers[#d.needers + 1] = who end
                for _, p in ipairs(type(r.packages) == "table" and r.packages or {}) do
                    if type(p) == "string" then
                        d.packages[#d.packages + 1] = p
                        local ns = p:match("^(/Game/[^/]+/)")
                        if ns then d.ns[ns] = true end
                    end
                end
                for _, t in ipairs(type(r.tags) == "table" and r.tags or {}) do
                    if type(t) == "string" then d.tags[#d.tags + 1] = t; CP.tagDep[t] = r.id end
                end
                for _, n in ipairs(type(r.names) == "table" and r.names or {}) do
                    if type(n) == "string" then d.names[#d.names + 1] = n end
                end
            end
        end
    end
    for id, d in pairs(CP.deps) do
        d.state = "missing"
        for _, mf in ipairs(manifests) do
            if tostring(mf.m.name) == id then
                d.ver = tostring(mf.m.version)
                d.state = CP.verGE(mf.m.version, d.minVersion) and "present" or "old"
            end
        end
        -- no manifest: the LAST RESORT is the path of the first package it ships (a dependency with no manifest).
        -- The TAG route (§2d.1, GetCustomizationPartIds) is NOT used: it takes a Lua-built FGameplayTagContainer as
        -- INPUT, and every Lua-built container this runtime ever passed reached the native EMPTY (1.8.10).
        if d.state == "missing" and #d.packages > 0 then d.state = "probe" end
    end
end

function CP.objPath(pkg)
    if pkg:find(".", 1, true) then return pkg end
    return pkg .. "." .. (pkg:match("([^/]+)$") or pkg)
end

-- stage 1 (after the primary-asset rescan): request the load; stage 2 (after the cache refresh): look, then decide.
function CP.probeRequires(stage)
    if CP.reqFinal then return end
    for _, d in pairs(CP.deps) do
        if d.state == "probe" then
            local op = CP.objPath(d.packages[1])
            if stage == 1 then
                pcall(LoadAsset, op)
            else
                local o = nil
                pcall(function() o = StaticFindObject(op) end)
                if pinOk(o) then d.state, d.via = "present", op else d.state = "missing" end
            end
        end
    end
    if stage ~= 1 then CP.finalizeRequires() end
end

function CP.fallbacksOf(mod, depId)
    local out, seen, uses = {}, {}, 0
    for _, mf in ipairs(manifests) do
        if tostring(mf.m.name) == mod then
            for _, rp in ipairs(type(mf.m.recruitPins) == "table" and mf.m.recruitPins or {}) do
                for _, s in ipairs(type(rp.slots) == "table" and rp.slots or {}) do
                    if type(s) == "table" and s.requires == depId then uses = uses + 1 end
                    local n = (type(s) == "table" and s.requires == depId) and CP.leaf(s.fallback) or nil
                    if n and not seen[n] then seen[n] = true; out[#out + 1] = n end
                end
            end
        end
    end
    return out, uses
end

-- exactly one line per (needing mod, dependency)
function CP.logRequires()
    local ids = {}
    for id in pairs(CP.deps) do ids[#ids + 1] = id end
    table.sort(ids)
    for _, id in ipairs(ids) do
        local d = CP.deps[id]
        local need = d.minVersion and (" >= " .. d.minVersion) or ""
        for _, mod in ipairs(d.needers) do
            if d.state == "present" then
                log("requires: " .. mod .. " needs " .. id .. need .. " — found " ..
                    (d.ver and ("v" .. d.ver) or ("by its package " .. tostring(d.via) .. " (no manifest)")))
            else
                local fbs, uses = CP.fallbacksOf(mod, id)
                local what = (d.state == "old") and ("found v" .. tostring(d.ver) .. ", TOO OLD") or "NOT FOUND"
                log("WARN: " .. mod .. " needs " .. id .. need .. " — " .. what .. "; " .. ((uses == 0)
                    and "no recruit pin of it depends on that mod"
                    or ("its pins into that mod " .. ((#fbs > 0) and ("use the fallback (" .. table.concat(fbs, ", ") .. ")")
                        or "are skipped"))))
            end
        end
    end
end

function CP.finalizeRequires(why)
    if CP.reqFinal then return end
    for _, d in pairs(CP.deps) do if d.state == "probe" then d.state = "missing" end end
    CP.reqFinal, CP.reqDeadline = true, nil
    if why then log("requires: the dependency probe did not finish (" .. why .. ") — an undecided dependency counts as missing") end
    CP.buildPins(true)
    CP.logRequires()
end

-- the dead-id set of ONE missing dependency, as seen from one slot: its name snapshot, its packages' leaves and the
-- pinned part itself. Registered in CP.deadName (id -> { dep, mod, fb = { [tag] = a fallback is delivered there } }).
function CP.markDead(d, depId, part, tag, hasFb, mod)
    local set = {}
    local function put(n)
        if not n then return end
        set[n] = true
        local x = CP.deadName[n]
        if not x then x = { dep = depId, mod = mod, fb = {} }; CP.deadName[n] = x end
        if hasFb then x.fb[tag] = true end
    end
    put(CP.leaf(part))
    if d then
        for _, n in ipairs(d.names) do put(CP.leaf(n)) end
        for _, p in ipairs(d.packages) do put(CP.leaf(p)) end
    end
    return set
end

-- is `p` (an id or a path) a part of a dependency that is not present? (by the dependency's package namespace)
function CP.isDeadPath(p)
    if type(p) ~= "string" then return false end
    local ns = p:match("^(/Game/[^/]+/)")
    if not ns then return false end
    for _, d in pairs(CP.deps) do if d.state ~= "present" and d.ns[ns] then return true end end
    return false
end

-- ONE manifest slot -> the pin's slot entry. Returns (entry, notes) or (nil, notes) when a missing dependency drops it.
function CP.slotOf(s, m)
    if type(s) ~= "table" or type(s.tag) ~= "string" or type(s.part) ~= "string" then return nil, nil end
    local mod = tostring(m.name)
    local e = { tag = s.tag, part = s.part }
    local notes = {}
    local depId = (type(s.requires) == "string" and s.requires ~= "") and s.requires or nil
    local fb = (type(s.fallback) == "string" and s.fallback ~= "") and s.fallback or nil
    if depId then
        local d = CP.deps[depId]
        e.dep = depId
        if not (d and d.state == "present") then
            e.depMissing = true
            e.dead = CP.markDead(d, depId, s.part, s.tag, fb ~= nil, mod)
            local st = d and ((d.state == "old") and "too old" or "missing") or "not declared in requires[]"
            if not fb then
                return nil, { shortTag(s.tag) .. ": dropped — " .. tostring(CP.leaf(s.part)) .. " needs " .. depId ..
                    " (" .. st .. ") and the slot declares no fallback" }
            end
            e.part, e.subst = fb, true
            notes[#notes + 1] = shortTag(s.tag) .. ": " .. tostring(CP.leaf(s.part)) .. " needs " .. depId .. " (" .. st ..
                ") — pinning the fallback " .. tostring(CP.leaf(fb))
        end
    elseif fb then
        notes[#notes + 1] = shortTag(s.tag) .. ": `fallback` without `requires` ignored (the contract pairs them)"
    end
    local nAcc, nTag, nDrop = 0, 0, 0
    if type(s.accept) == "table" then
        e.accept = {}
        for _, a in ipairs(s.accept) do
            local n = CP.leaf(a)
            if n and not (e.dead and e.dead[n]) and not CP.isDeadPath(a) then e.accept[n] = true; nAcc = nAcc + 1
            elseif n then nDrop = nDrop + 1 end
        end
    elseif type(s.accept) == "string" then
        notes[#notes + 1] = shortTag(s.tag) .. ": accept = \"" .. s.accept .. "\" was not expanded by the build — ignored"
    end
    if type(s.acceptTags) == "table" then
        e.acceptTags, e.acceptTagSet = {}, {}
        for _, t in ipairs(s.acceptTags) do
            if type(t) == "string" then
                local owner = CP.tagDep[t]
                local od = owner and CP.deps[owner]
                if owner and not (od and od.state == "present") then
                    nDrop = nDrop + 1                        -- §5.6.4: a missing dependency's classes are not a choice
                else
                    e.acceptTags[#e.acceptTags + 1] = t; e.acceptTagSet[t] = true; nTag = nTag + 1
                end
            end
        end
    end
    e.acceptOn = (s.acceptOn == "roster") and "roster" or "any"
    -- `escape`: the uninstall escape (D6 / §5.6.4), accepted on a ROSTER character only and never delivered
    local esc = CP.leaf(s.escape)
    if esc then e.rosterIds = { [esc] = "escape" } end
    if e.accept or e.acceptTags or e.rosterIds then
        local r = {}
        for n in pairs(e.rosterIds or {}) do r[#r + 1] = n end
        table.sort(r)
        notes[#notes + 1] = string.format("%s: accept-set %d id(s), %d tag(s)%s, on %s%s", shortTag(s.tag), nAcc, nTag,
            (nDrop > 0) and (" (" .. nDrop .. " dropped: their dependency is missing)") or "", e.acceptOn,
            (#r > 0) and ("; roster-only " .. table.concat(r, ", ")) or "")
    end
    return e, notes
end

-- the recruit pins, from every manifest. Re-run (quietly) once the dependency probe has decided.
function CP.buildPins(quiet)
    for i = #recruitPins, 1, -1 do recruitPins[i] = nil end
    pinKnownParts = nil          -- pinManifestParts() re-derives it from what is built here
    CP.deadName = {}
    for _, mf in ipairs(manifests) do
        local m = mf.m
        for _, rp in ipairs(type(m.recruitPins) == "table" and m.recruitPins or {}) do   -- 1.4.0; 1.5.0 adds `match`
            local match = (type(rp.match) == "table" and type(rp.match.slot) == "string" and type(rp.match.part) == "string")
                and { slot = rp.match.slot, part = rp.match.part } or nil
            if (type(rp.definition) == "string" or match) and type(rp.slots) == "table" then
                local slots, ghostTags, notes = {}, {}, {}
                for _, s in ipairs(rp.slots) do
                    local e, ns = CP.slotOf(s, m)
                    if e then slots[#slots + 1] = e elseif ns and type(s) == "table" then ghostTags[s.tag] = true end
                    for _, n in ipairs(ns or {}) do notes[#notes + 1] = n end
                end
                recruitPins[#recruitPins + 1] = { definition = rp.definition, match = match, slots = slots,
                                                  ghostTags = ghostTags, from = tostring(m.name) }
                if not quiet then
                    log("recruit pins: " .. (rp.definition and rp.definition:match("([^/]+)$") or "-") .. (match and (" | " .. match.slot:match("([^.]+)$") .. "=" .. match.part:match("([^/.]+)$")) or "") .. " -> " .. #slots .. " slot(s) (" .. tostring(m.name) .. ")")
                    for _, n in ipairs(notes) do log("recruit pins:   " .. n) end
                end
            end
        end
    end
end

-- a manifest that registers a pool table into DR_InitialCharacterPool but carries no `classPool` ships the pre-1.8.27
-- EXCLUSIVE source (POOL design B1 replaces it): whichever such mod mounts last hides the other class mods' recruits.
function CP.legacyWarn()
    for _, mf in ipairs(manifests) do
        local m = mf.m
        if m.classPool == nil then
            for _, r in ipairs(type(m.refreshers) == "table" and m.refreshers or {}) do
                if type(r) == "table" and r.name == "DR_InitialCharacterPool" and type(r.assets) == "table" and #r.assets > 0 then
                    log("WARN: " .. tostring(m.name) .. " v" .. tostring(m.version) .. " uses an exclusive recruit-pool " ..
                        "source (pre-classPool build); other class mods' recruits may be missing — rebuild or uninstall it" ..
                        ((m.name == "ZCSDK_Sith") and " (ZCSDK_Sith is retired: uninstall it, ZCSithClass replaces it)" or ""))
                    break
                end
            end
        end
    end
end

-- ---- §1b.4: settings.ini ----
-- -> { [section] = { { k =, v = }, … } } in file order, or nil when there is no file. ';' (and '#') start a comment.
function CP.readIni(path)
    local f = io.open(path, "r")
    if not f then return nil end
    local t, sec = {}, ""
    for raw in f:lines() do
        local line = raw:gsub("^\239\187\191", ""):gsub("[\r\n]+$", ""):gsub("%s*[;#].*$", "")
        line = line:match("^%s*(.-)%s*$") or ""
        if line ~= "" then
            local s = line:match("^%[%s*(.-)%s*%]$")
            if s then
                sec = s; t[sec] = t[sec] or {}
            else
                local k, v = line:match("^([^=]-)%s*=%s*(.*)$")
                if k and k ~= "" then t[sec] = t[sec] or {}; t[sec][#t[sec] + 1] = { k = k, v = v } end
            end
        end
    end
    f:close()
    return t
end

function CP.iniNum(v)
    local n = tonumber(v)
    if n and n >= 0 and n <= 1 then return n end
    return nil
end

function CP.fmtW(w) return (string.format("%.2f", w):gsub("0+$", ""):gsub("%.$", "")) end

-- the PLAYER'S settings.ini wins (D2): a row line, then the ini `Weight`, then the manifest's row weight.
function CP.applyIni(entry, ini, path)
    if not ini then
        log(("class pool: %s no settings.ini (manifest values)"):format(entry.mod))
        return
    end
    local sec = ini.ClassPool or {}
    local rowBy = {}
    for _, row in ipairs(entry.rows) do rowBy[row.row] = row end
    local W = nil
    for _, kv in ipairs(sec) do
        if kv.k:lower() == "weight" then
            local n = CP.iniNum(kv.v)
            if n then W = n else log("settings.ini: " .. kv.k .. "=" .. kv.v .. " ignored (0..1)") end
        elseif not rowBy[kv.k] then
            CP.once("ini|" .. path .. "|" .. kv.k, "settings.ini: unknown key " .. kv.k .. " ignored (" .. entry.mod .. ")")
        end
    end
    if W then for _, row in ipairs(entry.rows) do row.weight = W end end
    for _, kv in ipairs(sec) do
        local row = rowBy[kv.k]
        if row then
            local n = CP.iniNum(kv.v)
            if n then row.weight = n else log("settings.ini: " .. kv.k .. "=" .. kv.v .. " ignored (0..1)") end
        end
    end
    local ws = {}
    for _, row in ipairs(entry.rows) do ws[#ws + 1] = CP.fmtW(row.weight) end
    log(("class pool: %s settings.ini read (%d row(s), weights %s)"):format(entry.mod, #entry.rows, table.concat(ws, "/")))
end

function CP.readClassPool()
    CP.pool, CP.byGuid, CP.poolLive = {}, {}, false
    for _, mf in ipairs(manifests) do
        local m = mf.m
        local cpool = m.classPool
        if type(cpool) == "table" and type(cpool.rows) == "table" then
            local mod = tostring(m.name)
            local entry = { mod = mod, rows = {} }
            for _, r in ipairs(cpool.rows) do
                if type(r) == "table" and type(r.row) == "string" and type(r.guid) == "string" then
                    local g = r.guid:upper():gsub("[^0-9A-F]", "")
                    if #g == 32 then
                        local w = (r.recruitable == false) and 0 or (tonumber(r.weight) or 1)
                        if w < 0 then w = 0 elseif w > 1 then w = 1 end
                        local row = { mod = mod, row = r.row, guid = g, weight = w, cooked = (r.recruitable ~= false) }
                        entry.rows[#entry.rows + 1] = row
                        CP.byGuid[g] = row
                    else
                        log("class pool: " .. mod .. " row " .. r.row .. " has no usable GUID (" .. r.guid .. ") — skipped")
                    end
                end
            end
            local base = (tostring(mf.path or ""):match("([^/\\]+)%.zcsdk%.lua$")) or mod
            local ini = mf.gfp and (mf.dir .. "/settings.ini") or (mf.dir .. "/" .. base .. ".settings.ini")
            local iniT = CP.readIni(ini)
            CP.applyIni(entry, iniT, ini)
            -- LIVE = the loader has something to do for this mod: a row below 1, or a row the build cooked inactive
            -- that the player's ini re-enables (D2). With neither, nothing is ever written - and a manifest that says
            -- `weighted = false` with no player settings.ini is never live (the build's own statement).
            for _, row in ipairs(entry.rows) do
                if row.weight < 1 or (row.weight > 0 and not row.cooked) then entry.live = true end
            end
            if cpool.weighted == false and not iniT then entry.live = false end
            if entry.live then CP.poolLive = true end
            CP.pool[#CP.pool + 1] = entry
        end
    end
end

-- ---- §1b.1: the roll and the write ----
function CP.rollActive(w, rnd)
    if w >= 1 then return true end
    if w <= 0 then return false end
    return (rnd or math.random)() < w
end

-- an FGuid (a TMap key) -> "8X8X8X8X" (FGuid::ToString's Digits form, what the manifest carries)
function CP.guidHex(k)
    local g = k
    pcall(function() g = k:get() end)
    local parts = {}
    local ok = pcall(function()
        for _, f in ipairs({ "A", "B", "C", "D" }) do parts[#parts + 1] = math.tointeger(g[f]) end
    end)
    if not ok or #parts ~= 4 then return nil end
    for i = 1, 4 do
        if parts[i] == nil then return nil end
        parts[i] = parts[i] % 4294967296
    end
    return string.format("%08X%08X%08X%08X", parts[1], parts[2], parts[3], parts[4])
end

function CP.poolMgr()
    if CP.mgrPath then
        local o = nil
        pcall(function() o = StaticFindObject(CP.mgrPath) end)
        if pinOk(o) then return o end
    end
    local o = findLive("BitReactorCharacterPoolManager")
    if pinOk(o) then
        local n = nil
        pcall(function() n = o:GetFullName() end)
        if type(n) == "string" then CP.mgrPath = (n:gsub("^[^ ]+ ", "")) end
        return o
    end
    return nil
end

-- every character of every pool named InitialCharacterPool whose GUID a manifest lists: fn(guidHex, the value struct).
-- Only rows a manifest lists are ever handed out, so nothing else in the pool can be written (§1b.1.5).
function CP.poolEach(mgr, fn)
    return pcall(function()
        mgr.CharacterPools:ForEach(function(_, e)
            local p = e
            pcall(function() p = e:get() end)
            local nm = ""
            pcall(function() nm = p.CharacterPoolName:ToString() end)
            if nm == "InitialCharacterPool" then
                p.Characters:ForEach(function(k, v)
                    local g = CP.guidHex(k)
                    if g and CP.byGuid[g] then
                        local pc = v
                        pcall(function() pc = v:get() end)
                        fn(g, pc)
                    end
                end)
            end
        end)
    end)
end

function CP.poolRead(mgr)
    local cur = {}
    local ok, err = CP.poolEach(mgr, function(g, pc)
        local a = nil
        pcall(function() a = pc.bIsActive end)
        if type(a) == "boolean" then cur[g] = a end
    end)
    if not ok then CP.once("poolreaderr", "class pool: reading the live pool failed: " .. tostring(err)) end
    return cur
end

-- the write, and the proof: a SECOND walk of the map reads each value back. UE4SS's TMap value writes are unverified
-- (§1b), so a write that does not read back switches to the bridge verb `ZCSDK:poolactive` (NOT in bridge 0.5.3 - it
-- logs "unknown command" there - so until a bridge carries it the weight is reported as NOT applied, never assumed).
function CP.poolWrite(mgr, wrote, before)
    local addr = nil
    pcall(function() addr = mgr:GetAddress() end)
    if CP.writeRoute ~= "bridge" then
        CP.poolEach(mgr, function(g, pc) if wrote[g] ~= nil then pcall(function() pc.bIsActive = wrote[g] end) end end)
        local after = CP.poolRead(mgr)
        local bad = {}
        for g, a in pairs(wrote) do
            if after[g] == a then
                log(("class pool: poolactive %s %d->%d (%s; Lua, read back)"):format(g, before[g] and 1 or 0, a and 1 or 0,
                    CP.byGuid[g].row))
            else
                bad[g] = a
            end
        end
        if next(bad) == nil then CP.writeRoute = "lua"; return end
        CP.once("poolluafail", "class pool: the Lua write did not reach the pool (it read back unchanged) — using the " ..
            "bridge verb ZCSDK:poolactive from now on (bridge 0.5.3 does not implement it: until a bridge does, the " ..
            "weight is NOT applied)")
        CP.writeRoute = "bridge"
        wrote = bad
    end
    for g, a in pairs(wrote) do
        if addr then bridge(("ZCSDK:poolactive|%x|InitialCharacterPool|%s|%d"):format(addr, g, a and 1 or 0)) end
    end
    local after = CP.poolRead(mgr)
    for g, a in pairs(wrote) do
        if after[g] == a then
            log(("class pool: poolactive %s %d->%d (%s; bridge, read back)"):format(g, before[g] and 1 or 0, a and 1 or 0,
                CP.byGuid[g].row))
        else
            CP.once("poolna|" .. g, ("class pool: poolactive %s NOT applied (%s; the bridge did not change it)"):format(g,
                CP.byGuid[g].row))
        end
    end
end

-- ONE ROLL: decide every row first (roll-ahead: the roll made after refresh k governs refresh k+1), then read, then write
-- only what differs. A weight-0 row is written false ONCE and never rolled again; a weight-1 row that is already active
-- is never written.
function CP.poolRoll(reason, rnd)
    if not CP.poolLive then return end
    if CP.rolls >= CP.MAX_ROLLS then
        CP.once("rollcap", ("class pool: roll cap (%d) reached — the last state stays for this session"):format(CP.MAX_ROLLS))
        return
    end
    local mgr = CP.poolMgr()
    if not mgr then
        CP.once("nomgr", "class pool: no live BitReactorCharacterPoolManager — roll not applied (" .. tostring(reason) .. ")")
        return
    end
    CP.rolls = CP.rolls + 1
    local want = {}
    for _, e in ipairs(CP.pool) do
        if e.live then
            for _, row in ipairs(e.rows) do
                if not (row.weight <= 0 and row.zeroed) then want[row.guid] = CP.rollActive(row.weight, rnd) end
            end
        end
    end
    local cur = CP.poolRead(mgr)
    local wrote = {}
    for g, a in pairs(want) do
        local row = CP.byGuid[g]
        if cur[g] == nil then
            CP.once("noguid|" .. g, "WARN: class pool: " .. row.mod .. " row " .. row.row .. " (" .. g .. ") is not in " ..
                "the live InitialCharacterPool — skipped")
        else
            if row.weight <= 0 then row.zeroed = true end
            if cur[g] ~= a then wrote[g] = a end
        end
    end
    if next(wrote) then CP.poolWrite(mgr, wrote, cur) end
    for _, e in ipairs(CP.pool) do
        if e.live then
            local elig, ws, same = 0, {}, true
            for i, row in ipairs(e.rows) do
                local a = want[row.guid]
                if a == nil then a = cur[row.guid] end
                if a then elig = elig + 1 end
                ws[#ws + 1] = CP.fmtW(row.weight)
                if i > 1 and row.weight ~= e.rows[1].weight then same = false end
            end
            log(("class pool: %s %d/%d row(s) eligible (w=%s) [roll %d] (%s)"):format(e.mod, elig, #e.rows,
                same and (ws[1] or "?") or table.concat(ws, "/"), CP.rolls, tostring(reason)))
        end
    end
end

-- §1a loader census: a pool table the DataRegistry refused (`dtreg … = 0` in the bridge's own log) means another mod's
-- DR_InitialCharacterPool override is winning. Pool-table leaves only (the classPool naming, and the two legacy names).
function CP.dtregCensus()
    local want = {}
    for _, mf in ipairs(manifests) do
        for _, r in ipairs(type(mf.m.refreshers) == "table" and mf.m.refreshers or {}) do
            if type(r) == "table" and r.name == "DR_InitialCharacterPool" then
                for _, a in ipairs(type(r.assets) == "table" and r.assets or {}) do
                    local lf = CP.leaf(a)
                    if lf and (lf:find("_ZCSDKClassPool", 1, true) or lf:find("ZCSDK_Sith_Pool", 1, true)
                               or lf:find("ZCSDK_InitialCharacterPool", 1, true)) then want[a] = lf end
                end
            end
        end
    end
    if next(want) == nil then return end
    local f = io.open(UE4SS .. "ZCSDKBridge.log", "r")
    if not f then return end
    local size = f:seek("end") or 0
    f:seek("set", math.max(0, size - 262144))
    local text = f:read("a") or ""
    f:close()
    local last = {}
    for a, res in text:gmatch("dtreg (%S+) %-> UDataRegistry::RegisterSpecificAsset on %S+ = (%-?%d+)") do last[a] = tonumber(res) end
    for a, lf in pairs(want) do
        if last[a] == 0 then log("WARN: no source accepts " .. lf .. " (another mod's DR_InitialCharacterPool override is winning?)") end
    end
end

-- the step after the follow-up (the pool has been re-run and deduped): the census, then the session's first roll
function CP.afterFollowups()
    CP.dtregCensus()
    CP.poolRoll("after the follow-up")
end

-- discover's tail: requires[] -> the pins -> the legacy warning -> classPool + settings.ini
function CP.afterDiscover()
    CP.readRequires()
    local pending = false
    for _, d in pairs(CP.deps) do if d.state == "probe" then pending = true end end
    CP.reqFinal = not pending
    CP.reqDeadline = pending and (PS.clock() + 60) or nil   -- the pin waits at most this long for the path probe
    CP.buildPins()
    if not pending then CP.logRequires() end
    CP.legacyWarn()
    CP.readClassPool()
end

-- ---- H1 / §5.6: the accept-set ----
-- the truth table (SDK_CHANGE_REQUEST §5.1 + §5.6.1): `cur` is not `want` - is it a choice the pin leaves alone?
--   a dead id of a missing dependency     never
--   acceptOn "roster" on a fresh card      never (a card always gets `part`)
--   an `accept` id                        yes (on a card too when acceptOn is "any")
--   the slot's `escape` (fallbackSpec/Weapon) on a roster character only (a card that rolled it is still pinned)
--   the equipped weapon's identity tag     yes when it is in `acceptTags`
-- -> "accept" | "escape" | "tag" | nil
function CP.accepted(pin, cur, byDef, tagsOf)
    if type(cur) ~= "string" or cur == "" or cur == "?" or cur == "None" then return nil end
    if pin.dead and pin.dead[cur] then return nil end
    local roster = not byDef
    if pin.acceptOn == "roster" and not roster then return nil end
    if pin.accept and pin.accept[cur] then return "accept" end
    if pin.rosterIds and pin.rosterIds[cur] and roster then return "escape" end
    if pin.acceptTags and #pin.acceptTags > 0 and tagsOf then
        local tags = tagsOf(cur)
        if type(tags) == "table" then
            for _, t in ipairs(tags) do if pin.acceptTagSet[t] then return "tag" end end
        end
    end
    return nil
end

function CP.acceptLog(kind, pin, tag, ipath, cur)
    local owner = shortOwner(ipath)
    local k = "acc|" .. owner .. "|" .. tag .. "|" .. cur
    if kind == "escape" then
        local line
        if tag:find("%.Tactical%.Primary$") then line = owner .. " SPEC 1 holds the fallback spec " .. cur
        elseif tag:find("%.Specializations%.Weapon$") then line = owner .. " Weapon holds the fallback weapon " .. cur
        else line = owner .. " " .. shortTag(tag) .. " holds the fallback " .. cur end
        CP.once(k, "recruit pin: " .. line .. " — left alone (uninstall / troubleshooting)")
    elseif kind == "kept" then
        CP.once(k, "recruit pin: " .. shortTag(tag) .. " on " .. owner .. " holds " .. cur .. " — not re-toggled (an " ..
            "accept-set slot on a roster character: a toggle would reset the model the player picked)")
    else
        CP.once(k, "recruit pin: " .. shortTag(tag) .. " on " .. owner .. " holds accepted " .. cur ..
            ((kind == "tag") and " (by its identity tag)" or "") .. " — left as the player chose")
    end
end

-- a part's tags as strings, from whatever a UE4SS call handed back: an FGameplayTagContainer (userdata or wrapped), or
-- a Lua table holding one (the out-param table). nil = nothing readable; {} = a container that holds no tag.
function CP.tagsFrom(v, depth)
    if v == nil or depth > 2 then return nil end
    local tags = {}
    local okc = pcall(function()
        v.GameplayTags:ForEach(function(_, e)
            local t = e
            pcall(function() t = e:get() end)
            tags[#tags + 1] = t.TagName:ToString()
        end)
    end)
    if okc then return tags end
    if type(v) == "table" then
        for _, x in pairs(v) do
            local y = x
            pcall(function() y = x:get() end)
            local r = CP.tagsFrom(y, depth + 1)
            if r then return r end
        end
    end
    return nil
end

-- route 1: UCustomizationStatics::GetCustomizationPartTagsForPartId(FPrimaryAssetId, out FGameplayTagContainer) on the
-- CDO, handed the GearKit slot's OWN id struct (never a Lua-built one). UNPROVEN: the out-param's shape in UE4SS 3.0.1.
function CP.tagsLua(gs)
    local st = StaticFindObject("/Script/BitReactorCore.Default__CustomizationStatics")
    if not pinOk(st) then return nil end
    local out = {}
    local ok, ret = pcall(function()
        return st:GetCustomizationPartTagsForPartId(gs.CustomizationPartPrimaryAssetId, out)
    end)
    if not ok then
        CP.once("tagslua", "recruit pin: parttags via Lua: GetCustomizationPartTagsForPartId raised (" .. tostring(ret) ..
            ") — the out-param route is unavailable")
        return nil
    end
    return CP.tagsFrom(out, 0)
end

-- route 2: the bridge verb ZCSDK:parttags|<type>|<name>, answered in ue4ss/ZCSDKBridge.parttags as line 1
-- "<type>:<name>" then one tag per line (the contract for the bridge; NOT implemented in bridge 0.5.3).
function CP.tagsBridge(ptype, name)
    local f = UE4SS .. "ZCSDKBridge.parttags"
    pcall(os.remove, f)
    bridge("ZCSDK:parttags|" .. ptype .. "|" .. name)
    local lines = readLines(f)
    if #lines == 0 or lines[1] ~= (ptype .. ":" .. name) then
        CP.once("tagsbridge", "recruit pin: parttags via the bridge: no answer in ZCSDKBridge.parttags (bridge 0.5.3 " ..
            "does not implement ZCSDK:parttags) — the bridge route is unavailable")
        return nil
    end
    local t = {}
    for i = 2, #lines do t[#t + 1] = lines[i] end
    return t
end

-- the GearKit part's identity tags, resolved ONCE per distinct part id per session (strings only: tagsOf[id])
function CP.gearTags(gs)
    local name, ptype = "", ""
    pcall(function()
        local id = gs.CustomizationPartPrimaryAssetId
        name = id.PrimaryAssetName:ToString()
        ptype = id.PrimaryAssetType.Name:ToString()
    end)
    if type(name) ~= "string" or name == "" or name == "None" then return nil end
    local hit = CP.tagsOf[name]
    if hit ~= nil then return hit or nil end
    CP.tagCalls = CP.tagCalls + 1
    local tags, route = nil, nil
    if CP.tagRoute == nil or CP.tagRoute == "lua" then
        tags = CP.tagsLua(gs)
        if tags then route = "lua" end
    end
    if tags == nil and (CP.tagRoute == nil or CP.tagRoute == "bridge") then
        tags = CP.tagsBridge(ptype, name)
        if tags then route = "bridge" end
    end
    if CP.tagRoute == nil then CP.tagRoute = route or "none" end   -- the first answer decides the session's route
    CP.tagsOf[name] = tags or false
    log("recruit pin: parttags " .. name .. " -> " .. (tags and (#tags .. " tag(s) via " .. route ..
        ((#tags > 0) and (": " .. table.concat(tags, ", ")) or "")) or "unreadable"))
    return tags
end

-- the last resort, logged once: the pack's naming convention (spec CPD_WeaponSpec_<class> for tag …Melee.<class>).
function CP.nameTags(cur, pin)
    if not CP.NAME_TAG_FALLBACK then return nil end
    CP.once("nametags", "recruit pin: acceptTags: the GearKit part's tags could not be read — matching the weapon SPEC " ..
        "by the pack's naming convention (CPD_WeaponSpec_<class> for tag …Weapon.Melee.<class>) instead")
    local out = {}
    for _, t in ipairs(pin.acceptTags or {}) do
        local lf = t:match("([^.]+)$")
        if lf and cur == "CPD_WeaponSpec_" .. lf then out[#out + 1] = t end
    end
    return out
end

-- one character's weapon-class tags, for `acceptTags`: its GearKit part (collected THIS frame) or the name convention
function CP.weaponTags(c, cur, pin)
    local tags = nil
    if c.gear then
        local gs = c.gear.obj
        if pinOk(gs) then tags = CP.gearTags(gs) end
    end
    if tags == nil then tags = CP.nameTags(cur, pin) end
    return tags
end

-- ---- §1b.2: the Recruitment watcher (shared by the class-pool roll and G1) ----
-- the hook callback's ENTIRE body: count the event and note its time. No UObject, no log, no I/O - the pump reads the
-- counters later (roll-ahead, and the pin's re-arm).
function CP.onEvent(kind)
    local rn = CP.raceNote
    if rn then rn("hook") end
    local e = CP.evt
    if kind == "RecruitCharacter" then e.recruit = e.recruit + 1 else e.refresh = e.refresh + 1 end
    e.fired, e.t = true, PS.clock()
    -- 1.8.28 (fix 3): and make the pin task due on the next frame (one table write: its next-run time)
    local w = CP.wake
    if w then w() end
end

-- the 1.8.23 discipline: ONCE per process, flag set BEFORE the first call, a failure logged and never retried
function CP.armHooks(why)
    if recruitHookArmed then return end
    recruitHookArmed = true
    log("recruit watch: arming (" .. why .. ")")
    for _, fn in ipairs({ "RefreshCharacterVMs", "RecruitCharacter" }) do
        local kind = fn
        local ok, err = pcall(RegisterHook, "/Script/Bruno.BrunoCharacterRecruitmentViewModel:" .. fn, function() CP.onEvent(kind) end)
        if ok then log("recruit watch: hook armed on " .. fn)
        else
            log("recruit watch: RegisterHook FAILED on " .. fn .. " (not retrying, by design): " .. tostring(err))
            -- 1.8.28 (fix 5): the ONE case the census trigger stands in for a refresh
            if fn == "RefreshCharacterVMs" then
                CP.hookFailed = true
                log("recruit watch: RefreshCharacterVMs could not be hooked — using the census trigger")
            end
        end
    end
end

-- 1.8.28 (fix 5): is the census trigger in use? ONLY when RefreshCharacterVMs could not be hooked (RegisterHook failed)
-- or the kill switch is off - never because no refresh has happened yet (1.8.27 declared the hook "silent" 27 s after
-- arming, and every ordinary hub census drop after that was rolled as a refresh: rolls 3-5 of retail 2026-09-30). Off
-- for good once the hook has fired.
function CP.censusOn()
    if CP.evt.fired then return false end
    return (not CP.RECRUIT_HOOK) or (CP.hookFailed == true)
end

-- (a) something to watch, (b) the hub, (c) the census settled AND the hub up HUB_SETTLE_S; the kill switch first
function CP.armReady(hub, now)
    if not CP.RECRUIT_HOOK then return false, "RECRUIT_HOOK is off (the census trigger only)" end
    if not (CP.poolLive or #recruitPins > 0) then return false, "nothing to watch" end
    if not hub then return false, "not the hub" end
    if not CP.stable then return false, "the census is still climbing" end
    if not CP.hubSince or (now - CP.hubSince) < CP.HUB_SETTLE_S then
        return false, "the hub is younger than " .. CP.HUB_SETTLE_S .. " s"
    end
    return true
end

-- the census, from a pin pass (free) or the watcher's own poll: n = non-proxy instances, sum = their actor numbers
-- (a refresh that swaps cards keeps n and changes sum). nil n = the pin saw the census climbing. A change AFTER it has
-- settled, in the same world, is a Recruitment refresh - 1.8.28: only while the census trigger is in use (CP.censusOn:
-- the hook could not be registered, or the kill switch). It always feeds CP.stable (the arming rule and the hub roll).
function CP.noteCensus(w, n, sum)
    if n == nil then CP.stable = false; return end
    local sig = n .. "/" .. tostring(sum)
    if CP.cWorld ~= w then CP.cWorld, CP.cSig, CP.cN, CP.stable = w, sig, n, false; return end
    if sig == CP.cSig then CP.stable = true; return end
    if CP.stable and CP.censusOn() then
        local e = CP.evt
        e.census = e.census + 1
        e.why, e.t = tostring(CP.cN) .. "->" .. n, PS.clock()
    end
    CP.stable = (n <= (CP.cN or 0))
    CP.cSig, CP.cN = sig, n
end

function CP.censusPoll(w)
    local ok, insts = pcall(FindAllOf, "CustomizationInstance")
    if not ok or type(insts) ~= "table" then return end
    local n, sum = 0, 0
    for _, inst in ipairs(insts) do
        if pinOk(inst) then
            local nm = nil
            pcall(function() nm = inst:GetFullName() end)
            if type(nm) == "string" and not nm:find("Default__") then
                nm = (nm:gsub("^[^ ]+ ", ""))
                if not isProxyOwner(nm) then
                    n = n + 1
                    sum = sum + (tonumber(shortOwner(nm):match("_(%d+)$") or "0") or 0)
                end
            end
        end
    end
    CP.noteCensus(w, n, sum)
end

-- the watcher task (a pump task, 2.5 s): log the hook's firings, roll the pool per event, roll once per hub entry,
-- arm the hooks when the rule allows, and poll the census while nothing else feeds it and the hook has not fired.
function CP.watchTick()
    if not injected then return false end
    if not (CP.poolLive or #recruitPins > 0) then return true end     -- nothing to watch: stop for good
    local w = pinWorldName()
    local hub = (w:find("HUB_Root", 1, true) ~= nil)
    local now = PS.clock()
    if w ~= CP.wWorld then CP.wWorld, CP.hubSince, CP.hubRolled = w, hub and now or nil, false end
    local e, L = CP.evt, CP.seenLog
    for _, kv in ipairs({ { "refresh", "RefreshCharacterVMs" }, { "recruit", "RecruitCharacter" } }) do
        while L[kv[1]] < e[kv[1]] do
            L[kv[1]] = L[kv[1]] + 1
            L.lines = L.lines + 1
            if L.lines <= 200 then log("recruit watch: PATH> " .. kv[2] .. " (#" .. L[kv[1]] .. ")") end
        end
    end
    local tot = e.refresh + e.census
    if tot > CP.poolSeen then
        local why = (e.refresh > CP.poolSeenR) and "RefreshCharacterVMs" or ("census " .. e.why)
        CP.poolSeen, CP.poolSeenR = tot, e.refresh
        CP.poolRoll(why)
    end
    if hub and CP.stable and not CP.hubRolled then CP.hubRolled = true; CP.poolRoll("hub entry") end
    if not recruitHookArmed then
        local ok = CP.armReady(hub, now)
        if ok then
            CP.armHooks(("hub up %.0f s, census settled at %d instance(s)"):format(now - CP.hubSince, CP.cN or 0))
        end
    end
    CP.wTick = (CP.wTick or 0) + 1
    -- the watcher's own census poll (a FindAllOf) runs only while no pin pass feeds the census, and 1.8.28: only while
    -- something still needs it - the hooks are not armed yet (the arming rule and the hub roll read CP.stable), or the
    -- census trigger is in use. With the hooks armed, a dormant hub costs no FindAllOf at all.
    if hub and (CP.pinDormant or pinStop or #recruitPins == 0) and CP.wTick % 2 == 0
       and ((not recruitHookArmed and CP.RECRUIT_HOOK) or CP.censusOn() or not CP.hubRolled) then
        CP.censusPoll(w)
    end
    return false
end

-- ---- §3 G1: the pin task, dormant after `done` ----
function CP.foldEvents()
    local e = CP.evt
    CP.pinSeen = { refresh = e.refresh, recruit = e.recruit, census = e.census }
end

-- a world change re-arms only when it lands in the HUB: a mission rebuilds its characters from the save and a pin there
-- only writes ids (1.8.9), so re-arming into one would spend two of the 20 re-arms on every hub <-> mission round trip.
-- The mission world is still RECORDED, so the return to the hub (the same world name as before) reads as a change.
function CP.rearmReason(w)
    if w ~= pinWorld and w ~= "<none>" then
        if w:find("HUB_Root", 1, true) then return "world " .. (w:match("([^%.]+)$") or w) end
        pinWorld = w
    end
    local e, s = CP.evt, CP.pinSeen
    if e.refresh > s.refresh then return "RefreshCharacterVMs" end
    if e.recruit > s.recruit then return "RecruitCharacter" end
    if e.census > s.census then return "census " .. tostring(e.why) end
    return nil
end

-- a new EPISODE. Reset: the episode's verdict state and one-shot lines. Kept (session facts): delivered / known / ghost /
-- gave-up / vanilla - except a CARD's state on a refresh (a refresh re-rolls the cards; `|card:` keys, see PS.act).
function CP.rearm(reason, w)
    CP.rearms = CP.rearms + 1
    CP.lastRearm = PS.clock()
    CP.pinDormant = false
    pinDone = false
    pinWorld, pinIdle, pinSkip, pinWaited = w, 0, 0, 0
    pinSettle.last, pinSettle.waits = 0, 0
    for _, k in ipairs({ "waiting", "waitedout", "stalehold" }) do pinQuiet[k] = nil end
    for k in pairs(pinExpected) do pinExpected[k] = nil end
    if not reason:find("^world ") then
        for _, t in ipairs({ pinDelivered, pinToggled, pinAttempts }) do
            for k in pairs(t) do if k:find("|card:", 1, true) then t[k] = nil end end
        end
    else
        PS.lastWorld = nil   -- 1.8.28: a return to the hub is a NEW world for the sweeps, under the same name
    end
    CP.epUrgent, CP.verifyAt = nil, nil
    CP.foldEvents()
    log(("recruit pin: re-armed (%s) [%d/%d]"):format(reason, CP.rearms, CP.PIN_REARM_MAX))
end

-- 1.8.28 (fix 3): an urgent episode reached `done`: say how long after the EVENT (T-G1's number), and schedule ONE
-- verify pass (the card's async spawn writes its Talent from the voice map at its end; a slot that reverts is re-driven)
function CP.episodeDone(settled)
    local u = CP.epUrgent or (PS.P and PS.P.urgent)
    if not u then return end
    CP.epUrgent = nil
    log(("recruit pin: %s -> done %.1f s after the event (%d slot(s) DELIVERED this session); a verify pass in %d s")
        :format(u.why, PS.clock() - u.t, settled, PS.VERIFY_S))
    CP.verifyAt = PS.clock() + PS.VERIFY_S
end

function CP.runPass()
    local ok, r = xpcall(applyRecruitPins, pinTraceback)
    if not ok then log("recruit pin error: " .. tostring(r)); PS.P = nil; r = "idle" end
    return r
end

-- the tiers, by what the pass actually found:
--   "more"     1.8.27: the pass is unfinished -> again on the NEXT frame (return 0)
--   "urgent"   1.8.28: a Recruitment event, and the cards of ours are not all there yet -> look again in URGENT_STEP_S
--   "pinned"   a slot was just changed -> 5 s, more re-rolls usually follow
--   "targets"  pin-able characters are here and already correct (the squad in a mission) -> 7.5 s
--   "settling" 1.8.26: the census is still climbing, nothing was read -> look again at the next 2.5 s tick
--   "idle"     nothing this pin could ever apply to in this world -> back off to 10 then 20 s
--   "none"     1.8.28: nothing is ours and this world's sweeps are done -> DORMANT
--   "done"     1.8.27: the episode is over -> DORMANT (1.8.14-1.8.26: the loop stopped for the session)
function CP.afterPass(r)
    if r == "more" then return 0 end
    if r == "urgent" then return PS.URGENT_STEP_S end
    if r == "done" then
        if not CP.pinDormant then                       -- (a verify pass that found nothing to do is still dormant)
            CP.pinDormant = true
            log("recruit pin: dormant")
        end
    elseif r == "none" then
        CP.pinDormant = true
        log("recruit pin: dormant — nothing ours in this world after its sweeps; re-arms on a Recruitment refresh / " ..
            "recruit / world change")
    elseif r == "pinned" then
        pinIdle = 0
        pinSkip = CP.epUrgent and 0 or 1                     -- 1.8.14: 5 s, not 3 s; 1.8.28: 2.5 s in an urgent episode
    elseif r == "targets" then pinIdle = 0; pinSkip = 2
    elseif r == "settling" then pinSkip = 0
    else
        pinIdle = pinIdle + 1
        pinSkip = (pinIdle < 4) and 0 or ((pinIdle < 12) and 3 or 7)
    end
    return false
end

-- the pin task's body (a pump task, 2.5 s). DORMANT is O(1): the world name (the cheap read) and three counters -
-- no FindAllOf, no slot walk.
function CP.pinTick()
    if not injected then return false end
    if #recruitPins == 0 then return true end
    if not CP.reqFinal then
        if CP.reqDeadline and PS.clock() > CP.reqDeadline then CP.finalizeRequires("60 s after discover") else return false end
    end
    if pinStop then log("recruit pin: loop stopped"); return true end
    -- 1.8.28 (fix 3): a Recruitment event (the hook, not the census) since the last pass began is URGENT: the next pass
    -- runs now (the hook made this task due on the next frame, CP.wake), bypasses the spawn-wave settle and drives the
    -- cards of ours as soon as they exist - and a dormant loop re-arms for it below.
    local e, s = CP.evt, CP.pinSeen
    if (e.refresh > s.refresh or e.recruit > s.recruit) and not PS.urgent then
        PS.urgent = { t = e.t or PS.clock(), why = (e.refresh > s.refresh) and "RefreshCharacterVMs" or "RecruitCharacter" }
        pinSkip = 0
        log(("recruit pin: %s — an urgent pass: the spawn-wave settle is bypassed, the cards of ours are driven as soon as " ..
            "they exist"):format(PS.urgent.why))
    end
    if PS.P then
        local w = pinWorldName()
        if w == PS.P.world then return CP.afterPass(CP.runPass()) end
        log("recruit pin: pass " .. PS.P.pass .. " abandoned — the world changed mid-pass")
        PS.P = nil
    end
    if CP.pinDormant then
        local w = pinWorldName()
        local reason = CP.rearmReason(w)
        if not reason then
            -- 1.8.28: the ONE verify pass of an urgent episode (CP.episodeDone); dormant it stays unless a slot reverted
            if CP.verifyAt and PS.clock() >= CP.verifyAt then
                CP.verifyAt = nil
                PS.verifyNext = true
                log("recruit pin: verify pass — re-reading the slots this episode DELIVERED, once")
                return CP.afterPass(CP.runPass())
            end
            return false
        end
        -- §3.1.2: at most one re-arm per REARM_GAP; an event inside the gap WAITS for it (it is never lost). 1.8.28: the
        -- 1.8.27 fold ("an event within the gap belongs to the last re-arm") is gone: an episode now ends in seconds, so
        -- a second refresh inside the gap can bring cards the first episode never saw. Events that arrive before the
        -- episode's first pass still share one re-arm (the pass folds them all).
        if CP.lastRearm and (PS.clock() - CP.lastRearm) < CP.REARM_GAP then return false end
        if CP.rearms >= CP.PIN_REARM_MAX then
            log(("recruit pin: re-arm cap (%d) reached — dormant until the next launch"):format(CP.PIN_REARM_MAX))
            pinStop = true
            return true
        end
        CP.rearm(reason, w)
    end
    if pinSkip > 0 then pinSkip = pinSkip - 1; return false end
    -- 1.8.11: the world read goes through the same nil-hardening as the pin itself (GetFullName on an invalid world
    -- returns nil WITHOUT raising)
    local w = pinWorldName()
    if w ~= pinWorld then pinWorld = w; pinIdle = 0 end
    return CP.afterPass(CP.runPass())
end
-- ---- recruit pins (end) ----

-- ---- 1.8.26: THE GAME-THREAD PUMP (begin; tools/replay_pump.py extracts this block verbatim) ----
-- WHY. UE4SS 3.0.1 runs `LoopAsync` and `ExecuteWithDelay` bodies on its ASYNC thread, and calls queued
-- `ExecuteInGameThread` actions on the GAME thread with its action mutex already released (UE4SS+0x2f92a0: _Mtx_lock
-- on 0x1348db0, move the queue vector out, _Mtx_unlock, THEN call each action and luaL_unref it). One mod has ONE
-- lua_State, so every LoopAsync tick that overlapped a game-thread closure was two OS threads inside the same Lua VM.
-- The 2026-09-28 21:51 minidump caught the result: `L->top` lowered underneath a running IsValid. No amount of
-- thinning the async bodies closes that; only running no Lua there does.
-- HOW. `PUMP.fn` is ONE function value, queued ONCE from the end of the main chunk (`startPump`). Each run re-queues
-- that SAME value first (no closure is created per frame; each queue takes one registry ref that the runner unrefs
-- after the call, all on the game thread now). Because the runner has already moved its queue out before calling,
-- the re-queue lands in the fresh vector and runs on the NEXT engine tick — once per frame, never recursively. UE4SS
-- also sets a busy byte (0x1348d71) around each action and defers nested runs, and `PUMP.busy` below refuses a
-- re-entry without queuing a second chain.
-- WHAT RUNS IN IT. Periodic tasks (`addTask`, LoopAsync semantics: return true = stop for good, a number = run again
-- in that many seconds, anything else = run again after the period) and one-shot timers (`after`). Time is
-- os.clock() — on the Windows CRT that is WALL time since process start (not CPU time), 1 ms resolution. After a
-- stall (a loading screen) a task runs ONCE, never a catch-up burst: the next run is always measured from the end of
-- the last one, as LoopAsync did.
-- BUDGET. At most PUMP.TASKS_PER_TICK periodic tasks run per frame, picked round-robin, so the pin, ROWFIX and the
-- grants can never stack into one frame during a Den load. A task that raises is logged (capped) and keeps its
-- schedule; the pump itself cannot be killed by a task, because the re-queue happens before any task runs.
-- STATE. One table, because the main chunk sits at Lua's 200-local limit (every file-scope `local` counts).
local PUMP = {
    VERSION        = "1.8.29",  -- 1.8.28: the loader version the startup line prints (tools/selftest_loader.py checks it
                                -- against the header, the load line and modinfo.json - it cannot go stale again)
    TASKS_PER_TICK = 1,     -- periodic tasks per frame (one-shot timers are not counted; they are tiny)
    SLOW_MS        = 16,    -- a task that takes longer than this in one frame is logged (capped PER TASK), so a hitch
                            -- has a name. 1.8.27: 50 -> 16 (one 60 Hz frame), because the Den-pause check reads these lines
    LOG_CAP        = 20,    -- per-task error lines, and per-task slow-task lines, per session
    HEARTBEAT_S    = 300,   -- "pump: alive" cadence
    RACEPROBE      = false, -- ONE-LAUNCH PROBE (default OFF): count loader Lua that runs off the game thread
    clock = os.clock,
    tasks = {}, timers = {},
    cursor = 0, ticks = 0, runs = 0, errors = 0, slow = 0,
    busy = false, started = false, announced = false, nextBeat = 0,
    race = { entries = 0, off = 0, reentry = 0, threads = {}, where = {}, gt = nil, nextLog = 0 },
}

-- RACEPROBE: called at the top of every piece of loader Lua that UE4SS invokes after start-up (the pump, and each
-- RegisterHook callback). With the switch OFF it is one table read. With it ON it asks UE4SS which thread this is
-- (`IsInGameThread` / `GetCurrentThreadId` / `GetGameThreadId` exist in this UE4SS build; all are pcall'd, so a build
-- without them only loses the evidence, never the loader). The reading the retail check wants is `OFF the game
-- thread=0`, `pump re-entries=0` and ONE thread id in the braces.
local function raceNote(where)
    if not PUMP.RACEPROBE then return end
    local race = PUMP.race
    race.entries = race.entries + 1
    local tid, inGT = nil, nil
    pcall(function() tid = GetCurrentThreadId() end)
    pcall(function() inGT = IsInGameThread() end)
    local key = tostring(tid)
    race.threads[key] = (race.threads[key] or 0) + 1
    if where == "pump" and race.gt == nil then race.gt = key end
    local off = (inGT == false) or (inGT == nil and race.gt ~= nil and key ~= race.gt)
    if off then
        race.off = race.off + 1
        race.where[where] = (race.where[where] or 0) + 1
    end
end
function PUMP.raceReport(now)
    local race = PUMP.race
    if not PUMP.RACEPROBE or now < race.nextLog then return end
    race.nextLog = now + 10
    local th, wh = {}, {}
    for k, n in pairs(race.threads) do th[#th + 1] = k .. "=" .. n end
    for k, n in pairs(race.where) do wh[#wh + 1] = k .. "=" .. n end
    table.sort(th); table.sort(wh)
    local gid = "?"; pcall(function() gid = tostring(GetGameThreadId()) end)
    log(("RACEPROBE: loader Lua entries=%d, OFF the game thread=%d%s, pump re-entries=%d, threads {%s}, game thread=%s")
        :format(race.entries, race.off, (#wh > 0) and (" (" .. table.concat(wh, ", ") .. ")") or "", race.reentry,
                table.concat(th, ", "), gid))
end

-- a periodic task. `firstS` = seconds until its first run (default: one period; math.huge = dormant until `wake`)
local function addTask(name, periodS, fn, firstS)
    local t = { name = name, period = periodS, fn = fn, nextAt = PUMP.clock() + (firstS or periodS),
                runs = 0, errs = 0, done = false, slow = 0, maxMs = 0 }
    PUMP.tasks[#PUMP.tasks + 1] = t
    return t
end
local function wake(t, inS) t.nextAt = PUMP.clock() + (inS or 0) end
-- a one-shot timer, run inside the pump on the game thread (replaces ExecuteWithDelay + ExecuteInGameThread)
local function after(ms, fn, tag)
    PUMP.timers[#PUMP.timers + 1] = { at = PUMP.clock() + ms / 1000, fn = fn, tag = tag or "timer" }
end

function PUMP.runTask(t)
    local clock = PUMP.clock
    local t0 = clock()
    local ok, r = pcall(t.fn)
    local t1 = clock()
    t.runs = t.runs + 1; PUMP.runs = PUMP.runs + 1
    if not ok then
        t.errs = t.errs + 1; PUMP.errors = PUMP.errors + 1
        if t.errs <= PUMP.LOG_CAP then
            log("pump: task " .. t.name .. " raised (it keeps its schedule): " .. tostring(r))
        end
        t.nextAt = t1 + t.period
    elseif r == true then
        t.done = true
    elseif type(r) == "number" then
        t.nextAt = t1 + r
    else
        t.nextAt = t1 + t.period
    end
    local ms = (t1 - t0) * 1000
    if ms > t.maxMs then t.maxMs = ms end
    if ms > PUMP.SLOW_MS then
        PUMP.slow = PUMP.slow + 1
        t.slow = t.slow + 1
        -- 1.8.27: capped PER TASK, so a noisy startup task cannot use up the lines the pin's Den check needs
        if t.slow <= PUMP.LOG_CAP then
            log(("pump: task %s took %.0f ms in one frame"):format(t.name, ms))
        end
    end
end

function PUMP.body()
    PUMP.ticks = PUMP.ticks + 1
    local now = PUMP.clock()
    local tasks, timers = PUMP.tasks, PUMP.timers
    if not PUMP.announced then
        PUMP.announced = true; PUMP.nextBeat = now + PUMP.HEARTBEAT_S
        local names = {}
        for _, t in ipairs(tasks) do
            names[#names + 1] = t.name .. ((t.nextAt == math.huge) and " (on demand)" or ("/" .. t.period .. "s"))
        end
        log("pump: running on the game thread (" .. PUMP.VERSION .. "; no LoopAsync, no ExecuteWithDelay) — " .. #tasks ..
            " task(s): " .. table.concat(names, ", ") .. "; at most " .. PUMP.TASKS_PER_TICK .. " per frame" ..
            (PUMP.RACEPROBE and "; RACEPROBE ON" or ""))
    end
    -- one-shot timers: every due one, in order; a timer may add timers (they wait for their own time)
    local i = 1
    while i <= #timers do
        local tm = timers[i]
        if now >= tm.at then
            table.remove(timers, i)
            local ok, err = pcall(tm.fn)
            if not ok then log("pump: timer " .. tm.tag .. " raised: " .. tostring(err)) end
        else
            i = i + 1
        end
    end
    -- periodic tasks: round-robin from the one after the last that ran, at most TASKS_PER_TICK of them
    local n, ran = #tasks, 0
    for k = 1, n do
        if ran >= PUMP.TASKS_PER_TICK then break end
        local idx = ((PUMP.cursor + k - 1) % n) + 1
        local t = tasks[idx]
        if not t.done and now >= t.nextAt then
            PUMP.cursor = idx
            PUMP.runTask(t)
            ran = ran + 1
        end
    end
    if now >= PUMP.nextBeat then
        PUMP.nextBeat = now + PUMP.HEARTBEAT_S
        local live = 0
        for _, t in ipairs(tasks) do if not t.done then live = live + 1 end end
        -- 1.8.27: and each task's largest single frame so far, so the heartbeat alone answers "is anything still slow?"
        local mx = {}
        for _, t in ipairs(tasks) do if t.maxMs >= 1 then mx[#mx + 1] = ("%s %.0f"):format(t.name, t.maxMs) end end
        log(("pump: alive — %d frame(s), %d task run(s), %d task error(s), %d live task(s); max ms per frame: %s")
            :format(PUMP.ticks, PUMP.runs, PUMP.errors, live, (#mx > 0) and table.concat(mx, ", ") or "none >= 1"))
    end
    PUMP.raceReport(now)
end

-- THE pump: one function value for the whole session (PUMP.fn), so every re-queue hands UE4SS the same function
function PUMP.fn()
    raceNote("pump")
    if PUMP.busy then PUMP.race.reentry = PUMP.race.reentry + 1; return end   -- a nested run is not the chain: queue nothing
    PUMP.busy = true
    -- FIRST: keep the chain alive, whatever the tasks below do
    local okQ, errQ = pcall(ExecuteInGameThread, PUMP.fn)
    local ok, err = pcall(PUMP.body)
    if not ok then log("pump: body raised (the pump keeps running): " .. tostring(err)) end
    if not okQ then
        -- one more try at the end of the frame's work; if that fails too there is no thread left to retry from
        local ok2, err2 = pcall(ExecuteInGameThread, PUMP.fn)
        if not ok2 then
            log("pump: STOPPED — ExecuteInGameThread refused the re-queue twice: " .. tostring(errQ) .. " / " .. tostring(err2))
        end
    end
    PUMP.busy = false
end

-- called ONCE, as the last statement of the main chunk
local function startPump()
    if PUMP.started then return end
    PUMP.started = true
    if PUMP.RACEPROBE then
        local tid = "?"; pcall(function() tid = tostring(GetCurrentThreadId()) end)
        log("RACEPROBE: main chunk on thread " .. tid .. " (UE4SS's mod-start thread; this is before the pump starts)")
    end
    local ok, err = pcall(ExecuteInGameThread, PUMP.fn)
    if not ok then log("pump: could NOT be started — ExecuteInGameThread failed: " .. tostring(err)) end
end
CP.raceNote = raceNote   -- 1.8.27: the Recruitment hooks' callbacks (defined in the pin block, above this) note their thread too
-- ---- 1.8.26: THE GAME-THREAD PUMP (end) ----

-- ---- sequencing ----
-- 1.8.26: the startup steps are one pump task, dormant until the arm task wakes it; each step's `delay` is the wait
-- before the NEXT step, exactly as runSteps' ExecuteWithDelay chain had it.
local steps = {}
local function addStep(d, fn) steps[#steps + 1] = { delay = d, fn = fn } end
local stepTask
stepTask = addTask("steps", 1.0, function()
    local s = steps[stepTask.i]; if not s then return true end
    stepTask.i = stepTask.i + 1
    local ok, err = pcall(s.fn); if not ok then log("STEP ERROR: " .. tostring(err)) end
    if not steps[stepTask.i] then return true end
    return s.delay / 1000
end, math.huge)
stepTask.i = 1
addStep(3000, function() log("=== ZCSDKLoader start ==="); setTrigger() end)
addStep(1000, function() discover() end)
addStep(1000, function() bridge("ZCSDK:byclass|/Script/Bruno|BrunoModificationInventoryItem") end)
addStep(1000, function() injectRegistries() end)
addStep(3000, function() bridge("ZCSDK:byclass|/Script/Bruno|BrunoModificationInventoryItem") end)
addStep(1000, function() preloadPackages() end)
addStep(1000, function() rescanPrimaryTypes(); CP.probeRequires(1) end)   -- 1.8.27: a manifest-less dependency: request its package
addStep(3000, function() refreshCaches(); CP.probeRequires(2) end)         -- 1.8.27: ... and decide (then the requires lines)
addStep(2000, function() applyRefreshers() end)     -- 1.3.0: manifest refreshers (data registries re-scan the injected registry)
addStep(6000, function() applyFollowups() end)      -- ... then what the game built from them once at startup (character pools)
addStep(1000, function() CP.afterFollowups() end)   -- 1.8.27: the pool-table dtreg census, then the first class-pool roll
if DIAG then
    local REAL = "/Game/Game/GameData/ItemData/Modifications/Modification_Scope_LongRange_T1.Modification_Scope_LongRange_T1"
    addStep(1000, function() pcall(LoadAsset, REAL) end)
    addStep(5000, function()
        local o = StaticFindObject(REAL)
        if o and o:IsValid() then dumpObject(o, "REAL scope item") else log("real scope item not loaded (yet)") end
        for _, g in ipairs(grants) do
            pcall(LoadAsset, g.item); local pkg = g.item:match("^(.-)%.[^%.]+$"); if pkg then bridge("ZCSDK:loadpkg|" .. pkg) end
        end
    end)
    addStep(5000, function()
        for _, g in ipairs(grants) do
            local o = StaticFindObject(g.item)
            if o and o:IsValid() then dumpObject(o, "MOD item") else log("mod item not loaded: " .. g.item) end
        end
    end)
end
-- 1.8.19 (session_audit.py's own recommendation, CHANGELOG v1.28.32): only say "waiting" when there is something to
-- wait FOR. With no grants declared this banner was a gate that could never pass, and the audit charged it as one —
-- seven sessions' worth of open gates that were all vacuous.
addStep(1000, function()
    if #grants > 0 then
        log("=== ZCSDKLoader ready; waiting for an HQ inventory to apply " .. #grants .. " grant(s) ===")
    else
        log("=== ZCSDKLoader ready; 0 grant(s) declared, so no HQ inventory is needed ===")
    end
end)

-- the ARM check: every 3 s until a real world with a player controller is up (or 40 checks), then the steps start 8 s
-- later. 1.8.26: it now reads the player controller and the world ON THE GAME THREAD (it used to do both from
-- LoopAsync, i.e. UObject reads off-thread).
local ticks, armed = 0, false
addTask("arm", 3.0, function()
    if armed then return true end
    ticks = ticks + 1
    -- 1.8.27: the world through gameWorld() and the player controller through UGameplayStatics::GetPlayerController on
    -- its CDO (a static UFunction, the same call shape as GrantItem on BrunoGameStatics) - no FindAllOf unless that fails.
    local w = gameWorld()
    local pc = nil
    pcall(function() pc = StaticFindObject("/Script/Engine.Default__GameplayStatics"):GetPlayerController(w, 0) end)
    if not pinOk(pc) then local okP, pc2 = pcall(UEHelpers.GetPlayerController); if okP then pc = pc2 end end
    local wname = ""; pcall(function() wname = w:GetFullName() end)
    if type(wname) ~= "string" then wname = "" end
    if (pinOk(pc) and wname ~= "" and not wname:find("PSOLoader")) or ticks >= 40 then
        armed = true; log("armed: world=" .. wname); wake(stepTask, 8.0); return true
    end
    return false
end)
-- GRANTS: every 4 s once the registries are injected, until a pass reports done. 1.8.26: the pass runs in the pump
-- itself, so the 1.8.25 one-closure-in-flight guard (grantQueued / grantQueuedFor) and its 10-tick watchdog are gone:
-- there is no queue left for a closure to wait in, and no stale `done` to read.
addTask("grants", 4.0, function()
    if not injected then return false end
    local ok, r = pcall(applyGrants)
    if not ok then log("grant loop error: " .. tostring(r)) end
    if ok and r then return true end                             -- a pass reported done: stop for good
    return false
end)
-- 1.4.0: recruit pins, for as long as any manifest carries them. 1.7.0: paced — 3 s while it is doing something, backing off to
-- 24 s while it is not, and back to 3 s the moment the world changes or a pin lands. Everything that touches a UObject runs on the
-- game thread (reading the world off-thread through UE4SS's Lua binding is the kind of call that has faulted inside UE4SS before).
-- 1.8.26: the 2.5 s tick and the pinSkip tiers are unchanged; the tick is now a pump task.
-- 1.8.27: the body is CP.pinTick (in the recruit-pin block, so tools/replay_pin.py replays it): a sliced pass returns 0
-- ("again next frame"), `done` goes DORMANT and re-arms (G1). The Recruitment watcher (§1b.2) is its own task.
-- 1.8.28: the task is kept on CP (no new file-scope local: the main chunk sits at Lua's 200-local limit) so a Recruitment
-- hook can make it due on the NEXT frame (CP.wake: one field write; the hook callback itself still only counts).
CP.pinTask = addTask("pin", 2.5, function() return CP.pinTick() end)
CP.wake = function() CP.pinTask.nextAt = 0 end
addTask("recruit", 2.5, function() return CP.watchTick() end)
-- ---- the VAULT saber fix (loader 1.8.2; the diagnosis is CHANGELOG v1.28.4, the arming is the v1.28.6 lesson) ----
-- THE BUG: after a scripted traversal (a mantle / vault) the blade goes out and never comes back, on every saber on
-- 196985 — the game's own and the SDK's alike, so the hilt was never the variable. ZCUnlocked 1.4.1 reads it as the
-- humanoid ABP failing to re-fire OnLightSaberActivate after the landing. This does it from the other end, needing no
-- delegate access: the saber ACTOR already caches the decision.
--
-- VERIFIED OFFLINE before shipping (the thing v1.28.4 did not do — its own note says it "had no offline verification at
-- all"). From the cooked BP_FX_LightSaber_Base.uasset (tools/recon/pkgdump.py + bpclass.py):
--   * Activate  -> exp[13], a real UFunction on BP_FX_LightSaber_Base_C   (so it is callable)
--   * Deactivate-> exp[27], a real UFunction on BP_FX_LightSaber_Base_C   (so it is hookable)
--   * bIsActive, bSaberAutoActivateForCombat -> BoolProperty variables of the class
--   * "Cached Humanoid ABP" -> ObjectProperty typed exactly ABP_BR_Humanoid_Base_C
-- and from the cooked ABP_BR_Humanoid_Base.uasset: SetHasMantled is a real UFunction and HasMantled is in the class's
-- name table. CAVEAT, stated rather than hidden: bpclass.py MISREADS an AnimBlueprintGeneratedClass (it reports
-- ABP_BR_Humanoid_Base_C as "5 functions, 0 variables" — the same silently-wrong shape v1.28.4 hardened it against for
-- the saber), so HasMantled's type and semantics are CORROBORATED, not proven. Hence every read below is pcall'd and a
-- nil/garbage answer means DO NOTHING.
--
-- THE ARMING, which is the part that crashed last time. v1.8.0 retried RegisterHook every 5 s while the class was not
-- loaded and piled bad entries into UE4SS's Lua function registry until the game aborted at the main menu. Here
-- RegisterHook is called AT MOST ONCE: a flag guards it, and it is only reached after StaticFindObject proves the class
-- object is actually loaded (if the class is loaded, so is its Deactivate UFunction export). The loop only ever LOOKS;
-- it never registers speculatively, and it stops for good on the first success. StaticFindObject + LoopAsync +
-- ExecuteInGameThread are all APIs this loader already uses, so nothing unproven is introduced into a runtime that has
-- faulted twice. (1.8.26: the look is now a pump task on the game thread; LoopAsync is gone from the loader.)
local SABER_CLASS = "/Game/Game/FX/Blueprints/Lightsaber/BP_FX_LightSaber_Base.BP_FX_LightSaber_Base_C"
local SABER_FUNC  = "/Game/Game/FX/Blueprints/Lightsaber/BP_FX_LightSaber_Base.BP_FX_LightSaber_Base_C:Deactivate"
local saberHookArmed = false        -- RegisterHook has been called; never call it again, whatever happens next

-- ---- 1.8.3 DIAGNOSTICS: why did nothing happen? ----
-- 2026-09-11 retail: the hook ARMED and the blade still went out on a vault, with no other line in the log. That is
-- five different bugs wearing the same silence, because every guard below is a bare `return`:
--   (1) Deactivate is never called on a vault at all - the blade goes out by some other path
--   (2) bSaberAutoActivateForCombat is false        (3) the Cached Humanoid ABP is not valid
--   (4) HasMantled is false at that instant         (5) relight ran but the blade was already lit
-- The handoff claimed the log distinguished the outcomes; it distinguished armed / re-lit / neither, which is one
-- level too coarse to act on. These lines name the branch. Capped, because Deactivate fires on every legitimate
-- sheath too and an uncapped log would bury the answer - this is a diagnostic, not telemetry.
local vaultDiagN, VAULT_DIAG_MAX = 0, 60
local function vdiag(msg)
    if vaultDiagN >= VAULT_DIAG_MAX then return end
    vaultDiagN = vaultDiagN + 1
    log("vault saber: " .. msg .. (vaultDiagN == VAULT_DIAG_MAX and "   [further diagnostics suppressed]" or ""))
end

-- ---- 1.8.21: THE RELIGHT SWITCH, and the evidence that closed it ----
-- RETAIL 2026-09-14 04:53, loader 1.8.20 deployed, one second into a mission:
--     04:53:30  vault saber: PATH> DeactivateLightsaber
--     04:53:30  vault saber: DeactivateLightsaber: relighting through ActivateSaberCheck (HasMantled=true)
--     04:53:30  vault saber: relight (350ms) -> ActivateSaberCheck(1) [target from Owning Saber Position]
--     04:53:30  main.lua:2011: [Lua::Registry::get_function_ref] Ref was not function
--                   traceback: [C]: in method 'ActivateSaberCheck'
--     04:53:31  vault saber: PATH> ActivateSaberCheck  ... RELIGHT VERIFIED (900ms) - bIsActive=true |
--                   Activated Lightsaber Blade=set | Sheath=0.000
--   and the operator reports EVERY CHARACTER RUNNING IN PLACE at mission start — the insertion sequence never
--   completed. `ActivateSaberCheck` is a function THIS SAME MOD has RegisterHook'd (the log-only `[state]` probe of
--   1.8.6), so calling it from Lua made UE4SS's hook dispatcher fail to find its own Lua callback ref and throw
--   INSIDE the game's call frame. INFERRED: that exception, mid-`ActivateSaberCheck` during the insertion mantle,
--   broke the mission's start sequence. The inference may be imprecise; the two rules it produced are not:
--     (A) NEVER call a UFunction this runtime has hooked.  (B) NEVER drive the saber during the insertion mantle.
-- Hence OFF by default. The handlers keep every read and every diagnostic — they are how the next vault is judged —
-- and schedule nothing. If this is ever flipped true, `armPathProbe` refuses to register the `[state]` hooks on
-- ActivateSaberCheck/DeactivateSaberCheck, so rule (A) cannot be broken by a switch.
local RELIGHT_ENABLED = false
-- the one line a disabled deactivation prints, so a retail log still says what the loader decided and what to grep
-- for next. `which` names the path that reached it (Deactivate vs DeactivateLightsaber).
local function relightDisabledNotice(which)
    log("vault saber: relight DISABLED (1.8.21) [" .. which .. "] — leaving the blade to the game's own " ..
        "ActivateSaberCheck at the next turn; watch for `ActivateSaberCheck state: ... bIsActive=false` followed " ..
        "by `PATH> ActivateLightsaber`")
end

-- one re-light attempt: only if the blade is still out and the wielder is still mid-traversal
-- 1.8.5: calls ActivateLightsaber, NOT Activate. `Activate` is the generic component method and is not on the blade
-- path at all - the 2026-09-12 probe caught `ActivateLightsaber` lighting the blade at mission start while `Activate`
-- fired separately a third of a second earlier. Four versions of this fix called the wrong one.
-- 1.8.6: THE RELIGHT CALL IS WITHDRAWN. 1.8.5 called ActivateLightsaber() with no arguments and UE4SS threw
-- "UFunction expected 4 parameters, received 0" on every vault. I checked that the function EXISTED in the export
-- table and never checked its SIGNATURE - the same mistake this project keeps writing gotchas about, made one step
-- after the probe was built specifically to stop guessing. A Blueprint UFunction's parameters are serialised inside
-- the function export's own data, not as separate exports, so the signature needs real work to read offline; until
-- it IS read, this calls nothing. A throwing hook on a gameplay function is not something to leave deployed.
-- 1.8.7: RELIGHT BY REPLAYING THE EXTINGUISH ARGUMENTS.
-- The signature was finally READ rather than guessed (v1.28.29, tools/recon/bpclass.py against the cooked package):
--     ActivateLightsaber(Lightsaber Blade : StaticMeshComponent,
--                        BladeLight       : PointLightComponent,
--                        WeaponInteractionCollision : BoxComponent,
--                        Target Saber     : Enum_LightsaberStateTarget)
-- and DeactivateLightsaber takes THE IDENTICAL FOUR. That is what makes this safe: the hook is handed exactly the
-- arguments the relight needs, so nothing has to be reconstructed from the actor's variables or guessed - which is
-- what went wrong in 1.8.0-1.8.5 (four versions called the no-arg `Activate`; 1.8.5 called this one with none and
-- UE4SS threw "expected 4 parameters, received 0").
-- The captured values are resolved with :get() INSIDE the hook, because a RemoteUnrealParam wrapper is only valid for
-- the duration of the callback - the UObjects it yields stay valid afterwards, the wrapper does not.
-- 1.8.9 (the 2026-09-12 crash analysis): the three captured COMPONENTS are held across 350 ms and 900 ms of game
-- time, which is long enough for the wielder to be destroyed, the saber to be unequipped, or a level transition to
-- collect them. `args ~= nil` only says the capture happened; it says nothing about whether the objects it points at
-- are still alive. Passing a stale UObject into a UFunction call is a native fault that pcall cannot catch, so each
-- one is re-validated here and the stale one is NAMED - the same rule as GetClass: IsValid first, then use.
--
-- ================================================================================================================
-- 1.8.20: THE REPLAY IS WITHDRAWN. THE RELIGHT GOES THROUGH THE GAME'S OWN `ActivateSaberCheck`, AND `bIsActive`
--         IS NO LONGER ALLOWED TO REPORT SUCCESS.
--
-- WHAT RETAIL 2026-09-13 22:52 SHOWED (log ZCSDKLoader.log):
--   23:17:41  Hawks vaulted, DeactivateLightsaber fired (HasMantled=true, bSaberAutoActivateForCombat=true), the
--             1.8.19 relight replayed the four captured arguments into ActivateLightsaber and logged
--             `re-lit (350ms) - bIsActive now true`.
--   the operator reports THE BLADE WAS NEVER VISIBLE AGAIN for the rest of the mission, and
--   23:21:16  the game's OWN ActivateSaberCheck logged `HasMantled=false bIsActive=true` and DID NOTHING.
-- So 1.8.19 did not fix the blade; it set the flag that stops the game fixing the blade. v1.28.30's "RETAIL
-- CONFIRMED" confirmed the FLAG, never the blade.
--
-- WHY, PROVEN from the cooked class with tools/recon/kismet.py against
-- build/_retail/SWZeroCompany/Content/Game/FX/Blueprints/LightSaber/BP_FX_LightSaber_Base.uasset (re-run it; every
-- offset below is an offset into ExecuteUbergraph_BP_FX_LightSaber_Base, 1389 opcodes, CLEAN):
--   * `ActivateLightsaber` is ubergraph entry 864 (`+864 EX_Jump -> +520`). At `+521` it sets `Self.bIsActive = true`,
--     stores the three components into `Activated Lightsaber Blade` / `Activated Blade Light` / `Activated Weapon
--     Interaction Collision`, `+621 SetCollisionEnabled(5)`, `+659 Timeline_Blade::PlayFromStart`.
--     `DeactivateLightsaber` is entry 869 (`+869 EX_Jump -> +692`), the mirror with `ReverseFromEnd`.
--   * The 4th parameter `Target Saber` lands in the ubergraph locals `K2Node_CustomEvent_Target_Saber_2` / `_3` and
--     is NEVER READ as an operand anywhere in those 1389 opcodes. It is DEAD on both paths — which is why replaying
--     it changed nothing.
--   * The VISIBLE blade is produced ONLY by `Timeline_Blade__UpdateFunc` (entry 4198):
--     `SetScalarParameterValueOnMaterials("Sheath", ...)` on the blade mesh, and the light values via `+3111`.
--     `bIsActive` is read in exactly THREE places — `+1876` (DeactivateSaberCheck), `+2091` (ActivateSaberCheck) and
--     the `IsActive` getter — and drives NO visual state at all.
--   * `ActivateSaberCheck` is entry 1890. After `Trilla Alt Saber Override` (`+1890`, CDO false) it matches
--     `TargetSaber == 2` (`+1979`) OR `TargetSaber == Self.Owning Saber Position` (`+2010..+2048`), bails at `+2076`,
--     and then **`+2086 EX_JumpIfNot Self.bIsActive -> +1904`**, where `+1904` calls
--     `ActivateLightsaber(Self.Lightsaber_Blade, Self.BladeLight, WeaponInteractionCollision, TargetSaber)` from LIVE
--     component reads. If `bIsActive` is ALREADY true it falls into `+2100 EX_PopExecutionFlow` and does nothing.
--     `DeactivateSaberCheck` (entry 1679) mirrors it at `+1875`. Both are bound to the ABP's
--     OnLightSaberActivate / OnLightSaberDeactivate delegates at entry 964.
-- INFERRED, retail-only and stated as such: the blade stayed dark because `PlayFromStart` 350 ms into the mantle
-- montage did not advance the Sheath curve. What is PROVEN is that setting `bIsActive=true` turned the game's own
-- next-turn recovery at `+2086` into a no-op.
--
-- THE SIGNATURE, READ NOT GUESSED (v1.28.29's lesson, and this is the third function in this file to need it).
-- `python tools/recon/kismet.py <the cooked asset> --function ActivateSaberCheck` prints:
--     ### ActivateSaberCheck  (36 code / 48 archive bytes, 8 opcodes) CLEAN
--     #   params/locals: TargetSaber:ByteProperty
--     +0  EX_LetValueOnPersistentFrame ...:K2Node_CustomEvent_TargetSaber ; +18 call ubergraph, +27 EX_IntConst 1890
-- ONE parameter, `TargetSaber : ByteProperty` (Enum_LightsaberStateTarget). Not four. Not zero.
--
-- THE TARGET VALUE. `GetTargetLightsaber` is `State = Self.Owning Saber Position` and nothing else (6 opcodes), and
-- the base CDO's `Owning Saber Position` is 0; the game itself passes literal 1 at mission start (`+88`) and at
-- `+502`. Enum_LightsaberStateTarget (jmap, UserDefinedEnum): NewEnumerator0=0, NewEnumerator1=1, NewEnumerator2=2
-- ("both/any"), Enum_MAX=3. So the saber's OWN position always satisfies the `+2010` equality; the property is read
-- first, `GetTargetLightsaber()` is the fallback, and 2 ("both") is the last resort because `+1979` accepts it
-- unconditionally.
--
-- AND `bIsActive` IS NO LONGER A SUCCESS REPORT. It is the flag the old fix set while the blade stayed dark, so a
-- line saying "bIsActive now true" is exactly the line that misled v1.28.30. The call logs the flag, and then ONE
-- delayed read ~600 ms later reports the actual VISUAL state: `Activated Lightsaber Blade` non-null (the ubergraph
-- writes it at `+521`, so it is the cheapest proof ActivateLightsaber really ran) and, if it can be read at all, the
-- blade material's `Sheath` scalar — which is the single value `Timeline_Blade__UpdateFunc` drives. A relight that
-- flips the flag and leaves the blade dark reads `RELIGHT UNVERIFIED`, never as a success.
-- ================================================================================================================

-- the saber's own target enum, by the three routes in descending order of directness. Reads only, every step pcall'd.
local function saberTarget(saber)
    local v = nil
    pcall(function() v = saber["Owning Saber Position"] end)
    if type(v) == "number" then return v, "Owning Saber Position" end
    pcall(function() v = saber:GetTargetLightsaber() end)
    if type(v) == "number" then return v, "GetTargetLightsaber()" end
    return 2, "the enum's 'both' member (2) — neither the property nor the getter could be read"
end

-- the VISUAL state, read ~600 ms after the call. A FAILED read is reported as `<unreadable: why>` and concludes
-- NOTHING (1.8.16's lesson); only a successful read of a null/!IsValid `Activated Lightsaber Blade` means the blade
-- is not there.
local function bladeState(saber)
    local activated = "<unreadable>"
    local okA, blade = pcall(function() return saber["Activated Lightsaber Blade"] end)
    if not okA then activated = "<unreadable: " .. tostring(blade) .. ">"
    elseif blade == nil then activated = "null"
    elseif uvalid(blade) then activated = "set"
    else activated = "stale" end
    -- the Sheath scalar is what Timeline_Blade__UpdateFunc actually writes. `Blade materials` is an
    -- ArrayProperty<MaterialInstanceDynamic> on the class (recon/bpclass.py), and K2_GetScalarParameterValue is
    -- UMaterialInstanceDynamic's own BlueprintCallable getter — but neither the array accessor nor that call has
    -- ever been exercised from Lua in this runtime, so a failure here is REPORTED, never concluded from.
    local sheath = "<unreadable: not attempted>"
    pcall(function()
        local mats = saber["Blade materials"]
        if mats == nil then sheath = "<unreadable: 'Blade materials' is null>"; return end
        local mid = nil
        pcall(function() mid = mats[1] end)
        if not uvalid(mid) then
            mid = nil
            pcall(function()
                mats:ForEach(function(_, e)
                    if mid == nil then
                        local g = nil
                        pcall(function() g = e:get() end)
                        if uvalid(g) then mid = g end
                    end
                end)
            end)
        end
        if not uvalid(mid) then sheath = "<unreadable: no live MaterialInstanceDynamic in 'Blade materials'>"; return end
        local okS, v = pcall(function() return mid:K2_GetScalarParameterValue(FName("Sheath")) end)
        sheath = (okS and type(v) == "number") and string.format("%.3f", v)
                 or ("<unreadable: K2_GetScalarParameterValue failed: " .. tostring(v) .. ">")
    end)
    return activated, sheath
end

-- one re-light attempt, through the game's own check. 1.8.20: no captured components, so nothing stale can be
-- passed into a UFunction; the only UObject held across the delay is the saber, and it is re-validated here.
local function relight(saber, tag)
    local ok, err = pcall(function()
        if not uvalid(saber) then vdiag("relight (" .. tag .. "): saber no longer valid"); return end
        local target, how = saberTarget(saber)
        -- Announced BEFORE the call, deliberately: the 1.8.4 path probe hooks ActivateSaberCheck too, so the
        -- `vault probe: PATH> ActivateSaberCheck` line that follows this one is OURS, not the game's. Without this
        -- line the log cannot tell the two apart, and telling them apart is the whole retail check.
        log(("vault saber: relight (%s) -> ActivateSaberCheck(%s) [target from %s]"):format(tag, tostring(target), how))
        -- ActivateSaberCheck is SELF-IDEMPOTENT: +2086 makes it a no-op when bIsActive is already true, so the
        -- 350/900 ms pair costs nothing and the "already lit, leaving alone" early-out of 1.8.7 is not needed.
        -- 1.8.21 RULE (A) — DO NOT CALL A UFUNCTION THIS MOD HAS HOOKED. This line is only ever reached with
        -- RELIGHT_ENABLED true, and in that case `armPathProbe` has REFUSED to register the `[state]` hooks on
        -- ActivateSaberCheck/DeactivateSaberCheck. Retail 04:53:30 is what happens when both exist: UE4SS throws
        -- `[Lua::Registry::get_function_ref] Ref was not function` inside the game's own call frame. Anyone adding
        -- a call here must check PROBE_FUNCS first — a hooked callee is a fault, not a slow path.
        saber:ActivateSaberCheck(target)
        after(600, function()   -- 1.8.26: a pump timer, on the game thread (was ExecuteWithDelay + ExecuteInGameThread)
            local ok2, err2 = pcall(function()
                if not uvalid(saber) then
                    log("vault saber: RELIGHT UNVERIFIED (" .. tag .. ") - the saber went away before the check"); return end
                local activated, sheath = bladeState(saber)
                -- VERIFIED requires the VISUAL state, not the flag: `Activated Lightsaber Blade` is written at
                -- ubergraph +521, so it proves ActivateLightsaber really ran — but 1.8.19 got that far and the
                -- blade still stayed dark, so it is not sufficient on its own. A Sheath scalar that can actually
                -- be READ is the second half. The POLARITY of that number is not yet known (nothing offline says
                -- whether an extended blade is Sheath=0 or Sheath=1), so it is PRINTED and not judged: the first
                -- retail vault establishes it by comparing this line with a mission-start relight.
                local lit = (activated == "set") and (tonumber(sheath) ~= nil)
                log(("vault saber: %s (%s) - bIsActive=%s | Activated Lightsaber Blade=%s | Sheath=%s")
                    :format(lit and "RELIGHT VERIFIED" or "RELIGHT UNVERIFIED", tag,
                            tostring(saber.bIsActive), activated, sheath))
            end)
            if not ok2 then log("vault saber: RELIGHT UNVERIFIED (" .. tag .. ") - the check itself failed: " ..
                                tostring(err2)) end
        end, "relight check " .. tag)
    end)
    if not ok then log("vault saber: relight failed (" .. tag .. "): " .. tostring(err)) end
end

-- ---- 1.8.5: THE FIX, on the PROVEN trigger ----
-- Retail 2026-09-12 named the whole sequence. On the first vault: DeactivateLightsaber + DeactivateSaberCheck. On
-- every later vault: DeactivateSaberCheck alone (already out, nothing to do). At the next turn: ActivateSaberCheck
-- fires and DECLINES, then DeactivateSaberCheck again. ActivateLightsaber never runs after mission start, which is
-- exactly why the blade never returns on its own and why waiting for the game to recover was never going to work.
-- The gameplay side is unaffected throughout - the strike still animates, sounds and kills - so this is the blade's
-- visual/lit state alone.
--
-- THE DISCRIMINATOR, and why it is `bSaberAutoActivateForCombat` rather than `HasMantled`:
-- DeactivateLightsaber must also fire on a LEGITIMATE sheath (combat over, a cinematic), and re-lighting there would
-- be a new bug. `bSaberAutoActivateForCombat` is the game's OWN answer to "should this blade be lit for combat right
-- now", so deferring to it means a legitimate sheath is left alone without us having to model when one happens.
-- `HasMantled` was the plan for four versions and has never once been observed true at the moment of the call - so it
-- is LOGGED here, not trusted. If the log shows it reliably true on a vault, a later version can tighten on it.
local function onDeactivateLightsaber(saber)
    local ok, err = pcall(function()
        if not (saber and saber:IsValid()) then vdiag("DeactivateLightsaber: saber not valid"); return end
        -- The discriminator is the game's OWN answer to "should this blade be lit for combat right now". A legitimate
        -- sheath (combat over, a cinematic) clears it, so deferring to it means we never re-light over the game's
        -- intent. Retail 2026-09-12 measured it TRUE on a vault while bIsActive was false - exactly the stuck state.
        if not saber.bSaberAutoActivateForCombat then
            vdiag("DeactivateLightsaber: SKIP, bSaberAutoActivateForCombat=false (a legitimate sheath)"); return end
        local abp = saber["Cached Humanoid ABP"]
        local mantled = "ABP null"
        if abp and abp:IsValid() then mantled = tostring(abp.HasMantled) end
        -- 1.8.20: no `args captured=` any more — the relight replays nothing, so there is nothing to capture.
        vdiag("DeactivateLightsaber: state at the extinguish (HasMantled=" .. mantled .. ")")
        -- 1.8.21: reads and diagnostics above are UNCHANGED; only the scheduling is gated. Nothing is queued here.
        if not RELIGHT_ENABLED then relightDisabledNotice("DeactivateLightsaber"); return end
        vdiag("DeactivateLightsaber: relighting through ActivateSaberCheck (HasMantled=" .. mantled .. ")")
        after(350, function() relight(saber, "350ms") end, "relight 350ms")   -- 1.8.26: a pump timer (game thread)
        after(900, function() relight(saber, "900ms") end, "relight 900ms")
    end)
    if not ok then log("vault saber: DeactivateLightsaber handler error: " .. tostring(err)) end
end

local function onSaberDeactivate(saber)
    local ok, err = pcall(function()
        if not (saber and saber:IsValid()) then vdiag("Deactivate: saber not valid"); return end
        vdiag("PATH> Deactivate")                               -- (1) if this never appears, the blade goes out elsewhere
                                                                -- (1.8.19: was "Deactivate FIRED"; one firing verb now)
        -- should this saber be lit at all? a legitimate sheath (combat over, a cinematic) says no, and is left alone
        if not saber.bSaberAutoActivateForCombat then
            vdiag("  SKIP: bSaberAutoActivateForCombat=false (a legitimate sheath)"); return end
        local abp = saber["Cached Humanoid ABP"]
        if not (abp and abp:IsValid()) then
            vdiag("  SKIP: 'Cached Humanoid ABP' is null/invalid on this saber"); return end
        if not abp.HasMantled then                              -- not a traversal: a real deactivate, leave it alone
            vdiag("  SKIP: HasMantled=false (the discriminator says this is not a traversal)"); return end
        vdiag("  MATCH: HasMantled=true (the traversal shape)")
        -- 1.8.21: every read and every SKIP line above is unchanged; only the scheduling is gated.
        if not RELIGHT_ENABLED then relightDisabledNotice("Deactivate"); return end
        vdiag("  -> scheduling relight at 350ms and 900ms")
        after(350, function() relight(saber, "350ms") end, "relight 350ms")   -- 1.8.26: a pump timer (game thread)
        after(900, function() relight(saber, "900ms") end, "relight 900ms")
    end)
    if not ok then log("vault saber: hook body error: " .. tostring(err)) end
end

-- ---- 1.8.4: THE PATH PROBE. Which function actually extinguishes the blade? ----
-- 2026-09-12 retail, loader 1.8.3: the hook ARMED on `Deactivate` and `Deactivate FIRED` never appeared, so that
-- function is simply not on the vault path. Decoding the cooked class explains why - it exports FIFTY UFunctions
-- including BOTH a generic pair and a saber-specific pair:
--     Activate / Deactivate                 <- what 1.8.0-1.8.3 hooked, and what relight() called
--     ActivateLightsaber / DeactivateLightsaber
--     ActivateSaberCheck / DeactivateSaberCheck
--     Cinematic_Activate / Cinematic_Deactivate
-- The fix has been aimed at the generic pair for four versions. Rather than guess again, this registers a LOG-ONLY
-- hook on every candidate and prints which fires, in order, on a real vault. No relight is attempted here on purpose:
-- a probe that also acts cannot tell you whether it was right.
-- SAFETY: each RegisterHook is still called AT MOST ONCE, from the same one-shot arming path, and only after
-- StaticFindObject proves the class is loaded. The 1.8.0 abort came from RETRYING failed registrations on a timer,
-- not from registering several real ones - so N one-shot hooks carry the same risk as the one 1.8.2 already shipped.
-- NOTE: "Deactivate" is deliberately absent - SABER_FUNC already hooks it and logs "PATH> Deactivate". Registering
-- the same UFunction twice is an unknown, and this probe must not add a new failure mode to a runtime that has
-- already faulted twice.
local PROBE_FUNCS = {
    "DeactivateLightsaber", "DeactivateSaberCheck", "Cinematic_Deactivate",
    "Activate", "ActivateLightsaber", "ActivateSaberCheck", "Cinematic_Activate",
}
local probeArmed = false            -- same discipline as saberHookArmed: RegisterHook is NOT retry-safe
-- 1.8.21 RULE (A): the relight CALLS ActivateSaberCheck, and a UFunction this mod has HOOKED cannot be called from
-- Lua — retail 04:53:30 threw `[Lua::Registry::get_function_ref] Ref was not function` inside the game's own call
-- frame and the mission's insertion sequence never completed. So with the relight ON, the two `[state]` check hooks
-- are NOT registered. With the default (RELIGHT_ENABLED false) nothing is skipped and all 8 hooks arm as in 1.8.20.
local PROBE_SKIP = "vault probe: NOT hooking %s — the relight calls it and UE4SS cannot dispatch a hook from " ..
                   "inside a Lua-initiated call (1.8.21)"
local function armPathProbe(classPath)
    if probeArmed then return end   -- re-entry is impossible, whatever calls this and however often
    probeArmed = true               -- set BEFORE any RegisterHook: even if one throws, never retry
    for _, fn in ipairs(PROBE_FUNCS) do
        local target = classPath .. ":" .. fn
        local isFixTarget = (fn == "DeactivateLightsaber")     -- 1.8.5: the proven extinguish path
        -- 1.8.6: the SABER-CHECK functions are the ones worth watching now. At the start of the next turn the game
        -- runs ActivateSaberCheck and DECLINES to re-light. The hypothesis is that `HasMantled` is never CLEARED
        -- after a scripted traversal, so the check still believes the wielder is mid-vault - which would also
        -- explain why it was true when DeactivateLightsaber fired. Log the state at every check and find out.
        local isCheck = (fn == "ActivateSaberCheck" or fn == "DeactivateSaberCheck")
        if isCheck and RELIGHT_ENABLED then log(PROBE_SKIP:format(fn)); goto continue end   -- 1.8.21 rule (A), above
        local ok, err = pcall(RegisterHook, target, function(ctx)
            raceNote("hook")                    -- 1.8.26 RACEPROBE (one boolean test while it is OFF)
            vdiag("PATH> " .. fn)
            if isFixTarget or isCheck then
                local ok2, s = pcall(function() return ctx:get() end)
                if ok2 and isFixTarget then
                    -- 1.8.20: the four DeactivateLightsaber parameters are NOT captured any more. The relight calls
                    -- ActivateSaberCheck(TargetSaber), which reads Self.Lightsaber_Blade / Self.BladeLight /
                    -- WeaponInteractionCollision LIVE at ubergraph +1904 — so there is nothing to hold across the
                    -- 350/900 ms wait, and with it goes the whole stale-component failure mode of 1.8.7-1.8.19.
                    onDeactivateLightsaber(s)
                end
                if ok2 and isCheck then
                    local ok3, err3 = pcall(function()
                        if not (s and s:IsValid()) then return end
                        local abp = s["Cached Humanoid ABP"]
                        local m = (abp and abp:IsValid()) and tostring(abp.HasMantled) or "ABP null"
                        vdiag(("   %s state: HasMantled=%s bIsActive=%s autoCombat=%s"):format(
                            fn, m, tostring(s.bIsActive), tostring(s.bSaberAutoActivateForCombat)))
                    end)
                    if not ok3 then vdiag("   " .. fn .. " state read failed: " .. tostring(err3)) end
                end
            end
        end)
        -- 1.8.19 VOCABULARY: one arming verb for the whole runtime — `hook armed on <class>:<fn>` — so session_audit
        -- reads the probe's hooks exactly as it reads the fix's, and the FAILURE line names the function too.
        if ok then log("vault probe: hook armed on " .. target .. (isFixTarget and "  [handler]" or (isCheck and "  [state]" or "")))
        else log("vault probe: could NOT hook " .. target .. " (" .. tostring(err) .. ")") end
        ::continue::
    end
end

-- LOOK for the class; register exactly once when it is really there. Deliberately NOT a per-frame hook:
-- ABP_BR_Humanoid_Base_C:SetHasMantled is the obvious trigger but is driven by the anim graph, and putting Lua on the
-- frame path is exactly what this runtime must not do after the 2026-09-09/10 UE4SS Lua faults. One hook covers every
-- saber: each saber Blueprint is a data-only child of BP_FX_LightSaber_Base_C, so the base's UFunction is shared.
--
-- 1.8.23: RESIDENT IS NOT ENOUGH — WAIT FOR A MISSION, AND LET IT SETTLE. Two EXCEPTION_ACCESS_VIOLATIONs inside
-- UE4SS (2026-09-13 22:51:55 and 2026-09-15 08:58:38.9) landed at exactly this point: the class went resident during
-- the HUB's spawn wave, the loop began RegisterHooking, and the process died with UE4SS-only top frames. So the gate
-- is now three-part — a MISSION world (the TurnProbe's `/Maps/Skirmish/` marker, which `HUB_Root` and `MainMenu`
-- never match), the class resident, and SABER_HOOK_SETTLE seconds since that mission world was FIRST seen. Still
-- exactly one registration per process: `saberHookArmed` is the same one-shot guard and a failed RegisterHook is
-- still never retried.
local SABER_MISSION_MARK  = "/Maps/Skirmish/"   -- the mission test the TurnProbe uses (TurnProbe main.lua MISSION_MARK)
local SABER_HOOK_SETTLE   = 8                   -- seconds a mission world must have been up before any RegisterHook
local saberMissionWorld   = nil                 -- the mission world currently being waited on
local saberMissionSeenAt  = nil                 -- os.time() it was first seen
local saberDeferNoticed   = false               -- the "deferred to a mission world" line is logged once per process
-- 1.8.26: a PUMP task (5 s, unchanged), so the class look-up, the world read and the RegisterHook calls below all run
-- on the GAME thread. Until 1.8.25 this body ran on UE4SS's async thread (StaticFindObject every 5 s, and
-- pinWorldName() for the rest of the hub session once the class was resident) — the busiest async Lua in the loader
-- at exactly the moment of the Den crashes. The 1.8.23 mission gate, the settle and the one-shot guard are unchanged.
addTask("saber", 5.0, function()
    if saberHookArmed then return true end                      -- stop the loop for good
    local cls = StaticFindObject(SABER_CLASS)
    if not pinOk(cls) then return false end                     -- not loaded yet: LOOK again, register nothing
    local wname = pinWorldName()
    if not wname:find(SABER_MISSION_MARK, 1, true) then         -- the hub / the menu: LOOK again, register nothing
        if not saberDeferNoticed then
            saberDeferNoticed = true
            log("vault saber: arming deferred to a mission world (1.8.23) — the hub's spawn wave crashed UE4SS " ..
                "twice during RegisterHook")
        end
        saberMissionWorld, saberMissionSeenAt = nil, nil        -- the clock only ever runs in a mission world
        return false
    end
    if saberMissionWorld ~= wname then                          -- first sight of THIS mission world: start the clock
        saberMissionWorld, saberMissionSeenAt = wname, os.time()
        log(("vault saber: mission world seen at %s; arming in %d s"):format(os.date("%H:%M:%S"), SABER_HOOK_SETTLE))
        return false
    end
    if os.difftime(os.time(), saberMissionSeenAt) < SABER_HOOK_SETTLE then return false end   -- the burst is not over
    saberHookArmed = true                                       -- set BEFORE the call: even if it throws, never retry
    local ok, err = pcall(RegisterHook, SABER_FUNC, function(ctx)
        raceNote("hook")                        -- 1.8.26 RACEPROBE (one boolean test while it is OFF)
        local ok2, s = pcall(function() return ctx:get() end)
        if ok2 then onSaberDeactivate(s) end
    end)
    if ok then log("vault saber: hook armed on " .. SABER_FUNC)
    else log("vault saber: RegisterHook FAILED on " .. SABER_FUNC .. " (not retrying, by design): " .. tostring(err)) end
    armPathProbe(SABER_CLASS)           -- 1.8.4: log-only, tells us which function is really on the vault path
    return true
end)

-- ---- 1.8.29: ROWFIX (begin; tools/replay_pump.py extracts this block verbatim) ----
-- ---- 1.8.24: THE ARMOURY MODEL LIST'S BLANK ROWS (a latent game bug that a long weapon list exposes) ----
-- THE BUG (decoded from the retail paks, BF2BlasterPack notes/U_blank_tiles.md): the weapon MODEL list is
-- WBP_Customization_BoxList.PartList, a virtualised BitReactorListView of WBP_Customization_WeaponBox entries. The entry's
-- Construct and PreConstruct play its BuildOn animation at label "Off", which keys the entry's root panel (Overlay_0) to
-- RenderOpacity 0. Only the entry's own PlayBuildOn(Delay) plays "On" (opacity 1), and only BoxList.BuildOnTiles calls it:
-- once per page build, over PartList.GetDisplayedEntryWidgets() at that moment. A row the list generates LATER (scrolled
-- into view; the list shows about 7 rows) gets a fresh entry, or a pooled one that was itself fresh, and stays at opacity 0:
-- drawn as nothing, but still Visible, so it takes clicks. Hover and selection play "States" (colours), never BuildOn.
-- Stock weapon lists hold at most about 6 player-facing parts, so they never scroll and never hit this. A mod that adds
-- weapons makes the list scroll, and then stock rows and the mod's rows alike can go blank.
-- THE FIX: find every stuck entry (CONTENT - Overlay_0 - opacity < 0.05, the entry NOT Hidden - PlayBuildOn hides it for its delay - and
-- BuildOn not playing) and call the entry's OWN PlayBuildOn(0). If UE4SS cannot make that call, fall back to setting the
-- content's RenderOpacity to 1. A row must be seen stuck on two passes in a row (>= 1 s), and nothing is touched while any
-- entry of the same list is mid-cascade (Hidden), so the game's own build-on is never raced. In a list the game builds
-- correctly (every stock list) no entry is ever stuck, so this never fires there.
-- COST / SAFETY (the 1.7.0 and 1.8.x lessons): no RegisterHook and no NotifyOnNewObject; FindAllOf only, plus two UFunction
-- calls on widgets the SAME pass just found. All UObject access happens on the game thread (a pump task), every call pcall'd.
--
-- 1.8.29: THE ROWFIX STUTTER (support 2026-09-30: loader 1.8.26 + ZC Ultimate Blaster pack 1.0.0 + ZCUnlocked 1.4.72, game
-- 197649; ue4ss_stutter_log.log). After `ROWFIX armed (mode entry)` the hub logged `pump: task rowfix took 60-73 ms in one
-- frame` every 5.08 s for as long as the player stayed there, and never one `ROWFIX healed` line. The cause, in 1.8.24-1.8.28:
-- every pass in the hub began with `StaticFindObject(<the WeaponBox class>)` - in this UE4SS build a walk of the whole object
-- array, 50-90 ms in the hub (see THE FRAME-BOUNDED PASS) - and when the class was not resident (the page closed, or never
-- opened) the pass set rowSkip = 4, so it paid that walk again every fifth second, forever; while rows existed it paid the
-- walk AND a FindAllOf every second. None of it was needed with ZCUnlocked, whose `vm-blank` / `listfix` heal the same rows.
-- 1.8.29, four rules:
--   (a) NO CLASS LOOKUP, NO RE-FIND WITHIN A PASS. The class probe is gone: FindAllOf(<the row class>) answers "is the page
--       open" and "which rows" in ONE walk (no instance = not open; the class need not be looked up to know that). No widget is
--       cached ACROSS passes - UE4SS's IsValid() only tests the wrapped pointer for NULL (FocusProbe v1.28.34 disassembly,
--       UE4SS+0x2ad930), so a cached row the list destroyed and GC'd would read "valid" and PlayBuildOn would run on freed
--       memory (the X1 rule). What IS cached across passes is facts: the stuck keys, the busy lists, the counters.
--   (b) BACK OFF. While no row exists in the hub the probe backs off RF.PROBE_S (5 -> 10 -> 20 -> 30 s, reset on each hub
--       entry). On the page, after RF.CLEAN_PASSES (3) clean passes in a row (nothing stuck, nothing mid-cascade, 0 heals) the
--       1 s pass backs off to RF.ON_PAGE_S (2 -> 4 -> 8 s): each of those checks is the page-close detector and the scroll
--       detector at once, and a stuck or animating row brings the 1 s pass back. A probe that finds no row = the page closed:
--       DISARMED, and the probe schedule starts again. Leaving the hub disarms; the task then reads only the cheap world name.
--   (c) ZCUNLOCKED FIRST. If ZCUnlocked is installed and enabled (ue4ss/Mods/ZCUnlocked/dlls/main.dll, and mods.txt
--       `ZCUnlocked : 1` or its enabled.txt) and its blank-row healers are on (ZCUnlocked.log: `vm-blank: InitializeViewModel
--       detour armed` or its polling backstop, `listfix: armed`; with no log yet, both are on by default), ROWFIX makes NO
--       object lookup at all this session and says why ONCE. Only file reads, once, at the first hub pass. The player's
--       switch, ue4ss/Mods/ZCSDKLoader/settings.ini `[ROWFIX] Enabled = auto | on | off` (no file = auto): `on` runs both,
--       `off` runs neither. Without ZCUnlocked (or with both of its healers off) ROWFIX heals exactly as 1.8.24 did.
--   (d) ONE LOOKUP PER PASS. A pass makes at most ONE object lookup in "entry" mode (the row FindAllOf; "list" mode adds its
--       ListView FindAllOf = 2, PS.LOOKUPS), never a StaticFindObject; RF.maxLook records the worst pass. One log line per
--       arm, per back-off and per disarm (resumes capped at RF.RESUME_LOG_CAP), never one per pass.
local ROWFIX = true                 -- kill switch
-- WHICH repair, set from the round-6 experiment (BF2BlasterPack notes/U_blank_tiles.md section 9):
--   "entry" = Ctrl+F9 filled the blank slots (entries whose CONTENT sits at BuildOn "Off"): re-show stuck entries;
--   "list"  = Ctrl+F8 closed them (the list's layout / scroll state is off): after the MODEL list settles on a new
--             selection or item count, RequestRefresh() it, then BP_ScrollItemIntoView(selected) - what the list's own
--             PartViewModels handler does at build, re-done once the entries have their real size.
local ROWFIX_MODE = "entry"
-- 1.8.29: all ROWFIX state in ONE table (the main chunk sits at Lua's 200-local limit; 1.8.28 spent 13 locals here)
local RF = {
    LOG_CAP        = 500,       -- "ROWFIX healed <name> via PlayBuildOn|opacity" lines per session
    ROW_CLASS      = "WBP_Customization_WeaponBox_C",   -- the Armoury weapon page's row (FindAllOf short name)
    CLEAN_PASSES   = 3,         -- (b) clean passes in a row on the page before the 1 s pass backs off
    ON_PAGE_S      = { 2, 4, 8 },          -- (b) backed-off checks while rows exist (the last value repeats)
    PROBE_S        = { 5, 10, 20, 30 },    -- (b) probes in the hub while no row exists (reset on each hub entry)
    OFF_HUB_S      = 4,         -- away from the hub: the cheap world read only
    RESUME_LOG_CAP = 10,        -- "ROWFIX resumed" lines per session
    INI            = "Mods/ZCSDKLoader/settings.ini",   -- (c) [ROWFIX] Enabled = auto | on (run beside ZCUnlocked) | off
    ZCU_READ_MAX   = 256 * 1024,           -- bytes of ZCUnlocked.log read, once a session (its armed lines sit ~30 KB in)
    -- state
    state = "off",              -- off (not the hub) | wait (hub, no rows) | active (1 s) | backoff | skip (ZCUnlocked)
    world = nil, probeN = 0, clean = 0, backN = 0, zcu = nil, waitLogged = false,
    stuck = {}, busy = {}, healed = 0, visitHeals = 0, visitPasses = 0, resumes = 0,
    passes = 0, look = 0, maxLook = 0, lookups = 0, arms = 0, disarms = 0,
    list = { sig = {}, pending = {} },
}
-- 1.8.26: one GUARDED IsValid (it was `o.IsValid ~= nil and o:IsValid()`, unguarded, on the loader's second-hottest path)
local function rowValid(o)
    if o == nil then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return (ok and v) and true or false
end
-- the CONTENT root. WeaponBox is a CommonButtonBase (via WBP_BrunoListButtonBase), whose WidgetTree.RootWidget is the
-- runtime wrapper "InternalRootButtonBase"; BuildOn fades the designer root Overlay_0 inside it (round 5b measured the
-- wrapper by mistake). Overlay_0 is a BP variable; else the wrapper's GetContent().
local function rowRoot(w)
    local c = nil; pcall(function() c = w.Overlay_0 end)
    if rowValid(c) then return c end
    local r = nil; pcall(function() r = w.WidgetTree.RootWidget end)
    if rowValid(r) then pcall(function() c = r:GetContent() end) end
    return rowValid(c) and c or nil
end
local function rowState(w)          -- -> "stuck" | "building" | "ok" | "?" (+ root)
    local r = rowRoot(w); if not r then return "?", nil end
    local vis = -1; pcall(function() vis = w:GetVisibility() end)
    if vis == 2 then return "building", r end                     -- ESlateVisibility::Hidden = inside PlayBuildOn's delay
    local playing = false; pcall(function() playing = w:IsAnimationPlaying(w.BuildOn) end)
    if playing then return "building", r end
    local op = 1; pcall(function() op = r:GetRenderOpacity() end)
    return (op < 0.05) and "stuck" or "ok", r
end
local function rowOwner(w)          -- the entry's outer is the BoxList's WidgetTree; ITS outer is the BoxList
    local o = nil; pcall(function() o = w:GetOuter():GetOuter() end)
    return rowValid(o) and o or nil
end
-- (d) the ONE counted object lookup of a pass. -> the live rows of THIS pass (never kept past it)
function RF.find(cls)
    RF.look, RF.lookups = RF.look + 1, RF.lookups + 1
    local ok, list = pcall(FindAllOf, cls)
    return (ok and type(list) == "table") and list or {}
end
function RF.scan()
    local rows = {}
    for _, w in ipairs(RF.find(RF.ROW_CLASS)) do
        if rowValid(w) then
            local n = ""; pcall(function() n = w:GetFullName() end)
            if type(n) == "string" and not n:find("Default__", 1, true) then rows[#rows + 1] = w end
        end
    end
    return rows
end
-- one "entry" pass over THIS pass's rows. -> true when there is work (a row stuck or mid-cascade, or a heal this pass)
local function rowPass(rows)
    local work = false
    -- group by owning list; a list with any entry mid-cascade is left alone this pass
    local byOwner, busy = {}, {}
    for _, w in ipairs(rows) do
        local o = rowOwner(w); local okey = "?"
        if o then pcall(function() okey = o:GetFullName() or "?" end) end
        local st, r = rowState(w)
        if st == "building" then busy[okey] = true end
        byOwner[okey] = byOwner[okey] or {}
        table.insert(byOwner[okey], { w = w, st = st, r = r })
    end
    -- a list counts as mid-cascade for at most 5 passes (an entry left Hidden for good must not block the fix forever)
    -- (a list mid-cascade is work - the 1 s pass waits it out - but only for those 5 passes, so a row Hidden for good
    -- cannot hold the pass at 1 s either)
    for okey in pairs(byOwner) do
        RF.busy[okey] = busy[okey] and ((RF.busy[okey] or 0) + 1) or nil
        if busy[okey] and RF.busy[okey] <= 5 then work = true end
    end
    local seen = {}
    for okey, list in pairs(byOwner) do
        if not (busy[okey] and RF.busy[okey] <= 5) then
            for _, e in ipairs(list) do
                if e.st == "stuck" then
                    work = true
                    local key = ""; pcall(function() key = e.w:GetFullName() end)
                    seen[key] = (RF.stuck[key] or 0) + 1
                    if seen[key] >= 2 then
                        seen[key] = nil
                        local how = "PlayBuildOn"
                        if not pcall(function() e.w:PlayBuildOn(0.0) end) then
                            how = pcall(function() e.r:SetRenderOpacity(1.0) end) and "opacity" or "FAILED (PlayBuildOn and opacity both raised)"
                        end
                        RF.healed, RF.visitHeals = RF.healed + 1, RF.visitHeals + 1
                        -- one line per healed row (the retail proof); capped so a pathological session cannot flood the log
                        if RF.healed <= RF.LOG_CAP then
                            local nm = "?"; pcall(function() nm = e.w.ModelText:GetText():ToString() end)
                            log("ROWFIX healed " .. tostring(nm) .. " via " .. how)
                        elseif RF.healed == RF.LOG_CAP + 1 then
                            log("ROWFIX: " .. RF.LOG_CAP .. " rows healed this session; further heals are not logged")
                        end
                    end
                end
            end
        end
    end
    RF.stuck = seen
    return work
end
-- "list" mode: per weapon MODEL list (a BitReactorListView under a ...ModelSlot... path) longer than the ~7 visible rows,
-- watch (item count, selected index); when it changes, wait 2 passes for the list to generate and size its rows, then
-- RequestRefresh() and, on the next pass, BP_ScrollItemIntoView(selected). Stock lists (<= 7 items) are never touched.
-- 1.8.29: the lists are found in the pass that uses them (1.8.24 kept them for 3 ticks - the X1 rule), the second lookup.
local function listPass()
    local work, L = false, RF.list
    for _, v in ipairs(RF.find("BitReactorListView")) do
        local key = ""; pcall(function() key = v:GetFullName() end)
        if rowValid(v) and type(key) == "string" and key:find("%.ModelSlot%.") then
            local n, sel, selIdx = 0, nil, -1
            pcall(function() n = v:GetNumItems() end)
            pcall(function() sel = v:BP_GetSelectedItem() end)
            if rowValid(sel) then pcall(function() selIdx = v:GetIndexForItem(sel) end) end
            if n > 7 then
                local sig = n .. "#" .. selIdx
                if L.sig[key] ~= sig then L.sig[key] = sig; L.pending[key] = 2 end
                local p = L.pending[key]
                if p then
                    work = true
                    if p > 1 then L.pending[key] = p - 1
                    elseif p == 1 then
                        pcall(function() v:RequestRefresh() end); L.pending[key] = 0
                    else
                        if rowValid(sel) then pcall(function() v:BP_ScrollItemIntoView(sel) end) end
                        L.pending[key] = nil; RF.healed, RF.visitHeals = RF.healed + 1, RF.visitHeals + 1
                        if RF.healed <= RF.LOG_CAP then log("ROWFIX re-laid-out a " .. n .. "-item MODEL list (selected index " .. selIdx .. ")") end
                    end
                end
            end
        end
    end
    return work
end
-- (c) is ZCUnlocked installed, enabled and healing these rows itself? File reads only (no UObject), once a session.
-- -> a reason string (skip ROWFIX) | nil (run ROWFIX), plus a note for the log
function RF.read(path, max)
    local f = io.open(path, "rb"); if not f then return nil end
    local s = f:read(max or "a"); f:close()
    return s or ""
end
-- the value of `key` in an ini text (in [section] when given, else in any section); nil when absent. ';' / '#' comments.
function RF.iniGet(text, section, key)
    local sec = ""
    local found = nil
    for raw in ((text or "") .. "\n"):gmatch("([^\r\n]*)\r?\n") do
        local line = raw:gsub("^\239\187\191", ""):gsub("%s*[;#].*$", ""):match("^%s*(.-)%s*$") or ""
        local s = line:match("^%[%s*(.-)%s*%]$")
        if s then sec = s:lower()
        elseif section == nil or sec == section:lower() then
            local k, v = line:match("^([^=]-)%s*=%s*(.*)$")
            if k and k:lower() == key:lower() then found = v end
        end
    end
    return found
end
function RF.zcuCheck()
    local dir = UE4SS .. "Mods/ZCUnlocked/"
    if not RF.read(dir .. "dlls/main.dll", 2) then return nil, "ZCUnlocked is not installed" end
    local how = nil
    local mt = RF.iniGet((RF.read(UE4SS .. "Mods/mods.txt") or ""):gsub("(%w+)%s*:%s*(%d)", "%1=%2"), nil, "ZCUnlocked")
    if mt == "1" then how = "mods.txt" end
    if not how and RF.read(dir .. "enabled.txt", 1) then how = "enabled.txt" end
    if not how then return nil, "ZCUnlocked is installed but not enabled (no `ZCUnlocked : 1` in mods.txt, no enabled.txt)" end
    local lg = RF.read(dir .. "dlls/ZCUnlocked.log", RF.ZCU_READ_MAX) or RF.read(dir .. "ZCUnlocked.log", RF.ZCU_READ_MAX)
    local ini = RF.read(dir .. "dlls/settings.ini") or ""
    local lfIni, vbIni = RF.iniGet(ini, nil, "listfix"), RF.iniGet(ini, nil, "vm_blank_refresh") or RF.iniGet(ini, nil, "vm-blank-refresh")
    local vm, lf = nil, nil
    if lg then                                     -- this launch's own account (ZCUnlocked starts before any Lua mod)
        vm = (lg:find("vm-blank: InitializeViewModel detour armed", 1, true) and "vm-blank armed")
          or (lg:find("vm-blank: InitializeViewModel detour FAILED", 1, true) and "vm-blank polling backstop") or nil
        local lfOff = lfIni == "0" or lg:find("listfix: off by ini", 1, true) or lg:find("listfix: quiet for the session", 1, true)
            or lg:find("listfix: the Blueprint-aware object walk is unavailable", 1, true)
        if not lfOff then lf = lg:find("listfix: armed", 1, true) and "listfix armed" or "listfix on (the default)" end
    else                                           -- no log yet: its ini, both on by default
        if vbIni ~= "0" then vm = "vm-blank (on by default; no ZCUnlocked.log yet)" end
        if lfIni ~= "0" then lf = "listfix (on by default)" end
    end
    local src = "ue4ss/Mods/ZCUnlocked via " .. how
    if not vm and not lf then
        return nil, "ZCUnlocked is installed (" .. src .. ") but its blank-row healers are off (no vm-blank line in its log, listfix off)"
    end
    local heals = (vm and lf) and (vm .. ", " .. lf) or (vm or lf)
    return "ZCUnlocked is installed and enabled (" .. src .. ") and heals the Armoury rows itself (" .. heals ..
        ") - no object lookup from ROWFIX this session ([ROWFIX] Enabled=on in ZCSDKLoader/settings.ini runs both)", nil
end
-- the player's switch: ue4ss/Mods/ZCSDKLoader/settings.ini  [ROWFIX] Enabled = auto (default) | on | off
function RF.mode()
    local v = (RF.iniGet(RF.read(UE4SS .. RF.INI) or "", "ROWFIX", "Enabled") or "auto"):lower()
    if v == "off" or v == "0" or v == "false" then return "off" end
    if v == "on" or v == "1" or v == "true" then return "on" end
    if v ~= "auto" then log("ROWFIX: settings.ini [ROWFIX] Enabled=" .. v .. " is not auto|on|off; auto is used") end
    return "auto"
end
function RF.disarm(why)
    if RF.state == "active" or RF.state == "backoff" then
        RF.disarms = RF.disarms + 1
        log(("ROWFIX disarmed: %s (%d heal(s), %d pass(es) this visit)"):format(why, RF.visitHeals, RF.visitPasses))
    end
    RF.stuck, RF.busy, RF.list = {}, {}, { sig = {}, pending = {} }
    RF.clean, RF.backN = 0, 0
end
-- the pass (a pump task). Returns the seconds until the next pass (LoopAsync-style `number`), or true = stopped for good.
function RF.task()
    if not ROWFIX then return true end
    RF.look = 0
    local hub, wname = strategySide()
    if not hub then                                               -- (b) mode exit: the cheap world read only
        if RF.state ~= "off" then RF.disarm("left the hub"); RF.state = "off"; RF.world = nil end
        return RF.OFF_HUB_S
    end
    if RF.zcu == nil then                                         -- (c) once a session, at the first hub pass
        local mode = RF.mode()
        if mode == "off" then
            RF.zcu, RF.state = "off", "skip"
            log("ROWFIX OFF for the session: ZCSDKLoader/settings.ini [ROWFIX] Enabled=off")
            return true
        end
        local skip, note = RF.zcuCheck()
        RF.zcu = skip or false
        if skip and mode == "auto" then
            RF.state = "skip"
            log("ROWFIX skipped: " .. skip)
            return true
        end
        log("ROWFIX: " .. (skip and ("runs beside ZCUnlocked (settings.ini [ROWFIX] Enabled=on): " .. skip) or (note or "no ZCUnlocked")))
    end
    if RF.world ~= wname then                                     -- (b) (re-)entered the hub: a fresh probe schedule
        RF.disarm("world change"); RF.world, RF.state, RF.probeN = wname, "wait", 0
    end
    RF.passes = RF.passes + 1
    local rows = RF.scan()                                        -- (a)(d) the ONE lookup: page open? which rows?
    local nxt
    if #rows == 0 then
        if RF.state == "active" or RF.state == "backoff" then RF.disarm("the Armoury weapon page closed (no rows)") end
        if not RF.waitLogged then
            RF.waitLogged = true
            log(("ROWFIX waiting: no Armoury weapon row in the hub; one row lookup every %d-%d s until the page opens")
                :format(RF.PROBE_S[1], RF.PROBE_S[#RF.PROBE_S]))
        end
        RF.state = "wait"
        RF.probeN = RF.probeN + 1
        nxt = RF.PROBE_S[math.min(RF.probeN, #RF.PROBE_S)]
    else
        if RF.state == "wait" then
            RF.state, RF.clean, RF.backN, RF.visitHeals, RF.visitPasses = "active", 0, 0, 0, 0
            RF.arms = RF.arms + 1
            log(("ROWFIX armed (mode %s): %d Armoury weapon row(s) on screen; 1 s passes until %d clean pass(es) in a row")
                :format(ROWFIX_MODE, #rows, RF.CLEAN_PASSES))
        end
        RF.visitPasses = RF.visitPasses + 1
        local work = rowPass(rows)
        if ROWFIX_MODE == "list" then work = listPass() or work end
        if work then
            if RF.state == "backoff" then
                RF.resumes = RF.resumes + 1
                if RF.resumes <= RF.RESUME_LOG_CAP then log("ROWFIX resumed 1 s passes: a row is stuck or mid build-on") end
            end
            RF.state, RF.clean, RF.backN = "active", 0, 0
            nxt = 1.0
        else
            RF.clean = RF.clean + 1
            if RF.state == "active" and RF.clean >= RF.CLEAN_PASSES then
                RF.state, RF.backN = "backoff", 0
                log(("ROWFIX backed off: %d clean pass(es) in a row, %d heal(s) this visit; checking every %d-%d s while the page is open")
                    :format(RF.clean, RF.visitHeals, RF.ON_PAGE_S[1], RF.ON_PAGE_S[#RF.ON_PAGE_S]))
            end
            if RF.state == "backoff" then
                RF.backN = RF.backN + 1
                nxt = RF.ON_PAGE_S[math.min(RF.backN, #RF.ON_PAGE_S)]
            else
                nxt = 1.0
            end
        end
    end
    if RF.look > RF.maxLook then RF.maxLook = RF.look end
    return nxt
end
-- 1.8.25 HARDENING kept ONE ROWFIX closure in UE4SS's game-thread queue at a time; 1.8.26 made the tick a PUMP task on the
-- game thread. 1.8.29: the task returns its own next delay (1 s working, RF.ON_PAGE_S backed off, RF.PROBE_S waiting,
-- RF.OFF_HUB_S off the hub); `true` (ZCUnlocked heals, or the kill switch) stops it for the session.
RF.taskRef = addTask("rowfix", 1.0, function()
    local ok, r = pcall(RF.task)
    if not ok then log("ROWFIX error (the loop keeps running): " .. tostring(r)); return 5 end
    return r
end)
-- ---- 1.8.29: ROWFIX (end) ----

log("ZCSDKLoader v1.8.29 loaded (win64=" .. WIN64 .. "); waiting for the main-menu world")
-- 1.8.26: the LAST statement of the main chunk. Everything above only registered tasks; nothing has run yet. From here on
-- every line of this loader runs inside `pump` on the game thread (or in a RegisterHook callback, also the game thread).
startPump()
